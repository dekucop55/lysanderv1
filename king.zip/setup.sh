#!/bin/bash

# Lysander VPS Deployment Script
# Target OS: Ubuntu 24.04 LTS
# Target Path: /root/AGT

echo "--- [START] Deploying Lysander Autonomous Agent ---"

# 1. Update System
echo "Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y
sudo apt-get install -y curl git wget

# 2. Install Node.js (LTS)
echo "Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Install PM2 globally
echo "Installing PM2..."
sudo npm install pm2 -g

# 4. Install Ollama
echo "Installing Ollama local..."
curl -fsSL https://ollama.com/install.sh | sh

# 5. Pull AI Model
echo "Pulling qwen2.5:7b model..."
ollama pull qwen2.5:7b

# 6. Create Project Directory
echo "Setting up project directory at /root/AGT..."
mkdir -p /root/AGT
# Note: The user should upload the code separately or git clone
# For now, we ensure the folder exists.

# 7. Setup Permissions
echo "Configuring permissions..."
chmod -R 755 /root/AGT

echo "--- [Selesai] Persiapan Dasar Berhasil ---"
echo "NEXT STEPS:"
echo "1. Upload your application files to /root/AGT"
echo "2. Create /root/AGT/.env using the configuration provided"
echo "3. Run: cd /root/AGT && npm install"
echo "4. Start bot with PM2: pm2 start dist/index.js --name lysander"
echo "--------------------------------------------------"
