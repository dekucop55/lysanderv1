
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
require('dotenv').config();

const BOT_TOKEN = process.env.BOT_TOKEN;
const ALLOWED_USER_ID = process.env.ALLOWED_USER_ID;
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen2.5:7b';
const BRAIN_PATH = path.join(__dirname, 'openclaw');

if (!BOT_TOKEN || !ALLOWED_USER_ID) {
    console.error("ERROR: BOT_TOKEN or ALLOWED_USER_ID missing in .env");
    process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
console.log("Lysander Engine Started... Status: Online");

async function loadBrain() {
    try {
        const identity = await fs.readFile(path.join(BRAIN_PATH, 'IDENTITY.md'), 'utf8');
        const soul = await fs.readFile(path.join(BRAIN_PATH, 'SOUL.md'), 'utf8');
        const agents = await fs.readFile(path.join(BRAIN_PATH, 'AGENTS.md'), 'utf8');
        return "\n[SYSTEM BRAIN]\n" + identity + "\n\n" + soul + "\n\n" + agents;
    } catch (e) {
        console.error("Brain load error:", e);
        return "You are Lysander, an autonomous AI agent. Be direct and assertive.";
    }
}

async function queryOllama(prompt, systemPrompt) {
    try {
        const fullUrl = OLLAMA_BASE_URL + "/api/generate";
        const response = await axios.post(fullUrl, {
            model: OLLAMA_MODEL,
            prompt: prompt,
            system: systemPrompt,
            stream: false,
            options: { temperature: 0.7 }
        });
        return response.data.response;
    } catch (e) {
        console.error("Ollama Error:", e.message);
        return "ERROR: Local Ollama connection failed. Please check if Ollama is running.";
    }
}

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    if (userId.toString() !== ALLOWED_USER_ID.toString()) {
        return bot.sendMessage(chatId, "Access Denied. You are not the Raja.");
    }
    const userInput = msg.text;
    if (!userInput) return;
    try {
        bot.sendChatAction(chatId, 'typing');
        const systemPrompt = await loadBrain();
        const response = await queryOllama(userInput, systemPrompt);
        await bot.sendMessage(chatId, response);
    } catch (e) {
        bot.sendMessage(chatId, "Critical Error occurred.");
    }
});

bot.on('polling_error', (error) => {
    console.log("Polling Error: " + error.message);
});
