#!/bin/bash

# Lysander Sovereign Agent Auto-Deploy Script
# Host: vans-sg-8gb | OS: Ubuntu 24.04

echo "🚀 Starting Lysander Deployment Sequence..."

# 1. Update System
echo "Updating system packages..."
sudo apt-get update && sudo apt-get upgrade -y

# 2. Install Node.js (LTS)
echo "Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Install PM2 Globally
echo "Installing PM2 for process management..."
sudo npm install -g pm2

# 4. Setup Project Directory
echo "Setting up project folders..."
mkdir -p ~/lysander-bot
cd ~/lysander-bot

# 5. Install Project Dependencies
echo "Installing dependencies from package.json..."
# Menyalin file dari folder transfer jika diperlukan, namun di sini asumsi file sudah di-upload
# npm install

# 6. Environment Check
if [ ! -f .env ]; then
    echo "⚠️  WARNING: .env file not found!"
    echo "Please create a .env file in ~/lysander-bot/ with your BOT_TOKEN and API keys."
    echo "You can use .env.example as a template."
    # cp .env.example .env
fi

# 7. Start the Bot with PM2
echo "Launching Lysander via PM2..."
pm2 start index.js --name "lysander-agent"

# 8. Setup PM2 to start on boot
echo "Configuring PM2 startup..."
pm2 startup | grep "sudo" | bash
pm2 save

echo "----------------------------------------------------------------"
echo "✅ DEPLOYMENT COMPLETE!"
echo "Bot Status: pm2 status"
echo "Real-time Logs: pm2 logs lysander-agent"
echo "----------------------------------------------------------------"
