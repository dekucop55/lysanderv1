const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
require('dotenv').config();

const BOT_TOKEN = process.env.BOT_TOKEN;
const ALLOWED_USER_ID = process.env.ALLOWED_USER_ID;
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434';
const BRAIN_PATH = path.join(__dirname, 'openclaw');
const MEMORY_PATH = path.join(BRAIN_PATH, 'memory');

// --- PROVIDER KEYS ---
const PROVIDERS = {
    GEMMA4: process.env.GEMMA4_API_KEY,
    OPENROUTER: {
        key: process.env.OPENROUTER_API_KEY,
        model: process.env.OPENROUTER_MODEL || 'moonshotai/kimi-k2.6:free',
        url: process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1'
    },
    ANTHROPIC: process.env.ANTHROPIC_API_KEY,
    KIMI: process.env.KIMI_API_KEY,
    DEEPSEEK: process.env.DEEPSEEK_API_KEY,
    GROQ: process.env.GROQ_API_KEY,
    OLLAMA_PRIMARY: process.env.OLLAMA_MODEL_PRIMARY || 'hermes3:8b',
    OLLAMA_BACKUP: process.env.OLLAMA_MODEL_BACKUP || 'qwen2.5:7b'
};

// --- WEB3 CONFIG ---
const WEB3_CONFIG = {
    ETH: process.env.RPC_URL_ETH,
    BSC: process.env.RPC_URL_BSC,
    SOL: process.env.RPC_URL_SOL,
    PK: process.env.PRIVATE_KEY
};

if (!BOT_TOKEN || !ALLOWED_USER_ID) {
    console.error("ERROR: BOT_TOKEN or ALLOWED_USER_ID missing in .env");
    process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
console.log("Lysander Engine Started... Status: Online | Router: Active | Omnichannel Cascade: Active | Memory: Active");

const SKILL_MAP = {
    'm1': { high: ['monetize', 'pricing', 'jual', 'jualan', 'cuan'], med: ['business', 'income', 'funnel', 'sell'], low: ['money', 'revenue'] },
    'm2': { high: ['vps', 'deploy', 'ssh', 'nginx', 'docker', 'systemd'], med: ['server', 'linux', 'bash', 'sysadmin'], low: ['host', 'install'] },
    'm3': { high: ['viral', 'hook', 'caption', 'thread', 'naskah'], med: ['content', 'post', 'copywriting', 'konten'], low: ['write', 'draft'] },
    'm4': { high: ['telegram bot', 'cron', 'webhook', 'n8n', 'automate'], med: ['bot', 'otomatis', 'schedule', 'jadwal'], low: ['run', 'trigger'] },
    'm5': { high: ['spreadsheet', 'excel', 'csv', 'dataset', 'snapshot'], med: ['data', 'analytics', 'report', 'laporan'], low: ['numbers', 'stats'] },
    'm6': { high: ['api', 'rest', 'webhook', 'midtrans', 'integrasi'], med: ['endpoint', 'sdk', 'integration'], low: ['connect', 'call'] },
    'm7': { high: ['llm', 'prompt', 'claude api', 'openrouter', 'kimi'], med: ['ai', 'agent', 'model', 'gpt'], low: ['inference'] },
    'm8': { high: ['pdf', 'docx', 'xlsx', 'pptx', 'generate file'], med: ['export', 'dokumen', 'file'], low: ['format', 'save'] },
    'm9': { high: ['landing page', 'react', 'tailwind', 'frontend'], med: ['website', 'ui', 'html', 'css'], low: ['web', 'design'] },
    'm10': { high: ['wallet', 'airdrop', 'on-chain', 'rpc', 'ethers'], med: ['crypto', 'web3', 'token', 'blockchain', 'eth'], low: ['mint', 'swap'] },
    'm11': { high: ['audit', 'vulnerability', 'exploit', 'scam check'], med: ['security', 'review', 'safe', 'malicious'], low: ['check', 'verify'] },
    'm12': { high: ['batch', 'parallel', 'bulk', 'mass', 'queue', 'worker'], med: ['concurrent', 'throughput', 'snapshot'], low: ['many', 'multi'] },
    'm13': { high: ['mint', 'opensea', 'manifold', 'zora', 'seadrop'], med: ['nft', 'claim', 'drop', 'collection'], low: ['collect', 'art'] },
    'x1': { high: ['improve system', 'self-audit', 'refactor brain'], med: ['audit me', 'review agent', 'upgrade self'], low: ['optimize'] },
    'x2': { high: ['strategy', 'architecture', 'decompose', 'plan'], med: ['complex', 'multi-step', 'design system'], low: ['think'] },
    'x3': { high: ['error', 'bug', 'debug', 'gagal', 'rusak', 'stack'], med: ['failed', 'broken', 'fix', 'crash', 'traceback'], low: ['issue'] },
};

async function loadBrain() {
    try {
        const identity = await fs.readFile(path.join(BRAIN_PATH, 'IDENTITY.md'), 'utf8');
        const soul = await fs.readFile(path.join(BRAIN_PATH, 'SOUL.md'), 'utf8');
        const agents = await fs.readFile(path.join(BRAIN_PATH, 'AGENTS.md'), 'utf8');
        
        let memoryContent = "";
        const today = new Date().toISOString().split('T')[0];
        const todayPath = path.join(MEMORY_PATH, `${today}.md`);
        if (await fs.pathExists(todayPath)) {
            memoryContent = await fs.readFile(todayPath, 'utf8');
        }

        // Web3 Context Injection
        const web3Context = `\\n[WEB3 ENV]\\nRPC_ETH: ${WEB3_CONFIG.ETH} | RPC_BSC: ${WEB3_CONFIG.BSC} | RPC_SOL: ${WEB3_CONFIG.SOL}\\nPK_STATUS: ${WEB3_CONFIG.PK ? 'Loaded' : 'Missing'}`;

        return "\\n[SYSTEM BRAIN]\\n" + identity + "\\n\\n" + soul + "\\n\\n" + agents + "\\n\\n" + web3Context + "\\n\\n[SESSION MEMORY]\\n" + memoryContent;
    } catch (e) {
        console.error("Brain load error:", e);
        return "You are Lysander, an autonomous AI agent.";
    }
}

async function writeMemory(type, context, decision, next) {
    try {
        await fs.ensureDir(MEMORY_PATH);
        const today = new Date().toISOString().split('T')[0];
        const filePath = path.join(MEMORY_PATH, `${today}.md`);
        const time = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta' });
        const entry = `[${time} WIB] [${type}] ${context} | ${decision} | ${next}\\n`;
        await fs.appendFile(filePath, entry);
    } catch (e) { console.error("Memory write error:", e); }
}

async function routeSkills(userInput) {
    const input = userInput.toLowerCase();
    let scores = {};
    for (const [skill, weights] of Object.entries(SKILL_MAP)) {
        let score = 0;
        weights.high.forEach(k => { if (input.includes(k)) score += 3; });
        weights.med.forEach(k => { if (input.includes(k)) score += 2; });
        weights.low.forEach(k => { if (input.includes(k)) score += 1; });
        if (score > 0) scores[skill] = score;
    }
    const sortedSkills = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    if (sortedSkills.length === 0) return { primary: null, supporting: [] };
    const [primary, primaryScore] = sortedSkills[0];
    const supporting = sortedSkills.slice(1).filter(([_, score]) => score > (primaryScore * 0.5)).map(([skill]) => skill);
    return { primary, supporting };
}

async function loadSkillFile(skillId) {
    try {
        const skillPath = path.join(BRAIN_PATH, 'skills', `${skillId}.md`);
        if (await fs.pathExists(skillPath)) return await fs.readFile(skillPath, 'utf8');
    } catch (e) { console.error(`Error loading skill ${skillId}:`, e); }
    return null;
}

// --- CASCADE PROVIDERS ---

async function callGemma4(prompt, systemPrompt) {
    if (!PROVIDERS.GEMMA4) throw new Error("GEMMA4_API_KEY missing");
    const response = await axios.post('https://api.ollama.com/v1/chat/completions', {
        model: 'gemma4',
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }]
    }, { headers: { 'Authorization': `Bearer ${PROVIDERS.GEMMA4}` }, timeout: 15000 });
    return response.data.choices[0].message.content;
}

async function callOpenRouter(prompt, systemPrompt) {
    if (!PROVIDERS.OPENROUTER.key) throw new Error("OpenRouter Key missing");
    const response = await axios.post(`${PROVIDERS.OPENROUTER.url}/chat/completions`, {
        model: PROVIDERS.OPENROUTER.model,
        messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }]
    }, { headers: { 'Authorization': `Bearer ${PROVIDERS.OPENROUTER.key}` }, timeout: 20000 });
    return response.data.choices[0].message.content;
}

async function callOllama(prompt, systemPrompt, model) {
    const response = await axios.post(`${OLLAMA_BASE_URL}/api/generate`, {
        model: model,
        prompt: prompt,
        system: systemPrompt,
        stream: false,
        options: { temperature: 0.7 }
    }, { timeout: 30000 });
    return response.data.response;
}

async function executeOmniCascade(prompt, systemPrompt) {
    const chain = [
        { name: 'Gemma4-Cloud', fn: () => callGemma4(prompt, systemPrompt) },
        { name: 'OpenRouter-Kimi', fn: () => callOpenRouter(prompt, systemPrompt) },
        { name: 'Ollama-Hermes3', fn: () => callOllama(prompt, systemPrompt, PROVIDERS.OLLAMA_PRIMARY) },
        { name: 'Ollama-Qwen2.5', fn: () => callOllama(prompt, systemPrompt, PROVIDERS.OLLAMA_BACKUP) },
    ];

    // Add other advanced keys if provided in .env
    if (PROVIDERS.ANTHROPIC) chain.push({ name: 'Anthropic-Claude', fn: async () => { /* Implementation follows API spec */ return "Claude implementation needed"; } });
    if (PROVIDERS.GROQ) chain.push({ name: 'Groq-Llama', fn: async () => { /* Implementation follows API spec */ return "Groq implementation needed"; } });

    for (const provider of chain) {
        try {
            console.log(`[OMNI-CASCADE] Attempting ${provider.name}...`);
            const result = await provider.fn();
            console.log(`[OMNI-CASCADE] Success with ${provider.name}`);
            return { content: result, model: provider.name };
        } catch (e) {
            console.error(`[OMNI-CASCADE] ${provider.name} failed: ${e.message}`);
            continue;
        }
    }
    throw new Error("All providers in omni-cascade failed.");
}

bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    if (userId.toString() !== ALLOWED_USER_ID.toString()) {
        return bot.sendMessage(chatId, "Access Denied. You are not the Raja.");
    }
    const userInput = msg.text;
    if (!userInput) return;

    try {
        bot.sendChatAction(chatId, 'typing');
        let systemPrompt = await loadBrain();
        const routing = await routeSkills(userInput);
        
        if (routing.primary) {
            const primaryContent = await loadSkillFile(routing.primary);
            if (primaryContent) systemPrompt += "\\n\\n[ACTIVE PRIMARY SKILL: " + routing.primary + "]\\n" + primaryContent;
            for (const sSkill of routing.supporting) {
                const sContent = await loadSkillFile(sSkill);
                if (sContent) systemPrompt += "\\n\\n[SUPPORTING SKILL: " + sSkill + "]\\n" + sContent;
            }
        }
        
        const cascadeResult = await executeOmniCascade(userInput, systemPrompt);
        const response = cascadeResult.content;
        
        const decisionKeywords = ['pakai', 'gunakan', 'setuju', 'lock', 'pilih', 'deploy', 'config', 'mint', 'swap'];
        const isDecision = decisionKeywords.some(k => userInput.toLowerCase().includes(k));
        
        if (isDecision || routing.primary) {
            await writeMemory(
                'DECISION/CONTEXT', 
                userInput, 
                `Model: ${cascadeResult.model} | Skill: ${routing.primary || 'None'}`, 
                'Proceed'
            );
        }

        await bot.sendMessage(chatId, response);
    } catch (e) {
        bot.sendMessage(chatId, "Critical Error: Omni-Cascade Failure. No providers online.");
        console.error(e);
    }
});

bot.on('polling_error', (error) => {
    console.log("Polling Error: " + error.message);
});
