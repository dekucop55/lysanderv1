import axios from 'axios';
import { CONFIG } from './config';

export class LLM {
    /**
     * Model Cascade Logic: 
     * Try Local (Ollama) -> Fallback to Cloud (OpenRouter) -> Fallback to specific providers
     */
    async generateResponse(prompt: string, forceCloud: boolean = false): Promise<string> {
        if (forceCloud) {
            return this.callOpenRouter(prompt);
        }

        // 1. Priority: Local Ollama (Sovereign's Home)
        try {
            return await this.callOllama(prompt);
        } catch (error) {
            console.error('[LLM] Local Ollama failed, escalating to Sovereign Provider Cascade...');
        }

        // 2. Provider Cascade according to .env / AGENTS.md R7
        const providers = [
            { name: 'anthropic', key: CONFIG.models.providers.anthropic, model: 'claude-3-5-sonnet' },
            { name: 'kimi', key: CONFIG.models.providers.kimi, model: 'moonshot-v1' },
            { name: 'openrouter', key: CONFIG.models.openrouter.apiKey, model: CONFIG.models.openrouter.model },
            { name: 'deepseek', key: CONFIG.models.providers.deepseek, model: 'deepseek-chat' },
            { name: 'groq', key: CONFIG.models.providers.groq, model: 'llama-3.1-70b' }
        ];

        for (const provider of providers) {
            if (!provider.key || provider.key === 'ENTER_YOUR_KEY_HERE') continue;
            try {
                return await this.callGenericProvider(provider.name, provider.model, provider.key, prompt);
            } catch (e) {
                console.error(`[LLM] Provider ${provider.name} failed. Trying next...`);
            }
        }

        throw new Error('All LLM providers failed. Sovereign mind is offline.');
    }

    private async callOllama(prompt: string): Promise<string> {
        const response = await axios.post(`${CONFIG.models.ollama.baseUrl}/api/generate`, {
            model: CONFIG.models.ollama.model,
            prompt: prompt,
            stream: false
        });
        return response.data.response;
    }

    private async callGenericProvider(name: string, model: string, key: string, prompt: string): Promise<string> {
        // Simplified generic call. In production, each provider has a slightly different API shape.
        // For OpenRouter, we use the existing callOpenRouter logic.
        if (name === 'openrouter') return this.callOpenRouter(prompt);
        
        // This is a placeholder for other provider-specific API calls (Anthropic, etc.)
        // In a full implementation, we would map each provider to its respective SDK/Endpoint.
        return this.callOpenRouter(prompt); // Fallback to OpenRouter if generic call is not configured
    }

    private async callOpenRouter(prompt: string): Promise<string> {
        const response = await axios.post(CONFIG.models.openrouter.baseUrl, {
            model: CONFIG.models.openrouter.model,
            messages: [{ role: 'user', content: prompt }]
        }, {
            headers: {
                'Authorization': `Bearer ${CONFIG.models.openrouter.apiKey}`,
                'HTTP-Referer': 'https://github.com/bbtpm2/lysander',
                'X-Title': 'Lysander Sovereign Agent'
            }
        });
        return response.data.choices[0].message.content;
    }
}
