import fs from 'fs-extra';
import path from 'path';
import axios from 'axios';
import dotenv from 'dotenv';
import { Executor } from './executor';

dotenv.config();

export class Orchestrator {
    private executor: Executor;
    private identity: any = {};
    private soul: any = {};
    private agentsConfig: any = {};

    constructor() {
        this.executor = new Executor();
    }

    async boot() {
        console.log('[BOOT] Initializing Lysander Sovereign Mind...');
        
        try {
            // 1. DNA Injection (Knowledge Loading)
            this.identity = await this.executor.readFile('/home/acer/Lysander/knowledge/IDENTITY.md');
            this.soul = await this.executor.readFile('/home/acer/Lysander/knowledge/SOUL.md');
            this.agentsConfig = await this.executor.readFile('/home/acer/Lysander/knowledge/agents.md');
            
            // 2. OpenClaw Core Sync
            const openclawRoot = '/home/acer/Lysander/openclaw_core';
            await this.executor.shellExecute(`ls ${openclawRoot}`);

            console.log('[BOOT] DNA Synchronized. Lysander is now awake.');
            return true;
        } catch (error) {
            console.error('[BOOT ERROR] Failed to synchronize DNA:', error);
            return false;
        }
    }

    /**
     * Implementation of OpenClaw Skill Router
     * Mapping input -> weights -> skill file based on AGENTS.md
     */
    async routeTask(input: string): Promise<{primary: string, supporting: string[]}> {
        console.log(`[ROUTING] Analyzing intent: ${input}`);
        
        const weights: Record<string, {high: string[], med: string[], low: string[]}> = {
            'm1': { high: ['monetize', 'pricing', 'jual', 'jualan', 'cuan'], med: ['business', 'income', 'funnel', 'sell'], low: ['money', 'revenue'] },
            'm2': { high: ['vps', 'deploy', 'ssh', 'nginx', 'docker', 'systemd'], med: ['server', 'linux', 'bash', 'sysadmin'], low: ['host', 'install'] },
            'm3': { high: ['viral', 'hook', 'caption', 'thread', 'naskah'], med: ['content', 'post', 'copywriting', 'konten'], low: ['write', 'draft'] },
            'm4': { high: ['telegram bot', 'cron', 'webhook', 'n8n', 'automate'], med: ['bot', 'otomatis', 'schedule', 'jadwal'], low: ['run', 'trigger'] },
            'm5': { high: ['spreadsheet', 'excel', 'csv', 'dataset', 'snapshot'], med: ['data', 'analytics', 'report', 'laporan'], low: ['numbers', 'stats'] },
            'm6': { high: ['api', 'rest', 'webhook', 'midtrans', 'integrasi'], med: ['endpoint', 'sdk', 'integration'], low: ['connect', 'call'] },
            'm7': { high: ['llm', 'prompt', 'claude api', 'openrouter', 'kimi'], med: ['ai', 'agent', 'model', 'gpt'], low: ['inference'] },
            'm8': { high: ['pdf', 'docx', 'xlsx', 'pptx', 'generate file'], med: ['export', 'dokumen', 'file'], low: ['format', 'save'] },
            'm9': { high: ['landing page', 'react', 'tailwind', 'frontend'], med: ['website', 'ui', 'html', 'css'], low: ['web', 'design'] },
            'm10': { high: ['wallet', 'airdrop', 'on-chain', 'rpc', 'ethers'], med: ['crypto', 'web3', 'token', 'blockchain', 'eth'], low: ['mint', 'swap'] },
            'm11': { high: ['audit', 'vulnerability', 'exploit', 'scam check'], med: ['security', 'review', 'safe', 'malicious'], low: ['check', 'verify'] },
            'm12': { high: ['batch', 'parallel', 'bulk', 'mass', 'queue', 'worker'], med: ['concurrent', 'throughput', 'snapshot'], low: ['many', 'multi'] },
            'm13': { high: ['mint', 'opensea', 'manifold', 'zora', 'seadrop'], med: ['nft', 'claim', 'drop', 'collection'], low: ['collect', 'art'] },
            'H1': { high: ['swap', '1inch', 'jupiter', 'jual token'], med: ['dex', 'slippage', 'aggregator'], low: ['trade'] },
            'H2': { high: ['bridge', 'layerzero', 'stargate', 'li.fi', 'across'], med: ['cross-chain', 'layer zero', 'hop'], low: ['move'] },
            'H3': { high: ['aave', 'lido', 'gmx', 'hyperliquid', 'pendle', 'defi'], med: ['lending', 'staking', 'restaking', 'perp'], low: ['yield'] },
            'H4': { high: ['snipe', 'honeypot', 'paircreated', 'sniping'], med: ['launch', 'rugcheck', 'goplus'], low: ['fast'] },
            'H5': { high: ['mempool', 'whale', 'nansen', 'arkham', 'smart money'], med: ['tracker', 'copy-trade', 'frontrun'], low: ['watch'] },
            'H6': { high: ['beli nft', 'blur', 'magic eden', 'tensor'], med: ['listing', 'fulfill', 'floor', 'reservoir'], low: ['buy nft'] },
            'H7': { high: ['siwe', 'walletconnect', 'eip-712', 'ens', 'permit'], med: ['sign-in', 'typed data', 'signature'], low: ['login'] },
            'x1': { high: ['improve system', 'self-audit', 'refactor brain'], med: ['audit me', 'upgrade self'], low: ['optimize'] },
            'x2': { high: ['strategy', 'architecture', 'decompose', 'plan'], med: ['complex', 'multi-step', 'design system'], low: ['think'] },
            'x3': { high: ['error', 'bug', 'debug', 'gagal', 'rusak', 'stack'], med: ['failed', 'broken', 'fix', 'crash', 'traceback'], low: ['issue'] }
        };

        let scores: Record<string, number> = {};
        const lowerInput = input.toLowerCase();

        for (const [skill, weightGroups] of Object.entries(weights)) {
            let score = 0;
            weightGroups.high.forEach(k => { if (lowerInput.includes(k)) score += 3; });
            weightGroups.med.forEach(k => { if (lowerInput.includes(k)) score += 2; });
            weightGroups.low.forEach(k => { if (lowerInput.includes(k)) score += 1; });
            scores[skill] = score;
        }

        const sortedSkills = Object.entries(scores).sort((a, b) => b[1] - a[1]);
        const primary = sortedSkills[0][1] > 0 ? sortedSkills[0][0] : 'core';
        const supporting = sortedSkills.filter(([s, score]) => s !== primary && score > 0).map(s => s[0]);
        
        return { primary, supporting };
    }

    async executeGoal(goal: string) {
        const { primary, supporting } = await this.routeTask(goal);
        console.log(`[EXECUTION] Primary skill: ${primary} | Supporting: ${supporting.join(', ')}`);

        if (primary === 'core') {
            return `Goal "${goal}" handled by core intelligence. Ready for reasoning.`;
        }

        let skillContent = '';
        try {
            const skillPath = primary.startsWith('H') 
                ? `/home/acer/Lysander/openclaw_core/skills/hermes/references/${this.mapHToRef(primary)}.md`
                : `/home/acer/Lysander/openclaw_core/skills/${primary}.md`;
            
            skillContent = await this.executor.readFile(skillPath);
        } catch (e: any) {
            return `Error loading skill ${primary}: ${e.message}`;
        }

        // --- Markdown-to-Action Engine Core ---
        // 1. Separate the DNA into conceptual zones (Strategy, Implementation, Pitfalls)
        const implementationMatch = skillContent.match(/## Implementation\s*([\s\S]*?)(?=\n##|$)/);
        const instructions = implementationMatch ? implementationMatch[1].trim() : skillContent;

        console.log(`[ENGINE] Executing skill ${primary} via instructions...`);
        
        // 2. The sovereign loop: Use LLM to translate Markdown instructions into concrete Shell commands
        // This is where Lysander's "Sovereign Mind" decides HOW to apply the skill.
        const executionPlan = `Goal: ${goal}\nSkill DNA: ${instructions}\n\nTask: Generate precise shell commands to execute this. Return only the commands, one per line.`;
        
        // Simulated LLM call (In full impl, this calls llm.generateResponse)
        const commands = `ls -la /home/acer/Lysander\necho "Sovereign execution of ${primary} complete"`; 

        const results: string[] = [];
        for (const cmd of commands.split('\n')) {
            const res = await this.executor.shellExecute(cmd);
            results.push(`CMD: ${cmd} -> EXIT: ${res.code}`);
        }

        return `Goal "${goal}" executed using ${primary}.\nResults:\n${results.join('\n')}`;
    }

    private mapHToRef(hSkill: string): string {
        const mapping: Record<string, string> = {
            'H1': 'swap', 'H2': 'bridge', 'H3': 'defi', 'H4': 'sniping', 'H5': 'monitoring', 'H6': 'nft', 'H7': 'web3_connect'
        };
        return mapping[hSkill] || 'core';
    }

}
