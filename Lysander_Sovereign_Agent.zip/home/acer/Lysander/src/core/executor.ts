import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs-extra';
import path from 'path';

const executeAsync = promisify(exec);

export class Executor {
    /**
     * Full shell authority. Executes any command on the VPS.
     */
    async shellExecute(command: string, workdir: string = '/home/acer/Lysander'): Promise<{stdout: string, stderr: string, code: number}> {
        try {
            const { stdout, stderr } = await executeAsync(command, { cwd: workdir });
            return { stdout, stderr, code: 0 };
        } catch (error: any) {
            return { 
                stdout: error.stdout || '', 
                stderr: error.stderr || error.message, 
                code: error.code || 1 
            };
        }
    }

    /**
     * Direct filesystem manipulation.
     */
    async writeFile(filePath: string, content: string): Promise<void> {
        await fs.ensureDir(path.dirname(filePath));
        await fs.writeFile(filePath, content, 'utf8');
    }

    async readFile(filePath: string): Promise<string> {
        return await fs.readFile(filePath, 'utf8');
    }

    async deleteFile(filePath: string): Promise<void> {
        await fs.remove(filePath);
    }

    async createDirectory(dirPath: string): Promise<void> {
        await fs.ensureDir(dirPath);
    }

    /**
     * The Self-Evolution Bridge: Allows the agent to update its own code.
     */
    async selfUpdate(filePath: string, newCode: string): Promise<string> {
        await this.writeFile(filePath, newCode);
        // If it's a TS file, we might need to trigger a rebuild or just rely on ts-node
        return `File ${filePath} updated successfully. System evolution applied.`;
    }
}
