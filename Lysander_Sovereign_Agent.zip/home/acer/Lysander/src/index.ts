import { Orchestrator } from './core/orchestrator';
import { TelegramInterface } from './interfaces/telegram';
import { LLM } from './core/llm';
import { validateConfig } from './core/config';

async function main() {
    if (!validateConfig()) {
        console.error('[CRITICAL] Essential config missing. Please check .env');
        process.exit(1);
    }

    const lysander = new Orchestrator();
    
    // Inject LLM capability into orchestrator
    (lysander as any).llm = new LLM();

    const success = await lysander.boot();
    
    if (success) {
        const telegram = new TelegramInterface(lysander);
        await telegram.start();
        
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('  LYSANDER PHOEBE KESET SEJUTA UMAT IS ONLINE');
        console.log('  Status: Sovereign Agent');
        console.log('  Authority: Root | Mode: Autonomous');
        console.log('  Interface: Telegram Gateway Active');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    } else {
        process.exit(1);
    }
}

main().catch(console.error);
