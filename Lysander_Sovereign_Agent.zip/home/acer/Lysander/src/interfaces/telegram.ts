import Telegram from 'node-telegram-bot-api';
import { CONFIG } from '../core/config';
import { Orchestrator } from '../core/orchestrator';

export class TelegramInterface {
    private bot: Telegram.Bot;
    private orchestrator: Orchestrator;
    private lastUpdateId: number = 0;

    constructor(orchestrator: Orchestrator) {
        this.orchestrator = orchestrator;
        this.bot = new Telegram.Bot(CONFIG.telegram.token, { polling: false });
    }

    async start() {
        console.log('[INTERFACE] Telegram Gateway online. Sovereign Mode Active.');
        
        this.bot.onText(/\/status/, (msg) => {
            this.sendResponse(msg.chat.id, '🟢 *Lysander Status: Online*\\nSovereign Core: Active\\nAutonomy: Root\\nHost: vans-sg-8gb');
        });

        // Polling loop for direct action execution
        setInterval(async () => {
            try {
                const updates = await this.bot.getUpdates({ offset: this.lastUpdateId + 1 });
                for (const update of updates) {
                    this.lastUpdateId = update.update_id;
                    const msg = update.message;
                    
                    if (!msg || !msg.text || msg.text.startsWith('/status')) continue;

                    // Security: Only allow the Sovereign Owner
                    if (msg.from.id.toString() !== CONFIG.telegram.allowedUserId) {
                        this.sendResponse(msg.chat.id, '❌ *Unauthorized operator.* Access denied.');
                        continue;
                    }

                    // DIRECT ACTION TRIGGER
                    // Input: files, URLs, code requests, or direct commands
                    try {
                        const response = await this.orchestrator.executeGoal(msg.text);
                        this.sendResponse(msg.chat.id, response);
                    } catch (error: any) {
                        this.sendResponse(msg.chat.id, `⚠️ *Execution Failure:*\\n\`${error.message}\``);
                    }
                }
            } catch (e) {
                console.error('[INTERFACE ERROR] Polling failure:', e);
            }
        }, 1000);
    }

    private sendResponse(chatId: number, text: string) {
        this.bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
    }
}
