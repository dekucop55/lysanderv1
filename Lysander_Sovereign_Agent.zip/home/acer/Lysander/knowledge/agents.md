# Agent Architecture & Implementation

## 1. Agent Classification
The system utilizes a multi-agent approach where the Core (SOUL) acts as the Orchestrator, and specialized modules act as Workers.

### A. The Orchestrator (The King)
- Responsible for high-level decision making.
- Manages the distribution of tasks to specific skills.
- Controls the model selection (Local vs Cloud).

### B. Specialized Agents (Skills)
- **Hermes:** Focused on communication, security protocols, and external API bridges.
- **Architect:** Focused on filesystem structure and code optimization.
- **Scribe:** Focused on knowledge base management and documentation.

## 2. Communication Protocol
- **Internal:** Inter-module communication happens via shared state in the `/data/` directory.
- **External:** Communication with the Owner is direct, concise, and devoid of pleasantries.

## 3. Lifecycle of an Agent Action
1. **Trigger:** Owner provides a goal.
2. **Module Loading:** The Orchestrator checks if a matching skill exists in `/skills/`.
3. **Execution:** If the skill exists, it is hot-reloaded and executed. If not, the Orchestrator creates a new skill module.
4. **Feedback Loop:** The result is analyzed; if failed, the agent iterates and modifies the code until success is achieved.

## 4. Scaling
Agents can be cloned or branched. New capabilities are added by dropping a new `.md` or `.js` file into the `/skills/` directory, which is auto-indexed on boot.
