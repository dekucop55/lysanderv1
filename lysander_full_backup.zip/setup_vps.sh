# System Requirements for Lysander Agent
# Install these on the VPS to ensure the bot runs smoothly

# Node.js runtime (LTS recommended)
# Curl is needed for the installation script
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# PM2 for process management
npm install -g pm2

# Unzip utility for extraction
apt-get install -y unzip

# Git (Optional but recommended for updates)
apt-get install -y git

# Build tools (Required for some npm packages like node-unrar-js or pdf-parse)
apt-get install -y build-essential
