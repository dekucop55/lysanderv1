# SYSTEM LOGS
- Format: [Timestamp] [Level] [Module] [Message]
- Retention: 30 days rolling.
- Alerting: Critical errors trigger immediate alert to Operator.
