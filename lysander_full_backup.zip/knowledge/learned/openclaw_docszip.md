The provided content is a **ZIP archive** containing a project called **`openclaw`**. Based on the file structure and visible metadata, here is the summary of its knowledge points:

### **Project Overview: openclaw**
*   **Purpose:** A structured knowledge base or documentation repository focused on a system/framework called "SOUL" and associated "Skills."
*   **Core Components:**
    *   **Core Logic/Philosophy:** Defined in `SOUL.md`.
    *   **Guidelines:** Operational instructions found in `panduan.md` (Indonesian for "guide/manual").
    *   **Skill Modules:** A directory of specialized skills (`skills/`), including:
        *   **General Skills:** Specific modules like `m9.md`.
        *   **Hermes Module:** A specialized sub-category (`skills/hermes/`) containing references and specific security documentation (`security.md`).

### **Structural Breakdown**
1.  **`openclaw/SOUL.md`**: Likely the central conceptual framework or "brain" of the project.
2.  **`openclaw/panduan.md`**: The primary user manual or setup guide.
3.  **`openclaw/skills/`**: A library of capabilities or automated tasks.
4.  **`openclaw/skills/hermes/`**: A dedicated section for "Hermes" (possibly a specific agent, bot, or communication protocol), with a focus on **security** protocols.