The provided content is a **ZIP archive** containing several Markdown (`.md`) files from a repository named `openclaw`. Based on the file structure and visible filenames, here is the summarized knowledge map:

### **Project Overview: OpenClaw**
The project appears to be a structured knowledge base or documentation set related to a specific system or framework called "OpenClaw."

### **Core Knowledge Components**
*   **SOUL (`SOUL.md`)**: Likely the core philosophy, conceptual framework, or the primary engine/module of the project.
*   **Guidance/Manual (`panduan.md`)**: A user guide or instructional manual (the word "panduan" is Indonesian for "guide/manual").
*   **Skills Framework (`/skills/`)**: A categorized directory of capabilities or "skills" the system can perform.
    *   **General Skills**: Includes specific skill modules (e.g., `m9.md`).
    *   **Hermes Module (`/skills/hermes/`)**: A specialized skill subset named "Hermes."
        *   **Security Reference (`security.md`)**: Specific technical documentation regarding security protocols or guidelines within the Hermes module.

### **Structure Summary**
| Component | Likely Purpose |
| :--- | :--- |
| **SOUL** | Core Logic / Philosophy |
| **Panduan** | User Instructions / Implementation Guide |
| **Skills** | Modular Capability Definitions |
| **Hermes $\rightarrow$ Security** | Specialized Security Specifications |