#!/bin/bash

# --- CONFIGURATION ---
VPS_IP="152.42.182.101"
VPS_USER="root"
VPS_DEST="/home/root/lysander-bot"
LOCAL_PROJECT_DIR=$(pwd)
ZIP_FILE="lysander_full_backup.zip"

echo "🚀 Starting FULL Deployment (Zip Mode) to VPS: $VPS_IP"

# 1. Zip everything (excluding unnecessary large files and node_modules)
echo "📦 Zipping project files..."
zip -r $ZIP_FILE . -x "$ZIP_FILE" "node_modules/*" ".git/*"

# 2. Create destination directory and prepare system requirements
echo "📁 Preparing VPS directory and installing dependencies..."
ssh $VPS_USER@$VPS_IP "
    apt-get update && \
    apt-get install -y unzip git build-essential curl && \
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && \
    apt-get install -y nodejs && \
    npm install -g pm2
"
ssh $VPS_USER@$VPS_IP "mkdir -p $VPS_DEST"

# 3. Transfer the ZIP file
echo "📤 Uploading zip archive..."
scp $ZIP_FILE $VPS_USER@$VPS_IP:$VPS_DEST/

# 4. Unzip and cleanup on VPS
echo "📂 Extracting files on VPS..."
ssh $VPS_USER@$VPS_IP "
    cd $VPS_DEST && \
    unzip -o $ZIP_FILE && \
    rm $ZIP_FILE
"

# 5. Finalize and restart bot (Automating the update sequence)
echo "⚙️ Finalizing Installation & Restarting..."
ssh $VPS_USER@$VPS_IP "
    cd $VPS_DEST && \
    npm install --production && \
    pm2 reload ecosystem.config.js || pm2 start ecosystem.config.js
"

# 6. Local cleanup
rm $ZIP_FILE

echo "✅ FULL Deployment Complete! Bot is now live with all updates."
echo "📊 Check status: ssh $VPS_USER@$VPS_IP 'pm2 status'"
echo "📋 Check logs: ssh $VPS_USER@$VPS_IP 'pm2 logs'"
