import axios from 'axios';
import { config } from './config.js';
import { getHistory, addMessage } from './memory.js';
import { getAllKnowledge } from './knowledge.js';

// Provider: 'ollama' or 'openrouter'
function getProvider() {
  return config.openrouterApiKey ? 'dual' : 'ollama';
}

// Send chat to local Ollama
async function chatOllama(messages) {
  const response = await axios.post(`${config.ollamaBaseUrl}/api/chat`, {
    model: config.ollamaModel,
    messages,
    stream: false,
  });

  return response.data.message.content;
}

// Send chat to OpenRouter (Kimi K2.6 free)
async function chatOpenRouter(messages) {
  const response = await axios.post(
    'https://openrouter.ai/api/v1/chat/completions',
    {
      model: config.openrouterModel,
      messages,
    },
    {
      headers: {
        'Authorization': `Bearer ${config.openrouterApiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://github.com/Randompeople1265/TestAgent',
        'X-OpenRouter-Title': 'Lysander Agent',
      },
    }
  );

  return response.data.choices[0].message.content;
}

// Build full message array with knowledge + history
async function buildMessages(chatId, userMessage) {
  const knowledge = await getAllKnowledge();
  const history = await getHistory(chatId);

  const messages = [];

  // Inject knowledge as system context
  if (knowledge) {
    messages.push({
      role: 'system',
      content: knowledge,
    });
  }

  // Add conversation history
  for (const msg of history) {
    messages.push(msg);
  }

  // Add current user message
  messages.push({
    role: 'user',
    content: userMessage,
  });

  return messages;
}

// Main chat function - try primary provider, fallback to secondary
export async function chat(chatId, userMessage) {
  const messages = await buildMessages(chatId, userMessage);
  let response;

  const provider = getProvider();

  if (provider === 'dual') {
    // Primary: Ollama (local, fast), Fallback: OpenRouter
    try {
      response = await chatOllama(messages);
    } catch (ollamaError) {
      console.log('[Lysander] Ollama tidak tersedia, fallback ke OpenRouter...');
      try {
        response = await chatOpenRouter(messages);
      } catch (openrouterError) {
        throw new Error(
          `Kedua provider gagal.\nOllama: ${ollamaError.message}\nOpenRouter: ${openrouterError.message}`
        );
      }
    }
  } else {
    // Only Ollama available
    try {
      response = await chatOllama(messages);
    } catch (error) {
      throw new Error(`Ollama tidak tersedia: ${error.message}`);
    }
  }

  // Save to memory
  await addMessage(chatId, 'user', userMessage);
  await addMessage(chatId, 'assistant', response);

  return response;
}

// Direct chat without memory (used for summarization, etc.)
export async function chatDirect(messages) {
  const provider = getProvider();

  if (provider === 'dual') {
    try {
      return await chatOllama(messages);
    } catch {
      return await chatOpenRouter(messages);
    }
  }

  return await chatOllama(messages);
}
