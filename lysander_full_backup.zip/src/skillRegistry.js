import { readdir, readFile, stat } from 'fs/promises';
import { resolve, join, extname, basename } from 'path';
import { config } from './config.js';

/**
 * Skill Registry — manages all loaded skills/plugins
 * 
 * Responsibilities:
 * - Load semua skill dari folder skills/ saat boot
 * - Hot-reload skill baru tanpa restart
 * - Provide skill list ke agent loop
 * - Match skill berdasarkan trigger keywords
 */

// In-memory registry
const skills = new Map();

/**
 * Load single skill file
 * @param {string} filePath - absolute path to skill file
 * @returns {object|null} loaded skill or null if invalid
 */
async function loadSkillFile(filePath) {
  const fileName = basename(filePath);

  // Skip files with underscore prefix (templates, disabled)
  if (fileName.startsWith('_')) {
    console.log(`[Skills] Skipped: ${fileName} (underscore prefix)`);
    return null;
  }

  // Only .js files
  if (extname(filePath) !== '.js') {
    return null;
  }

  try {
    // Dynamic import with cache-busting for hot reload
    const cacheBuster = `?t=${Date.now()}`;
    const module = await import(`file://${filePath}${cacheBuster}`);
    const skill = module.default;

    // Validate skill structure
    if (!skill || !skill.name || !skill.execute || typeof skill.execute !== 'function') {
      console.log(`[Skills] Invalid skill structure: ${fileName}`);
      return null;
    }

    // Ensure required fields
    skill.description = skill.description || 'No description';
    skill.version = skill.version || '1.0.0';
    skill.triggers = skill.triggers || [];
    skill.filePath = filePath;
    skill.fileName = fileName;
    skill.loadedAt = new Date().toISOString();

    return skill;
  } catch (error) {
    console.error(`[Skills] Failed to load ${fileName}:`, error.message);
    return null;
  }
}

/**
 * Load semua skills dari skills directory
 */
export async function loadAllSkills() {
  const skillsDir = config.skillsDir;

  try {
    const dirStat = await stat(skillsDir).catch(() => null);
    if (!dirStat) {
      console.log(`[Skills] Skills directory not found, creating: ${skillsDir}`);
      const { mkdir } = await import('fs/promises');
      await mkdir(skillsDir, { recursive: true });
      return;
    }

    const files = await readdir(skillsDir);
    let loaded = 0;

    for (const file of files) {
      const filePath = resolve(skillsDir, file);
      const fileStat = await stat(filePath);

      if (!fileStat.isFile()) continue;

      const skill = await loadSkillFile(filePath);
      if (skill) {
        skills.set(skill.name, skill);
        loaded++;
        console.log(`[Skills] Loaded: ${skill.name} v${skill.version}`);
      }
    }

    console.log(`[Skills] Total loaded: ${loaded}/${files.length} files`);
  } catch (error) {
    console.error(`[Skills] Error loading skills:`, error.message);
  }
}

/**
 * Hot-reload: load atau reload satu skill by file name
 * @param {string} fileName - nama file skill (e.g., 'web_scraper.js')
 * @returns {object|null} loaded skill or null
 */
export async function reloadSkill(fileName) {
  const filePath = resolve(config.skillsDir, fileName);

  // Unload existing jika ada
  for (const [name, skill] of skills.entries()) {
    if (skill.fileName === fileName) {
      skills.delete(name);
      console.log(`[Skills] Unloaded: ${name}`);
      break;
    }
  }

  // Load fresh
  const skill = await loadSkillFile(filePath);
  if (skill) {
    skills.set(skill.name, skill);
    console.log(`[Skills] Reloaded: ${skill.name} v${skill.version}`);
    return skill;
  }

  return null;
}

/**
 * Unload skill by name
 * @param {string} skillName
 * @returns {boolean}
 */
export function unloadSkill(skillName) {
  if (skills.has(skillName)) {
    skills.delete(skillName);
    console.log(`[Skills] Unloaded: ${skillName}`);
    return true;
  }
  return false;
}

/**
 * Get semua loaded skills (untuk agent awareness)
 * @returns {Array} array of { name, description, version, triggers }
 */
export function getSkillsList() {
  const list = [];
  for (const [_, skill] of skills) {
    list.push({
      name: skill.name,
      description: skill.description,
      version: skill.version,
      triggers: skill.triggers,
    });
  }
  return list;
}

/**
 * Get skill by name
 * @param {string} name
 * @returns {object|null}
 */
export function getSkill(name) {
  return skills.get(name) || null;
}

/**
 * Find matching skills berdasarkan user message
 * Cek apakah ada trigger keyword yang cocok
 * @param {string} userMessage
 * @returns {Array} matching skills
 */
export function findMatchingSkills(userMessage) {
  const msg = userMessage.toLowerCase();
  const matches = [];

  for (const [_, skill] of skills) {
    for (const trigger of skill.triggers) {
      if (msg.includes(trigger.toLowerCase())) {
        matches.push(skill);
        break; // satu trigger match cukup
      }
    }
  }

  return matches;
}

/**
 * Execute skill
 * @param {string} skillName - nama skill
 * @param {object} context - { userMessage, chatId, agentDirect, config }
 * @returns {object} { success, result, error? }
 */
export async function executeSkill(skillName, context) {
  const skill = skills.get(skillName);

  if (!skill) {
    return { success: false, error: `Skill "${skillName}" not found.` };
  }

  try {
    console.log(`[Skills] Executing: ${skillName}`);
    const result = await skill.execute(context);
    return result;
  } catch (error) {
    console.error(`[Skills] Execution error (${skillName}):`, error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Get skill count
 */
export function getSkillCount() {
  return skills.size;
}

/**
 * Get skill registry info (for debugging)
 */
export function getRegistryInfo() {
  return {
    total: skills.size,
    skills: Array.from(skills.values()).map(s => ({
      name: s.name,
      version: s.version,
      fileName: s.fileName,
      loadedAt: s.loadedAt,
      triggers: s.triggers,
    })),
  };
}
