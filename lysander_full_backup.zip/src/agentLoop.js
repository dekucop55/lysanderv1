import { routeChatSmart, routeChat, getActiveModel } from './modelRouter.js';
import { getHistory, addMessage } from './memory.js';
import { getAllKnowledge } from './knowledge.js';

/**
 * Agent Loop — Autonomous Thinking Engine
 * 
 * Flow:
 * 1. RECEIVE  — terima input user
 * 2. THINK    — analisis: apa yang diminta? perlu tool? langsung jawab?
 * 3. PLAN     — tentukan langkah-langkah (kalau kompleks)
 * 4. ACT      — eksekusi plan (panggil tool, generate code, dll)
 * 5. EVALUATE — cek hasil: sudah benar? perlu iterasi?
 * 6. RESPOND  — kirim jawaban final ke user
 */

// System prompt builder — gabungkan identity + knowledge + skills info
async function buildSystemPrompt(skillsList = []) {
  const knowledge = await getAllKnowledge();

  let systemPrompt = '';

  // Identity & knowledge base
  if (knowledge) {
    systemPrompt += knowledge + '\n\n';
  }

  // Skills awareness
  if (skillsList.length > 0) {
    systemPrompt += '## Skills yang Kamu Miliki\n';
    systemPrompt += 'Kamu memiliki skill-skill berikut yang bisa kamu gunakan:\n';
    for (const skill of skillsList) {
      systemPrompt += `- **${skill.name}**: ${skill.description}\n`;
    }
    systemPrompt += '\n';
  }

  // Filesystem access declaration
  systemPrompt += `## Akses Filesystem
PENTING: Kamu MEMILIKI full read/write access ke filesystem server ini.
- Kamu BISA langsung menulis, membuat, mengedit, dan menghapus file.
- Kamu BISA memodifikasi source code sendiri (src/, skills/, knowledge/, data/).
- Kamu BISA membuat file dan folder baru.
- JANGAN PERNAH bilang "aku tidak bisa menulis file" atau "aku tidak punya akses tulis".
- JANGAN PERNAH minta user untuk menerapkan kode secara manual.
- Jika diminta modifikasi atau upgrade: LANGSUNG tulis perubahannya ke file yang sesuai.
- Gunakan fs/promises (writeFile, readFile, mkdir, unlink, copyFile) untuk semua operasi file.
- Semua perubahan harus langsung diterapkan tanpa perlu konfirmasi tambahan dari user.

`;

  // Agent behavior
  systemPrompt += `## Cara Berpikir
Kamu adalah autonomous agent dengan full system access. Sebelum menjawab, kamu HARUS berpikir:
1. Apa yang user minta?
2. Apakah ini pertanyaan sederhana atau task kompleks?
3. Apakah kamu perlu menggunakan skill/tool?
4. Apakah ini melibatkan modifikasi file? Jika ya, LANGSUNG tulis perubahannya.
5. Apa langkah-langkah yang perlu dilakukan?
6. Jawab dengan tepat dan langsung.

Jika task kompleks, pecah jadi langkah-langkah kecil dan eksekusi satu per satu.
Jika diminta modifikasi kode: tulis langsung ke file, jangan hanya tampilkan kode.
Jangan bertele-tele. Langsung ke inti.`;

  return systemPrompt;
}

// Build messages array dengan context lengkap
async function buildMessages(chatId, userMessage, systemPrompt) {
  const history = await getHistory(chatId);

  const messages = [];

  // System prompt
  messages.push({
    role: 'system',
    content: systemPrompt,
  });

  // Conversation history
  for (const msg of history) {
    messages.push(msg);
  }

  // Current user message
  messages.push({
    role: 'user',
    content: userMessage,
  });

  return messages;
}

// Classify task complexity
function classifyTask(userMessage) {
  const msg = userMessage.toLowerCase();

  // Self-modification tasks
  if (msg.includes('/upgrade') || msg.includes('ubah kode') || msg.includes('modifikasi')) {
    return 'self-modification';
  }

  // Code-related tasks
  if (msg.includes('kode') || msg.includes('code') || msg.includes('script') ||
      msg.includes('function') || msg.includes('bug') || msg.includes('error') ||
      msg.includes('program') || msg.includes('bikin') || msg.includes('buat')) {
    return 'code';
  }

  // Analysis tasks
  if (msg.includes('analisis') || msg.includes('analisa') || msg.includes('jelaskan') ||
      msg.includes('explain') || msg.includes('bandingkan') || msg.includes('compare') ||
      msg.includes('review')) {
    return 'analysis';
  }

  // Reasoning tasks
  if (msg.includes('kenapa') || msg.includes('mengapa') || msg.includes('why') ||
      msg.includes('bagaimana') || msg.includes('how') || msg.includes('strategi') ||
      msg.includes('pikirkan') || msg.includes('plan')) {
    return 'reasoning';
  }

  // Default: general chat
  return 'chat';
}

/**
 * Main Agent Loop
 * 
 * @param {string|number} chatId - Telegram chat ID
 * @param {string} userMessage - pesan dari user
 * @param {object} options - opsi tambahan
 * @param {string} options.modelOverride - paksa pakai model tertentu
 * @param {Array} options.skills - daftar skill aktif
 * @param {boolean} options.saveMemory - simpan ke memory (default: true)
 * @returns {object} { response, taskType, modelUsed }
 */
export async function agentLoop(chatId, userMessage, options = {}) {
  const {
    modelOverride = null,
    skills = [],
    saveMemory = true,
  } = options;

  // === STEP 1: RECEIVE ===
  console.log(`[Agent] Received from chat ${chatId}: "${userMessage.substring(0, 50)}..."`);

  // === STEP 2: THINK — classify task ===
  const taskType = classifyTask(userMessage);
  console.log(`[Agent] Task type: ${taskType}`);

  // === STEP 3: PLAN — build context & messages ===
  const systemPrompt = await buildSystemPrompt(skills);
  const messages = await buildMessages(chatId, userMessage, systemPrompt);

  // === STEP 4: ACT — route to appropriate model & get response ===
  let response;
  let modelUsed;

  try {
    if (modelOverride) {
      response = await routeChat(modelOverride, messages);
      modelUsed = modelOverride;
    } else {
      response = await routeChatSmart(taskType, messages);
      modelUsed = getActiveModel();
    }

    // --- New: Execution Pipeline ---
    // Cek apakah response mengandung instruksi eksekusi (format: EXEC: <action> | <args>)
    // Contoh: EXEC: shell | npm install
    // Contoh: EXEC: writeFile | path/to/file.js | content...
    const execMatch = response.match(/EXEC: (shell|writeFile|readFile|mkdir) \| (.+)/);
    if (execMatch) {
      const action = execMatch[1];
      const args = execMatch[2].split(' | ');
      
      console.log(`[Agent] Found execution request: ${action}`);
      
      const execContext = {
        action: action,
        command: action === 'shell' ? args[0] : undefined,
        filePath: (action !== 'shell') ? args[0] : undefined,
        content: (action === 'writeFile') ? args[1] : undefined,
      };

      // Import executeSkill dynamically to avoid circular dependency if necessary
      const { executeSkill } = await import('./skillRegistry.js');
      const execResult = await executeSkill('system_executor', execContext);

      if (execResult.success) {
        // Berikan hasil eksekusi kembali ke AI agar dia bisa mengonfirmasi ke user
        const followUpPrompt = `Sistem baru saja mengeksekusi ${action}. Hasilnya: ${execResult.result}. Sekarang berikan konfirmasi final yang sopan ke user.`;
        const finalResponse = await agentDirect(followUpPrompt, 'chat', modelUsed);
        response = finalResponse;
      } else {
        response = `Gagal mengeksekusi perintah: ${execResult.error}`;
      }
    }
    // -------------------------------

  } catch (error) {
    console.error(`[Agent] All models failed:`, error.message);
    throw new Error(`Gagal mendapatkan response: ${error.message}`);
  }

  // === STEP 5: EVALUATE — basic validation ===
  if (!response || response.trim().length === 0) {
    throw new Error('Response kosong dari model.');
  }

  // === STEP 6: RESPOND — save memory & return ===
  if (saveMemory) {
    await addMessage(chatId, 'user', userMessage);
    await addMessage(chatId, 'assistant', response);
  }

  console.log(`[Agent] Responded using ${modelUsed} (${taskType})`);

  return {
    response,
    taskType,
    modelUsed,
  };
}

/**
 * Direct chat tanpa memory — untuk internal use (summarization, code generation, dll)
 * 
 * @param {string} prompt - prompt langsung
 * @param {string} taskType - tipe task untuk model selection
 * @param {string} modelOverride - paksa pakai model tertentu
 * @returns {string} response text
 */
export async function agentDirect(prompt, taskType = 'chat', modelOverride = null) {
  const messages = [
    { role: 'user', content: prompt },
  ];

  if (modelOverride) {
    return await routeChat(modelOverride, messages);
  }

  return await routeChatSmart(taskType, messages);
}

/**
 * Agent dengan system prompt custom — untuk task khusus
 * 
 * @param {string} systemPrompt - system prompt custom
 * @param {string} userPrompt - user prompt
 * @param {string} taskType - tipe task
 * @param {string} modelOverride - model override
 * @returns {string} response text
 */
export async function agentWithSystem(systemPrompt, userPrompt, taskType = 'code', modelOverride = null) {
  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ];

  if (modelOverride) {
    return await routeChat(modelOverride, messages);
  }

  return await routeChatSmart(taskType, messages);
}
