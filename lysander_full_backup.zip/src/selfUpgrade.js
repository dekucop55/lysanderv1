import { readFile, writeFile, unlink, mkdir, readdir, stat, copyFile } from 'fs/promises';
import { existsSync } from 'fs';
import { resolve, extname, basename, join } from 'path';
import axios from 'axios';
import pdfParse from 'pdf-parse';
import AdmZip from 'adm-zip';
import { createExtractorFromData } from 'node-unrar-js';
import { config } from './config.js';
import { agentWithSystem, agentDirect } from './agentLoop.js';
import { reloadSkill } from './skillRegistry.js';
import { safeApplySkill } from './hotReload.js';

/**
 * Self-Upgrade Engine — True Self-Modification
 * 
 * Flow:
 * 1. EXTRACT  — buka file (zip/rar/single), ambil semua konten
 * 2. SCAN     — identifikasi file mana yang merupakan kode/config/prompt
 * 3. ANALYZE  — LLM baca & pahami: skill apa yang dimiliki agent ini?
 * 4. GENERATE — LLM tulis kode skill baru berdasarkan analisis
 * 5. APPLY    — tulis file ke skills/, hot-reload registry
 * 6. REPORT   — lapor hasilnya ke user
 */

// === DIRECTORY SETUP ===

async function ensureDir(dirPath) {
  if (!existsSync(dirPath)) {
    await mkdir(dirPath, { recursive: true });
  }
}

async function ensureUploadDir() {
  await ensureDir(config.uploadDir);
}

async function ensureSkillsDir() {
  await ensureDir(config.skillsDir);
}

async function ensureBackupDir() {
  const backupDir = resolve(config.skillsDir, '../backups');
  await ensureDir(backupDir);
  return backupDir;
}

// === FILE EXTRACTION ===

// Ekstensi yang dianggap source code
const CODE_EXTENSIONS = [
  '.js', '.ts', '.py', '.jsx', '.tsx', '.mjs', '.cjs',
  '.java', '.go', '.rb', '.php', '.rs', '.c', '.cpp',
];

// Ekstensi yang dianggap config/docs
const DOC_EXTENSIONS = [
  '.md', '.txt', '.json', '.yaml', '.yml', '.toml', '.env', '.cfg', '.ini',
];

function isCodeFile(fileName) {
  const ext = extname(fileName).toLowerCase();
  return CODE_EXTENSIONS.includes(ext);
}

function isDocFile(fileName) {
  const ext = extname(fileName).toLowerCase();
  return DOC_EXTENSIONS.includes(ext);
}

function isReadableFile(fileName) {
  return isCodeFile(fileName) || isDocFile(fileName);
}

/**
 * Extract konten dari berbagai format file
 * @returns {Array} [{ path, content, type: 'code'|'doc'|'other' }]
 */
async function extractFiles(filePath, fileName) {
  const ext = extname(fileName).toLowerCase();

  switch (ext) {
    case '.zip':
      return extractZip(filePath);
    case '.rar':
      return extractRar(filePath);
    case '.pdf':
      return [{ path: fileName, content: await extractPdf(filePath), type: 'doc' }];
    default:
      // Single file
      const content = await readFile(filePath, 'utf-8');
      const type = isCodeFile(fileName) ? 'code' : 'doc';
      return [{ path: fileName, content, type }];
  }
}

async function extractZip(filePath) {
  const zip = new AdmZip(filePath);
  const entries = zip.getEntries();
  const files = [];

  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const name = entry.entryName;

    if (isReadableFile(name)) {
      const content = entry.getData().toString('utf-8');
      const type = isCodeFile(name) ? 'code' : 'doc';
      files.push({ path: name, content, type });
    } else if (name.toLowerCase().endsWith('.pdf')) {
      try {
        const pdfBuffer = entry.getData();
        const data = await pdfParse(pdfBuffer);
        files.push({ path: name, content: data.text, type: 'doc' });
      } catch {
        // Skip unreadable PDFs
      }
    }
  }

  return files;
}

async function extractRar(filePath) {
  const buffer = await readFile(filePath);
  const extractor = await createExtractorFromData({ data: buffer });
  const { files: rarFiles } = extractor.extract();
  const files = [];

  for (const file of [...rarFiles]) {
    if (file.fileHeader.flags.directory) continue;
    const name = file.fileHeader.name;

    if (isReadableFile(name)) {
      const content = Buffer.from(file.extraction).toString('utf-8');
      const type = isCodeFile(name) ? 'code' : 'doc';
      files.push({ path: name, content, type });
    }
  }

  return files;
}

async function extractPdf(filePath) {
  const buffer = await readFile(filePath);
  const data = await pdfParse(buffer);
  return data.text;
}

// === URL FETCHING ===

export async function fetchFromUrl(url) {
  try {
    const response = await axios.get(url, {
      timeout: 30000,
      headers: { 'User-Agent': 'Lysander-Agent/1.0' },
      responseType: 'text',
    });

    let text = response.data;

    if (typeof text === 'string' && text.includes('<')) {
      text = text
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }

    return text;
  } catch (error) {
    throw new Error(`Gagal fetch URL: ${error.message}`);
  }
}

// === AGENT ANALYSIS ===

/**
 * Step 2 & 3: Scan & Analyze — LLM analisis source code agent lain
 * Identifikasi skills/kemampuan yang bisa di-clone
 */
async function analyzeAgentSource(extractedFiles) {
  // Build context dari semua file
  let context = '';
  for (const file of extractedFiles) {
    // Truncate per file jika terlalu panjang
    const maxPerFile = 5000;
    const content = file.content.length > maxPerFile
      ? file.content.substring(0, maxPerFile) + '\n[...truncated]'
      : file.content;
    context += `\n=== FILE: ${file.path} (${file.type}) ===\n${content}\n`;
  }

  // Truncate total jika terlalu panjang
  const maxTotal = 30000;
  if (context.length > maxTotal) {
    context = context.substring(0, maxTotal) + '\n\n[...remaining files truncated]';
  }

  const systemPrompt = `You are a code analyst. Your job is to analyze source code from another AI agent/bot and identify the distinct SKILLS or CAPABILITIES it has.

For each skill you identify, provide:
1. A short unique name (snake_case, e.g., "web_scraper", "image_generator")
2. What the skill does (1-2 sentences)
3. The core logic/algorithm (describe how it works)
4. Dependencies required (npm packages, APIs, etc.)
5. Trigger keywords (when would a user want this skill?)

Respond in JSON format:
{
  "agent_name": "name of the agent if identifiable",
  "skills": [
    {
      "name": "skill_name",
      "description": "what it does",
      "logic": "how it works - detailed enough to reimplement",
      "dependencies": ["package1", "package2"],
      "triggers": ["keyword1", "keyword2"]
    }
  ]
}

If you cannot identify any distinct skills, return:
{ "agent_name": "unknown", "skills": [] }

Only return valid JSON. No markdown, no explanation.`;

  const userPrompt = `Analyze this agent's source code and identify its skills:\n${context}`;

  const response = await agentWithSystem(systemPrompt, userPrompt, 'analysis');

  // Parse JSON response
  try {
    // Clean response — remove markdown code blocks if present
    let cleaned = response.trim();
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');
    }
    return JSON.parse(cleaned);
  } catch (parseError) {
    throw new Error(`Gagal parse analisis dari LLM: ${parseError.message}\nRaw: ${response.substring(0, 500)}`);
  }
}

// === CODE GENERATION ===

/**
 * Step 4: Generate — LLM tulis kode skill baru berdasarkan analisis
 */
async function generateSkillCode(skillInfo) {
  const systemPrompt = `You are a code generator. You write JavaScript ES Module skill files for an autonomous Telegram bot agent.

Each skill file must follow this exact structure:

\`\`\`javascript
export default {
  name: 'skill_name',
  description: 'What this skill does',
  version: '1.0.0',
  triggers: ['keyword1', 'keyword2'],
  async execute(context) {
    // context contains: { userMessage, chatId, agentDirect, config }
    // agentDirect(prompt, taskType) — call LLM directly
    // config — bot configuration

    // Your skill logic here

    return {
      success: true,
      result: 'Response to send to user',
    };
  },
};
\`\`\`

Rules:
- Use ES Module syntax (import/export)
- The execute function receives a context object
- Always return { success: boolean, result: string } or { success: false, error: string }
- Use try/catch for error handling
- If the skill needs external packages, add them as dynamic imports with error handling
- Keep it self-contained — don't import from other project files
- Write working, production-ready code

Only output the JavaScript code. No markdown, no explanation, no code blocks.`;

  const userPrompt = `Generate a skill file for:
Name: ${skillInfo.name}
Description: ${skillInfo.description}
Logic: ${skillInfo.logic}
Dependencies: ${JSON.stringify(skillInfo.dependencies)}
Triggers: ${JSON.stringify(skillInfo.triggers)}`;

  const response = await agentWithSystem(systemPrompt, userPrompt, 'code');

  // Clean response
  let code = response.trim();
  if (code.startsWith('```')) {
    code = code.replace(/^```(?:javascript|js)?\n?/, '').replace(/\n?```$/, '');
  }

  return code;
}

// === APPLY & HOT-RELOAD ===

/**
 * Step 5: Apply — tulis skill file dengan proteksi rollback otomatis
 * Delegasi ke safeApplySkill dari hotReload.js:
 *   backup → tulis → test load → rollback kalau gagal
 */
async function applySkill(skillName, skillCode) {
  await ensureSkillsDir();

  const result = await safeApplySkill(skillName, skillCode);

  if (!result.success) {
    const rollbackNote = result.rolledBack
      ? ` (rolled back: ${result.rollbackTo})`
      : '';
    throw new Error(`${result.error}${rollbackNote}`);
  }

  return { fileName: `${skillName}.js`, skill: result.skill };
}

/**
 * Validate generated code — basic syntax check
 */
function validateSkillCode(code) {
  // Must have export default
  if (!code.includes('export default')) {
    return { valid: false, error: 'Missing "export default"' };
  }

  // Must have name property
  if (!code.includes('name:') && !code.includes("name :")) {
    return { valid: false, error: 'Missing "name" property' };
  }

  // Must have execute function
  if (!code.includes('execute')) {
    return { valid: false, error: 'Missing "execute" function' };
  }

  // Basic bracket matching
  const opens = (code.match(/{/g) || []).length;
  const closes = (code.match(/}/g) || []).length;
  if (opens !== closes) {
    return { valid: false, error: `Bracket mismatch: ${opens} opens, ${closes} closes` };
  }

  return { valid: true };
}

// === MAIN UPGRADE FLOWS ===

/**
 * Full upgrade from file — analisis agent lain, clone skills
 * 
 * @param {string} filePath - path ke file yang diupload
 * @param {string} fileName - nama file asli
 * @returns {object} { success, skills: [...], errors: [...] }
 */
export async function upgradeFromFile(filePath, fileName) {
  const result = {
    success: false,
    skills: [],
    errors: [],
    agentName: 'unknown',
  };

  try {
    // Step 1: Extract
    console.log(`[Upgrade] Extracting: ${fileName}`);
    const extractedFiles = await extractFiles(filePath, fileName);

    if (extractedFiles.length === 0) {
      result.errors.push('Tidak ada file yang bisa dibaca dari input.');
      return result;
    }

    console.log(`[Upgrade] Extracted ${extractedFiles.length} files`);

    // Step 2 & 3: Analyze
    console.log(`[Upgrade] Analyzing agent source...`);
    const analysis = await analyzeAgentSource(extractedFiles);
    result.agentName = analysis.agent_name || 'unknown';

    if (!analysis.skills || analysis.skills.length === 0) {
      result.errors.push('Tidak ditemukan skill yang bisa di-clone dari source ini.');
      return result;
    }

    console.log(`[Upgrade] Found ${analysis.skills.length} skills to clone`);

    // Step 4 & 5: Generate & Apply each skill
    for (const skillInfo of analysis.skills) {
      try {
        console.log(`[Upgrade] Generating skill: ${skillInfo.name}`);
        const code = await generateSkillCode(skillInfo);

        // Validate
        const validation = validateSkillCode(code);
        if (!validation.valid) {
          result.errors.push(`${skillInfo.name}: validation failed — ${validation.error}`);
          continue;
        }

        // Apply
        const applied = await applySkill(skillInfo.name, code);
        result.skills.push({
          name: skillInfo.name,
          description: skillInfo.description,
          fileName: applied.fileName,
        });

        console.log(`[Upgrade] ✓ Skill applied: ${skillInfo.name}`);
      } catch (skillError) {
        result.errors.push(`${skillInfo.name}: ${skillError.message}`);
        console.error(`[Upgrade] ✗ Failed: ${skillInfo.name} — ${skillError.message}`);
      }
    }

    result.success = result.skills.length > 0;

  } catch (error) {
    result.errors.push(`Fatal: ${error.message}`);
    console.error(`[Upgrade] Fatal error:`, error);
  } finally {
    // Cleanup uploaded file
    try {
      await unlink(filePath);
    } catch {
      // Ignore
    }
  }

  return result;
}

/**
 * Full upgrade from URL — fetch source, analisis, clone skills
 * 
 * @param {string} url - URL ke source code / repo
 * @returns {object} { success, skills: [...], errors: [...] }
 */
export async function upgradeFromUrl(url) {
  const result = {
    success: false,
    skills: [],
    errors: [],
    agentName: 'unknown',
  };

  try {
    // Fetch content
    console.log(`[Upgrade] Fetching: ${url}`);
    const content = await fetchFromUrl(url);

    if (!content || content.trim().length === 0) {
      result.errors.push('Konten dari URL kosong.');
      return result;
    }

    // Treat as single file
    const extractedFiles = [{ path: url, content, type: 'code' }];

    // Analyze
    console.log(`[Upgrade] Analyzing source from URL...`);
    const analysis = await analyzeAgentSource(extractedFiles);
    result.agentName = analysis.agent_name || 'unknown';

    if (!analysis.skills || analysis.skills.length === 0) {
      result.errors.push('Tidak ditemukan skill yang bisa di-clone dari URL ini.');
      return result;
    }

    console.log(`[Upgrade] Found ${analysis.skills.length} skills`);

    // Generate & Apply
    for (const skillInfo of analysis.skills) {
      try {
        const code = await generateSkillCode(skillInfo);
        const validation = validateSkillCode(code);

        if (!validation.valid) {
          result.errors.push(`${skillInfo.name}: validation failed — ${validation.error}`);
          continue;
        }

        const applied = await applySkill(skillInfo.name, code);
        result.skills.push({
          name: skillInfo.name,
          description: skillInfo.description,
          fileName: applied.fileName,
        });
      } catch (skillError) {
        result.errors.push(`${skillInfo.name}: ${skillError.message}`);
      }
    }

    result.success = result.skills.length > 0;

  } catch (error) {
    result.errors.push(`Fatal: ${error.message}`);
  }

  return result;
}

/**
 * Format upgrade result untuk display ke user
 */
export function formatUpgradeResult(result) {
  let msg = '';

  if (result.success) {
    msg += `✓ Upgrade berhasil dari agent: ${result.agentName}\n\n`;
    msg += `Skills yang di-clone (${result.skills.length}):\n`;
    for (const skill of result.skills) {
      msg += `  • ${skill.name} — ${skill.description}\n`;
    }
  } else {
    msg += `✗ Upgrade gagal.\n`;
  }

  if (result.errors.length > 0) {
    msg += `\nErrors (${result.errors.length}):\n`;
    for (const err of result.errors) {
      msg += `  ⚠ ${err}\n`;
    }
  }

  return msg;
}
