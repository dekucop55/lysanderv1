import TelegramBot from 'node-telegram-bot-api';
import { resolve } from 'path';
import { writeFile, readFile, mkdir, unlink } from 'fs/promises';
import { existsSync } from 'fs';
import { config } from './config.js';
import { agentLoop, agentDirect, agentWithSystem } from './agentLoop.js';
import { clearHistory } from './memory.js';
import { listKnowledge, deleteKnowledge } from './knowledge.js';
import { upgradeFromUrl, upgradeFromFile, formatUpgradeResult } from './selfUpgrade.js';
import { getActiveModel, setActiveModel, listModels, listModelsWithStatus, isModelOnline } from './modelRouter.js';
import { loadAllSkills, getSkillsList, getRegistryInfo, executeSkill, findMatchingSkills } from './skillRegistry.js';
import { rollbackSkill, listBackups, cleanOldBackups } from './hotReload.js';
import { safeApplySkill } from './hotReload.js';

// State for pending file uploads
const pendingUploads = new Map();

/**
 * Handle self-modification requests — agent langsung tulis perubahan ke file
 * Deteksi apakah user meminta modifikasi kode agent, dan jika ya, langsung eksekusi
 */
async function handleSelfModification(chatId, userMessage) {
  const msg = userMessage.toLowerCase();

  // Deteksi keyword modifikasi
  const modKeywords = ['ubah kode', 'modifikasi', 'edit file', 'update file', 'tulis file',
    'ganti kode', 'perbaiki kode', 'tambah fitur', 'hapus fitur', 'ubah sistem',
    'modify', 'rewrite', 'change code', 'update code', 'edit code',
    'tambahkan ke', 'ubah di file', 'tulis ulang'];

  const isModRequest = modKeywords.some(kw => msg.includes(kw));
  if (!isModRequest) return null;

  // Agent akan menganalisis permintaan dan menghasilkan kode perubahan
  const systemPrompt = `Kamu adalah Lysander, autonomous agent dengan FULL WRITE ACCESS ke filesystem.
User meminta kamu melakukan modifikasi pada kode/sistem. Kamu HARUS:
1. Tentukan file mana yang perlu diubah (path relatif dari root project)
2. Tulis kode perubahannya
3. Respond dalam format JSON:

{
  "action": "modify",
  "files": [
    {
      "path": "relative/path/to/file.js",
      "operation": "write_full" | "create_new",
      "content": "full file content here"
    }
  ],
  "summary": "Penjelasan singkat apa yang diubah"
}

Jika kamu tidak yakin file mana yang harus diubah, atau permintaan tidak jelas:
{
  "action": "clarify",
  "message": "Pertanyaan klarifikasi kamu"
}

Root project: ${resolve(config.skillsDir, '..')}
Struktur folder utama:
- src/ — source code utama (agentLoop.js, bot.js, config.js, dll)
- skills/ — skill modules
- knowledge/ — knowledge base files
- data/memory/ — conversation memory

PENTING: Return ONLY valid JSON. No markdown, no explanation outside JSON.`;

  try {
    const response = await agentWithSystem(systemPrompt, userMessage, 'code');

    // Parse response
    let parsed;
    try {
      let cleaned = response.trim();
      if (cleaned.startsWith('```')) {
        cleaned = cleaned.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');
      }
      parsed = JSON.parse(cleaned);
    } catch {
      // Jika gagal parse sebagai JSON, fallback ke chat biasa
      return null;
    }

    if (parsed.action === 'clarify') {
      return parsed.message;
    }

    if (parsed.action === 'modify' && parsed.files && parsed.files.length > 0) {
      const results = [];
      const projectRoot = resolve(config.skillsDir, '..');

      for (const file of parsed.files) {
        const filePath = resolve(projectRoot, file.path);

        // Security check: hanya izinkan tulis di dalam project directory
        if (!filePath.startsWith(projectRoot)) {
          results.push(`⚠ Ditolak: ${file.path} (di luar project directory)`);
          continue;
        }

        try {
          // Pastikan directory ada
          const dir = resolve(filePath, '..');
          if (!existsSync(dir)) {
            await mkdir(dir, { recursive: true });
          }

          await writeFile(filePath, file.content, 'utf-8');
          results.push(`✓ ${file.operation === 'create_new' ? 'Dibuat' : 'Diupdate'}: ${file.path}`);
        } catch (writeErr) {
          results.push(`✗ Gagal: ${file.path} — ${writeErr.message}`);
        }
      }

      return `Modifikasi selesai:\n${results.join('\n')}\n\n${parsed.summary || ''}`;
    }

    return null;
  } catch (error) {
    console.error(`[Bot] Self-modification error:`, error.message);
    return null;
  }
}

// Initialize bot with polling
const bot = new TelegramBot(config.botToken, { polling: true });

// Auth middleware
function isAllowed(msg) {
  return msg.from.id === config.allowedUserId;
}

// Ensure upload directory exists
async function ensureUploadDir() {
  if (!existsSync(config.uploadDir)) {
    await mkdir(config.uploadDir, { recursive: true });
  }
}

// Download file from Telegram
async function downloadTelegramFile(fileId, fileName) {
  await ensureUploadDir();
  const filePath = resolve(config.uploadDir, fileName);
  const fileStream = await bot.getFileStream(fileId);

  const chunks = [];
  for await (const chunk of fileStream) {
    chunks.push(chunk);
  }
  const buffer = Buffer.concat(chunks);
  await writeFile(filePath, buffer);

  return filePath;
}

// === COMMANDS ===

// /start
bot.onText(/\/start/, (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;

  const activeModel = getActiveModel();
  const skillCount = getSkillsList().length;

  bot.sendMessage(chatId,
    `Lysander aktif.\n` +
    `Model: ${activeModel}\n` +
    `Skills: ${skillCount} loaded\n\n` +
    `Commands:\n` +
    `/model — lihat/ganti model aktif\n` +
    `/models — list semua model tersedia\n` +
    `/skills — list skill yang aktif\n` +
    `/upgrade <url> — clone skill dari URL\n` +
    `/rollback <skill> — rollback skill ke versi sebelumnya\n` +
    `/backups — list semua backup\n` +
    `/knowledge — list knowledge\n` +
    `/forget <file> — hapus knowledge\n` +
    `/reset — hapus history chat`
  );
});

// /reset
bot.onText(/\/reset/, async (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  await clearHistory(chatId);
  bot.sendMessage(chatId, 'History percakapan sudah dihapus.');
});

// /model — lihat model aktif, atau /model <name> untuk ganti
bot.onText(/\/model\s*(.*)/, (msg, match) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const target = match[1] ? match[1].trim() : '';

  if (!target) {
    // Tampilkan model aktif
    const active = getActiveModel();
    const model = config.availableModels[active];
    bot.sendMessage(chatId,
      `Model aktif: ${active}\n` +
      `Provider: ${model.provider}\n` +
      `ID: ${model.id}\n` +
      `Capabilities: ${model.capabilities.join(', ')}`
    );
    return;
  }

  // Ganti model
  try {
    const newModel = setActiveModel(target);
    bot.sendMessage(chatId, `Model aktif diganti ke: ${newModel}`);
  } catch (error) {
    bot.sendMessage(chatId, error.message);
  }
});

// /models — list semua model
bot.onText(/\/models/, async (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;

  bot.sendChatAction(chatId, 'typing');
  const models = await listModelsWithStatus();
  let text = 'Model tersedia (Real-time Status):\n\n';

  for (const m of models) {
    const status = m.active ? '● AKTIF' : '○';
    const onlineText = m.online ? '🟢 Online' : '🔴 Offline';
    text += `${status} ${m.name} ${onlineText}\n`;
    text += `  ${m.description}\n`;
    text += `  Capabilities: ${m.capabilities.join(', ')}\n\n`;
  }

  text += 'Ganti model: /model <nama>';
  bot.sendMessage(chatId, text);
});

// /skills — list skill aktif
bot.onText(/\/skills/, (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;

  const skills = getSkillsList();

  if (skills.length === 0) {
    bot.sendMessage(chatId, 'Belum ada skill yang aktif.\nKirim file agent lain untuk upgrade.');
    return;
  }

  let text = `Skills aktif (${skills.length}):\n\n`;
  for (const skill of skills) {
    text += `• ${skill.name} v${skill.version}\n`;
    text += `  ${skill.description}\n`;
    text += `  Triggers: ${skill.triggers.join(', ')}\n\n`;
  }

  bot.sendMessage(chatId, text);
});

// /upgrade <url> — clone skill dari URL
bot.onText(/\/upgrade (.+)/, async (msg, match) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const url = match[1].trim();

  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    bot.sendMessage(chatId, 'URL tidak valid. Harus diawali http:// atau https://');
    return;
  }

  bot.sendMessage(chatId, 'Menganalisis source dari URL... Ini mungkin butuh waktu.');
  bot.sendChatAction(chatId, 'typing');

  try {
    const result = await upgradeFromUrl(url);
    const report = formatUpgradeResult(result);
    bot.sendMessage(chatId, report);
  } catch (error) {
    bot.sendMessage(chatId, `Upgrade gagal: ${error.message}`);
  }
});

// /rollback <skill_name> — rollback skill ke versi sebelumnya
bot.onText(/\/rollback (.+)/, async (msg, match) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const skillName = match[1].trim();

  const result = await rollbackSkill(skillName);
  if (result.success) {
    bot.sendMessage(chatId, `✓ Skill "${skillName}" di-rollback dari: ${result.restoredFrom}`);
  } else {
    bot.sendMessage(chatId, `✗ Rollback gagal: ${result.error}`);
  }
});

// /backups — list semua backup
bot.onText(/\/backups/, async (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;

  const backups = await listBackups();

  if (backups.length === 0) {
    bot.sendMessage(chatId, 'Belum ada backup.');
    return;
  }

  let text = `Backups (${backups.length}):\n\n`;
  for (const b of backups) {
    text += `• ${b.skillName} — ${b.date}\n`;
  }
  text += '\nRollback: /rollback <skill_name>';
  bot.sendMessage(chatId, text);
});

// /knowledge — list knowledge files
bot.onText(/\/knowledge/, async (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const files = await listKnowledge();

  if (files.length === 0) {
    bot.sendMessage(chatId, 'Belum ada knowledge.');
    return;
  }

  const list = files.map((f, i) => `${i + 1}. ${f}`).join('\n');
  bot.sendMessage(chatId, `Knowledge:\n\n${list}`);
});

// /forget <filename>
bot.onText(/\/forget (.+)/, async (msg, match) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const filename = match[1].trim();
  const target = filename.endsWith('.md') ? filename : `${filename}.md`;

  const deleted = await deleteKnowledge(target);
  if (deleted) {
    bot.sendMessage(chatId, `Knowledge "${target}" dihapus.`);
  } else {
    bot.sendMessage(chatId, `Knowledge "${target}" tidak ditemukan.`);
  }
});

// === FILE UPLOAD HANDLER ===

bot.on('document', async (msg) => {
  if (!isAllowed(msg)) return;
  const chatId = msg.chat.id;
  const doc = msg.document;
  const fileName = doc.file_name;
  const ext = fileName.toLowerCase().split('.').pop();

  // Supported extensions — diperluas
  const supported = ['pdf', 'txt', 'md', 'zip', 'rar', 'js', 'ts', 'py', 'jsx', 'tsx', 'json', 'yaml', 'yml'];
  if (!supported.includes(ext)) {
    bot.sendMessage(chatId, `Format .${ext} tidak didukung.\nKirim: .zip, .rar, .pdf, .txt, .js, .py, .ts, .json`);
    return;
  }

  bot.sendMessage(chatId,
    'File diterima. Mau aku apakan?\n' +
    '1. Ketik "upgrade" — analisis & clone skills dari file ini\n' +
    '2. Ketik topik lain — simpan sebagai knowledge biasa'
  );

  // Download file
  try {
    const filePath = await downloadTelegramFile(doc.file_id, fileName);
    pendingUploads.set(chatId, {
      filePath,
      fileName,
      timestamp: Date.now(),
    });
  } catch (error) {
    bot.sendMessage(chatId, `Gagal download file: ${error.message}`);
  }
});

// === MESSAGE HANDLER (utama) ===

bot.on('message', async (msg) => {
  if (!isAllowed(msg)) return;
  if (!msg.text) return;

  const chatId = msg.chat.id;
  const text = msg.text.trim();

  // Skip commands
  if (text.startsWith('/')) return;

  // === Handle pending file upload ===
  if (pendingUploads.has(chatId)) {
    const pending = pendingUploads.get(chatId);
    pendingUploads.delete(chatId);

    if (text.toLowerCase() === 'upgrade') {
      // UPGRADE MODE — analisis & clone skills
      bot.sendMessage(chatId, 'Memulai analisis source code... Mengidentifikasi skills...');
      bot.sendChatAction(chatId, 'typing');

      try {
        const result = await upgradeFromFile(pending.filePath, pending.fileName);
        const report = formatUpgradeResult(result);
        bot.sendMessage(chatId, report);
      } catch (error) {
        bot.sendMessage(chatId, `Upgrade gagal: ${error.message}`);
      }
    } else {
      // KNOWLEDGE MODE — simpan sebagai knowledge biasa (legacy)
      bot.sendMessage(chatId, `Memproses file sebagai knowledge "${text}"...`);
      bot.sendChatAction(chatId, 'typing');

      try {
        // Import legacy summarize function
        const { agentDirect } = await import('./agentLoop.js');
        const { readFile } = await import('fs/promises');

        const content = await readFile(pending.filePath, 'utf-8').catch(() => 'Unable to read file as text.');
        const maxChars = 15000;
        const truncated = content.length > maxChars
          ? content.substring(0, maxChars) + '\n[truncated]'
          : content;

        // Generate optimal filename using agent
        const fileNameSuggestion = await agentDirect(
          `Based on this content, suggest a very short, concise, and descriptive filename (max 3 words, lowercase, no spaces, use underscores). Return ONLY the filename, nothing else. Content: ${truncated}`,
          'analysis'
        );
        const finalTopic = fileNameSuggestion.trim().replace(/[^a-z0-9_]/gi, '');
        
        const summary = await agentDirect(
          `Summarize the following content into structured knowledge points. Keep it concise. Write in English.\n\n${truncated}`,
          'analysis'
        );

        // Save as learned knowledge
        const { saveLearnedKnowledge } = await import('./knowledge.js');
        const filename = await saveLearnedKnowledge(finalTopic || text, summary);
        bot.sendMessage(chatId, `Knowledge "${finalTopic || text}" disimpan: ${filename}`);
      } catch (error) {
        bot.sendMessage(chatId, `Gagal memproses: ${error.message}`);
      }
    }
    return;
  }

  // === Handle self-modification requests ===
  const modResult = await handleSelfModification(chatId, text);
  if (modResult) {
    bot.sendMessage(chatId, modResult);
    return;
  }

  // === Check matching skills ===
  const matchingSkills = findMatchingSkills(text);
  if (matchingSkills.length > 0) {
    // Ada skill yang cocok — execute skill pertama yang cocok
    const skill = matchingSkills[0];
    console.log(`[Bot] Matched skill: ${skill.name}`);

    try {
      bot.sendChatAction(chatId, 'typing');
      const result = await executeSkill(skill.name, {
        userMessage: text,
        chatId,
        agentDirect,
        config,
      });

      if (result.success) {
        bot.sendMessage(chatId, result.result);
      } else {
        // Skill gagal — fallback ke agent loop biasa
        console.log(`[Bot] Skill failed, falling back to agent loop`);
        const agentResult = await agentLoop(chatId, text, { skills: getSkillsList() });
        bot.sendMessage(chatId, agentResult.response);
      }
    } catch (error) {
      bot.sendMessage(chatId, `Error: ${error.message}`);
    }
    return;
  }

  // === Regular chat — agent loop ===
  try {
    bot.sendChatAction(chatId, 'typing');
    const skills = getSkillsList();
    const result = await agentLoop(chatId, text, { skills });
    bot.sendMessage(chatId, result.response);
  } catch (error) {
    bot.sendMessage(chatId, `Error: ${error.message}`);
  }
});

// Error handling
bot.on('polling_error', (error) => {
  console.error('[Lysander] Polling error:', error.code, error.message);
});

// Boot: load all skills
loadAllSkills().then(() => {
  console.log('[Lysander] Bot ready. Skills loaded.');
}).catch((err) => {
  console.error('[Lysander] Failed to load skills:', err.message);
});

export default bot;
