import { readFile, readdir, unlink, writeFile } from 'fs/promises';
import { existsSync } from 'fs';
import { resolve, join } from 'path';
import { config } from './config.js';

export async function loadBaseKnowledge() {
  const basePath = resolve(config.knowledgeDir, 'base.md');
  try {
    const content = await readFile(basePath, 'utf-8');
    return content;
  } catch {
    return '';
  }
}

export async function loadLearnedKnowledge() {
  if (!existsSync(config.learnedDir)) {
    return '';
  }

  try {
    const files = await readdir(config.learnedDir);
    const mdFiles = files.filter(f => f.endsWith('.md'));

    if (mdFiles.length === 0) return '';

    const contents = [];
    for (const file of mdFiles) {
      const filePath = join(config.learnedDir, file);
      const content = await readFile(filePath, 'utf-8');
      contents.push(`## ${file.replace('.md', '')}\n${content}`);
    }

    return contents.join('\n\n');
  } catch {
    return '';
  }
}

export async function getAllKnowledge() {
  const base = await loadBaseKnowledge();
  const learned = await loadLearnedKnowledge();

  let combined = '';
  if (base) combined += base;
  if (learned) combined += '\n\n# Learned Knowledge\n\n' + learned;

  return combined;
}

export async function listKnowledge() {
  if (!existsSync(config.learnedDir)) {
    return [];
  }

  try {
    const files = await readdir(config.learnedDir);
    return files.filter(f => f.endsWith('.md'));
  } catch {
    return [];
  }
}

export async function deleteKnowledge(filename) {
  const filePath = resolve(config.learnedDir, filename);

  if (!filePath.startsWith(config.learnedDir)) {
    throw new Error('Invalid file path');
  }

  if (!existsSync(filePath)) {
    return false;
  }

  await unlink(filePath);
  return true;
}

export async function saveLearnedKnowledge(topic, content) {
  // Bersihkan nama file dari karakter terlarang
  const safeTopic = topic.replace(/[^a-z0-9]/gi, '_').toLowerCase();
  const fileName = `${safeTopic}.md`;
  const filePath = resolve(config.learnedDir, fileName);

  await writeFile(filePath, content, 'utf-8');
  return fileName;
}

