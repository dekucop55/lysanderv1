import { existsSync } from 'fs';
import { mkdir } from 'fs/promises';
import { config } from './config.js';

// Ensure required directories exist
async function ensureDirectories() {
  const dirs = [
    config.uploadDir,
    config.memoryDir,
    config.knowledgeDir,
    config.learnedDir,
    config.skillsDir,
  ];

  for (const dir of dirs) {
    if (!existsSync(dir)) {
      await mkdir(dir, { recursive: true });
    }
  }
}

// Start the bot
async function main() {
  try {
    console.log('[Lysander] Booting...');

    // Create directories
    await ensureDirectories();

    // Import bot (triggers skill loading + polling)
    await import('./bot.js');

    // Status report
    const available = Object.keys(config.availableModels);
    console.log('[Lysander] ══════════════════════════════');
    console.log('[Lysander] Lysander Autonomous Agent');
    console.log('[Lysander] ══════════════════════════════');
    console.log(`[Lysander] Default model: ${config.defaultModel}`);
    console.log(`[Lysander] Available models: ${available.join(', ')}`);
    console.log(`[Lysander] Skills dir: ${config.skillsDir}`);
    console.log(`[Lysander] User ID: ${config.allowedUserId}`);
    console.log('[Lysander] ══════════════════════════════');
    console.log('[Lysander] Ready.');
  } catch (error) {
    console.error('[Lysander] FATAL:', error.message);
    console.error(error.stack);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Lysander] Shutting down...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('[Lysander] Terminated.');
  process.exit(0);
});

// Unhandled rejection handler
process.on('unhandledRejection', (reason, promise) => {
  console.error('[Lysander] Unhandled rejection:', reason);
});

main();
