import { readFile, writeFile, copyFile, mkdir, readdir, unlink, stat } from 'fs/promises';
import { existsSync } from 'fs';
import { resolve, basename } from 'path';
import { config } from './config.js';
import { reloadSkill, unloadSkill, getSkill } from './skillRegistry.js';

/**
 * Hot-Reload & Rollback Manager
 * 
 * Tanggung jawab:
 * - Backup skill sebelum dimodifikasi
 * - Test skill baru bisa di-load tanpa error
 * - Rollback otomatis kalau skill baru crash
 * - Kelola riwayat backup (history)
 */

// Backup directory
function getBackupDir() {
  return resolve(config.skillsDir, '../backups');
}

async function ensureBackupDir() {
  const backupDir = getBackupDir();
  if (!existsSync(backupDir)) {
    await mkdir(backupDir, { recursive: true });
  }
  return backupDir;
}

/**
 * Buat backup dari skill file yang ada
 * @param {string} fileName - nama file skill (e.g., 'web_scraper.js')
 * @returns {string|null} path backup, atau null kalau file tidak ada
 */
export async function backupSkill(fileName) {
  const filePath = resolve(config.skillsDir, fileName);

  if (!existsSync(filePath)) {
    return null; // tidak ada yang perlu di-backup (skill baru)
  }

  const backupDir = await ensureBackupDir();
  const timestamp = Date.now();
  const backupName = `${basename(fileName, '.js')}_${timestamp}.js.bak`;
  const backupPath = resolve(backupDir, backupName);

  await copyFile(filePath, backupPath);
  console.log(`[HotReload] Backup created: ${backupName}`);

  return backupPath;
}

/**
 * Restore skill dari backup file
 * @param {string} backupPath - path ke file backup
 * @param {string} fileName - nama file skill tujuan
 */
async function restoreFromBackup(backupPath, fileName) {
  const filePath = resolve(config.skillsDir, fileName);
  await copyFile(backupPath, filePath);
  console.log(`[HotReload] Restored from backup: ${fileName}`);
}

/**
 * Cari backup terbaru untuk skill tertentu
 * @param {string} skillName - nama skill (tanpa .js)
 * @returns {string|null} path backup terbaru
 */
export async function findLatestBackup(skillName) {
  const backupDir = getBackupDir();
  if (!existsSync(backupDir)) return null;

  const files = await readdir(backupDir);
  const baseName = skillName.replace(/\.js$/, '');

  // Filter backup untuk skill ini: format "skillname_timestamp.js.bak"
  const backups = files
    .filter(f => f.startsWith(`${baseName}_`) && f.endsWith('.js.bak'))
    .map(f => {
      const match = f.match(/_(\d+)\.js\.bak$/);
      return { file: f, timestamp: match ? Number(match[1]) : 0 };
    })
    .sort((a, b) => b.timestamp - a.timestamp);

  if (backups.length === 0) return null;
  return resolve(backupDir, backups[0].file);
}

/**
 * Safe apply: tulis skill baru dengan proteksi rollback
 * 
 * Flow:
 * 1. Backup versi lama (kalau ada)
 * 2. Tulis kode baru
 * 3. Coba hot-reload (test load)
 * 4. Kalau gagal → rollback ke versi lama / hapus file baru
 * 
 * @param {string} skillName - nama skill (tanpa .js)
 * @param {string} skillCode - kode skill baru
 * @returns {object} { success, skill?, error?, rolledBack? }
 */
export async function safeApplySkill(skillName, skillCode) {
  const fileName = `${skillName}.js`;
  const filePath = resolve(config.skillsDir, fileName);

  // Pastikan skills dir ada
  if (!existsSync(config.skillsDir)) {
    await mkdir(config.skillsDir, { recursive: true });
  }

  const isUpdate = existsSync(filePath);
  let backupPath = null;

  // Step 1: Backup versi lama
  if (isUpdate) {
    backupPath = await backupSkill(fileName);
  }

  // Step 2: Tulis kode baru
  try {
    await writeFile(filePath, skillCode, 'utf-8');
  } catch (writeError) {
    return { success: false, error: `Gagal menulis file: ${writeError.message}` };
  }

  // Step 3: Test hot-reload
  try {
    const loaded = await reloadSkill(fileName);

    if (!loaded) {
      throw new Error('Skill gagal di-load (kemungkinan syntax/struktur error).');
    }

    // Sukses
    console.log(`[HotReload] Safe apply sukses: ${skillName}`);
    return { success: true, skill: loaded };

  } catch (loadError) {
    // Step 4: ROLLBACK
    console.error(`[HotReload] Load gagal, rollback: ${loadError.message}`);

    // Unload skill yang error dari registry
    unloadSkill(skillName);

    if (backupPath && existsSync(backupPath)) {
      // Restore versi lama
      await restoreFromBackup(backupPath, fileName);
      await reloadSkill(fileName); // reload versi lama
      return {
        success: false,
        error: loadError.message,
        rolledBack: true,
        rollbackTo: 'previous version',
      };
    } else {
      // Skill baru — hapus file yang error
      try {
        await unlink(filePath);
      } catch {
        // ignore
      }
      return {
        success: false,
        error: loadError.message,
        rolledBack: true,
        rollbackTo: 'removed (was new skill)',
      };
    }
  }
}

/**
 * Manual rollback skill ke versi backup terbaru
 * @param {string} skillName - nama skill
 * @returns {object} { success, error? }
 */
export async function rollbackSkill(skillName) {
  const fileName = `${skillName}.js`;
  const backupPath = await findLatestBackup(skillName);

  if (!backupPath) {
    return { success: false, error: `Tidak ada backup untuk skill "${skillName}".` };
  }

  try {
    await restoreFromBackup(backupPath, fileName);
    const loaded = await reloadSkill(fileName);

    if (!loaded) {
      return { success: false, error: 'Backup di-restore tapi gagal di-load.' };
    }

    return { success: true, restoredFrom: basename(backupPath) };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

/**
 * List semua backup yang tersedia
 * @returns {Array} [{ skillName, fileName, timestamp, date }]
 */
export async function listBackups() {
  const backupDir = getBackupDir();
  if (!existsSync(backupDir)) return [];

  const files = await readdir(backupDir);
  const backups = [];

  for (const file of files) {
    if (!file.endsWith('.js.bak')) continue;
    const match = file.match(/^(.+)_(\d+)\.js\.bak$/);
    if (match) {
      const timestamp = Number(match[2]);
      backups.push({
        skillName: match[1],
        fileName: file,
        timestamp,
        date: new Date(timestamp).toISOString(),
      });
    }
  }

  return backups.sort((a, b) => b.timestamp - a.timestamp);
}

/**
 * Bersihkan backup lama, simpan hanya N terbaru per skill
 * @param {number} keepPerSkill - jumlah backup yang disimpan per skill (default 3)
 */
export async function cleanOldBackups(keepPerSkill = 3) {
  const backups = await listBackups();
  const backupDir = getBackupDir();

  // Group by skill
  const bySkill = {};
  for (const b of backups) {
    if (!bySkill[b.skillName]) bySkill[b.skillName] = [];
    bySkill[b.skillName].push(b);
  }

  let removed = 0;
  for (const skillName of Object.keys(bySkill)) {
    const list = bySkill[skillName].sort((a, b) => b.timestamp - a.timestamp);
    const toRemove = list.slice(keepPerSkill); // sisanya dihapus

    for (const b of toRemove) {
      try {
        await unlink(resolve(backupDir, b.fileName));
        removed++;
      } catch {
        // ignore
      }
    }
  }

  if (removed > 0) {
    console.log(`[HotReload] Cleaned ${removed} old backups.`);
  }

  return removed;
}
