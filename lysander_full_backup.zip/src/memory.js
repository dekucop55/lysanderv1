import { readFile, writeFile, unlink, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { resolve } from 'path';
import { config } from './config.js';

function getFilePath(chatId) {
  return resolve(config.memoryDir, `${chatId}.json`);
}

async function ensureDir() {
  if (!existsSync(config.memoryDir)) {
    await mkdir(config.memoryDir, { recursive: true });
  }
}

export async function loadHistory(chatId) {
  const filePath = getFilePath(chatId);
  try {
    const data = await readFile(filePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export async function saveHistory(chatId, messages) {
  await ensureDir();
  const filePath = getFilePath(chatId);
  await writeFile(filePath, JSON.stringify(messages, null, 2), 'utf-8');
}

export async function addMessage(chatId, role, content) {
  const history = await loadHistory(chatId);
  history.push({ role, content });

  // Keep only last maxHistory messages
  const trimmed = history.slice(-config.maxHistory);
  await saveHistory(chatId, trimmed);
  return trimmed;
}

export async function getHistory(chatId) {
  const history = await loadHistory(chatId);
  return history.slice(-config.maxHistory);
}

export async function clearHistory(chatId) {
  const filePath = getFilePath(chatId);
  try {
    await unlink(filePath);
  } catch {
    // File doesn't exist, nothing to clear
  }
}
