import axios from 'axios';
import { config } from './config.js';

/**
 * Model Router — sistem pemilihan model aktif
 * 
 * Bukan fallback. Bot MEMILIH model berdasarkan:
 * 1. Task type (chat, code, analysis, self-modification)
 * 2. Ketersediaan model (cek koneksi)
 * 3. Override manual dari user (/model <name>)
 */

// State: model yang sedang aktif
let activeModel = config.defaultModel;

// Get current active model name
export function getActiveModel() {
  return activeModel;
}

// Set active model manually
export function setActiveModel(modelName) {
  if (!config.models[modelName]) {
    throw new Error(`Model "${modelName}" tidak dikenal. Available: ${Object.keys(config.availableModels).join(', ')}`);
  }
  if (!config.availableModels[modelName]) {
    throw new Error(`Model "${modelName}" tidak tersedia (API key missing?). Available: ${Object.keys(config.availableModels).join(', ')}`);
  }
  activeModel = modelName;
  return activeModel;
}

// List semua model yang tersedia dengan status online aktual
export async function listModelsWithStatus() {
  const result = [];
  const models = Object.entries(config.availableModels);
  
  const statusChecks = models.map(async ([name, model]) => {
    const online = await isModelOnline(name);
    return {
      name,
      id: model.id,
      provider: model.provider,
      capabilities: model.capabilities,
      description: model.description,
      active: name === activeModel,
      online,
    };
  });
  
  return await Promise.all(statusChecks);
}

// List semua model (versi cepat/sinkron)
export function listModels() {
  const result = [];
  for (const [name, model] of Object.entries(config.availableModels)) {
    result.push({
      name,
      id: model.id,
      provider: model.provider,
      capabilities: model.capabilities,
      description: model.description,
      active: name === activeModel,
    });
  }
  return result;
}

// Pilih model terbaik berdasarkan task type
export function selectModelForTask(taskType) {
  const available = Object.entries(config.availableModels);

  // Cari model yang punya capability untuk task ini
  const capable = available.filter(([_, model]) =>
    model.capabilities.includes(taskType)
  );

  if (capable.length === 0) {
    // Fallback ke active model
    return activeModel;
  }

  // Sort by priority (lower = better)
  capable.sort((a, b) => a[1].priority - b[1].priority);
  return capable[0][0];
}

// === PROVIDER IMPLEMENTATIONS ===

// Chat via Ollama (local)
async function chatOllama(model, messages) {
  const response = await axios.post(`${model.baseUrl}/api/chat`, {
    model: model.id,
    messages,
    stream: false,
  }, { 
    timeout: 120000,
    headers: {
      'Authorization': `Bearer ${model.apiKey}`,
      'Content-Type': 'application/json'
    }
  });

  return response.data.message.content;
}

// Chat via OpenRouter
async function chatOpenRouter(model, messages) {
  const response = await axios.post(
    `${model.baseUrl}/chat/completions`,
    {
      model: model.id,
      messages,
    },
    {
      headers: {
        'Authorization': `Bearer ${model.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://github.com/Randompeople1265/TestAgent',
        'X-OpenRouter-Title': 'Lysander Agent',
      },
      timeout: 120000,
    }
  );

  return response.data.choices[0].message.content;
}

// Chat via Kiro API
async function chatKiro(model, messages) {
  const response = await axios.post(
    `${model.baseUrl}/chat/completions`,
    {
      model: model.id,
      messages,
    },
    {
      headers: {
        'Authorization': `Bearer ${model.apiKey}`,
        'Content-Type': 'application/json',
      },
      timeout: 120000,
    }
  );

  return response.data.choices[0].message.content;
}

// === MAIN ROUTER ===

/**
 * Kirim chat ke model tertentu
 * @param {string} modelName - nama model (ollama, openrouter, kiro) atau null untuk active model
 * @param {Array} messages - array of {role, content}
 * @returns {string} response text
 */
export async function routeChat(modelName, messages) {
  const name = modelName || activeModel;
  const model = config.availableModels[name];

  if (!model) {
    throw new Error(`Model "${name}" tidak tersedia.`);
  }

  console.log(`[Router] Using model: ${name} (${model.id})`);

  switch (model.provider) {
    case 'ollama':
      return await chatOllama(model, messages);
    case 'openrouter':
      return await chatOpenRouter(model, messages);
    case 'kiro':
      return await chatKiro(model, messages);
    default:
      throw new Error(`Unknown provider: ${model.provider}`);
  }
}

/**
 * Kirim chat dengan auto-select model berdasarkan task type
 * Jika model pertama gagal, coba model lain yang tersedia
 * @param {string} taskType - tipe task (chat, code, analysis, reasoning, self-modification)
 * @param {Array} messages - array of {role, content}
 * @returns {string} response text
 */
export async function routeChatSmart(taskType, messages) {
  const primaryModel = selectModelForTask(taskType);
  const allModels = Object.keys(config.availableModels);

  // Coba primary model dulu
  try {
    return await routeChat(primaryModel, messages);
  } catch (primaryError) {
    console.log(`[Router] ${primaryModel} gagal: ${primaryError.message}`);

    // Coba model lain yang tersedia
    for (const name of allModels) {
      if (name === primaryModel) continue;
      try {
        console.log(`[Router] Trying alternative: ${name}`);
        return await routeChat(name, messages);
      } catch (altError) {
        console.log(`[Router] ${name} juga gagal: ${altError.message}`);
        continue;
      }
    }

    throw new Error(`Semua model gagal. Primary (${primaryModel}): ${primaryError.message}`);
  }
}

/**
 * Cek apakah model tertentu online/tersedia
 * @param {string} modelName
 * @returns {boolean}
 */
export async function isModelOnline(modelName) {
  const model = config.availableModels[modelName];
  if (!model) return false;

  try {
    if (model.provider === 'ollama') {
      await axios.get(`${model.baseUrl}/api/tags`, { timeout: 5000 });
      return true;
    } else if (model.provider === 'openrouter') {
      await axios.get(`${model.baseUrl}/models`, { timeout: 5000 });
      return true;
    } else if (model.provider === 'kiro') {
      await axios.get(`${model.baseUrl}/models`, { timeout: 5000 });
      return true;
    } else {
      await axios.get(model.baseUrl, { timeout: 5000 });
      return true;
    }
  } catch (error) {
    return error.response !== undefined;
  }
}
