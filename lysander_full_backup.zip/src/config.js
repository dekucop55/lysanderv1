import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: resolve(__dirname, '../.env') });

const required = ['BOT_TOKEN', 'ALLOWED_USER_ID'];

for (const key of required) {
  if (!process.env[key]) {
    throw new Error(`Missing required environment variable: ${key}`);
  }
}

// Model definitions — setiap model punya provider, id, dan kapabilitas
const models = {
  ollama: {
    provider: 'ollama',
    id: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
    baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
    apiKey: process.env.OLLAMA_API_KEY || '',
    capabilities: ['chat', 'reasoning', 'code', 'analysis'],
    priority: 1,
    description: 'Ollama Cloud model — Gemma 4 high performance',
  },
  openrouter: {
    provider: 'openrouter',
    id: process.env.OPENROUTER_MODEL || 'moonshotai/kimi-k2.6:free',
    baseUrl: process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
    apiKey: process.env.OPENROUTER_API_KEY || '',
    capabilities: ['chat', 'reasoning', 'code', 'analysis', 'long-context'],
    priority: 2,
    description: 'OpenRouter cloud model — free tier, good for long context',
  },
  kiro: {
    provider: 'kiro',
    id: process.env.KIRO_MODEL || 'kiro-default',
    baseUrl: process.env.KIRO_BASE_URL || 'https://api.kiro.dev/v1',
    apiKey: process.env.KIRO_API_KEY || '',
    capabilities: ['chat', 'reasoning', 'code', 'analysis', 'self-modification'],
    priority: 3,
    description: 'Kiro API — advanced reasoning and code generation',
  },
};

// Filter hanya model yang punya API key / tersedia
function getAvailableModels() {
  const available = {};
  for (const [name, model] of Object.entries(models)) {
    if (model.provider === 'ollama') {
      // Ollama selalu tersedia (cek koneksi nanti di runtime)
      available[name] = model;
    } else if (model.apiKey) {
      available[name] = model;
    }
  }
  return available;
}

export const config = {
  // Core
  botToken: process.env.BOT_TOKEN,
  allowedUserId: Number(process.env.ALLOWED_USER_ID),

  // Models
  models,
  availableModels: getAvailableModels(),
  defaultModel: process.env.DEFAULT_MODEL || 'ollama', // model default untuk chat biasa

  // Directories
  workspace: '/root/lysanderv1/',
  uploadDir: resolve('/root/lysanderv1/', 'uploads'),
  memoryDir: resolve('/root/lysanderv1/', 'data/memory'),
  knowledgeDir: resolve('/root/lysanderv1/', 'knowledge'),
  learnedDir: resolve('/root/lysanderv1/', 'knowledge/learned'),
  skillsDir: resolve('/root/lysanderv1/', 'skills'),

  // Settings
  maxHistory: 20,
};
