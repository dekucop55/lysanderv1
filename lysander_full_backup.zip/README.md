# Lysander — Telegram Ollama Agent

Autonomous Telegram bot powered by Ollama (Hermes3) running locally on WSL.

## Features

- Local LLM via Ollama (Hermes3)
- OpenRouter fallback (Kimi K2.6 free)
- Persistent conversation memory
- Self-upgrade from URL or file uploads (PDF, TXT, ZIP, RAR)
- Knowledge base management
- Private bot — single user only

## Requirements

- Node.js v18+
- Ollama installed and running in WSL
- Telegram Bot Token (from @BotFather)
- Telegram User ID (from @userinfobot)

## Setup

### 1. Install Ollama (WSL)

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama pull hermes3
```

### 2. Clone and Install

```bash
cd /home/acer
git clone https://github.com/Randompeople1265/TestAgent.git
cd TestAgent/telegram-ollama-agent
npm install
```

### 3. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your values:

```env
BOT_TOKEN=your_bot_token_here
ALLOWED_USER_ID=your_telegram_user_id_here
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=hermes3
OPENROUTER_API_KEY=your_openrouter_key_here
OPENROUTER_MODEL=moonshotai/kimi-k2.6:free
```

### 4. Run

```bash
# Make sure Ollama is running first
ollama serve

# In another terminal, start the bot
npm start
```

Development mode (auto-restart on file changes):

```bash
npm run dev
```

## Commands

| Command | Description |
|---------|-------------|
| `/start` | Activate Lysander |
| `/reset` | Clear conversation history |
| `/model` | Show active model info |
| `/upgrade <url>` | Learn from a URL |
| `/knowledge` | List learned knowledge |
| `/forget <name>` | Delete specific knowledge |

## Self-Upgrade

### From URL

```
/upgrade https://docs.example.com/topic
```

### From File

Send a file (.pdf, .txt, .zip, .rar) directly in chat. Lysander will ask for the topic name, then process and store the knowledge.

## Project Structure

```
telegram-ollama-agent/
├── src/
│   ├── index.js           # Entry point
│   ├── bot.js             # Telegram bot handlers
│   ├── ollama.js          # LLM client (Ollama + OpenRouter)
│   ├── memory.js          # Persistent conversation history
│   ├── knowledge.js       # Knowledge base manager
│   ├── selfUpgrade.js     # Self-upgrade logic
│   └── config.js          # Configuration loader
├── knowledge/
│   ├── base.md            # Core identity
│   └── learned/           # Learned knowledge files
├── data/
│   └── memory/            # Chat history (JSON per user)
├── uploads/               # Temporary file storage
├── .env.example           # Environment template
├── .gitignore
├── package.json
└── README.md
```

## VSCode + WSL

Open the project in VSCode via WSL:

```bash
code /home/acer/TestAgent/telegram-ollama-agent
```

Or from Windows, open VSCode and use "Remote - WSL: Open Folder" to navigate to:

```
\\wsl.localhost\Ubuntu\home\acer\TestAgent\telegram-ollama-agent
```

## License

Private project.
