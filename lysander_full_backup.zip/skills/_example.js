/**
 * Contoh skill template.
 * Setiap skill HARUS export object dengan struktur ini.
 * 
 * File ini tidak akan di-load (prefix underscore = diabaikan oleh registry).
 */

export default {
  // Nama skill (unique identifier)
  name: 'example_skill',

  // Deskripsi singkat — akan dibaca agent untuk tahu kapan pakai skill ini
  description: 'Contoh skill template. Tidak melakukan apa-apa.',

  // Versi skill
  version: '1.0.0',

  // Kapan skill ini relevan? Agent akan cek keyword ini.
  triggers: ['contoh', 'example', 'test'],

  // Fungsi utama skill
  // @param {object} context - { userMessage, chatId, agentDirect, config }
  // @returns {object} { success, result, error? }
  async execute(context) {
    return {
      success: true,
      result: 'Ini adalah contoh skill. Ganti dengan logika kamu.',
    };
  },
};
