/**
 * System Executor Skill
 * 
 * Memungkinkan agent untuk menjalankan command shell dan operasi file 
 * secara nyata di sistem VPS.
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import { writeFile, readFile, mkdir } from 'fs/promises';
import { resolve } from 'path';
import { config } from '../src/config.js';

const execPromise = promisify(exec);

export default {
  name: 'system_executor',
  description: 'Eksekusi command shell, tulis file, dan kelola filesystem VPS secara langsung.',
  version: '1.0.0',
  triggers: ['jalankan', 'execute', 'write file', 'ubah kode', 'mkdir', 'npm install', 'pm2 restart', 'cat'],

  /**
   * Execute action
   * @param {object} context { userMessage, command, filePath, content, action }
   */
  async execute(context) {
    const { action, command, filePath, content } = context;

    try {
      if (action === 'shell') {
        console.log(`[SystemExecutor] Running shell: ${command}`);
        const { stdout, stderr } = await execPromise(command);
        return { 
          success: true, 
          result: stdout || stderr || 'Command executed successfully with no output.' 
        };
      }

      if (action === 'writeFile') {
        const absolutePath = resolve(filePath);
        console.log(`[SystemExecutor] Writing file: ${absolutePath}`);
        await writeFile(absolutePath, content);
        return { success: true, result: `File successfully written to ${absolutePath}` };
      }

      if (action === 'readFile') {
        const absolutePath = resolve(filePath);
        console.log(`[SystemExecutor] Reading file: ${absolutePath}`);
        const data = await readFile(absolutePath, 'utf8');
        return { success: true, result: data };
      }

      if (action === 'mkdir') {
        const absolutePath = resolve(filePath);
        console.log(`[SystemExecutor] Creating directory: ${absolutePath}`);
        await mkdir(absolutePath, { recursive: true });
        return { success: true, result: `Directory created: ${absolutePath}` };
      }

      return { success: false, error: `Action ${action} not supported by system_executor.` };
    } catch (error) {
      console.error(`[SystemExecutor] Error:`, error.message);
      return { success: false, error: error.message };
    }
  }
};
