module.exports = {
  apps: [{
    name: 'lysander-bot',
    script: 'src/bot.js',
    cwd: '/home/root/lysander-bot', // Update this path to your actual folder path on VPS
    interpreter: 'node',
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
    },
    log_output_path: 'logs/out.log',
    error_log_path: 'logs/err.log',
    merge_logs: true,
  }]
};