#!/bin/bash

# Lysander Sovereign Agent Deployment Script v3.1
# Targeted for VPS deployment with local Ollama instance

set -e

echo "--- [STARTING LYSANDER DEPLOYMENT] ---"

# 1. Update System & Install Dependencies
echo "[1/6] Updating system and installing core deps..."
sudo apt-get update && sudo apt-get upgrade -y
sudo apt-get install -y curl wget git build-essential python3 python3-pip

# 2. Install Node.js (LTS)
echo "[2/6] Installing Node.js LTS..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 3. Install PM2 (Process Manager)
echo "[3/6] Installing PM2 for persistent process..."
sudo npm install -g pm2

# 4. Setup Ollama (Local Inference)
echo "[4/6] Installing Ollama..."
if ! command -v ollama &> /dev/null; then
    curl -fsSL https://ollama.com/install.sh | sh
    sudo systemctl enable ollama
    sudo systemctl start ollama
else
    echo "Ollama already installed. Skipping..."
fi

# 5. Initialize Project
echo "[5/6] Initializing project environment..."
# Assuming the files are extracted into the current directory
npm install

# 6. Model Pre-loading (Pulling the models requested by the Raja)
echo "[6/6] Pre-loading local models..."
ollama pull hermes3:8b
ollama pull qwen2.5:7b

echo "--- [DEPLOYMENT COMPLETE] ---"
echo "Next steps:"
echo "1. Edit .env file with your BOT_TOKEN, ALLOWED_USER_ID and API Keys."
echo "2. Start agent: pm2 start index.js --name lysander-agent"
echo "3. Save PM2 list: pm2 save"
echo "4. Setup boot: pm2 startup"
