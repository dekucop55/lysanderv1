// src/skills/m2.js — VPS, infra, deployment, self-upgrade (EXECUTION MODE)
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

const execAsync = promisify(exec);

/**
 * Detect if query is a direct VPS action command (read file, run command, check status)
 * vs a general question that needs LLM advisory.
 */
function detectVpsIntent(query) {
  const lower = query.toLowerCase().trim();

  // READ FILE patterns
  const readPatterns = [
    /(?:baca|lihat|tampilkan|show|cat|read|akses|buka|cek isi)\s+(?:file|isi)\s+(.+)/i,
    /(?:cat|head|tail|less|more)\s+(.+)/i,
    /(?:isi|content|konten)\s+(?:file|dari)\s+(.+)/i,
  ];
  for (const p of readPatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'READ_FILE', target: m[1].trim().replace(/[`"']/g, '') };
  }

  // RUN COMMAND patterns
  const cmdPatterns = [
    /(?:jalankan|run|execute)\s+(?:command|perintah|cmd)\s*[:`]?\s*(.+)/i,
    /^(?:pm2|systemctl|docker|nginx|ufw|htop|df|du|free|uptime|whoami|ls|pwd|ps|npm|npx|node|pip|apt|curl|wget)\b(.*)$/i,
    /(?:cek|check)\s+(?:status|log|disk|memory|ram|cpu|port|process|service)\s*(.*)/i,
    /(?:restart|stop|start|reload)\s+(?:bot|raja-bot|raja|service|pm2|nginx|docker)\s*(.*)/i,
    /(?:pm2\s+(?:flush|restart|stop|start|reload|logs|status|delete|save))\s*(.*)/i,
  ];
  for (const p of cmdPatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'RUN_CMD', command: m[0].trim() };
  }

  // INSTALL PACKAGE patterns (separate — extract only package names, not whole sentence)
  const installMatch = lower.match(/(?:install|pasang)\s+(?:package|paket|module|modul)?\s*([@\w][\w./-]*(?:\s+[@\w][\w./-]*)*)/i);
  if (installMatch) {
    // Only take valid package name tokens (words with @, -, /, .)
    const rawPkgs = installMatch[1].split(/\s+/).filter(w => /^[@\w][\w./-]*$/.test(w));
    if (rawPkgs.length > 0) {
      return { intent: 'RUN_CMD', command: `npm install ${rawPkgs.join(' ')}` };
    }
  }

  // LOG ACCESS patterns
  const logPatterns = [
    /(?:akses|baca|lihat|show|tampilkan|berikan|kasih)\s+(?:log|logs|error log|tampilan log)/i,
    /(?:pm2 logs|journalctl|tail.*log)/i,
    /(?:cek|check)\s+(?:error|log|logs)/i,
    /(?:berikan|tampilkan|kasih|show)\s+(?:tampilan|isi|output)\s+log/i,
    /\blog\s+vps\b/i,
  ];
  for (const p of logPatterns) {
    if (p.test(lower)) return { intent: 'READ_LOG' };
  }

  // LIST FILES patterns
  const lsPatterns = [
    /(?:list|ls|daftar)\s+(?:file|folder|dir|isi)\s+(.+)/i,
    /(?:apa aja|apa saja)\s+(?:di|dalam|file)\s+(.+)/i,
  ];
  for (const p of lsPatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'LIST_DIR', target: m[1].trim().replace(/[`"']/g, '') };
  }

  // WRITE FILE patterns
  const writePatterns = [
    /(?:tulis|write|buat|create|bikin)\s+(?:file|text|txt)\s+(.+)/i,
    /(?:buat|bikin|create)\s+(.+\.(?:txt|md|json|js|sh|py|log|cfg|conf|ini))/i,
    /(?:simpan|save|taruh)\s+(?:file|teks|text)\s+(.+)/i,
  ];
  for (const p of writePatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'WRITE_FILE', target: m[1].trim() };
  }

  // DELETE FILE patterns
  const deletePatterns = [
    /(?:hapus|delete|remove|rm|buang|sikat)\s+(?:file\s+)?(.+\.[\w]+)/i,
    /(?:rm\s+-[rf]+)\s+(.+)/i,
  ];
  for (const p of deletePatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'DELETE_FILE', target: m[1].trim().replace(/[`"']/g, '') };
  }

  // APPEND FILE patterns (must be before EDIT to avoid overlap)
  const appendPatterns = [
    /(?:tambahkan|append|tambah)\s+(?:teks|text|isi|baris|line)?\s*["""]?(.+?)["""]?\s+(?:ke|to|di|into)\s+(?:file\s+)?(.+)/i,
    /(?:append|tambahkan)\s+(?:ke|to)\s+(.+)/i,
  ];
  for (const p of appendPatterns) {
    const m = lower.match(p);
    if (m) {
      if (m.length >= 3) return { intent: 'APPEND_FILE', content: m[1].trim(), target: m[2].trim().replace(/[`"']/g, '') };
      return { intent: 'APPEND_FILE', target: m[1].trim().replace(/[`"']/g, ''), content: null };
    }
  }

  // EDIT FILE patterns
  const editPatterns = [
    /(?:edit|ubah|modif|modify|ganti isi|update isi|perbarui)\s+(?:file\s+)?(.+\.[\w]+)/i,
    /(?:ubah|ganti|replace)\s+(.+)\s+(?:di|dalam|in)\s+(?:file\s+)?(.+\.[\w]+)/i,
  ];
  for (const p of editPatterns) {
    const m = lower.match(p);
    if (m) return { intent: 'EDIT_FILE', target: (m[2] || m[1]).trim().replace(/[`"']/g, '') };
  }

  return { intent: null };
}

/**
 * Safely execute a shell command with timeout
 */
async function safeExec(command, timeout = 15000) {
  try {
    const { stdout, stderr } = await execAsync(command, {
      cwd: config.raja.home || '/opt/raja-bot',
      timeout,
      maxBuffer: 1024 * 1024, // 1MB
    });
    return { ok: true, output: (stdout || stderr || '').trim() };
  } catch (err) {
    return { ok: false, output: err.message || String(err) };
  }
}

/**
 * Safely read a file
 */
function safeReadFile(filePath, maxLines = 100) {
  try {
    // Resolve path (allow absolute or relative to RAJA_HOME)
    let resolved = filePath;
    if (!path.isAbsolute(filePath)) {
      resolved = path.join(config.raja.home || '/opt/raja-bot', filePath);
    }

    if (!fs.existsSync(resolved)) {
      return { ok: false, output: `File not found: ${resolved}` };
    }

    const stat = fs.statSync(resolved);
    if (stat.isDirectory()) {
      const entries = fs.readdirSync(resolved);
      return { ok: true, output: `📁 ${resolved}\n${entries.map(e => `  ${e}`).join('\n')}` };
    }

    // Limit large files
    const content = fs.readFileSync(resolved, 'utf8');
    const lines = content.split('\n');
    if (lines.length > maxLines) {
      return { ok: true, output: `📄 ${resolved} (${lines.length} lines, showing last ${maxLines}):\n\n${lines.slice(-maxLines).join('\n')}` };
    }
    return { ok: true, output: `📄 ${resolved}:\n\n${content}` };
  } catch (err) {
    return { ok: false, output: `Error reading file: ${err.message}` };
  }
}

export default {
  id: 'm2',
  name: 'vps-deploy',
  description: 'VPS shell execution, file access, sysadmin, Docker, Nginx, systemd, deployment, self-upgrade',
  keywords: {
    'akses file': 3, 'baca file': 3, 'cat file': 3, 'read file': 3,
    'lihat log': 3, 'akses log': 3, 'cek log': 3, 'pm2 logs': 3,
    'jalankan command': 3, 'run command': 3, 'eksekusi': 2,
    'list file': 3, 'ls': 2, 'isi folder': 3,
    'cek disk': 3, 'cek memory': 3, 'cek status': 2,
    'restart bot': 3, 'restart service': 3,
  },

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    // 1. Detect if this is an actionable VPS command
    const intent = detectVpsIntent(query);

    // 2. Execute based on intent
    switch (intent.intent) {
      case 'READ_FILE': {
        const result = safeReadFile(intent.target);
        if (result.ok) return result.output;
        return `❌ ${result.output}`;
      }

      case 'READ_LOG': {
        // Read PM2 logs or bot logs
        const logDir = config.raja.logDir || '/opt/raja-bot/logs';
        let logContent = '';

        // Try PM2 logs first
        const pm2Result = await safeExec('pm2 logs raja-bot --nostream --lines 50');
        if (pm2Result.ok && pm2Result.output) {
          logContent = pm2Result.output;
        } else {
          // Fallback to log files
          const result = safeReadFile(logDir);
          if (result.ok) logContent = result.output;
          else logContent = 'No logs available.';
        }

        return `📋 Recent Logs:\n\n${logContent.substring(0, 3500)}`;
      }

      case 'RUN_CMD': {
        // Translate common natural language to actual shell commands
        let cmd = intent.command;
        const cmdLower = cmd.toLowerCase();
        if (/restart\s+(raja-bot|raja|bot)/i.test(cmdLower)) cmd = 'pm2 restart raja-bot';
        else if (/stop\s+(raja-bot|raja|bot)/i.test(cmdLower)) cmd = 'pm2 stop raja-bot';
        else if (/start\s+(raja-bot|raja|bot)/i.test(cmdLower)) cmd = 'pm2 start raja-bot';
        else if (/reload\s+(raja-bot|raja|bot)/i.test(cmdLower)) cmd = 'pm2 reload raja-bot';
        else if (/cek\s+status/i.test(cmdLower)) cmd = 'pm2 status';
        else if (/cek\s+(disk|storage)/i.test(cmdLower)) cmd = 'df -h';
        else if (/cek\s+(memory|ram)/i.test(cmdLower)) cmd = 'free -h';
        else if (/cek\s+cpu/i.test(cmdLower)) cmd = 'top -bn1 | head -20';
        else if (/cek\s+(log|logs)/i.test(cmdLower)) cmd = 'pm2 logs raja-bot --nostream --lines 30';
        else if (/cek\s+port/i.test(cmdLower)) cmd = 'ss -tlnp';
        else if (/cek\s+(process|proses)/i.test(cmdLower)) cmd = 'pm2 status';

        // Execute the command
        const result = await safeExec(cmd, 120000); // 2min timeout for installs
        if (result.ok) {
          return `✅ \`${cmd}\`\n\`\`\`\n${result.output.substring(0, 3500)}\n\`\`\``;
        }
        return `❌ Command failed: \`${cmd}\`\n${result.output.substring(0, 2000)}`;
      }

      case 'LIST_DIR': {
        const result = safeReadFile(intent.target);
        return result.ok ? result.output : `❌ ${result.output}`;
      }

      case 'DELETE_FILE': {
        let targetPath = intent.target;
        if (!path.isAbsolute(targetPath)) {
          targetPath = path.join(config.raja.home || '/opt/raja-bot', targetPath);
        }
        // Safety: don't allow deleting critical files
        const PROTECTED = ['.env', 'package.json', 'package-lock.json', 'src/core/brain.js', 'src/core/skill-registry.js'];
        const relative = path.relative(config.raja.home || '/opt/raja-bot', targetPath);
        if (PROTECTED.some(p => relative === p || relative.startsWith('node_modules'))) {
          return `❌ File \`${relative}\` protected. Gak bisa dihapus via chat.`;
        }
        if (!fs.existsSync(targetPath)) {
          return `❌ File tidak ditemukan: \`${targetPath}\``;
        }
        try {
          const stat = fs.statSync(targetPath);
          if (stat.isDirectory()) {
            fs.rmSync(targetPath, { recursive: true, force: true });
          } else {
            fs.unlinkSync(targetPath);
          }
          return `✅ Deleted: \`${targetPath}\``;
        } catch (delErr) {
          return `❌ Gagal hapus: ${delErr.message}`;
        }
      }

      case 'WRITE_FILE': {
        // For simple write operations, use LLM to determine filename + content, then write directly
        const { callCascade: llmCall } = await import('../llm/cascade.js');
        const writeMessages = [
          {
            role: 'system',
            content: `Kamu adalah RAJA. User minta buat/tulis file di VPS. Extract filename dan content dari instruksi.
JAWAB HANYA DENGAN JSON: {"filename": "path/atau/nama.ext", "content": "isi file"}
Kalau path tidak absolute, asumsikan relative dari /opt/raja-bot/.
Kalau user bilang "folder raja-bot" atau "di bot" = /opt/raja-bot/
JANGAN tambahkan penjelasan apapun di luar JSON.`,
          },
          { role: 'user', content: query },
        ];
        try {
          const writeResult = await llmCall(writeMessages, { maxTokens: 500, temperature: 0.1 });
          const jsonMatch = writeResult.text.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const { filename, content } = JSON.parse(jsonMatch[0]);
            let targetPath = filename;
            if (!path.isAbsolute(targetPath)) {
              targetPath = path.join(config.raja.home || '/opt/raja-bot', targetPath);
            }
            fs.mkdirSync(path.dirname(targetPath), { recursive: true });
            fs.writeFileSync(targetPath, content, 'utf8');
            return `✅ File ditulis: \`${targetPath}\`\nIsi: ${content.substring(0, 200)}`;
          }
          return '❌ Gagal parse instruksi write. Coba lebih spesifik: "buat file [nama] isi [konten]"';
        } catch (writeErr) {
          return `❌ Gagal write file: ${writeErr.message}`;
        }
      }

      case 'APPEND_FILE': {
        let targetPath = intent.target;
        if (!path.isAbsolute(targetPath)) {
          targetPath = path.join(config.raja.home || '/opt/raja-bot', targetPath);
        }
        if (!fs.existsSync(targetPath)) {
          return `❌ File tidak ditemukan: \`${targetPath}\``;
        }
        // If content was extracted from pattern, append directly
        if (intent.content) {
          fs.appendFileSync(targetPath, '\n' + intent.content, 'utf8');
          return `✅ Appended ke \`${targetPath}\`:\n${intent.content.substring(0, 200)}`;
        }
        // Otherwise, use LLM to extract what to append
        const { callCascade: appendLlm } = await import('../llm/cascade.js');
        const appendMessages = [
          {
            role: 'system',
            content: `User minta append/tambah konten ke file. Extract apa yang mau ditambahkan.
JAWAB HANYA DENGAN JSON: {"content": "teks yang mau ditambahkan"}
JANGAN tambahkan penjelasan apapun di luar JSON.`,
          },
          { role: 'user', content: query },
        ];
        try {
          const appendResult = await appendLlm(appendMessages, { maxTokens: 500, temperature: 0.1 });
          const jsonMatch = appendResult.text.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            const { content } = JSON.parse(jsonMatch[0]);
            fs.appendFileSync(targetPath, '\n' + content, 'utf8');
            return `✅ Appended ke \`${targetPath}\`:\n${content.substring(0, 200)}`;
          }
          return '❌ Gagal parse konten append. Coba: "tambahkan [teks] ke file [nama]"';
        } catch (appendErr) {
          return `❌ Gagal append: ${appendErr.message}`;
        }
      }

      case 'EDIT_FILE': {
        let targetPath = intent.target;
        if (!path.isAbsolute(targetPath)) {
          targetPath = path.join(config.raja.home || '/opt/raja-bot', targetPath);
        }
        if (!fs.existsSync(targetPath)) {
          return `❌ File tidak ditemukan: \`${targetPath}\``;
        }
        // Read current content, send to LLM with edit instruction, write back
        const currentContent = fs.readFileSync(targetPath, 'utf8');
        if (currentContent.length > 15000) {
          return `❌ File terlalu besar (${currentContent.length} chars) untuk edit via chat. Gunakan /codenow.`;
        }
        const { callCascade: editLlm } = await import('../llm/cascade.js');
        const editMessages = [
          {
            role: 'system',
            content: `Kamu adalah RAJA. User minta edit file. Berikan file LENGKAP setelah dimodifikasi.
JAWAB HANYA dengan isi file yang sudah di-edit. TANPA penjelasan, tanpa markdown code block, langsung raw content file.
Kalau instruksi tidak jelas, lakukan perubahan minimal yang masuk akal.`,
          },
          {
            role: 'user',
            content: `Instruksi: ${query}\n\n--- ISI FILE SAAT INI (${targetPath}) ---\n${currentContent}`,
          },
        ];
        try {
          const editResult = await editLlm(editMessages, { maxTokens: 4000, temperature: 0.2 });
          let newContent = editResult.text;
          // Strip markdown code fences if LLM wraps it
          newContent = newContent.replace(/^```[\w]*\n?/, '').replace(/\n?```\s*$/, '');
          // Safety check: don't write empty file
          if (!newContent || newContent.trim().length < 5) {
            return `❌ LLM returned empty content. Edit dibatalkan.`;
          }
          // Backup original
          const backupPath = targetPath + '.bak';
          fs.writeFileSync(backupPath, currentContent, 'utf8');
          // Write new content
          fs.writeFileSync(targetPath, newContent, 'utf8');
          const diffLines = Math.abs(newContent.split('\n').length - currentContent.split('\n').length);
          return `✅ File edited: \`${targetPath}\`\n📋 Backup: \`${backupPath}\`\n📊 ${newContent.split('\n').length} lines (${diffLines > 0 ? `±${diffLines} lines changed` : 'same length'})`;
        } catch (editErr) {
          return `❌ Gagal edit file: ${editErr.message}`;
        }
      }

      default: {
        // Fallback to LLM advisory for general VPS questions
        const messages = [
          {
            role: 'system',
            content: `Kamu adalah RAJA. Skill aktif: m2 (VPS/Deploy).
PENTING: Kamu BISA mengeksekusi command langsung di VPS ini. Jangan bilang "saya tidak bisa akses". Kamu punya akses penuh.

Kalau user minta baca file atau jalankan command, LAKUKAN LANGSUNG. Gak perlu minta user paste log.

Expert dalam:
- Ubuntu/Debian VPS setup dan hardening
- Nginx reverse proxy, SSL via Certbot
- Docker, Docker Compose
- systemd/PM2 process management
- Git-based deployments
- Monitoring: htop, journalctl, log rotation
- Firewall: ufw, fail2ban

Output: bash commands yang langsung bisa dijalankan, atau hasil eksekusi langsung.`,
          },
          { role: 'user', content: query },
        ];

        const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
        return result.text;
      }
    }
  },
};
