// src/skills/m6.js — Integrations, payment gateways, webhooks, SDKs
export default {
  id: 'm6',
  name: 'integrations',
  description: 'Third-party integrations, payment gateways (Midtrans, Xendit), webhooks, REST APIs, SDKs',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m6 (Integrations).
Expert dalam:
- Midtrans payment gateway (snap, core API, notification handling)
- Xendit (invoice, disbursement, e-wallet)
- Stripe (payment intents, subscriptions, webhooks)
- WhatsApp Business API (Meta WABA, Fonnte, WA Gateway)
- Google Sheets API, Google Drive API
- Airtable, Notion API
- REST API design dan consumption
- OAuth 2.0 flow implementation
- Webhook security (signature verification)
- Rate limiting dan retry patterns untuk external APIs
- SDK patterns dan error handling

Output: production-grade code dengan proper error handling.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.4 });
    return result.text;
  },
};
