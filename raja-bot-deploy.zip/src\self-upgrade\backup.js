// src/self-upgrade/backup.js — Backup engine
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

const execAsync = promisify(exec);

export async function createBackup({ reason = 'manual', version = 'unknown' } = {}) {
  const backupDir = config.raja.backupDir;
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupId = `backup-${timestamp}`;
  const backupPath = path.join(backupDir, backupId);

  fs.mkdirSync(backupPath, { recursive: true });

  // Backup source files (exclude node_modules, logs, data)
  const excludes = ['--exclude=node_modules', '--exclude=logs', '--exclude=data', '--exclude=.git'];
  try {
    await execAsync(
      `tar -czf ${path.join(backupPath, 'src.tar.gz')} ${excludes.join(' ')} -C ${config.raja.home} src package.json`,
      { timeout: 60000 }
    );
  } catch (e) {
    logger.warn(`[backup] tar failed: ${e.message}. Trying manual copy...`);
    // Fallback: copy src directory
    try {
      fs.cpSync(path.join(config.raja.home, 'src'), path.join(backupPath, 'src'), { recursive: true });
    } catch (e2) {
      logger.error(`[backup] Manual copy also failed: ${e2.message}`);
    }
  }

  // Save metadata
  const meta = {
    id: backupId,
    reason,
    version,
    ts: Date.now(),
    path: backupPath,
  };
  fs.writeFileSync(path.join(backupPath, 'meta.json'), JSON.stringify(meta, null, 2));

  logger.info(`[backup] Created: ${backupId} (${reason})`);
  return backupId;
}

export async function listBackups() {
  const backupDir = config.raja.backupDir;
  if (!fs.existsSync(backupDir)) return [];

  const dirs = fs.readdirSync(backupDir)
    .filter((d) => d.startsWith('backup-'))
    .map((d) => {
      const metaPath = path.join(backupDir, d, 'meta.json');
      if (!fs.existsSync(metaPath)) return null;
      try {
        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
        return meta;
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .sort((a, b) => b.ts - a.ts); // newest first

  return dirs;
}

export async function restoreBackup(backupId) {
  const backupDir = config.raja.backupDir;
  const backupPath = path.join(backupDir, backupId);

  if (!fs.existsSync(backupPath)) {
    throw new Error(`Backup not found: ${backupId}`);
  }

  const tarPath = path.join(backupPath, 'src.tar.gz');
  if (fs.existsSync(tarPath)) {
    await execAsync(`tar -xzf ${tarPath} -C ${config.raja.home}`, { timeout: 60000 });
  } else {
    // Fallback: copy src
    const srcBackup = path.join(backupPath, 'src');
    if (fs.existsSync(srcBackup)) {
      fs.cpSync(srcBackup, path.join(config.raja.home, 'src'), { recursive: true, force: true });
    } else {
      throw new Error(`No restorable content in backup ${backupId}`);
    }
  }

  logger.info(`[backup] Restored: ${backupId}`);
}
