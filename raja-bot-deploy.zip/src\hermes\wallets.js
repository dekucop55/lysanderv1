// src/hermes/wallets.js — Multi-chain wallet manager
import { ethers } from 'ethers';
import Database from 'better-sqlite3';
import { config } from '../config.js';
import { encrypt, decrypt } from '../utils/crypto.js';
import { logger } from '../utils/logger.js';
import fs from 'fs';
import path from 'path';

let db;

function getDb() {
  if (db) return db;
  const dbPath = path.join(config.raja.dataDir, 'wallets.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  db = new Database(dbPath);
  db.exec(`
    CREATE TABLE IF NOT EXISTS wallets (
      label TEXT PRIMARY KEY,
      address TEXT NOT NULL,
      chain_type TEXT NOT NULL DEFAULT 'evm',
      encrypted_pk TEXT,
      created_at REAL NOT NULL
    );
  `);
  return db;
}

/**
 * Import/create wallet and store encrypted private key
 * Requires master password (HERMES_MASTER_PW)
 */
export async function importWallet({ label, privateKey, chainType = 'evm' }) {
  const pw = config.governor.masterPw;
  if (!pw) throw new Error('HERMES_MASTER_PW not set. Cannot store wallet keys.');

  const db = getDb();
  let address;

  if (chainType === 'evm') {
    const wallet = new ethers.Wallet(privateKey);
    address = wallet.address;
  } else {
    throw new Error(`Chain type ${chainType} not supported yet`);
  }

  const encryptedPk = encrypt(privateKey, pw);
  db.prepare('INSERT OR REPLACE INTO wallets(label, address, chain_type, encrypted_pk, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(label, address, chainType, encryptedPk, Date.now() / 1000);

  logger.info(`[wallet] Imported ${label}: ${address}`);
  return { label, address, chainType };
}

/**
 * Get decrypted private key for a wallet — case-insensitive
 */
export async function getPrivateKey(label) {
  const pw = config.governor.masterPw;
  if (!pw) throw new Error('HERMES_MASTER_PW not set');

  const db = getDb();
  let row = db.prepare('SELECT * FROM wallets WHERE label = ?').get(label);
  if (!row) {
    row = db.prepare('SELECT * FROM wallets WHERE LOWER(label) = LOWER(?)').get(label);
  }
  if (!row) throw new Error(`Wallet "${label}" not found`);

  return decrypt(row.encrypted_pk, pw);
}

/**
 * Get wallet info (without private key) — case-insensitive label lookup
 */
export function getWalletInfo(label) {
  const db = getDb();
  // Try exact match first, then case-insensitive
  let row = db.prepare('SELECT label, address, chain_type, created_at FROM wallets WHERE label = ?').get(label);
  if (!row) {
    row = db.prepare('SELECT label, address, chain_type, created_at FROM wallets WHERE LOWER(label) = LOWER(?)').get(label);
  }
  return row;
}

/**
 * List all wallet labels and addresses
 */
export function listWallets() {
  const db = getDb();
  return db.prepare('SELECT label, address, chain_type, created_at FROM wallets ORDER BY label').all();
}

/**
 * Get EVM balance for a wallet
 */
export async function getBalance(label, chain = 'ethereum') {
  const info = getWalletInfo(label);
  if (!info) throw new Error(`Wallet "${label}" not found`);

  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`RPC not configured for chain: ${chain}`);

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const balance = await provider.getBalance(info.address);
  const balanceEth = ethers.formatEther(balance);

  return {
    label,
    address: info.address,
    chain,
    balance: parseFloat(balanceEth),
    balanceRaw: balance.toString(),
    symbol: getChainSymbol(chain),
  };
}

/**
 * Generate a new random wallet
 */
export function generateWallet() {
  const wallet = ethers.Wallet.createRandom();
  return {
    address: wallet.address,
    privateKey: wallet.privateKey,
    mnemonic: wallet.mnemonic?.phrase,
  };
}

function getChainSymbol(chain) {
  const map = {
    ethereum: 'ETH', base: 'ETH', arbitrum: 'ETH', optimism: 'ETH',
    polygon: 'MATIC', bsc: 'BNB', avalanche: 'AVAX',
  };
  return map[chain] || chain.toUpperCase();
}
