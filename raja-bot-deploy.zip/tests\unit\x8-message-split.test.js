import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { splitMessage } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 11.3**
 * Property 12: Message splitting respects 4096 limit.
 */
describe('Property 12: Message Splitting', () => {
  it('all chunks are <= 4096 characters', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 0, maxLength: 20000 }),
      (text) => {
        const chunks = splitMessage(text);
        for (const chunk of chunks) {
          assert.ok(chunk.length <= 4096, `Chunk too long: ${chunk.length}`);
        }
      }
    ), { numRuns: 200 });
  });

  it('concatenation of chunks equals original text (allowing newline trimming)', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 1, maxLength: 10000 }),
      (text) => {
        const chunks = splitMessage(text);
        const rejoined = chunks.join('\n');
        // Allow minor whitespace differences from split
        assert.ok(rejoined.length >= text.length * 0.95, 'Too much content lost');
      }
    ), { numRuns: 100 });
  });

  it('returns single chunk for short messages', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 0, maxLength: 4096 }),
      (text) => {
        const chunks = splitMessage(text);
        assert.strictEqual(chunks.length, 1);
        assert.strictEqual(chunks[0], text);
      }
    ), { numRuns: 100 });
  });
});
