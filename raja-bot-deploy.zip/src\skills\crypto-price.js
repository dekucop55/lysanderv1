// src/skills/crypto-price.js — Real-time crypto price fetcher (CoinGecko free API)
import axios from 'axios';
import { logger } from '../utils/logger.js';

// ─── CoinGecko ID mapping ───────────────────────────────────────────────────

const COIN_MAP = {
  btc: 'bitcoin', bitcoin: 'bitcoin',
  eth: 'ethereum', ethereum: 'ethereum',
  sol: 'solana', solana: 'solana',
  bnb: 'binancecoin', bsc: 'binancecoin',
  matic: 'matic-network', polygon: 'matic-network',
  avax: 'avalanche-2', avalanche: 'avalanche-2',
  arb: 'arbitrum', arbitrum: 'arbitrum',
  op: 'optimism', optimism: 'optimism',
  doge: 'dogecoin', dogecoin: 'dogecoin',
  xrp: 'ripple', ripple: 'ripple',
  ada: 'cardano', cardano: 'cardano',
  dot: 'polkadot', polkadot: 'polkadot',
  link: 'chainlink', chainlink: 'chainlink',
  uni: 'uniswap', uniswap: 'uniswap',
  aave: 'aave',
  atom: 'cosmos', cosmos: 'cosmos',
  near: 'near', 'near protocol': 'near',
  apt: 'aptos', aptos: 'aptos',
  sui: 'sui',
  sei: 'sei-network',
  ton: 'the-open-network', toncoin: 'the-open-network',
  pepe: 'pepe',
  wif: 'dogwifcoin',
  bonk: 'bonk',
  shib: 'shiba-inu',
  floki: 'floki',
  render: 'render-token',
  fet: 'artificial-superintelligence-alliance',
  inj: 'injective-protocol',
  tia: 'celestia',
  jup: 'jupiter-exchange-solana',
  usdt: 'tether', tether: 'tether',
  usdc: 'usd-coin',
};

// ─── Intent Detection ────────────────────────────────────────────────────────

const PRICE_PATTERNS = [
  /(?:harga|price|berapa)\s+(.+?)(?:\s+sekarang|\s+now|\s+saat ini)?$/i,
  /(?:cek|check)\s+(?:harga|price)\s+(.+)/i,
  /(.+?)\s+(?:berapa|harga|price)(?:\s+sekarang)?/i,
  /^(?:harga|price)\s+(.+)/i,
];

function extractCoinFromQuery(query) {
  const lower = query.toLowerCase().trim();

  // Try patterns
  for (const pattern of PRICE_PATTERNS) {
    const match = lower.match(pattern);
    if (match) {
      const coinRaw = match[1].trim().replace(/[?!.,]/g, '');
      // Check direct map
      if (COIN_MAP[coinRaw]) return { coin: coinRaw, geckoId: COIN_MAP[coinRaw] };
      // Try without spaces
      const noSpace = coinRaw.replace(/\s+/g, '');
      if (COIN_MAP[noSpace]) return { coin: noSpace, geckoId: COIN_MAP[noSpace] };
      // Try first word
      const firstWord = coinRaw.split(/\s+/)[0];
      if (COIN_MAP[firstWord]) return { coin: firstWord, geckoId: COIN_MAP[firstWord] };
      // Return raw — will try as gecko ID directly
      return { coin: coinRaw, geckoId: coinRaw };
    }
  }

  // Direct single-word check
  const words = lower.split(/\s+/);
  for (const word of words) {
    if (COIN_MAP[word]) return { coin: word, geckoId: COIN_MAP[word] };
  }

  return null;
}

// ─── Price Fetcher ───────────────────────────────────────────────────────────

async function fetchPrice(geckoId) {
  try {
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${geckoId}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true`;
    const response = await axios.get(url, { timeout: 10000 });
    const data = response.data[geckoId];

    if (!data) return null;

    return {
      price: data.usd,
      change24h: data.usd_24h_change,
      marketCap: data.usd_market_cap,
    };
  } catch (err) {
    logger.warn(`[crypto-price] CoinGecko fetch failed for ${geckoId}: ${err.message}`);
    return null;
  }
}

async function fetchMultiplePrices(geckoIds) {
  try {
    const ids = geckoIds.join(',');
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`;
    const response = await axios.get(url, { timeout: 10000 });
    return response.data;
  } catch (err) {
    logger.warn(`[crypto-price] Multi-fetch failed: ${err.message}`);
    return null;
  }
}

function formatPrice(price) {
  if (price >= 1000) return `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  if (price >= 1) return `$${price.toFixed(2)}`;
  if (price >= 0.01) return `$${price.toFixed(4)}`;
  return `$${price.toFixed(8)}`;
}

function formatMarketCap(mc) {
  if (!mc) return '';
  if (mc >= 1e12) return `$${(mc / 1e12).toFixed(2)}T`;
  if (mc >= 1e9) return `$${(mc / 1e9).toFixed(2)}B`;
  if (mc >= 1e6) return `$${(mc / 1e6).toFixed(1)}M`;
  return `$${mc.toLocaleString()}`;
}

// ─── Skill Export ────────────────────────────────────────────────────────────

export default {
  id: 'crypto-price',
  name: 'crypto-price-checker',
  description: 'Real-time crypto price checker via CoinGecko (free, no API key)',
  keywords: {
    'harga': 3, 'price': 3, 'berapa harga': 3, 'cek harga': 3,
    'harga sekarang': 3, 'price now': 3, 'berapa': 2,
    'market cap': 2, 'marketcap': 2,
  },

  async execute(query, context) {
    const extracted = extractCoinFromQuery(query);

    if (!extracted) {
      return '❌ Gue gak bisa detect koin mana yang lo mau cek. Coba: "harga ETH" atau "berapa harga BTC sekarang?"';
    }

    const { coin, geckoId } = extracted;

    const data = await fetchPrice(geckoId);

    if (!data) {
      // Try as-is (maybe it's already a valid gecko ID)
      const retry = await fetchPrice(coin);
      if (!retry) {
        return `❌ Gagal fetch harga "${coin}". Cek nama koin-nya atau coba lagi nanti (CoinGecko rate limit).`;
      }
      return formatResult(coin, retry);
    }

    return formatResult(coin, data);
  },
};

function formatResult(coin, data) {
  const symbol = coin.toUpperCase();
  const changeEmoji = data.change24h >= 0 ? '📈' : '📉';
  const changeStr = data.change24h !== null ? `${data.change24h >= 0 ? '+' : ''}${data.change24h.toFixed(2)}%` : 'N/A';
  const mcStr = data.marketCap ? `\nMarket Cap: ${formatMarketCap(data.marketCap)}` : '';

  return `${changeEmoji} **${symbol}**: ${formatPrice(data.price)}\n24h: ${changeStr}${mcStr}\n\n_Data: CoinGecko (real-time)_`;
}
