// src/utils/retry.js — Exponential backoff retry helper
import { logger } from './logger.js';

/**
 * Retry async function with exponential backoff
 * @param {Function} fn - async function to retry
 * @param {Object} opts
 * @param {number} opts.retries - max attempts (default 3)
 * @param {number} opts.baseDelay - initial delay ms (default 1000)
 * @param {number} opts.maxDelay - max delay ms (default 30000)
 * @param {number} opts.factor - backoff multiplier (default 2)
 * @param {Function} opts.onRetry - callback(err, attempt) called before each retry
 */
export async function retry(fn, opts = {}) {
  const {
    retries = 3,
    baseDelay = 1000,
    maxDelay = 30000,
    factor = 2,
    onRetry = null,
    label = 'operation',
  } = opts;

  let lastErr;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      return await fn(attempt);
    } catch (err) {
      lastErr = err;
      if (attempt === retries) break;

      const delay = Math.min(baseDelay * factor ** (attempt - 1), maxDelay);
      const jitter = Math.random() * delay * 0.1;
      const waitMs = Math.round(delay + jitter);

      logger.warn(`[retry] ${label} attempt ${attempt}/${retries} failed: ${err.message}. Retrying in ${waitMs}ms`);

      if (onRetry) onRetry(err, attempt);
      await sleep(waitMs);
    }
  }

  throw lastErr;
}

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Circuit breaker pattern
 */
export class CircuitBreaker {
  constructor({ threshold = 5, resetTimeout = 60000, name = 'circuit' } = {}) {
    this.threshold = threshold;
    this.resetTimeout = resetTimeout;
    this.name = name;
    this.failures = 0;
    this.state = 'closed'; // closed, open, half-open
    this.nextRetry = null;
  }

  async call(fn) {
    if (this.state === 'open') {
      if (Date.now() < this.nextRetry) {
        throw new Error(`Circuit ${this.name} is OPEN. Retry after ${new Date(this.nextRetry).toISOString()}`);
      }
      this.state = 'half-open';
    }

    try {
      const result = await fn();
      this._onSuccess();
      return result;
    } catch (err) {
      this._onFailure();
      throw err;
    }
  }

  _onSuccess() {
    this.failures = 0;
    this.state = 'closed';
  }

  _onFailure() {
    this.failures++;
    if (this.failures >= this.threshold) {
      this.state = 'open';
      this.nextRetry = Date.now() + this.resetTimeout;
      logger.warn(`[circuit] ${this.name} OPENED after ${this.failures} failures`);
    }
  }

  get status() {
    return { state: this.state, failures: this.failures, nextRetry: this.nextRetry };
  }
}
