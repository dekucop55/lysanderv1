// src/core/auto-push.js — Daily Auto-Push Scheduler
// Validates: Requirements 6.1, 6.8
//
// Schedules daily push to GitHub at 03:00 WIB (20:00 UTC)
// with concurrent push lock, retry logic, and logging.

import cron from 'node-cron';
import { execSync } from 'child_process';
import { logger } from '../utils/logger.js';
import fs from 'fs';
import path from 'path';

export class AutoPushScheduler {
  /**
   * @param {Object} options
   * @param {string} [options.cronSchedule='0 20 * * *'] - Cron expression (default 03:00 WIB = 20:00 UTC)
   * @param {number} [options.maxRetries=3] - Max retry attempts for network errors
   * @param {number} [options.retryIntervalMs=300000] - Interval between retries (5 min)
   * @param {number} [options.pushTimeoutMs=120000] - Timeout per push attempt (120s)
   * @param {string} [options.logFile='logs/auto-push.log'] - Path to log file
   * @param {Function} [options.execFn] - Dependency-injectable exec function (default: execSync from child_process)
   * @param {Function} [options.backupFn] - Dependency-injectable backup function (default: createBackup from memory.js)
   * @param {Function} [options.rotateFn] - Dependency-injectable rotate function (default: rotateBackups from memory.js)
   */
  constructor(options = {}) {
    this.cronSchedule = options.cronSchedule || '0 20 * * *'; // 03:00 WIB = 20:00 UTC
    this.maxRetries = options.maxRetries != null ? options.maxRetries : 3;
    this.retryIntervalMs = options.retryIntervalMs != null ? options.retryIntervalMs : 5 * 60 * 1000;
    this.pushTimeoutMs = options.pushTimeoutMs != null ? options.pushTimeoutMs : 120 * 1000;
    this.logFile = options.logFile || 'logs/auto-push.log';
    this.isRunning = false;
    this.cronJob = null;
    // Dependency injection for testability: allows tests to pass a mock exec function
    this._exec = options.execFn || execSync;
    // Dependency injection for backup/rotate — optional, resolved lazily from memory.js if not provided
    this._backupFn = options.backupFn || null;
    this._rotateFn = options.rotateFn || null;
  }

  /**
   * Start the cron scheduler.
   * Idempotent — calling start() when already running does nothing.
   */
  start() {
    if (this.cronJob) return;
    this.cronJob = cron.schedule(this.cronSchedule, () => {
      this.triggerPush();
    });
    logger.info(`[AUTO-PUSH] Scheduler started: ${this.cronSchedule}`);
  }

  /**
   * Stop the cron scheduler.
   * Safe to call even if not started.
   */
  stop() {
    if (this.cronJob) {
      this.cronJob.stop();
      this.cronJob = null;
    }
    logger.info('[AUTO-PUSH] Scheduler stopped');
  }

  /**
   * Trigger a push cycle. Rejects concurrent triggers via isRunning lock.
   * @returns {Promise<PushResult>}
   *
   * @typedef {Object} PushResult
   * @property {'success'|'failed'|'skipped'} status
   * @property {number} codeFiles - Number of code files changed
   * @property {number} dataFiles - Number of data files changed
   * @property {string|null} error - Error message if failed
   * @property {string} timestamp - ISO 8601
   */
  async triggerPush() {
    // Concurrent push lock (Requirement 6.8)
    if (this.isRunning) {
      logger.warn('[AUTO-PUSH] Push already running, rejecting trigger');
      const result = {
        status: 'skipped',
        codeFiles: 0,
        dataFiles: 0,
        error: 'concurrent push rejected',
        timestamp: new Date().toISOString()
      };
      this.writeLog(result);
      return result;
    }

    this.isRunning = true;
    try {
      // Detect changes in tracked directories
      const changes = await this.detectChanges();

      // Skip if no changes (Requirement 6.3)
      if (changes.codeFiles.length === 0 && changes.dataFiles.length === 0) {
        const result = {
          status: 'skipped',
          codeFiles: 0,
          dataFiles: 0,
          error: null,
          timestamp: new Date().toISOString()
        };
        logger.info('[AUTO-PUSH] No changes detected, skipping');
        this.writeLog(result);
        return result;
      }

      // Backup memory.db before push (Requirement 7.2)
      await this._runBackup();

      // Format commit message (Requirement 6.2)
      const commitMsg = this.formatCommitMessage(changes.codeFiles.length, changes.dataFiles.length);

      // Execute git add, commit, push with retry logic (Requirements 6.4, 6.6)
      await this.executeGitPush(commitMsg, changes);

      const result = {
        status: 'success',
        codeFiles: changes.codeFiles.length,
        dataFiles: changes.dataFiles.length,
        error: null,
        timestamp: new Date().toISOString()
      };
      this.writeLog(result);
      return result;
    } catch (err) {
      const result = {
        status: 'failed',
        codeFiles: 0,
        dataFiles: 0,
        error: err.message,
        timestamp: new Date().toISOString()
      };
      this.writeLog(result);
      return result;
    } finally {
      this.isRunning = false;
    }
  }

  /**
   * Run createBackup() + rotateBackups() before each push.
   * Non-critical: failures are logged as warnings, push is NOT blocked.
   * Validates: Requirements 7.2, 7.4
   *
   * backupFn and rotateFn are resolved from constructor options first;
   * if not provided, they are dynamically imported from memory.js to avoid
   * circular-dependency issues at module load time.
   */
  async _runBackup() {
    try {
      // Resolve backup function — prefer injected, else dynamic import (avoids circular deps)
      let backupFn = this._backupFn;
      let rotateFn = this._rotateFn;

      if (!backupFn || !rotateFn) {
        const memoryModule = await import('./memory.js');
        if (!backupFn) backupFn = memoryModule.createBackup;
        if (!rotateFn) rotateFn = memoryModule.rotateBackups;
      }

      // Step 1: createBackup() (Req 7.2)
      backupFn();
      logger.info('[AUTO-PUSH] Memory backup created before push');

      // Step 2: rotateBackups() — keep max 7 (Req 7.4)
      try {
        rotateFn();
        logger.info('[AUTO-PUSH] Backup rotation complete');
      } catch (rotateErr) {
        logger.warn(`[AUTO-PUSH] Backup rotation failed (non-critical): ${rotateErr.message}`);
      }
    } catch (backupErr) {
      // Backup failure is non-critical — log and continue
      logger.warn(`[AUTO-PUSH] Memory backup failed (non-critical): ${backupErr.message}`);
    }
  }

  /**
   * Execute git add, commit, and push with retry logic.
   * Validates: Requirements 6.4, 6.6
   *
   * - network/timeout errors → retry up to maxRetries (3) with retryIntervalMs (5 min) between
   * - auth/conflict errors → no retry, notify owner immediately
   * - After exhausting retries → notify owner
   *
   * @param {string} commitMsg - Formatted commit message
   * @param {{codeFiles: string[], dataFiles: string[]}} changes - Detected file changes
   */
  async executeGitPush(commitMsg, changes) {
    const allFiles = [...changes.codeFiles, ...changes.dataFiles];

    // Stage files
    this._exec(`git add ${allFiles.join(' ')}`, {
      cwd: process.cwd(),
      encoding: 'utf8',
      timeout: 30000
    });

    // Commit
    this._exec(`git commit -m "${commitMsg}"`, {
      cwd: process.cwd(),
      encoding: 'utf8',
      timeout: 30000
    });

    // Push with retries
    let lastError = null;
    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        this._exec('git push', {
          cwd: process.cwd(),
          encoding: 'utf8',
          timeout: this.pushTimeoutMs
        });
        return; // Success
      } catch (err) {
        lastError = err;
        const errorType = this.classifyError(err);

        if (errorType === 'auth' || errorType === 'conflict') {
          // Non-retryable: notify immediately
          await this.notifyOwner({
            status: 'failed',
            error: err.message,
            timestamp: new Date().toISOString()
          }, attempt);
          throw err;
        }

        // Network/timeout: retry if attempts remain
        if (attempt < this.maxRetries) {
          logger.warn(`[AUTO-PUSH] Push attempt ${attempt + 1} failed (${errorType}), retrying in ${this.retryIntervalMs / 1000}s...`);
          await new Promise(resolve => setTimeout(resolve, this.retryIntervalMs));
        }
      }
    }

    // All retries exhausted
    await this.notifyOwner({
      status: 'failed',
      error: lastError?.message,
      timestamp: new Date().toISOString()
    }, this.maxRetries);
    throw lastError;
  }

  /**
   * Detect changes in tracked directories (src/, data/, scripts/, package.json).
   * Uses `git status --porcelain` to detect modified, added, or untracked files.
   * @returns {Promise<{codeFiles: string[], dataFiles: string[]}>}
   */
  async detectChanges() {
    try {
      const output = this._exec('git status --porcelain', {
        cwd: process.cwd(),
        encoding: 'utf8',
        timeout: 30000
      });

      if (!output || !output.trim()) {
        return { codeFiles: [], dataFiles: [] };
      }

      // Split by newline and filter out empty lines — do NOT trim() the full output
      // because leading spaces in porcelain format are meaningful status indicators
      const lines = output.split('\n').filter(line => line.length > 0);
      const codeFiles = [];
      const dataFiles = [];

      for (const line of lines) {
        // git status --porcelain format: XY filename
        // Positions 0-1 are status indicators (X=index, Y=worktree), position 2 is space
        // The file path starts at position 3
        const filePath = line.substring(3);

        // Handle renamed files (format: "old -> new")
        const actualPath = filePath.includes(' -> ')
          ? filePath.split(' -> ')[1]
          : filePath;

        if (
          actualPath.startsWith('src/') ||
          actualPath.startsWith('scripts/') ||
          actualPath === 'package.json'
        ) {
          codeFiles.push(actualPath);
        } else if (actualPath.startsWith('data/')) {
          dataFiles.push(actualPath);
        }
      }

      return { codeFiles, dataFiles };
    } catch (err) {
      logger.error(`[AUTO-PUSH] detectChanges failed: ${err.message}`);
      throw err;
    }
  }

  /**
   * Format commit message per Requirement 6.2.
   * Format: [auto-sync] YYYY-MM-DD | code: N files | data: M files
   * @param {number} codeCount
   * @param {number} dataCount
   * @returns {string}
   */
  formatCommitMessage(codeCount, dataCount) {
    const date = new Date().toISOString().split('T')[0];
    return `[auto-sync] ${date} | code: ${codeCount} files | data: ${dataCount} files`;
  }

  /**
   * Classify error type for retry logic (Requirement 6.4, 6.6).
   * @param {Error} error
   * @returns {'network'|'timeout'|'auth'|'conflict'|'unknown'}
   */
  classifyError(error) {
    const msg = (error.message || '').toLowerCase();

    if (
      msg.includes('timeout') ||
      msg.includes('etimedout') ||
      msg.includes('deadline_exceeded') ||
      msg.includes('timed out')
    ) {
      return 'timeout';
    }
    if (
      msg.includes('econnrefused') ||
      msg.includes('econnreset') ||
      msg.includes('enotfound') ||
      msg.includes('network') ||
      msg.includes('fetch failed')
    ) {
      return 'network';
    }
    if (msg.includes('auth') || msg.includes('403') || msg.includes('401') || msg.includes('permission denied') || msg.includes('authentication')) {
      return 'auth';
    }
    if (msg.includes('conflict') || msg.includes('merge') || msg.includes('non-fast-forward')) {
      return 'conflict';
    }

    return 'unknown';
  }

  /**
   * Notify owner via Telegram on push failure.
   * Validates: Requirements 6.5, 6.7
   *
   * Sends a Telegram message containing:
   * - Timestamp of the failure
   * - Error type/message
   * - Number of retries attempted
   *
   * Uses native fetch() (Node 18+) to call Telegram Bot API directly.
   * Never throws — notification failure is caught and logged.
   *
   * @param {PushResult} result
   * @param {number} retryCount
   */
  async notifyOwner(result, retryCount) {
    try {
      const { config } = await import('../config.js');
      const botToken = config.telegram?.token || process.env.BOT_TOKEN;
      const ownerChatId = config.telegram?.allowedUserId || process.env.ALLOWED_USER_ID;

      if (!botToken || !ownerChatId) {
        logger.warn('[AUTO-PUSH] No Telegram credentials configured, skipping notification');
        return;
      }

      const message = `⚠️ *Auto-Push Failed*\n` +
        `⏱ Timestamp: ${result.timestamp}\n` +
        `❌ Error: ${result.error || 'Unknown'}\n` +
        `🔄 Retries: ${retryCount}\n` +
        `📊 Status: ${result.status}`;

      const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: ownerChatId,
          text: message,
          parse_mode: 'Markdown'
        })
      });

      if (!response.ok) {
        logger.warn(`[AUTO-PUSH] Telegram API returned ${response.status}: ${response.statusText}`);
      } else {
        logger.info(`[AUTO-PUSH] Owner notified: ${result.status}`);
      }
    } catch (err) {
      // Don't throw — notification failure shouldn't break the push flow
      logger.error(`[AUTO-PUSH] Failed to notify owner: ${err.message}`);
    }
  }

  /**
   * Write log entry to logs/auto-push.log (Requirement 6.7).
   * Format: JSON per line with timestamp, status, file counts, and error.
   * @param {PushResult} result
   */
  writeLog(result) {
    try {
      const logDir = path.dirname(this.logFile);
      if (!fs.existsSync(logDir)) {
        fs.mkdirSync(logDir, { recursive: true });
      }

      const entry = JSON.stringify({
        timestamp: result.timestamp,
        status: result.status,
        codeFiles: result.codeFiles,
        dataFiles: result.dataFiles,
        error: result.error
      }) + '\n';

      fs.appendFileSync(this.logFile, entry, 'utf8');
    } catch (err) {
      logger.error(`[AUTO-PUSH] Failed to write log: ${err.message}`);
    }
  }
}
