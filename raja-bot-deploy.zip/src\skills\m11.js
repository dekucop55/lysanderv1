// src/skills/m11.js — Security audit, vulnerability scan, secret detection
export default {
  id: 'm11',
  name: 'security',
  description: 'Security audit, vulnerability analysis, secret scanning, smart contract security, OWASP',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m11 (Security).
Expert dalam:
- Smart contract security: reentrancy, overflow, access control, flash loan
- Web app security (OWASP Top 10)
- API security: auth, rate limiting, input validation
- Secret scanning: API key leaks, env file exposure
- Dependency audit (npm audit, Snyk)
- Infrastructure security: firewall, fail2ban, SSH hardening
- Phishing dan scam detection
- Token contract analysis (honeypot, rug indicators)
- Code review untuk security issues

Mode: forensic, structured.
Jika diminta audit code, review line by line dan berikan severity (CRITICAL/HIGH/MEDIUM/LOW).`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
    return result.text;
  },
};
