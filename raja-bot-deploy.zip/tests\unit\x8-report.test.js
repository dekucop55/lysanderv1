import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { computeHealthScore, generateReport, splitMessage, HEALTH_WEIGHTS } from '../../src/skills/x8.js';
import { createMockDiagnosticReport, createMockCheckResult, createMockRepairAction, createMockRoutingFixResult, createMockPromptEnhanceResult } from '../helpers/x8-test-utils.js';

/**
 * **Validates: Requirements 3.4, 5.2, 10.2, 10.3, 11.4, 13.2, 19.4**
 * Properties 4, 5, 8, 11, 13, 20, 29: Report generation completeness.
 */
describe('Property 4: Integrity results fully reported', () => {
  it('modified/missing/added files appear in report output', () => {
    const report = createMockDiagnosticReport({
      checks: [createMockCheckResult({ category: 'integrity', status: 'warn', details: [{ type: 'modified', files: ['a.js'] }, { type: 'missing', files: ['b.js'] }] })],
    });
    report.healthScore = computeHealthScore(report);
    const messages = generateReport(report);
    const text = messages.join('\n');
    assert.ok(text.includes('integrity') || text.includes('Integrity'));
  });
});

describe('Property 5: Provider probe results', () => {
  it('reachable providers show latency', () => {
    const report = createMockDiagnosticReport({
      checks: [createMockCheckResult({ category: 'llm', details: [{ name: 'ollama', reachable: true, latencyMs: 150 }] })],
    });
    report.healthScore = computeHealthScore(report);
    const messages = generateReport(report);
    const text = messages.join('\n');
    assert.ok(text.includes('llm') || text.includes('LLM'));
  });
});

describe('Property 8: Repair before/after state', () => {
  it('all repair actions have beforeState and afterState', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 1, maxLength: 50 }),
      fc.string({ minLength: 1, maxLength: 50 }),
      (before, after) => {
        const action = createMockRepairAction({ beforeState: before, afterState: after });
        assert.ok(action.beforeState.length > 0);
        assert.ok(action.afterState.length > 0);
      }
    ), { numRuns: 50 });
  });
});

describe('Property 11: Report emoji mapping', () => {
  it('pass gets ✅, warn gets ⚠️, critical gets 🔴', () => {
    const checks = [
      createMockCheckResult({ category: 'skills', status: 'pass', summary: 'all good' }),
      createMockCheckResult({ category: 'llm', status: 'warn', summary: 'some down' }),
      createMockCheckResult({ category: 'telegram', status: 'critical', summary: 'disconnected' }),
    ];
    const report = createMockDiagnosticReport({ checks });
    report.healthScore = computeHealthScore(report);
    const text = generateReport(report).join('\n');
    assert.ok(text.includes('✅'));
    assert.ok(text.includes('⚠️'));
    assert.ok(text.includes('🔴'));
  });
});

describe('Property 13: Report required sections', () => {
  it('report contains Health Score and Summary', () => {
    const report = createMockDiagnosticReport({
      checks: [createMockCheckResult({ category: 'skills' })],
      healthScore: 85,
    });
    const text = generateReport(report).join('\n');
    assert.ok(text.includes('Health Score'));
    assert.ok(text.includes('Summary'));
  });
});

describe('Property 20: Code repair report completeness', () => {
  it('code repairs show in report', () => {
    const report = createMockDiagnosticReport({
      checks: [createMockCheckResult({ category: 'skills' })],
      codeRepairs: [{ success: true, file: 'test.js', errorType: 'syntax_error', errorMessage: 'err', fixDescription: 'Fixed syntax', backupId: 'b1', rolledBack: false }],
    });
    report.healthScore = computeHealthScore(report);
    const text = generateReport(report).join('\n');
    assert.ok(text.includes('Code Repairs') || text.includes('test.js'));
  });
});

describe('Property 29: Behavioral repair report completeness', () => {
  it('routing fixes show in report', () => {
    const report = createMockDiagnosticReport({
      checks: [createMockCheckResult({ category: 'behavioral', status: 'warn' })],
      routingFixes: [createMockRoutingFixResult()],
      promptEnhancements: [createMockPromptEnhanceResult()],
    });
    report.healthScore = computeHealthScore(report);
    const text = generateReport(report).join('\n');
    assert.ok(text.includes('Routing') || text.includes('routing'));
  });
});
