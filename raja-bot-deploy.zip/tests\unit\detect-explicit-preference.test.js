// tests/unit/detect-explicit-preference.test.js
// Unit tests for detectExplicitPreference (Task 2.3)
// Validates: Requirements 5.2

import { describe, it, expect } from 'vitest';
import { detectExplicitPreference, PREFERENCE_KEYWORDS } from '../../src/core/conversation-learner.js';

describe('detectExplicitPreference', () => {
  // ─── Input Validation ───────────────────────────────────────────────────────
  describe('input validation', () => {
    it('returns null for null input', () => {
      expect(detectExplicitPreference(null)).toBeNull();
    });

    it('returns null for undefined input', () => {
      expect(detectExplicitPreference(undefined)).toBeNull();
    });

    it('returns null for non-string input', () => {
      expect(detectExplicitPreference(123)).toBeNull();
      expect(detectExplicitPreference({})).toBeNull();
      expect(detectExplicitPreference([])).toBeNull();
    });

    it('returns null for empty string', () => {
      expect(detectExplicitPreference('')).toBeNull();
    });

    it('returns null for whitespace-only string', () => {
      expect(detectExplicitPreference('   ')).toBeNull();
    });

    it('returns null if no keyword matches', () => {
      expect(detectExplicitPreference('halo apa kabar')).toBeNull();
    });

    it('returns null if keyword found but no value after it', () => {
      expect(detectExplicitPreference('aku lebih suka')).toBeNull();
    });
  });

  // ─── Indonesian Keywords ────────────────────────────────────────────────────
  describe('Indonesian keyword detection', () => {
    it('detects "aku lebih suka" → key: preference', () => {
      const result = detectExplicitPreference('aku lebih suka format JSON');
      expect(result).not.toBeNull();
      expect(result.key).toBe('preference');
      expect(result.value).toBe('format JSON');
    });

    it('detects "aku mau pakai" → key: tool_preference', () => {
      const result = detectExplicitPreference('aku mau pakai TypeScript');
      expect(result).not.toBeNull();
      expect(result.key).toBe('tool_preference');
      expect(result.value).toBe('TypeScript');
    });

    it('detects "jangan pakai" → key: avoidance', () => {
      const result = detectExplicitPreference('jangan pakai var di code');
      expect(result).not.toBeNull();
      expect(result.key).toBe('avoidance');
      expect(result.value).toBe('var di code');
    });

    it('detects "selalu kasih" → key: always_do', () => {
      const result = detectExplicitPreference('selalu kasih contoh dalam bahasa Indonesia');
      expect(result).not.toBeNull();
      expect(result.key).toBe('always_do');
      expect(result.value).toBe('contoh dalam bahasa Indonesia');
    });

    it('detects "ganti ke" → key: switch_to', () => {
      const result = detectExplicitPreference('ganti ke dark mode');
      expect(result).not.toBeNull();
      expect(result.key).toBe('switch_to');
      expect(result.value).toBe('dark mode');
    });

    it('detects "pakai format" → key: tool_preference', () => {
      const result = detectExplicitPreference('pakai format markdown untuk output');
      expect(result).not.toBeNull();
      expect(result.key).toBe('tool_preference');
      expect(result.value).toBe('markdown untuk output');
    });
  });

  // ─── English Keywords ───────────────────────────────────────────────────────
  describe('English keyword detection', () => {
    it('detects "i prefer" → key: preference', () => {
      const result = detectExplicitPreference('i prefer dark mode');
      expect(result).not.toBeNull();
      expect(result.key).toBe('preference');
      expect(result.value).toBe('dark mode');
    });

    it('detects "always use" → key: tool_preference', () => {
      const result = detectExplicitPreference('always use prettier for formatting');
      expect(result).not.toBeNull();
      expect(result.key).toBe('tool_preference');
      expect(result.value).toBe('prettier for formatting');
    });

    it('detects "never use" → key: avoidance', () => {
      const result = detectExplicitPreference('never use tabs for indentation');
      expect(result).not.toBeNull();
      expect(result.key).toBe('avoidance');
      expect(result.value).toBe('tabs for indentation');
    });

    it('detects "switch to" → key: switch_to', () => {
      const result = detectExplicitPreference('switch to vitest from jest');
      expect(result).not.toBeNull();
      expect(result.key).toBe('switch_to');
      expect(result.value).toBe('vitest from jest');
    });
  });

  // ─── Value Extraction ───────────────────────────────────────────────────────
  describe('value extraction', () => {
    it('strips trailing punctuation from value', () => {
      const result = detectExplicitPreference('aku lebih suka Python!');
      expect(result.value).toBe('Python');
    });

    it('strips multiple trailing punctuation marks', () => {
      const result = detectExplicitPreference('i prefer tabs.,;');
      expect(result.value).toBe('tabs');
    });

    it('is case-insensitive for keyword matching', () => {
      const result = detectExplicitPreference('Aku Lebih Suka format tabel');
      expect(result).not.toBeNull();
      expect(result.key).toBe('preference');
      expect(result.value).toBe('format tabel');
    });

    it('preserves original case in value', () => {
      const result = detectExplicitPreference('i prefer TypeScript over JavaScript');
      expect(result.value).toBe('TypeScript over JavaScript');
    });

    it('keyword can appear mid-sentence', () => {
      const result = detectExplicitPreference('kalau bisa aku lebih suka bahasa Indonesia ya');
      expect(result).not.toBeNull();
      expect(result.key).toBe('preference');
      expect(result.value).toBe('bahasa Indonesia ya');
    });
  });

  // ─── PREFERENCE_KEYWORDS Export ─────────────────────────────────────────────
  describe('PREFERENCE_KEYWORDS constant', () => {
    it('is exported as an array', () => {
      expect(Array.isArray(PREFERENCE_KEYWORDS)).toBe(true);
    });

    it('contains expected keywords', () => {
      expect(PREFERENCE_KEYWORDS).toContain('aku lebih suka');
      expect(PREFERENCE_KEYWORDS).toContain('jangan pakai');
      expect(PREFERENCE_KEYWORDS).toContain('i prefer');
      expect(PREFERENCE_KEYWORDS).toContain('never use');
      expect(PREFERENCE_KEYWORDS).toContain('always use');
      expect(PREFERENCE_KEYWORDS).toContain('switch to');
    });

    it('has 10 keyword entries', () => {
      expect(PREFERENCE_KEYWORDS.length).toBe(10);
    });
  });
});
