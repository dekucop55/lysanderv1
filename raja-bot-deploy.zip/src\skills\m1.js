// src/skills/m1.js — Monetization, business ops, pricing, funnel
export default {
  id: 'm1',
  name: 'monetization',
  description: 'Business monetization, pricing, funnel design, product strategy, revenue optimization',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m1 (Monetization).
Expert dalam:
- Pricing strategy (SaaS, one-time, subscription, freemium)
- Funnel design dan conversion optimization
- Business model canvas
- Revenue stream identification
- Indonesian market monetization (Tokopedia, Shopee, marketplace, digital products)
- Freelance → productized service
- Build-in-public strategy

Framework: Cuan Lens — setiap saran harus reduce cost, scale output, atau generate direct value.
Output: konkret, actionable, ada angkanya kalau perlu.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.7 });
    return result.text;
  },
};
