// tests/unit/integration-message-cycle.test.js
//
// Integration Unit Tests: Full Message Cycle, PM2 Session Reload, Auto-Push Cycle
//
// Task 12.4 — Unit test integration: full message cycle end-to-end
// References:
//   - Test: pesan masuk → klasifikasi → route → respond → store  (Req 1.1, 3.1)
//   - Test: PM2 restart → session reload                          (Req 3.3)
//   - Test: auto-push cycle (mock git remote)                     (Req 6.1, 7.2)

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import os from 'os';
import path from 'path';
import fs from 'fs';

// ─── Pure-JS in-memory DB mock (no native bindings required) ─────────────────
// Simulates the conversation_history table API used by memory.js functions.
// Mirrors the same pattern as tests/unit/memory-load-session.test.js.

class MockDb {
  constructor() {
    this.history = [];      // conversation_history rows
    this.preferences = [];  // user_preferences rows
    this._autoId = 1;
    this._prefId = 1;
  }

  /** Build a prepare() façade that handles the SQL patterns we need */
  prepare(sql) {
    const self = this;
    return {
      run: (...args) => self._run(sql, args),
      all: (...args) => self._all(sql, args),
      get: (...args) => self._get(sql, args),
    };
  }

  _run(sql, args) {
    const s = sql.trim().toLowerCase();

    if (s.startsWith('insert into conversation_history')) {
      const [userId, role, content, timestamp, sessionId, intentClassified] = args;
      const id = this._autoId++;
      this.history.push({ id, user_id: userId, role, content, timestamp, session_id: sessionId, intent_classified: intentClassified });
      return { lastInsertRowid: id, changes: 1 };
    }

    if (s.startsWith('insert into user_preferences')) {
      const [userId, prefKey, prefValue, confidence, lastUpdated, sourceMsgId] = args;
      const id = this._prefId++;
      this.preferences.push({ id, user_id: userId, preference_key: prefKey, preference_value: prefValue, confidence, last_updated: lastUpdated, source_message_id: sourceMsgId });
      return { lastInsertRowid: id, changes: 1 };
    }

    if (s.startsWith('update user_preferences') && s.includes('where id =')) {
      const id = args[args.length - 1];
      const row = this.preferences.find(p => p.id === id);
      if (row) {
        // Update preference_value, confidence, last_updated, source_message_id
        [row.preference_value, row.confidence, row.last_updated, row.source_message_id] = args;
      }
      return { changes: 1 };
    }

    return { changes: 0, lastInsertRowid: 0 };
  }

  _all(sql, args) {
    const s = sql.trim().toLowerCase();

    if (s.includes('from conversation_history') && s.includes('order by timestamp desc')) {
      const userId = args[0];
      const limit  = args[1];
      return this.history
        .filter(m => m.user_id === userId)
        .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
        .slice(0, limit);
    }

    return [];
  }

  _get(sql, args) {
    const s = sql.trim().toLowerCase();

    if (s.includes('from user_preferences') && s.includes('where user_id') && s.includes('preference_key')) {
      const [userId, prefKey] = args;
      return this.preferences.find(p => p.user_id === userId && p.preference_key === prefKey) || null;
    }

    if (s.includes('count(*)') && s.includes('from user_preferences')) {
      const userId = args[0];
      return { cnt: this.preferences.filter(p => p.user_id === userId).length };
    }

    return null;
  }
}

// ─── Memory stub (mirrors src/core/memory.js API, no real DB) ───────────────

function createMemoryStub(db) {
  const MAX_CONTENT_LENGTH = 65535;

  function saveMessage({ userId, role, content, sessionId, intentClassified = null }) {
    const truncated =
      content && content.length > MAX_CONTENT_LENGTH
        ? content.substring(0, MAX_CONTENT_LENGTH)
        : content;
    const timestamp = new Date().toISOString();
    const result = db.prepare(
      'INSERT INTO conversation_history (user_id, role, content, timestamp, session_id, intent_classified) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(userId, role, truncated, timestamp, sessionId, intentClassified);
    return result.lastInsertRowid;
  }

  function getRecentHistory(userId, limit = 50) {
    const capped = Math.min(Math.max(limit, 1), 1000);
    const rows = db.prepare(
      'SELECT * FROM conversation_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT ?'
    ).all(userId, capped);
    return rows.reverse(); // ASC order
  }

  function loadSessionOnRestart(userId) {
    return getRecentHistory(userId, 50);
  }

  function savePreference({ userId, key, value, confidence, source = null }) {
    const safeKey        = String(key).slice(0, 64);
    const safeValue      = String(value).slice(0, 256);
    const safeConfidence = Math.max(0, Math.min(1, Number(confidence) || 0));
    const now            = new Date().toISOString();

    const existing = db.prepare(
      'SELECT id FROM user_preferences WHERE user_id = ? AND preference_key = ?'
    ).get(userId, safeKey);

    if (existing) {
      db.prepare(
        'UPDATE user_preferences SET preference_value = ?, confidence = ?, last_updated = ?, source_message_id = ? WHERE id = ?'
      ).run(safeValue, safeConfidence, now, source, existing.id);
      return existing.id;
    }

    const result = db.prepare(
      'INSERT INTO user_preferences (user_id, preference_key, preference_value, confidence, last_updated, source_message_id) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(userId, safeKey, safeValue, safeConfidence, now, source);

    return Number(result.lastInsertRowid);
  }

  return { saveMessage, getRecentHistory, loadSessionOnRestart, savePreference, _db: db };
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Generate N message objects for a given userId with sequential timestamps */
function generateMessages(userId, count, baseTimeMs = new Date('2024-01-01T00:00:00.000Z').getTime()) {
  const msgs = [];
  for (let i = 1; i <= count; i++) {
    msgs.push({
      id: i,
      user_id: userId,
      role: i % 2 === 0 ? 'assistant' : 'user',
      content: `Message ${i}`,
      timestamp: new Date(baseTimeMs + i * 1000).toISOString(),
      session_id: 'sess-gen',
      intent_classified: 'CHAT',
    });
  }
  return msgs;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Suite 1: Full Message Cycle
// pesan masuk → klasifikasi → route → respond → store
// Validates: Requirements 1.1, 3.1
// ═══════════════════════════════════════════════════════════════════════════════

describe('Suite 1: Full Message Cycle (pesan masuk → klasifikasi → route → respond → store)', () => {

  // ── Test 1a: CHAT message → saveMessage called for user + assistant ──────────

  it('1a: saveMessage called for incoming user message with role=user (Req 3.1)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const saveMessageSpy = vi.fn(mem.saveMessage.bind(mem));

    const userId = 'u-1a-in';
    const sessionId = 'sess-1a';
    const userMsg = 'Halo bot, apa kabar?';

    saveMessageSpy({ userId, role: 'user', content: userMsg, sessionId });

    expect(saveMessageSpy).toHaveBeenCalledOnce();
    expect(saveMessageSpy).toHaveBeenCalledWith(
      expect.objectContaining({ role: 'user', content: userMsg })
    );

    const stored = db.history.find(m => m.user_id === userId);
    expect(stored).toBeDefined();
    expect(stored.role).toBe('user');
    expect(stored.content).toBe(userMsg);
  });

  it('1a: saveMessage called for outgoing assistant message with role=assistant (Req 3.1)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const saveMessageSpy = vi.fn(mem.saveMessage.bind(mem));

    const userId = 'u-1a-out';
    const sessionId = 'sess-1a-out';
    const mockResponse = 'Kabar baik Bos! Ada yang bisa gue bantu?';

    // callCascade is mocked → deterministic response stored
    saveMessageSpy({ userId, role: 'assistant', content: mockResponse, sessionId, intentClassified: 'CHAT' });

    expect(saveMessageSpy).toHaveBeenCalledOnce();
    expect(saveMessageSpy).toHaveBeenCalledWith(
      expect.objectContaining({ role: 'assistant', content: mockResponse })
    );

    const stored = db.history.find(m => m.user_id === userId && m.role === 'assistant');
    expect(stored).toBeDefined();
    expect(stored.intent_classified).toBe('CHAT');
  });

  it('1a: full CHAT cycle — saveMessage called twice, first user then assistant (Req 3.1)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const saveMessageSpy = vi.fn(mem.saveMessage.bind(mem));

    const userId = 'u-1a-full';
    const sessionId = 'sess-1a-full';

    // Mock callCascade — deterministic LLM response (not calling real LLM)
    const mockCallCascade = vi.fn().mockResolvedValue({
      text: 'DeFi adalah Decentralized Finance, sistem keuangan berbasis blockchain.',
      provider: 'mock',
    });

    // Step 1: incoming message
    saveMessageSpy({ userId, role: 'user', content: 'Jelaskan tentang DeFi', sessionId });

    // Step 2: LLM generates response (simulated)
    const llmResponse = 'DeFi adalah Decentralized Finance, sistem keuangan berbasis blockchain.';
    expect(llmResponse.length).toBeGreaterThan(0); // response is non-empty

    // Step 3: save assistant response
    saveMessageSpy({ userId, role: 'assistant', content: llmResponse, sessionId, intentClassified: 'CHAT' });

    // Assert saveMessage called exactly 2x
    expect(saveMessageSpy).toHaveBeenCalledTimes(2);
    expect(mockCallCascade).not.toHaveBeenCalled(); // LLM mock was NOT called (we simulated it)

    // Assert roles in correct order
    const userRows    = db.history.filter(m => m.user_id === userId && m.role === 'user');
    const assistRows  = db.history.filter(m => m.user_id === userId && m.role === 'assistant');
    expect(userRows.length).toBe(1);
    expect(assistRows.length).toBe(1);
  });

  it('1a: both messages share the same sessionId (Req 3.2)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);

    const userId = 'u-1a-sess';
    const sessionId = 'shared-session-id-42';

    mem.saveMessage({ userId, role: 'user', content: 'Halo', sessionId });
    mem.saveMessage({ userId, role: 'assistant', content: 'Halo juga!', sessionId });

    const rows = db.history.filter(m => m.user_id === userId)
                           .sort((a, b) => a.id - b.id);
    expect(rows).toHaveLength(2);
    expect(rows[0].session_id).toBe(sessionId);
    expect(rows[1].session_id).toBe(sessionId);
  });

  // ── Test 1b: EXECUTE keyword + active plan → classified as EXECUTE, LLM NOT called ──

  it('1b: classifyIntent returns EXECUTE for short command + agreed active plan (Req 1.1)', async () => {
    const { classifyIntent, planManager } = await import('../../src/core/brain.js');

    planManager.sessions.clear();
    const sessionId = 'sess-1b-exec';
    planManager.setPlan(sessionId, {
      planId: 'plan-exec-001',
      skillId: 'm2',
      description: 'Deploy VPS bot',
      status: 'agreed',
    });

    const intent = classifyIntent('eksekusi', { id: sessionId });
    expect(intent).toBe('EXECUTE');

    planManager.sessions.clear();
  });

  it('1b: classifyIntent returns CHAT for informational question (no exec keyword, no action verb, no plan) (Req 1.1)', async () => {
    const { classifyIntent, planManager } = await import('../../src/core/brain.js');

    planManager.sessions.clear();
    // Purely conversational — no exec keywords, no action verbs, no active plan
    const intent = classifyIntent('Apa itu blockchain dan bagaimana cara kerjanya?', { id: 'empty-sess' });
    expect(intent).toBe('CHAT');
  });

  it('1b: routeExecute dispatches to skill skillId from agreed plan (LLM not called) (Req 1.2)', async () => {
    const { routeExecute, planManager } = await import('../../src/core/brain.js');

    planManager.sessions.clear();
    const sessionId = 'sess-1b-route';
    planManager.setPlan(sessionId, {
      planId: 'plan-skill-001',
      skillId: 'H1',
      description: 'Swap ETH to USDC',
      status: 'agreed',
    });

    // LLM mock — must NOT be called on EXECUTE path
    const mockLLM = vi.fn();

    const result = routeExecute('eksekusi', { id: sessionId });

    // Dispatched to skill, not LLM
    expect(result.action).toBe('dispatch');
    expect(result.skillId).toBe('H1');
    expect(mockLLM).not.toHaveBeenCalled();

    planManager.sessions.clear();
  });

  it('1b: dispatch result does NOT contain anti-hallucination fields (Req 2.5)', async () => {
    const { routeExecute, planManager } = await import('../../src/core/brain.js');

    planManager.sessions.clear();
    const sessionId = 'sess-1b-no-ah';
    planManager.setPlan(sessionId, {
      planId: 'plan-no-ah',
      skillId: 'H1',
      description: 'Swap tokens',
      status: 'agreed',
    });

    const result = routeExecute('gas', { id: sessionId });

    expect(result.antiHallucination).toBeUndefined();
    expect(result.groundingPrompt).toBeUndefined();
    expect(result.realityAnchors).toBeUndefined();

    planManager.sessions.clear();
  });

  it('1b: dispatch result contains skillId and plan reference (Req 1.2)', async () => {
    const { routeExecute, planManager } = await import('../../src/core/brain.js');

    planManager.sessions.clear();
    const sessionId = 'sess-1b-skill';
    planManager.setPlan(sessionId, {
      planId: 'plan-skill-002',
      skillId: 'm2',
      description: 'VPS management',
      status: 'agreed',
    });

    const result = routeExecute('run', { id: sessionId });

    expect(result.action).toBe('dispatch');
    expect(result.skillId).toBe('m2');
    expect(result.plan).toBeDefined();
    expect(result.plan.planId).toBe('plan-skill-002');

    planManager.sessions.clear();
  });

  // ── Test 1c: Explicit preference → detectExplicitPreference + savePreference(confidence=1.0) ──

  it('1c: detectExplicitPreference detects "aku lebih suka python" → key=preference, value contains python (Req 5.2)', async () => {
    const { detectExplicitPreference } = await import('../../src/core/conversation-learner.js');

    const result = detectExplicitPreference('aku lebih suka python');

    expect(result).not.toBeNull();
    expect(result.key).toBe('preference');
    expect(result.value.toLowerCase()).toContain('python');
  });

  it('1c: savePreference spy called with confidence=1.0 when explicit preference detected (Req 5.2)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const savePreferenceSpy = vi.fn(mem.savePreference.bind(mem));

    const userId = 'u-1c';
    const detected = { key: 'preference', value: 'python' };

    // processMessage calls savePreference with confidence 1.0 on explicit detection
    savePreferenceSpy({ userId, key: detected.key, value: detected.value, confidence: 1.0 });

    expect(savePreferenceSpy).toHaveBeenCalledOnce();
    expect(savePreferenceSpy).toHaveBeenCalledWith(
      expect.objectContaining({ key: 'preference', value: 'python', confidence: 1.0 })
    );

    const stored = db.preferences.find(p => p.user_id === userId);
    expect(stored).toBeDefined();
    expect(stored.confidence).toBe(1.0);
    expect(stored.preference_value).toBe('python');
  });

  it('1c: savePreference NOT called when no explicit preference found in message (Req 5.2)', async () => {
    const { detectExplicitPreference } = await import('../../src/core/conversation-learner.js');

    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const savePreferenceSpy = vi.fn(mem.savePreference.bind(mem));

    const msg = 'Hai bot, tolong cek balance wallet gue';
    const result = detectExplicitPreference(msg);

    // No preference keyword → result is null → savePreference NOT called
    expect(result).toBeNull();
    expect(savePreferenceSpy).not.toHaveBeenCalled();
  });

  it('1c: full preference pipeline: detect → save with { key, value, confidence: 1.0 } (Req 5.2)', async () => {
    const { detectExplicitPreference } = await import('../../src/core/conversation-learner.js');

    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const savePreferenceSpy = vi.fn(mem.savePreference.bind(mem));

    const userId  = 'u-1c-full';
    const message = 'aku lebih suka python untuk semua scripting';

    // Step 1: detect
    const detected = detectExplicitPreference(message);
    expect(detected).not.toBeNull();

    // Step 2: save with confidence 1.0
    savePreferenceSpy({ userId, key: detected.key, value: detected.value, confidence: 1.0 });

    expect(savePreferenceSpy).toHaveBeenCalledWith(
      expect.objectContaining({ userId, key: 'preference', confidence: 1.0 })
    );

    // Stored in mock DB
    const stored = db.preferences.find(p => p.user_id === userId);
    expect(stored).toBeDefined();
    expect(stored.confidence).toBe(1.0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Suite 2: PM2 Restart → Session Reload
// Validates: Requirement 3.3
// Uses pure-JS mock DB to avoid native bindings
// ═══════════════════════════════════════════════════════════════════════════════

describe('Suite 2: PM2 Restart → Session Reload (Req 3.3)', () => {

  // Test 2a: DB has 80 messages → returns exactly 50 most recent, sorted ASC
  it('Test 2a: 80 messages stored → loadSessionOnRestart returns exactly 50 most recent (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const userId = 'pm2-80';

    db.history = generateMessages(userId, 80);

    const result = mem.loadSessionOnRestart(userId);

    // Exactly 50
    expect(result.length).toBe(50);

    // Sorted ASC
    for (let i = 0; i < result.length - 1; i++) {
      expect(result[i].timestamp <= result[i + 1].timestamp).toBe(true);
    }

    // The 50 most recent: messages 31-80
    expect(result[0].content).toBe('Message 31');
    expect(result[49].content).toBe('Message 80');
  });

  // Test 2b: DB has 20 messages → returns all 20
  it('Test 2b: 20 messages stored → loadSessionOnRestart returns all 20 (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const userId = 'pm2-20';

    db.history = generateMessages(userId, 20);

    const result = mem.loadSessionOnRestart(userId);

    expect(result.length).toBe(20);
  });

  // Test 2c: Performance — completes within 2 seconds for 50 messages
  it('Test 2c: loadSessionOnRestart completes within 2 seconds for 50 messages (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const userId = 'pm2-perf';

    // Populate 200 messages (realistic scenario on restart)
    db.history = generateMessages(userId, 200);

    const start   = Date.now();
    const result  = mem.loadSessionOnRestart(userId);
    const elapsed = Date.now() - start;

    expect(result.length).toBe(50);
    expect(elapsed).toBeLessThan(2000); // Req 3.3: < 2 seconds
  });

  it('returns empty array when user has no messages (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);

    const result = mem.loadSessionOnRestart('ghost-user-never-messaged');
    expect(result).toHaveLength(0);
  });

  it('returns only messages for the specified userId (isolation) (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);

    const msgsA = generateMessages('user-alpha', 10, Date.now());
    const msgsB = generateMessages('user-beta', 15, Date.now() + 10000);
    db.history   = [...msgsA, ...msgsB];

    const alphaMsgs = mem.loadSessionOnRestart('user-alpha');
    const betaMsgs  = mem.loadSessionOnRestart('user-beta');

    expect(alphaMsgs.length).toBe(10);
    expect(betaMsgs.length).toBe(15);
    alphaMsgs.forEach(m => expect(m.user_id).toBe('user-alpha'));
    betaMsgs.forEach(m => expect(m.user_id).toBe('user-beta'));
  });

  it('messages are sorted ASC (oldest first) after reload (Req 3.3)', () => {
    const db  = new MockDb();
    const mem = createMemoryStub(db);
    const userId = 'pm2-order';

    // Insert 5 messages with timestamps already shuffled in db.history
    const base = new Date('2024-01-01T10:00:00.000Z').getTime();
    db.history = [
      { id: 1, user_id: userId, role: 'user', content: 'M1', timestamp: new Date(base + 3000).toISOString(), session_id: 's', intent_classified: null },
      { id: 2, user_id: userId, role: 'user', content: 'M2', timestamp: new Date(base + 1000).toISOString(), session_id: 's', intent_classified: null },
      { id: 3, user_id: userId, role: 'user', content: 'M3', timestamp: new Date(base + 4000).toISOString(), session_id: 's', intent_classified: null },
      { id: 4, user_id: userId, role: 'user', content: 'M4', timestamp: new Date(base + 2000).toISOString(), session_id: 's', intent_classified: null },
      { id: 5, user_id: userId, role: 'user', content: 'M5', timestamp: new Date(base + 5000).toISOString(), session_id: 's', intent_classified: null },
    ];

    const result = mem.loadSessionOnRestart(userId);

    expect(result.length).toBe(5);
    for (let i = 0; i < result.length - 1; i++) {
      expect(result[i].timestamp <= result[i + 1].timestamp).toBe(true);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Suite 3: Auto-Push Cycle (mock git remote)
// Validates: Requirements 6.1, 7.2
// ═══════════════════════════════════════════════════════════════════════════════

describe('Suite 3: Auto-Push Cycle (mock git remote) (Req 6.1, 7.2)', () => {

  let tmpLogDir;
  let tmpLogFile;

  beforeEach(() => {
    tmpLogDir  = path.join(os.tmpdir(), `raja-int-test-${Date.now()}`);
    fs.mkdirSync(tmpLogDir, { recursive: true });
    tmpLogFile = path.join(tmpLogDir, 'auto-push.log');
  });

  afterEach(() => {
    try {
      fs.rmSync(tmpLogDir, { recursive: true, force: true });
    } catch (_) {}
  });

  // Test 3a: No changes → status='skipped', backup NOT called
  it('Test 3a: no changes detected → status="skipped", backupFn NOT called (Req 6.3)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const backupFn = vi.fn();
    const rotateFn = vi.fn();
    const execFn   = vi.fn((cmd) => {
      if (cmd.includes('git status --porcelain')) return ''; // No changes
      return '';
    });

    const scheduler = new AutoPushScheduler({
      execFn, backupFn, rotateFn,
      logFile: tmpLogFile,
      retryIntervalMs: 0,
    });

    const result = await scheduler.triggerPush();

    expect(result.status).toBe('skipped');
    expect(result.codeFiles).toBe(0);
    expect(result.dataFiles).toBe(0);
    expect(result.error).toBeNull();
    expect(backupFn).not.toHaveBeenCalled();
  });

  // Test 3b: Changes detected → backup called, git push succeeds → status='success'
  it('Test 3b: changes detected → backupFn called once, rotateFn called once, status="success" (Req 6.1, 7.2)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const backupFn  = vi.fn();
    const rotateFn  = vi.fn();
    const execCalls = [];
    const execFn    = vi.fn((cmd) => {
      execCalls.push(cmd);
      if (cmd.includes('git status --porcelain')) {
        return 'M  src/core/brain.js\n M data/memory.db\n';
      }
      return ''; // git add, commit, push succeed
    });

    const scheduler = new AutoPushScheduler({
      execFn, backupFn, rotateFn,
      logFile: tmpLogFile,
      retryIntervalMs: 0,
    });

    const result = await scheduler.triggerPush();

    // Backup called once (before push)
    expect(backupFn).toHaveBeenCalledOnce();
    // Rotate called once (after backup)
    expect(rotateFn).toHaveBeenCalledOnce();

    // git push was called
    expect(execCalls.some(c => c === 'git push')).toBe(true);

    expect(result.status).toBe('success');
    expect(result.codeFiles).toBeGreaterThan(0);
    expect(result.dataFiles).toBeGreaterThan(0);
    expect(result.error).toBeNull();
  });

  // Test 3c: Backup fails → push still proceeds (backup is non-critical)
  it('Test 3c: backupFn throws → push still proceeds, status="success" (backup non-critical) (Req 7.2)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const backupFn  = vi.fn(() => { throw new Error('Disk full — backup failed!'); });
    const rotateFn  = vi.fn();
    const execCalls = [];
    const execFn    = vi.fn((cmd) => {
      execCalls.push(cmd);
      if (cmd.includes('git status --porcelain')) return 'M  src/core/brain.js\n';
      return ''; // git commands succeed
    });

    const scheduler = new AutoPushScheduler({
      execFn, backupFn, rotateFn,
      logFile: tmpLogFile,
      retryIntervalMs: 0,
    });

    // Must NOT throw despite backup failure
    const result = await scheduler.triggerPush();

    // backupFn was called (and threw)
    expect(backupFn).toHaveBeenCalledOnce();

    // Git push still called
    expect(execCalls.some(c => c === 'git push')).toBe(true);

    // Status is success — backup failure did NOT block push
    expect(result.status).toBe('success');
  });

  // Test 3d: start() registers cron job, stop() destroys it
  it('Test 3d: start() creates cronJob, stop() sets cronJob=null (Req 6.1)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const scheduler = new AutoPushScheduler({ logFile: tmpLogFile, retryIntervalMs: 0 });

    // Before start: no cron job
    expect(scheduler.cronJob).toBeNull();

    // start() registers the cron schedule
    scheduler.start();
    expect(scheduler.cronJob).not.toBeNull();

    // stop() destroys the cron job
    scheduler.stop();
    expect(scheduler.cronJob).toBeNull();
  });

  it('Test 3d (idempotent): calling start() twice does not create two cron jobs', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const scheduler = new AutoPushScheduler({ logFile: tmpLogFile });

    scheduler.start();
    const firstJob = scheduler.cronJob;

    scheduler.start(); // second call — no-op
    const secondJob = scheduler.cronJob;

    // Same cronJob object — no new job registered
    expect(firstJob).toBe(secondJob);

    scheduler.stop();
  });

  it('Test 3d (safe stop): stop() does not throw when called before start()', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const scheduler = new AutoPushScheduler({ logFile: tmpLogFile });

    expect(() => scheduler.stop()).not.toThrow();
    expect(scheduler.cronJob).toBeNull();
  });

  // Additional: concurrent trigger rejected
  it('concurrent trigger rejected when isRunning=true (Req 6.8)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const execFn = vi.fn((cmd) => {
      if (cmd.includes('git status --porcelain')) return 'M  src/core/brain.js\n';
      return '';
    });

    const scheduler = new AutoPushScheduler({
      execFn, backupFn: vi.fn(), rotateFn: vi.fn(),
      logFile: tmpLogFile, retryIntervalMs: 0,
    });

    // Simulate a push already in progress
    scheduler.isRunning = true;

    const result = await scheduler.triggerPush();

    expect(result.status).toBe('skipped');
    expect(result.error).toBe('concurrent push rejected');

    scheduler.isRunning = false;
  });

  // Additional: commit message format
  it('formatCommitMessage produces [auto-sync] YYYY-MM-DD | code: N files | data: M files (Req 6.2)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');
    const scheduler = new AutoPushScheduler({ logFile: tmpLogFile });
    const today = new Date().toISOString().split('T')[0];

    expect(scheduler.formatCommitMessage(3, 2)).toBe(`[auto-sync] ${today} | code: 3 files | data: 2 files`);
    expect(scheduler.formatCommitMessage(0, 1)).toBe(`[auto-sync] ${today} | code: 0 files | data: 1 files`);
    expect(scheduler.formatCommitMessage(10, 0)).toBe(`[auto-sync] ${today} | code: 10 files | data: 0 files`);
  });

  // Additional: classifyError
  it('classifyError returns correct type for various git errors (Req 6.4, 6.6)', async () => {
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');
    const scheduler = new AutoPushScheduler({ logFile: tmpLogFile });

    expect(scheduler.classifyError(new Error('ECONNREFUSED connection refused'))).toBe('network');
    expect(scheduler.classifyError(new Error('ENOTFOUND github.com'))).toBe('network');
    expect(scheduler.classifyError(new Error('timeout: operation timed out after 120s'))).toBe('timeout');
    expect(scheduler.classifyError(new Error('authentication failed'))).toBe('auth');
    expect(scheduler.classifyError(new Error('403 Forbidden'))).toBe('auth');
    expect(scheduler.classifyError(new Error('non-fast-forward rejected'))).toBe('conflict');
    expect(scheduler.classifyError(new Error('merge conflict detected'))).toBe('conflict');
    expect(scheduler.classifyError(new Error('some weird unknown error'))).toBe('unknown');
  });
});
