import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { computeHealthScore, HEALTH_WEIGHTS } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 2.6**
 * Property 10: Health score bounded [0,100] and correctly weighted.
 */
describe('Property 10: Health Score', () => {
  const categories = Object.keys(HEALTH_WEIGHTS);

  it('always returns value in [0, 100]', () => {
    fc.assert(fc.property(
      fc.array(fc.record({
        category: fc.constantFrom(...categories),
        score: fc.integer({ min: -50, max: 200 }),
      }), { minLength: 1, maxLength: 6 }),
      (checks) => {
        const report = { checks };
        const score = computeHealthScore(report);
        assert.ok(score >= 0 && score <= 100, `Score ${score} out of bounds`);
      }
    ), { numRuns: 200 });
  });

  it('returns 0 for empty checks', () => {
    assert.strictEqual(computeHealthScore({ checks: [] }), 0);
    assert.strictEqual(computeHealthScore(null), 0);
  });

  it('returns 100 when all categories score 100', () => {
    const checks = categories.map(c => ({ category: c, score: 100 }));
    assert.strictEqual(computeHealthScore({ checks }), 100);
  });

  it('returns 0 when all categories score 0', () => {
    const checks = categories.map(c => ({ category: c, score: 0 }));
    assert.strictEqual(computeHealthScore({ checks }), 0);
  });
});
