// src/hermes/sniping.js — Token sniping with honeypot/rug detection
import { ethers } from 'ethers';
import axios from 'axios';
import { config } from '../config.js';
import { getPrivateKey, getWalletInfo } from './wallets.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { logger } from '../utils/logger.js';

const UNISWAP_V2_FACTORY_ABI = [
  'event PairCreated(address indexed token0, address indexed token1, address pair, uint)',
];
const UNISWAP_V2_ROUTER = '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D';
const ROUTER_ABI = [
  'function swapExactETHForTokensSupportingFeeOnTransferTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) external payable',
];
const WETH = '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2';

/**
 * Check if a token is a honeypot/rug using GoPlus API
 */
export async function honeypotCheck({ tokenAddress, chain = 'ethereum' }) {
  const chainMap = { ethereum: 1, bsc: 56, polygon: 137, arbitrum: 42161, base: 8453 };
  const chainId = chainMap[chain] || 1;

  try {
    const res = await axios.get(
      `https://api.gopluslabs.io/api/v1/token_security/${chainId}?contract_addresses=${tokenAddress}`,
      { timeout: 15000 }
    );

    const data = res.data?.result?.[tokenAddress.toLowerCase()];
    if (!data) return { safe: false, reason: 'No data from GoPlus' };

    const risks = [];
    if (data.is_honeypot === '1') risks.push('HONEYPOT');
    if (data.is_blacklisted === '1') risks.push('BLACKLISTED');
    if (data.is_mintable === '1') risks.push('MINTABLE');
    if (data.can_take_back_ownership === '1') risks.push('CAN_TAKE_BACK_OWNERSHIP');
    if (parseFloat(data.buy_tax || 0) > 10) risks.push(`BUY_TAX_HIGH(${data.buy_tax}%)`);
    if (parseFloat(data.sell_tax || 0) > 10) risks.push(`SELL_TAX_HIGH(${data.sell_tax}%)`);
    if (parseInt(data.holder_count || 0) < 50) risks.push(`LOW_HOLDERS(${data.holder_count})`);

    return {
      safe: risks.length === 0,
      risks,
      data: {
        buyTax: data.buy_tax,
        sellTax: data.sell_tax,
        holders: data.holder_count,
        lpLocked: data.lp_locked === '1',
        ownerAddress: data.owner_address,
        totalSupply: data.total_supply,
      },
    };
  } catch (err) {
    logger.warn(`[sniper] GoPlus check failed: ${err.message}`);
    return { safe: false, reason: `GoPlus error: ${err.message}` };
  }
}

/**
 * Snipe a token on new pair creation
 * @param {Object} opts
 * @param {string} opts.walletLabel
 * @param {string} opts.tokenAddress - token to snipe
 * @param {string} opts.chain
 * @param {number} opts.amountEth - ETH to spend
 * @param {number} opts.minTokenOut - min tokens out (anti-MEV)
 * @param {boolean} opts.skipHoneypotCheck - danger! only for testing
 */
export async function snipeToken({ walletLabel, tokenAddress, chain = 'ethereum', amountEth, minTokenOut = 0, skipHoneypotCheck = false }) {
  // 1. Honeypot check (mandatory)
  if (!skipHoneypotCheck) {
    const check = await honeypotCheck({ tokenAddress, chain });
    if (!check.safe) {
      const reason = `Token failed safety check: ${check.risks?.join(', ') || check.reason}`;
      logger.warn(`[sniper] ${reason}`);
      return { success: false, reason, blocked: true };
    }
  }

  // 2. Governor gate
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: 'snipe',
    usdValue: amountEth * 3500, // rough ETH price estimate
    slippage: 50, // sniping inherently high slippage — use high allowance
    simulated: true,
  });
  if (!decision.allowed) return { success: false, reason: decision.reason };

  // 3. Execute swap
  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);
  const wallet = new ethers.Wallet(pk, provider);

  const router = new ethers.Contract(UNISWAP_V2_ROUTER, ROUTER_ABI, wallet);
  const info = getWalletInfo(walletLabel);

  const tx = await router.swapExactETHForTokensSupportingFeeOnTransferTokens(
    minTokenOut,
    [WETH, tokenAddress],
    info.address,
    Math.floor(Date.now() / 1000) + 60,
    { value: ethers.parseEther(String(amountEth)) }
  );

  await tx.wait();

  governorRecord({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: 'snipe',
    usdValue: amountEth * 3500,
    txHash: tx.hash,
  });

  logger.info(`[sniper] Sniped ${tokenAddress} | tx: ${tx.hash}`);
  return {
    success: true,
    txHash: tx.hash,
    token: tokenAddress,
    chain,
    spentEth: amountEth,
    explorer: `https://etherscan.io/tx/${tx.hash}`,
  };
}

/**
 * Listen for new pair creations on Uniswap V2
 * Returns unsubscribe function
 */
export function watchNewPairs({ chain = 'ethereum', onPair }) {
  const wsUrl = config.rpc.wsEvm?.ethereum;
  if (!wsUrl) {
    logger.warn('[sniper] WebSocket RPC not configured. Cannot watch pairs.');
    return () => {};
  }

  const provider = new ethers.WebSocketProvider(wsUrl);
  const FACTORY = '0x5C69bEe701ef814a2B6a3EDD4B1652CB9cc5aA6f';
  const factory = new ethers.Contract(FACTORY, UNISWAP_V2_FACTORY_ABI, provider);

  factory.on('PairCreated', (token0, token1, pair, _) => {
    onPair({ token0, token1, pair, chain });
  });

  return () => {
    factory.removeAllListeners();
    provider.destroy();
  };
}

function getChainId(chain) {
  const map = { ethereum: 1, base: 8453, arbitrum: 42161, polygon: 137, bsc: 56 };
  return map[chain] || 1;
}
