// tests/unit/brain-error-handling.test.js
// Unit Tests for Task 5.3: Error handling dan logging untuk skill execution
// Validates: Requirements 2.6, 2.7

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { ERROR_CATEGORIES, classifyError, executeSkill, formatErrorReport } from '../../src/core/brain.js';

// ─── Mock logger ─────────────────────────────────────────────────────────────
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn(),
  }
}));

// Mock dependencies that brain.js imports
vi.mock('../../src/config.js', () => ({
  config: { llm: { ollamaCloud: { model: 'test' } }, raja: { logDir: './logs' } }
}));

vi.mock('../../src/llm/cascade.js', () => ({
  callCascade: vi.fn(),
  switchProvider: vi.fn(),
  resolveProviderName: vi.fn(),
  getProviderStatus: vi.fn(() => ({ providers: [], mode: 'test' })),
}));

vi.mock('../../src/core/memory.js', () => ({
  recallMemory: vi.fn(async () => []),
  rememberFact: vi.fn(async () => {}),
}));

vi.mock('../../src/core/skill-registry.js', () => ({
  skills: {
    'test-skill': {
      name: 'Test Skill',
      module: { execute: vi.fn() }
    },
    'broken-skill': {
      name: 'Broken Skill',
      module: { execute: vi.fn() }
    }
  },
  routeSkill: vi.fn(() => ({ skill: null, score: 0, matched: [] })),
  fuzzyMatch: vi.fn(() => null),
  getSuggestions: vi.fn(() => []),
}));

vi.mock('../../src/self-upgrade/code-engine.js', () => ({
  selfModifyFromMessage: vi.fn(),
}));

vi.mock('../../src/core/conversation-learner.js', () => ({
  detectDissatisfaction: vi.fn(() => ({ dissatisfied: false })),
  detectSatisfaction: vi.fn(() => ({ satisfied: false })),
  learnFromMistake: vi.fn(async () => {}),
  reinforceGoodResponse: vi.fn(async () => {}),
  recallLessons: vi.fn(async () => ''),
}));

// ─── Tests ───────────────────────────────────────────────────────────────────

describe('ERROR_CATEGORIES', () => {
  it('should have all four required categories', () => {
    expect(ERROR_CATEGORIES).toHaveProperty('network');
    expect(ERROR_CATEGORIES).toHaveProperty('timeout');
    expect(ERROR_CATEGORIES).toHaveProperty('permission');
    expect(ERROR_CATEGORIES).toHaveProperty('runtime');
  });

  it('each category should have patterns array and suggestion string', () => {
    for (const [category, value] of Object.entries(ERROR_CATEGORIES)) {
      expect(Array.isArray(value.patterns)).toBe(true);
      expect(value.patterns.length).toBeGreaterThan(0);
      expect(typeof value.suggestion).toBe('string');
      expect(value.suggestion.length).toBeGreaterThan(0);
    }
  });
});

describe('classifyError()', () => {
  describe('network errors', () => {
    it('should classify ECONNREFUSED as network', () => {
      const result = classifyError(new Error('connect ECONNREFUSED 127.0.0.1:3000'));
      expect(result.category).toBe('network');
      expect(result.suggestion).toBe(ERROR_CATEGORIES.network.suggestion);
    });

    it('should classify ETIMEDOUT as network', () => {
      const result = classifyError(new Error('ETIMEDOUT'));
      expect(result.category).toBe('network');
    });

    it('should classify ENOTFOUND as network', () => {
      const result = classifyError(new Error('getaddrinfo ENOTFOUND api.example.com'));
      expect(result.category).toBe('network');
    });

    it('should classify "fetch failed" as network', () => {
      const result = classifyError(new Error('fetch failed'));
      expect(result.category).toBe('network');
    });
  });

  describe('timeout errors', () => {
    it('should classify timeout as timeout', () => {
      const result = classifyError(new Error('operation timeout after 30000ms'));
      expect(result.category).toBe('timeout');
      expect(result.suggestion).toBe(ERROR_CATEGORIES.timeout.suggestion);
    });

    it('should classify DEADLINE_EXCEEDED as timeout', () => {
      const result = classifyError(new Error('DEADLINE_EXCEEDED'));
      expect(result.category).toBe('timeout');
    });

    it('should classify AbortError as timeout', () => {
      const result = classifyError(new Error('AbortError: signal timed out'));
      expect(result.category).toBe('timeout');
    });
  });

  describe('permission errors', () => {
    it('should classify EACCES as permission', () => {
      const result = classifyError(new Error('EACCES: permission denied'));
      expect(result.category).toBe('permission');
      expect(result.suggestion).toBe(ERROR_CATEGORIES.permission.suggestion);
    });

    it('should classify EPERM as permission', () => {
      const result = classifyError(new Error('EPERM: operation not permitted'));
      expect(result.category).toBe('permission');
    });

    it('should classify 403 as permission', () => {
      const result = classifyError(new Error('Request failed with status 403'));
      expect(result.category).toBe('permission');
    });

    it('should classify unauthorized as permission', () => {
      const result = classifyError(new Error('unauthorized access'));
      expect(result.category).toBe('permission');
    });
  });

  describe('runtime errors', () => {
    it('should classify TypeError as runtime', () => {
      const result = classifyError(new TypeError('Cannot read properties of undefined'));
      expect(result.category).toBe('runtime');
      expect(result.suggestion).toBe(ERROR_CATEGORIES.runtime.suggestion);
    });

    it('should classify ReferenceError as runtime', () => {
      const result = classifyError(new Error('ReferenceError: x is not defined'));
      expect(result.category).toBe('runtime');
    });

    it('should classify SyntaxError as runtime', () => {
      const result = classifyError(new Error('SyntaxError: Unexpected token'));
      expect(result.category).toBe('runtime');
    });
  });

  describe('default fallback', () => {
    it('should default to runtime for unknown errors', () => {
      const result = classifyError(new Error('something completely unknown happened'));
      expect(result.category).toBe('runtime');
      expect(result.suggestion).toBe(ERROR_CATEGORIES.runtime.suggestion);
    });

    it('should handle non-Error objects (strings)', () => {
      const result = classifyError('ECONNREFUSED from server');
      expect(result.category).toBe('network');
    });
  });

  describe('case insensitivity', () => {
    it('should match patterns case-insensitively', () => {
      const result = classifyError(new Error('econnrefused from some host'));
      expect(result.category).toBe('network');
    });

    it('should match mixed-case pattern', () => {
      const result = classifyError(new Error('The aborterror was raised'));
      expect(result.category).toBe('timeout');
    });
  });
});

describe('executeSkill()', () => {
  let loggerMock;

  beforeEach(async () => {
    const loggerModule = await import('../../src/utils/logger.js');
    loggerMock = loggerModule.logger;
    vi.clearAllMocks();
  });

  it('should return success with result and duration on successful execution', async () => {
    const { skills } = await import('../../src/core/skill-registry.js');
    skills['test-skill'].module.execute.mockResolvedValue('execution result');

    const result = await executeSkill('test-skill', 'test message', { userId: 'u1' });

    expect(result.success).toBe(true);
    expect(result.result).toBe('execution result');
    expect(result.duration).toBeGreaterThanOrEqual(0);
    expect(typeof result.duration).toBe('number');
  });

  it('should log success with correct format', async () => {
    const { skills } = await import('../../src/core/skill-registry.js');
    skills['test-skill'].module.execute.mockResolvedValue('ok');

    await executeSkill('test-skill', 'test message');

    expect(loggerMock.info).toHaveBeenCalledWith(
      expect.stringMatching(/\[EXEC\] skill=test-skill status=success duration=\d+ms/)
    );
  });

  it('should return structured error on failure without LLM fallback', async () => {
    const { skills } = await import('../../src/core/skill-registry.js');
    skills['broken-skill'].module.execute.mockRejectedValue(new Error('ECONNREFUSED'));

    const result = await executeSkill('broken-skill', 'test message');

    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(result.error.skillId).toBe('broken-skill');
    expect(result.error.category).toBe('network');
    expect(result.error.suggestion).toBe(ERROR_CATEGORIES.network.suggestion);
    expect(result.error.message).toBe('ECONNREFUSED');
    expect(result.duration).toBeGreaterThanOrEqual(0);
    // No LLM fallback — result should be the error, not an LLM response
    expect(result.result).toBeUndefined();
  });

  it('should log failure with correct format', async () => {
    const { skills } = await import('../../src/core/skill-registry.js');
    skills['broken-skill'].module.execute.mockRejectedValue(new Error('ETIMEDOUT'));

    await executeSkill('broken-skill', 'test message');

    expect(loggerMock.error).toHaveBeenCalledWith(
      expect.stringMatching(/\[EXEC\] skill=broken-skill status=failed duration=\d+ms error=ETIMEDOUT/)
    );
  });

  it('should handle skill not found error', async () => {
    const result = await executeSkill('nonexistent-skill', 'test message');

    expect(result.success).toBe(false);
    expect(result.error.skillId).toBe('nonexistent-skill');
    expect(result.error.category).toBe('runtime');
  });

  it('should measure duration accurately', async () => {
    const { skills } = await import('../../src/core/skill-registry.js');
    skills['test-skill'].module.execute.mockImplementation(
      () => new Promise(resolve => setTimeout(() => resolve('done'), 50))
    );

    const result = await executeSkill('test-skill', 'test message');

    expect(result.success).toBe(true);
    expect(result.duration).toBeGreaterThanOrEqual(40); // Allow some variance
  });
});

describe('formatErrorReport()', () => {
  it('should include skill name, category, and suggestion', () => {
    const errorInfo = {
      skillId: 'swap-engine',
      category: 'network',
      suggestion: 'Cek koneksi internet VPS atau retry dalam beberapa saat'
    };

    const report = formatErrorReport(errorInfo);

    expect(report).toContain('swap-engine');
    expect(report).toContain('network');
    expect(report).toContain('Cek koneksi internet VPS atau retry dalam beberapa saat');
  });

  it('should format correctly with warning emoji', () => {
    const errorInfo = {
      skillId: 'deploy-skill',
      category: 'timeout',
      suggestion: 'Operasi memakan waktu terlalu lama, coba lagi atau pecah jadi step lebih kecil'
    };

    const report = formatErrorReport(errorInfo);

    expect(report).toMatch(/^⚠️ Skill "deploy-skill" gagal\./);
    expect(report).toContain('Kategori: timeout');
    expect(report).toContain('Saran: ');
  });

  it('should produce multi-line format', () => {
    const errorInfo = {
      skillId: 'test',
      category: 'permission',
      suggestion: 'Cek permission file/API key yang digunakan'
    };

    const report = formatErrorReport(errorInfo);
    const lines = report.split('\n');

    expect(lines.length).toBe(3);
    expect(lines[0]).toContain('Skill "test" gagal');
    expect(lines[1]).toContain('Kategori: permission');
    expect(lines[2]).toContain('Saran: Cek permission file/API key yang digunakan');
  });
});
