// src/self-upgrade/code-engine.js — Autonomous code writer & self-modifier
// FITUR UTAMA: bot bisa menulis/modifikasi kode dirinya sendiri dari instruksi Telegram
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { config } from '../config.js';
import { callCascade } from '../llm/cascade.js';
import { logger } from '../utils/logger.js';
import { createBackup } from './backup.js';
import { healthCheck } from './healthcheck.js';

const execAsync = promisify(exec);

// Commands that code-engine is NOT allowed to execute
const BLOCKED_COMMANDS = [
  /\bnode\s+src\/index\.js\b/i,         // No spawning bot directly
  /\bnode\s+\.\/src\/index\.js\b/i,
  /\bnohup\b/i,                          // No background processes
  /\b&\s*$/,                             // No backgrounding with &
  /\bdisown\b/i,
  /\bscreen\b/i,
  /\btmux\b/i,
  /\brm\s+-rf\s+\//i,                   // No recursive delete from root
  /\bcurl\b.*\|\s*bash/i,               // No pipe-to-bash
  /\bwget\b.*\|\s*bash/i,
];

/**
 * Safe exec wrapper — blocks dangerous commands
 */
async function safeExecAsync(command, options = {}) {
  for (const pattern of BLOCKED_COMMANDS) {
    if (pattern.test(command)) {
      throw new Error(`Blocked command: "${command}" — security policy violation`);
    }
  }
  return execAsync(command, options);
}

// File-file yang TIDAK BOLEH dimodifikasi via Telegram (frozen)
const FROZEN_FILES = new Set([
  'src/self-upgrade/upgrade.js',
  'src/self-upgrade/code-engine.js',  // self-modify guard
  'src/self-upgrade/backup.js',
  'src/self-upgrade/healthcheck.js',
  'src/core/skill-integrity.js',
  'src/watchdog/monitor.js',
  'src/hermes/governor.js',
  '.env',
  'package-lock.json',
]);

const CODE_WRITER_SYSTEM = `Kamu adalah RAJA, autonomous AI agent yang bisa memodifikasi kode diri sendiri.

LIMITASI PENTING:
- Kamu TIDAK BISA mengakses URL/internet/GitHub langsung. Kalau user kasih link GitHub, JANGAN generate kode berdasarkan asumsi isi repo.
- Kalau instruksi mereferensi URL tanpa isi file → minta user upload file-nya langsung, atau tulis implementasi berdasarkan deskripsi yang diberikan.
- Kalau instruksi "hapus/delete skill [nama]" → action: "delete", path: "src/skills/[nama].js"

TUGASMU:
Berdasarkan instruksi operator, tulis atau modifikasi file JavaScript untuk raja-bot.

Struktur bot raja-bot (Node.js ESM):
- src/skills/*.js — skill files, export default { id, name, description, async execute(query, context) }
- src/hermes/*.js — crypto modules
- src/telegram/commands/*.js — command handlers, export named functions
- src/core/brain.js — router utama
- src/telegram/bot.js — bot handler, perlu update kalau ada command baru

Contoh skill file minimal:
\`\`\`js
export default {
  id: 'crypto-price',
  name: 'crypto-price-checker',
  description: 'Cek harga real-time cryptocurrency via CoinGecko',
  keywords: { 'cek harga': 3, 'harga crypto': 3, 'price': 3, 'btc': 2, 'eth': 2, 'bitcoin': 2, 'ethereum': 2 },
  async execute(query, context) {
    // logic — HARUS return string hasil
    return 'Harga BTC: $105,000';
  }
};
\`\`\`

PENTING: field "keywords" WAJIB ada di setiap skill baru.
Format: { 'keyword': weight } — weight 3=high, 2=medium, 1=low.
Keywords adalah kata/frasa yang user akan ketik untuk trigger skill ini.

Kalau instruksi tambah skill baru:
1. Buat src/skills/[id].js
2. TIDAK perlu modifikasi skill-registry.js — registry auto-load dari folder

Kalau instruksi tambah Telegram command baru:
1. Tambah function di src/telegram/commands/*.js
2. Modify src/telegram/bot.js — tambah bot.onText handler

OUTPUT FORMAT (WAJIB):
Jawab dengan JSON valid saja, tidak ada teks lain di luar JSON:
{
  "plan": "1-2 kalimat rencana eksekusi",
  "files": [
    {
      "action": "create" | "modify" | "delete",
      "path": "path/relative/dari/root/botnya",
      "content": "isi file lengkap (untuk create/modify)",
      "reason": "kenapa file ini dibuat/diubah"
    }
  ],
  "restartRequired": true | false,
  "npmInstallRequired": false,
  "newPackages": [],
  "summary": "ringkasan apa yang diubah"
}

RULES:
- path selalu relative dari root bot (contoh: "src/skills/H8.js")
- content harus kode lengkap, bukan snippet — tidak ada "// ... rest of code"
- Untuk modify: sertakan file LENGKAP setelah dimodifikasi
- JANGAN modifikasi frozen files: src/self-upgrade/upgrade.js, src/self-upgrade/code-engine.js, src/core/skill-integrity.js, src/hermes/governor.js, src/watchdog/monitor.js
- Semua import harus pakai path relatif dengan .js extension
- Gunakan ES modules (import/export), bukan require
- Kalau butuh package baru, set npmInstallRequired: true dan list di newPackages
- restartRequired: true kalau perubahan butuh restart bot
`;

/**
 * Parse instruksi natural language dari operator dan generate perubahan kode
 */
export async function generateCodeChanges(instruction, context = '') {
  const messages = [
    { role: 'system', content: CODE_WRITER_SYSTEM },
    {
      role: 'user',
      content: `Instruksi operator: "${instruction}"
      
${context ? `Context tambahan:\n${context}` : ''}

Tulis perubahan yang diperlukan dalam format JSON yang diminta.`,
    },
  ];

  const result = await callCascade(messages, { maxTokens: 4000, temperature: 0.2 });

  // Extract JSON dari response
  const jsonMatch = result.text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('LLM tidak mengembalikan JSON valid');
  }

  const plan = JSON.parse(jsonMatch[0]);
  return plan;
}

/**
 * Validasi plan sebelum eksekusi
 */
function validatePlan(plan) {
  const errors = [];

  if (!plan.files || !Array.isArray(plan.files)) {
    errors.push('plan.files harus array');
  }

  for (const f of (plan.files || [])) {
    // Cek frozen files
    const normalPath = f.path?.replace(/^\//, '').replace(/\\/g, '/');
    if (FROZEN_FILES.has(normalPath)) {
      errors.push(`FROZEN: ${f.path} tidak bisa dimodifikasi`);
    }

    // Cek path traversal
    if (f.path?.includes('..')) {
      errors.push(`Path traversal tidak diizinkan: ${f.path}`);
    }

    // Harus ada content untuk create/modify
    if ((f.action === 'create' || f.action === 'modify') && !f.content) {
      errors.push(`File ${f.path}: content kosong untuk action ${f.action}`);
    }
  }

  return errors;
}

/**
 * Eksekusi plan: tulis file, install deps, restart
 * @param {Object} plan - hasil dari generateCodeChanges
 * @param {Function} onProgress - callback progress(message)
 */
export async function executePlan(plan, onProgress = () => {}) {
  const root = config.raja.home;
  const written = [];
  const errors = [];

  // 1. Validasi
  const validationErrors = validatePlan(plan);
  if (validationErrors.length > 0) {
    return { success: false, errors: validationErrors };
  }

  // 2. Backup sebelum perubahan apapun
  onProgress('💾 Backup state...');
  const backupId = await createBackup({ reason: 'pre-code-change', version: 'auto' });

  try {
    // 3. Tulis semua file
    for (const f of plan.files) {
      const fullPath = path.join(root, f.path);

      if (f.action === 'delete') {
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
          written.push(`🗑 Deleted: ${f.path}`);
          onProgress(`🗑 Deleted: ${f.path}`);
        }
        continue;
      }

      if (f.action === 'create' || f.action === 'modify') {
        // Buat direktori kalau belum ada
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, f.content, 'utf8');
        written.push(`✅ ${f.action === 'create' ? 'Created' : 'Modified'}: ${f.path}`);
        onProgress(`✅ ${f.action === 'create' ? 'Created' : 'Modified'}: ${f.path}`);
      }
    }

    // 4. Install npm packages kalau ada
    if (plan.npmInstallRequired && plan.newPackages?.length > 0) {
      onProgress(`📦 Installing: ${plan.newPackages.join(', ')}`);
      const pkgs = plan.newPackages.map(p => `"${p}"`).join(' ');
      await safeExecAsync(`npm install --save ${pkgs}`, {
        cwd: root,
        timeout: 120000,
      });
      written.push(`📦 Installed: ${plan.newPackages.join(', ')}`);
    }

    // 5. Skill integrity re-generate kalau ada skill file baru
    const hasSkillChanges = plan.files.some(f => f.path.includes('/skills/'));
    if (hasSkillChanges) {
      onProgress('🔐 Regenerating skill integrity manifest...');
      await safeExecAsync(`node src/core/skill-integrity.js generate`, { cwd: root });
    }

    // 6. Restart kalau diminta
    if (plan.restartRequired) {
      onProgress('🔄 Restarting bot...');
      await restartBot();

      // Health check
      onProgress('🏥 Health check...');
      const health = await healthCheck({ retries: 5, interval: 8000 });
      if (!health.ok) {
        throw new Error(`Health check gagal setelah restart: ${health.error}`);
      }
      written.push('🔄 Bot restarted & healthy');
    }

    logger.info(`[code-engine] Plan executed: ${written.length} changes, backup: ${backupId}`);
    return { success: true, changes: written, backupId, plan };

  } catch (err) {
    logger.error(`[code-engine] Execution failed: ${err.message}`);

    // Rollback dari backup
    try {
      onProgress('⏪ Rollback...');
      const { restoreBackup } = await import('./backup.js');
      await restoreBackup(backupId);
      if (plan.restartRequired) {
        await restartBot();
        await healthCheck({ retries: 3, interval: 5000 });
      }
      written.push('⏪ Rolled back ke state sebelumnya');
    } catch (rollbackErr) {
      logger.error(`[code-engine] Rollback failed: ${rollbackErr.message}`);
      errors.push(`Rollback gagal: ${rollbackErr.message}`);
    }

    return { success: false, error: err.message, changes: written, errors, backupId };
  }
}

/**
 * Flow lengkap: parse instruksi → generate plan → konfirmasi → eksekusi
 * Dipakai oleh Telegram command handler (/code, /codenow)
 */
export async function selfModify({ instruction, autoConfirm = false, onProgress = () => {}, onConfirm }) {
  onProgress('🧠 Analyzing instruction...');

  // Generate plan
  let plan;
  try {
    plan = await generateCodeChanges(instruction);
  } catch (err) {
    return { success: false, error: `Failed to generate plan: ${err.message}` };
  }

  // Validasi plan
  const errors = validatePlan(plan);
  if (errors.length > 0) {
    return { success: false, error: errors.join('\n'), plan };
  }

  // Ringkasan plan untuk konfirmasi
  const planSummary = formatPlanSummary(plan);

  if (!autoConfirm && onConfirm) {
    const confirmed = await onConfirm(planSummary);
    if (!confirmed) {
      return { success: false, error: 'Dibatalkan oleh operator', cancelled: true };
    }
  }

  // Eksekusi
  return await executePlan(plan, onProgress);
}

/**
 * selfModifyFromMessage — Single entry point untuk autonomous modification dari pesan Telegram.
 * Dipanggil oleh brain.js ketika intent classifier mendeteksi self-modification intent.
 * Tidak perlu konfirmasi — langsung eksekusi.
 *
 * @param {number|string} chatId
 * @param {string} instruction - instruksi bersih (sudah di-extract dari pesan)
 * @param {Object} bot - instance TelegramBot
 */
export async function selfModifyFromMessage(chatId, instruction, bot) {
  // Kirim ack langsung
  await bot.sendMessage(chatId, '🤖 Oke, saya akan kerjakan sekarang...\nGenerating code...').catch(() => {});

  try {
    // 1. Analyze
    await bot.sendMessage(chatId, '🧠 Analyzing request...').catch(() => {});

    // 2. Generate plan dari LLM
    let plan;
    try {
      plan = await generateCodeChanges(instruction);
    } catch (err) {
      await bot.sendMessage(chatId, `❌ Gagal generate plan: ${err.message}`).catch(() => {});
      return;
    }

    // 3. Validasi
    const validationErrors = validatePlan(plan);
    if (validationErrors.length > 0) {
      await bot.sendMessage(chatId, `❌ Validasi gagal:\n${validationErrors.join('\n')}`).catch(() => {});
      return;
    }

    if (!plan.files?.length) {
      await bot.sendMessage(chatId, '❌ LLM tidak menghasilkan perubahan file. Coba instruksi lebih spesifik.').catch(() => {});
      return;
    }

    // 4. Backup
    const root = config.raja.home;
    const backupId = await createBackup({ reason: 'pre-selfmodify-message', version: 'auto' });

    // 5. Tulis file dengan progress ke Telegram
    const written = [];
    for (const f of plan.files) {
      const fullPath = path.join(root, f.path);

      if (f.action === 'delete') {
        if (fs.existsSync(fullPath)) {
          fs.unlinkSync(fullPath);
          written.push(`🗑 ${f.path}`);
          await bot.sendMessage(chatId, `🗑 Deleted: ${f.path}`).catch(() => {});
        }
        continue;
      }

      if (f.action === 'create' || f.action === 'modify') {
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, f.content, 'utf8');
        written.push(`${f.action === 'create' ? '🆕' : '✏️'} ${f.path}`);
        await bot.sendMessage(chatId, `📝 Writing code: ${f.path}`).catch(() => {});
      }
    }

    // 6. Install dependencies kalau perlu
    if (plan.npmInstallRequired && plan.newPackages?.length > 0) {
      await bot.sendMessage(chatId, `📦 Installing dependencies: ${plan.newPackages.join(', ')}...`).catch(() => {});
      const pkgs = plan.newPackages.map(p => `"${p}"`).join(' ');
      await safeExecAsync(`npm install --save ${pkgs}`, { cwd: root, timeout: 120000 });
      written.push(`📦 ${plan.newPackages.join(', ')}`);
    }

    // 7. Update integrity manifest kalau ada skill changes
    const hasSkillChanges = plan.files.some(f => f.path.includes('/skills/'));
    if (hasSkillChanges) {
      await bot.sendMessage(chatId, '🔐 Updating integrity manifest...').catch(() => {});
      try {
        await safeExecAsync(`node src/core/skill-integrity.js generate`, { cwd: root });
      } catch (intErr) {
        logger.warn(`[selfModifyFromMessage] integrity regen warning: ${intErr.message}`);
      }

      // 7b. Hot-reload skill registry (agar skill baru langsung aktif tanpa restart)
      try {
        const { initSkillRegistry } = await import('../core/skill-registry.js');
        await initSkillRegistry();
        await bot.sendMessage(chatId, '🔄 Skill registry reloaded.').catch(() => {});
      } catch (reloadErr) {
        logger.warn(`[selfModifyFromMessage] skill reload warning: ${reloadErr.message}`);
      }
    }

    // 8. Restart kalau diminta
    if (plan.restartRequired) {
      await bot.sendMessage(chatId, '🔄 Restarting bot...').catch(() => {});
      await restartBot();

      // 9. Health check
      await bot.sendMessage(chatId, '🏥 Running health check...').catch(() => {});
      const health = await healthCheck({ retries: 5, interval: 8000 });
      if (!health.ok) {
        throw new Error(`Health check gagal setelah restart: ${health.error}`);
      }
    }

    // 10. Auto-sync to GitHub (non-blocking)
    try {
      const { execSync } = await import('child_process');
      execSync('bash scripts/git-sync.sh', { cwd: root, timeout: 30000, stdio: 'pipe' });
      logger.info('[selfModifyFromMessage] Git auto-sync completed.');
    } catch (syncErr) {
      logger.warn(`[selfModifyFromMessage] Git sync skipped: ${syncErr.message}`);
      // Non-fatal — cron will catch it later
    }

    // 11. Laporan sukses ke user
    const changeList = written.map(w => `  ${w}`).join('\n');
    await bot.sendMessage(
      chatId,
      `✅ Selesai!\n\n${changeList}\n\nSkill/fitur baru sudah aktif. Coba sekarang.`,
      { parse_mode: 'Markdown' }
    ).catch(() => {});

    logger.info(`[selfModifyFromMessage] Success: ${written.length} changes, backup: ${backupId}`);

  } catch (err) {
    logger.error(`[selfModifyFromMessage] Error: ${err.message}`);

    // Rollback
    await bot.sendMessage(chatId, '⏪ Gagal, melakukan rollback...').catch(() => {});
    try {
      const { restoreBackup } = await import('./backup.js');
      // Ambil backup terbaru
      await restoreBackup('latest');
      await bot.sendMessage(chatId, '✅ Rollback selesai. State bot kembali normal.').catch(() => {});
    } catch (rollbackErr) {
      logger.error(`[selfModifyFromMessage] Rollback failed: ${rollbackErr.message}`);
    }

    await bot.sendMessage(chatId, `❌ Detail error: ${err.message}`).catch(() => {});
  }
}

function formatPlanSummary(plan) {
  const lines = [
    `📋 Plan: ${plan.plan}`,
    '',
    `Files yang akan diubah (${plan.files.length}):`,
  ];

  for (const f of plan.files) {
    const icon = f.action === 'create' ? '🆕' : f.action === 'modify' ? '✏️' : '🗑';
    lines.push(`${icon} ${f.action.toUpperCase()}: ${f.path}`);
    if (f.reason) lines.push(`   → ${f.reason}`);
  }

  if (plan.npmInstallRequired) {
    lines.push(``, `📦 New packages: ${plan.newPackages?.join(', ')}`);
  }
  if (plan.restartRequired) {
    lines.push(`🔄 Bot restart required`);
  }

  return lines.join('\n');
}

async function restartBot() {
  // ONLY use pm2 restart — never spawn raw node process
  try {
    await execAsync('pm2 restart raja-bot', { timeout: 15000 });
    logger.info('[code-engine] Bot restarted via pm2');
  } catch (err) {
    logger.error(`[code-engine] pm2 restart failed: ${err.message}`);
    // Do NOT use process.exit or spawn raw node — let operator handle manually
    throw new Error('pm2 restart failed. Manual restart required.');
  }
}
