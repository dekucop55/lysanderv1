// tests/pbt/preference-decay.test.js
// Property-Based Test for Preference Confidence Decay (Property 18)
// **Validates: Requirements 5.6**
//
// Property 18: For any preferensi yang tidak diupdate selama D hari (D > 90),
// confidence SHALL berkurang sebesar floor((D - 90) / 30) × 0.1.
// Preferensi dengan confidence = 0.0 SHALL dihapus pada siklus compact.
import { describe, it, expect, beforeEach } from 'vitest';
import fc from 'fast-check';

// === Mock Preference DB (mirrors SQLite behavior for testing) ===
class MockPreferenceDB {
  constructor() {
    this.rows = [];
    this.nextId = 1;
  }

  clear() {
    this.rows = [];
    this.nextId = 1;
  }

  insert(row) {
    const newRow = { ...row, id: this.nextId++ };
    this.rows.push(newRow);
    return newRow.id;
  }

  getAll() {
    return [...this.rows];
  }

  getById(id) {
    return this.rows.find(r => r.id === id) || null;
  }

  update(id, fields) {
    const idx = this.rows.findIndex(r => r.id === id);
    if (idx >= 0) {
      this.rows[idx] = { ...this.rows[idx], ...fields };
    }
  }

  delete(id) {
    this.rows = this.rows.filter(r => r.id !== id);
  }

  findStalePreferences(cutoffIso) {
    return this.rows.filter(r => r.last_updated < cutoffIso);
  }
}

let mockDb;

/**
 * runPreferenceDecay implementation mirroring the real logic in src/core/memory.js
 * Uses mockDb instead of SQLite. Takes `nowMs` param for deterministic testing.
 */
function runPreferenceDecay(nowMs) {
  const ninetyDaysMs = 90 * 24 * 60 * 60 * 1000;
  const ninetyDaysAgo = new Date(nowMs - ninetyDaysMs).toISOString();

  const stalePreferences = mockDb.findStalePreferences(ninetyDaysAgo);

  if (stalePreferences.length === 0) {
    return { decayed: 0, deleted: 0 };
  }

  let decayed = 0;
  let deleted = 0;

  for (const pref of stalePreferences) {
    const lastUpdatedMs = new Date(pref.last_updated).getTime();
    const daysSinceUpdate = (nowMs - lastUpdatedMs) / (24 * 60 * 60 * 1000);

    // Calculate decay: floor((D - 90) / 30) * 0.1
    const decayPeriods = Math.floor((daysSinceUpdate - 90) / 30);
    if (decayPeriods <= 0) continue;

    const decayAmount = decayPeriods * 0.1;
    const newConfidence = Math.round((pref.confidence - decayAmount) * 100) / 100;

    if (newConfidence <= 0) {
      mockDb.delete(pref.id);
      deleted++;
    } else {
      mockDb.update(pref.id, { confidence: newConfidence });
      decayed++;
    }
  }

  return { decayed, deleted };
}

beforeEach(() => {
  mockDb = new MockPreferenceDB();
});

describe('Property 18: Preference Confidence Decay', () => {
  /**
   * **Validates: Requirements 5.6**
   *
   * Property 18a: For any preference not updated for D days (D > 90),
   * confidence SHALL be reduced by floor((D - 90) / 30) × 0.1
   */
  it('decay formula is correctly applied: confidence reduced by floor((D-90)/30) * 0.1', () => {
    fc.assert(
      fc.property(
        // D: days since last update, must be > 90 to trigger decay
        fc.integer({ min: 91, max: 1000 }),
        // initialConfidence: starting confidence between 0.1 and 1.0
        fc.double({ min: 0.1, max: 1.0, noNaN: true }),
        (daysSinceUpdate, initialConfidence) => {
          mockDb.clear();

          const nowMs = Date.now();
          const lastUpdatedMs = nowMs - daysSinceUpdate * 24 * 60 * 60 * 1000;
          const lastUpdatedIso = new Date(lastUpdatedMs).toISOString();

          // Round initial confidence to avoid floating point weirdness
          const roundedConfidence = Math.round(initialConfidence * 100) / 100;

          mockDb.insert({
            user_id: 'user1',
            preference_key: 'test_pref',
            preference_value: 'test_val',
            confidence: roundedConfidence,
            last_updated: lastUpdatedIso,
            source_message_id: null
          });

          runPreferenceDecay(nowMs);

          // Expected decay calculation
          const expectedDecayPeriods = Math.floor((daysSinceUpdate - 90) / 30);
          const expectedDecayAmount = expectedDecayPeriods * 0.1;
          const expectedNewConfidence = Math.round((roundedConfidence - expectedDecayAmount) * 100) / 100;

          const row = mockDb.getById(1);

          if (expectedNewConfidence <= 0) {
            // Should be deleted
            expect(row).toBeNull();
          } else {
            // Should be decayed to expected value
            expect(row).not.toBeNull();
            expect(row.confidence).toBeCloseTo(expectedNewConfidence, 2);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  /**
   * **Validates: Requirements 5.6**
   *
   * Property 18b: Preferences with confidence that would reach 0.0 are deleted
   */
  it('preferences with confidence reaching 0.0 or below are deleted on compact', () => {
    fc.assert(
      fc.property(
        // D large enough to ensure deletion for any initial confidence
        fc.integer({ min: 91, max: 2000 }),
        // Low initial confidence that's likely to reach zero
        fc.double({ min: 0.01, max: 0.5, noNaN: true }),
        (daysSinceUpdate, initialConfidence) => {
          mockDb.clear();

          const nowMs = Date.now();
          const lastUpdatedMs = nowMs - daysSinceUpdate * 24 * 60 * 60 * 1000;
          const lastUpdatedIso = new Date(lastUpdatedMs).toISOString();

          const roundedConfidence = Math.round(initialConfidence * 100) / 100;

          mockDb.insert({
            user_id: 'user1',
            preference_key: 'decay_pref',
            preference_value: 'decay_val',
            confidence: roundedConfidence,
            last_updated: lastUpdatedIso,
            source_message_id: null
          });

          runPreferenceDecay(nowMs);

          const expectedDecayPeriods = Math.floor((daysSinceUpdate - 90) / 30);
          const expectedDecayAmount = expectedDecayPeriods * 0.1;
          const expectedNewConfidence = Math.round((roundedConfidence - expectedDecayAmount) * 100) / 100;

          const row = mockDb.getById(1);

          if (expectedNewConfidence <= 0) {
            // MUST be deleted
            expect(row).toBeNull();
          } else {
            // MUST still exist with reduced confidence
            expect(row).not.toBeNull();
            expect(row.confidence).toBeGreaterThan(0);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  /**
   * **Validates: Requirements 5.6**
   *
   * Property 18c: Preferences updated within 90 days are NOT decayed
   */
  it('preferences updated within 90 days are NOT decayed', () => {
    fc.assert(
      fc.property(
        // D: days since last update, 0 to 90 inclusive — should NOT decay
        fc.integer({ min: 0, max: 90 }),
        // Any confidence
        fc.double({ min: 0.1, max: 1.0, noNaN: true }),
        (daysSinceUpdate, initialConfidence) => {
          mockDb.clear();

          const nowMs = Date.now();
          const lastUpdatedMs = nowMs - daysSinceUpdate * 24 * 60 * 60 * 1000;
          const lastUpdatedIso = new Date(lastUpdatedMs).toISOString();

          const roundedConfidence = Math.round(initialConfidence * 100) / 100;

          mockDb.insert({
            user_id: 'user1',
            preference_key: 'recent_pref',
            preference_value: 'recent_val',
            confidence: roundedConfidence,
            last_updated: lastUpdatedIso,
            source_message_id: null
          });

          runPreferenceDecay(nowMs);

          // Preference should NOT be affected
          const row = mockDb.getById(1);
          expect(row).not.toBeNull();
          expect(row.confidence).toBe(roundedConfidence);
        }
      ),
      { numRuns: 200 }
    );
  });

  /**
   * **Validates: Requirements 5.6**
   *
   * Property 18d: The decay formula is correctly applied across random D values
   * — specifically verifying the floor((D-90)/30) periods calculation
   */
  it('decay periods calculation matches floor((D-90)/30) exactly', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 91, max: 3000 }),
        (daysSinceUpdate) => {
          mockDb.clear();

          const nowMs = Date.now();
          const lastUpdatedMs = nowMs - daysSinceUpdate * 24 * 60 * 60 * 1000;
          const lastUpdatedIso = new Date(lastUpdatedMs).toISOString();

          // Use high confidence to avoid deletion, so we can check the exact value
          const initialConfidence = 1.0;

          mockDb.insert({
            user_id: 'user1',
            preference_key: 'periods_test',
            preference_value: 'val',
            confidence: initialConfidence,
            last_updated: lastUpdatedIso,
            source_message_id: null
          });

          runPreferenceDecay(nowMs);

          const expectedPeriods = Math.floor((daysSinceUpdate - 90) / 30);
          const expectedDecay = expectedPeriods * 0.1;
          const expectedConfidence = Math.round((initialConfidence - expectedDecay) * 100) / 100;

          const row = mockDb.getById(1);

          if (expectedConfidence <= 0) {
            expect(row).toBeNull();
          } else {
            expect(row).not.toBeNull();
            expect(row.confidence).toBeCloseTo(expectedConfidence, 2);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  /**
   * **Validates: Requirements 5.6**
   *
   * Property 18e: Multiple preferences are each decayed independently
   * based on their own last_updated timestamp
   */
  it('multiple preferences decay independently based on their individual last_updated', () => {
    fc.assert(
      fc.property(
        // Generate 2-5 preferences with different ages
        fc.array(
          fc.record({
            daysSinceUpdate: fc.integer({ min: 50, max: 500 }),
            confidence: fc.double({ min: 0.3, max: 1.0, noNaN: true })
          }),
          { minLength: 2, maxLength: 5 }
        ),
        (preferences) => {
          mockDb.clear();

          const nowMs = Date.now();

          // Insert preferences with varying ages
          for (let i = 0; i < preferences.length; i++) {
            const { daysSinceUpdate, confidence } = preferences[i];
            const lastUpdatedMs = nowMs - daysSinceUpdate * 24 * 60 * 60 * 1000;
            const lastUpdatedIso = new Date(lastUpdatedMs).toISOString();
            const roundedConfidence = Math.round(confidence * 100) / 100;

            mockDb.insert({
              user_id: 'user1',
              preference_key: `pref_${i}`,
              preference_value: `val_${i}`,
              confidence: roundedConfidence,
              last_updated: lastUpdatedIso,
              source_message_id: null
            });
          }

          runPreferenceDecay(nowMs);

          // Verify each preference was handled correctly based on its own age
          for (let i = 0; i < preferences.length; i++) {
            const { daysSinceUpdate, confidence } = preferences[i];
            const roundedConfidence = Math.round(confidence * 100) / 100;
            const row = mockDb.getById(i + 1);

            if (daysSinceUpdate <= 90) {
              // Should NOT be decayed
              expect(row).not.toBeNull();
              expect(row.confidence).toBe(roundedConfidence);
            } else {
              // Should be decayed
              const expectedPeriods = Math.floor((daysSinceUpdate - 90) / 30);
              const expectedDecay = expectedPeriods * 0.1;
              const expectedNewConfidence = Math.round((roundedConfidence - expectedDecay) * 100) / 100;

              if (expectedNewConfidence <= 0) {
                expect(row).toBeNull();
              } else {
                expect(row).not.toBeNull();
                expect(row.confidence).toBeCloseTo(expectedNewConfidence, 2);
              }
            }
          }
        }
      ),
      { numRuns: 100 }
    );
  });
});
