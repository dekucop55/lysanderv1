// src/index.js — RAJA Bot entry point
import 'dotenv/config';
import { logger } from './utils/logger.js';
import { config, validateConfig } from './config.js';
import { startBot } from './telegram/bot.js';
import { startWatchdog, initWatchdogHeartbeat } from './watchdog/monitor.js';
import { initMemory, checkIntegrity, restoreFromBackup, runPreferenceDecay } from './core/memory.js';
import { initSkillRegistry } from './core/skill-registry.js';
import { verifyIntegrity } from './core/skill-integrity.js';
import { runDailyReflection } from './core/reflection.js';
import { runDailyBriefing } from './core/briefing.js';
import { weeklyLearningReview } from './core/conversation-learner.js';
import { initGovernor } from './hermes/governor.js';
import { ContextWindow } from './core/context-window.js';
import { AutoPushScheduler } from './core/auto-push.js';
import cron from 'node-cron';

// Exported instances for use by brain.js and other modules
export let contextWindow = null;
export const autoPushScheduler = new AutoPushScheduler();

async function main() {
  logger.info('═'.repeat(60));
  logger.info('RAJA BOT 4.0 — IRONCLAW EDITION');
  logger.info('Lysander Phoebe Keset Sejuta Umat');
  logger.info('═'.repeat(60));

  // 1. Validate config
  const cfgCheck = validateConfig();
  if (!cfgCheck.valid) {
    logger.error(`Config invalid: ${cfgCheck.missing.join(', ')}`);
    process.exit(1);
  }

  // 2. Initialize memory
  await initMemory();
  logger.info('✓ Memory initialized');

  // 2a. DB integrity check — restore from backup if corrupted (Req 7.3)
  try {
    const dbPath = (config.raja?.dataDir || 'data') + '/memory.db';
    const isOk = checkIntegrity(dbPath);
    if (!isOk) {
      logger.warn('⚠️  DB integrity check failed — attempting restore from backup');
      const restore = restoreFromBackup();
      if (restore.success) {
        logger.info(`✓ DB restored from backup: ${restore.backupUsed}`);
      } else {
        logger.warn('⚠️  DB restore failed — starting with empty database');
      }
    } else {
      logger.info('✓ DB integrity verified');
    }
  } catch (err) {
    logger.warn(`⚠️  DB integrity check skipped (non-critical): ${err.message}`);
  }

  // 2b. Initialize governor
  initGovernor();
  logger.info('✓ Governor initialized');

  // 3. Skill integrity check (CRITICAL)
  const integrity = await verifyIntegrity();
  if (integrity.tampered) {
    logger.warn(`⚠️  Skill integrity: ${integrity.modified.length} modified, ${integrity.missing.length} missing, ${integrity.added.length} added`);
    logger.warn('   Halaman on-chain ops akan ditahan sampai di-audit');
  } else {
    logger.info('✓ Skill integrity verified');
  }

  // 4. Initialize skill registry
  await initSkillRegistry();
  logger.info(`✓ Skill registry loaded`);

  // 4a. Initialize ContextWindow — export for use by brain.js (Req 4.1)
  try {
    // Import memory module functions to pass as interface to ContextWindow
    const memoryModule = await import('./core/memory.js');
    contextWindow = new ContextWindow(memoryModule);
    logger.info('✓ ContextWindow initialized');
  } catch (err) {
    logger.warn(`⚠️  ContextWindow init failed (non-critical): ${err.message}`);
  }

  // 5. Watchdog heartbeat init (non-critical)
  try {
    initWatchdogHeartbeat();
    logger.info('✓ Watchdog heartbeat initialized');
  } catch (err) {
    logger.warn(`⚠️  Watchdog heartbeat init failed (non-critical): ${err.message}`);
  }

  // 6. Start watchdog interval
  startWatchdog();
  logger.info('✓ Watchdog active');

  // 7. Start Telegram bot (CRITICAL)
  await startBot();
  logger.info('✓ Telegram bot online');

  // 8. Start AutoPushScheduler (Req 6.1)
  try {
    autoPushScheduler.start();
    logger.info('✓ AutoPushScheduler started');
  } catch (err) {
    logger.warn(`⚠️  AutoPushScheduler start failed (non-critical): ${err.message}`);
  }

  // 10. Register cron jobs (non-critical)
  registerCronJobs();

  // 11. Graceful shutdown
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  
  logger.info('═'.repeat(60));
  logger.info('RAJA ready. All operational automation active.');
  logger.info('Cron: reflection@3AM, briefing@6AM');
  logger.info('═'.repeat(60));
}

/**
 * Register all cron jobs for operational automation.
 * Non-critical — logs warning and continues on failure.
 */
function registerCronJobs() {
  try {
    cron.schedule('0 3 * * *', runDailyReflection, { timezone: 'Asia/Jakarta' });
    cron.schedule('0 6 * * *', runDailyBriefing, { timezone: 'Asia/Jakarta' });
    // Weekly learning review: every Sunday at 4AM WIB
    cron.schedule('0 4 * * 0', weeklyLearningReview, { timezone: 'Asia/Jakarta' });
    // Daily preference decay: 2AM WIB (Req 5.6)
    cron.schedule('0 2 * * *', () => {
      try {
        const result = runPreferenceDecay();
        logger.info(`[cron] runPreferenceDecay: decayed=${result.decayed}, deleted=${result.deleted}`);
      } catch (err) {
        logger.warn(`[cron] runPreferenceDecay failed (non-critical): ${err.message}`);
      }
    }, { timezone: 'Asia/Jakarta' });
    logger.info('✓ Cron jobs registered (reflection@3AM, briefing@6AM, learning@Sun4AM, preferenceDecay@2AM WIB)');
  } catch (err) {
    logger.warn(`⚠️  Cron registration failed (non-critical): ${err.message}`);
  }
}

async function shutdown() {
  logger.info('Shutdown signal received...');
  // Stop AutoPushScheduler gracefully (Req 6.1)
  try {
    autoPushScheduler.stop();
  } catch (err) {
    logger.warn(`⚠️  AutoPushScheduler stop failed: ${err.message}`);
  }
  // Cleanup, close DBs, etc.
  process.exit(0);
}

main().catch((err) => {
  logger.error(`FATAL: ${err.message}`);
  logger.error(err.stack);
  process.exit(1);
});