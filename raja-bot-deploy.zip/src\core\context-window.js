// src/core/context-window.js — Context Window Builder for LLM prompt injection
import { logger } from '../utils/logger.js';

/**
 * @typedef {Object} ContextPayload
 * @property {string} recentHistory - 10 pesan terakhir sesi aktif (formatted)
 * @property {string} longTermMemories - Max 5 memori relevan (formatted)
 * @property {string} userPreferences - Ringkasan preferensi (max 500 token)
 * @property {number} totalTokens - Total estimasi token
 */

export class ContextWindow {
  /**
   * @param {Object} memory - Memory module instance
   * @param {Object} [options]
   * @param {number} [options.maxLongTermTokens=2000] - Max token dari long-term memories
   * @param {number} [options.maxPreferenceTokens=500] - Max token untuk preferensi
   * @param {number} [options.maxMemories=5] - Max jumlah memori yang diambil
   * @param {number} [options.minRelevanceScore=0.1] - Skor minimum untuk memori relevan
   * @param {number} [options.sessionTimeoutMs=1800000] - Session timeout (30 menit default)
   */
  constructor(memory, options = {}) {
    this.memory = memory;
    this.maxLongTermTokens = options.maxLongTermTokens || 2000;
    this.maxPreferenceTokens = options.maxPreferenceTokens || 500;
    this.maxMemories = options.maxMemories || 5;
    this.minRelevanceScore = options.minRelevanceScore || 0.1;
    this.sessionTimeoutMs = options.sessionTimeoutMs || 30 * 60 * 1000;
  }

  /**
   * Estimasi jumlah token dari string (word-split approximation).
   * Menggunakan split whitespace — memberikan estimasi ~1.3x token aktual.
   * 
   * @param {string} text
   * @returns {number}
   */
  estimateTokens(text) {
    if (!text || typeof text !== 'string') return 0;
    return text.split(/\s+/).filter(w => w.length > 0).length;
  }

  /**
   * Memilih memori yang fit dalam budget token.
   * Prioritas: score tertinggi (asumsi array sudah sorted by relevance desc).
   * Potong memori dengan skor terendah (stop menambah saat budget terlampaui).
   * 
   * Requirements: 4.3, 4.4
   * - Total long-term memories tidak melebihi budgetTokens
   * - Memori dengan Relevance_Score tertinggi diprioritaskan
   * - Memori dengan skor terendah dipotong terlebih dahulu
   * 
   * @param {Object[]} memories - Sorted by relevance desc (must have .content and .score)
   * @param {number} budgetTokens
   * @returns {Object[]}
   */
  fitToBudget(memories, budgetTokens) {
    if (!memories || memories.length === 0) return [];
    if (budgetTokens <= 0) return [];

    const selected = [];
    let tokensUsed = 0;

    for (const memory of memories) {
      const memTokens = this.estimateTokens(memory.content);
      if (tokensUsed + memTokens <= budgetTokens) {
        selected.push(memory);
        tokensUsed += memTokens;
      } else {
        break; // Budget exceeded — stop adding more (lower-scored memories are cut)
      }
    }

    return selected;
  }

  /**
   * Menghitung relevance score untuk satu memori.
   * Formula: (token_overlap * 0.6) + (recency_factor * 0.3) + (interaction_frequency * 0.1)
   * recency_factor = 0.5 ^ (age_days / 30)
   * 
   * Requirements: 4.2
   * 
   * @param {string} query - Current message
   * @param {Object} memory - Memory record (must have .content, .ts or .timestamp)
   * @param {Object} userStats - User interaction stats (must have .interactionFrequency)
   * @returns {number} Score 0.0 - 1.0
   */
  calculateRelevanceScore(query, memory, userStats) {
    // Edge case: empty or invalid query
    if (!query || typeof query !== 'string') return 0;

    // 1. Token overlap: fraction of query tokens that appear in memory content
    const queryTokens = query.toLowerCase().split(/\s+/).filter(w => w.length > 0);
    if (queryTokens.length === 0) return 0;

    const memoryContent = (memory && memory.content) || '';
    const memoryTokens = new Set(memoryContent.toLowerCase().split(/\s+/).filter(w => w.length > 0));

    const matchingTokens = queryTokens.filter(qt => memoryTokens.has(qt));
    const tokenOverlap = matchingTokens.length / queryTokens.length; // 0.0 to 1.0

    // 2. Recency factor: 0.5 ^ (age_days / 30)
    const memoryTimestamp = memory?.ts || memory?.timestamp;
    let recencyFactor = 0;
    if (memoryTimestamp != null) {
      const tsMs = typeof memoryTimestamp === 'number'
        ? memoryTimestamp
        : new Date(memoryTimestamp).getTime();
      if (!isNaN(tsMs)) {
        const ageMs = Date.now() - tsMs;
        const ageDays = Math.max(0, ageMs / (24 * 60 * 60 * 1000));
        recencyFactor = Math.pow(0.5, ageDays / 30);
      }
    }

    // 3. Interaction frequency: from userStats (normalized 0.0 to 1.0)
    const interactionFrequency = Math.min(1, Math.max(0, userStats?.interactionFrequency || 0));

    // Formula: (token_overlap * 0.6) + (recency_factor * 0.3) + (interaction_frequency * 0.1)
    const score = (tokenOverlap * 0.6) + (recencyFactor * 0.3) + (interactionFrequency * 0.1);

    return Math.max(0, Math.min(1, score)); // Clamp to [0, 1]
  }

  /**
   * Membangun context payload untuk LLM prompt.
   * 
   * Logic:
   * 1. Ambil 10 pesan terakhir sesi aktif (jika ada pesan dalam 30 menit terakhir)
   * 2. Ambil max 5 memori dari long-term memory dengan score > 0.1
   * 3. Injeksi preferensi user (max 500 token)
   * 4. Total long-term context max 2000 token
   * 5. Graceful degradation: jika DB tidak accessible, gunakan session-only context
   * 
   * Requirements: 4.1, 4.5, 4.6, 4.7, 4.8
   * 
   * @param {string} userId
   * @param {string} currentMessage
   * @param {string} sessionId
   * @returns {Promise<ContextPayload>}
   */
  async buildContext(userId, currentMessage, sessionId) {
    let recentHistory = '';
    let longTermMemories = '';
    let userPreferences = '';
    let totalTokens = 0;

    try {
      // 1. Get 10 most recent messages from active session (within sessionTimeoutMs)
      const recentMessages = this.memory.getRecentHistory(userId, 10);
      if (recentMessages.length > 0) {
        const lastMsg = recentMessages[recentMessages.length - 1];
        const lastMsgTime = new Date(lastMsg.timestamp).getTime();
        if (Date.now() - lastMsgTime <= this.sessionTimeoutMs) {
          recentHistory = recentMessages
            .map(m => `${m.role}: ${m.content}`)
            .join('\n');
        }
      }

      // 2. Get long-term memories with relevance scoring
      const allMemories = await this.memory.recallMemory(currentMessage, this.maxMemories * 2);
      const userStats = { interactionFrequency: 0 };

      const scoredMemories = allMemories
        .map(mem => ({
          ...mem,
          score: this.calculateRelevanceScore(currentMessage, mem, userStats)
        }))
        .filter(mem => mem.score > this.minRelevanceScore)
        .sort((a, b) => b.score - a.score)
        .slice(0, this.maxMemories);

      const selectedMemories = this.fitToBudget(scoredMemories, this.maxLongTermTokens);
      if (selectedMemories.length > 0) {
        longTermMemories = selectedMemories.map(m => m.content).join('\n');
      }

      // 3. Get user preferences (max 500 tokens)
      const prefs = this.memory.getPreferences(userId);
      if (prefs && prefs.length > 0) {
        const prefText = prefs
          .map(p => `${p.key || p.preference_key}: ${p.value || p.preference_value}`)
          .join('; ');
        const prefTokens = this.estimateTokens(prefText);
        if (prefTokens <= this.maxPreferenceTokens) {
          userPreferences = prefText;
        } else {
          // Truncate to fit budget by taking words up to limit
          const words = prefText.split(/\s+/);
          let truncated = [];
          let count = 0;
          for (const word of words) {
            if (count >= this.maxPreferenceTokens) break;
            truncated.push(word);
            count++;
          }
          userPreferences = truncated.join(' ');
        }
      }

      totalTokens = this.estimateTokens(recentHistory) +
                    this.estimateTokens(longTermMemories) +
                    this.estimateTokens(userPreferences);

    } catch (err) {
      // Graceful degradation: session-only context if DB fails
      // recentHistory might already be set from before the error
      // longTermMemories and userPreferences will remain empty strings
      logger.error(`[CONTEXT] buildContext failed: ${err.message}`);
      totalTokens = this.estimateTokens(recentHistory);
    }

    return { recentHistory, longTermMemories, userPreferences, totalTokens };
  }
}
