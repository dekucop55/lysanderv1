// src/skills/H5.js — Hermes: Monitoring (whale tracker, smart money, mempool) with intent detection
import { trackWallet, getWhaleMovements, getSmartMoneyActivity, getTokenPrice } from '../hermes/monitoring.js';
import { logger } from '../utils/logger.js';

// ─── Chain aliases ───────────────────────────────────────────────────────────
const CHAIN_ALIASES = {
  eth: 'ethereum', ethereum: 'ethereum', base: 'base',
  arb: 'arbitrum', arbitrum: 'arbitrum', op: 'optimism', optimism: 'optimism',
  poly: 'polygon', polygon: 'polygon', bsc: 'bsc', avax: 'avalanche',
};

/**
 * Detect actionable monitoring intent from natural language query.
 * Returns { intent, params } or null for general questions.
 */
function detectMonitorIntent(query) {
  const q = query.trim();

  // Pattern: "track <address> [on <chain>]" / "pantau wallet <address>" / "monitor <address>"
  const trackMatch = q.match(
    /(?:track|monitor|pantau|watch|follow)\s+(?:wallet\s+)?(0x[a-fA-F0-9]{40})(?:\s+(?:on|di|chain)\s+(\S+))?/i
  );
  if (trackMatch) {
    const address = trackMatch[1];
    const chain = resolveChain(trackMatch[2]) || 'ethereum';
    return { intent: 'TRACK_WALLET', params: { address, chain } };
  }

  // Pattern: "whale movements" / "monitor whale" / "whale alert" / "whale [on chain]"
  const whaleMatch = q.match(
    /(?:whale\s+(?:movements?|alerts?|tracker|activity)|monitor\s+whale|cek\s+whale|lihat\s+whale)(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:min)\s+([\d.]+))?/i
  );
  if (whaleMatch) {
    const chain = resolveChain(whaleMatch[1]) || 'ethereum';
    const minValueEth = whaleMatch[2] ? parseFloat(whaleMatch[2]) : 100;
    return { intent: 'WHALE_MOVEMENTS', params: { chain, minValueEth } };
  }

  // Pattern: "smart money <address>" / "cek smart money"
  const smartMoneyMatch = q.match(
    /(?:smart\s+money|nansen|arkham)\s+(?:activity\s+)?(0x[a-fA-F0-9]{40})?(?:\s+(?:source|via)\s+(\S+))?/i
  );
  if (smartMoneyMatch) {
    const address = smartMoneyMatch[1] || null;
    const source = smartMoneyMatch[2] || 'nansen';
    if (address) {
      return { intent: 'SMART_MONEY', params: { address, source } };
    }
  }

  // Pattern: "price <token_address> [on chain]" / "harga token <address>"
  const priceMatch = q.match(
    /(?:price|harga|cek\s+harga)\s+(?:token\s+)?(0x[a-fA-F0-9]{40})(?:\s+(?:on|di)\s+(\S+))?/i
  );
  if (priceMatch) {
    const tokenAddress = priceMatch[1];
    const chain = resolveChain(priceMatch[2]) || 'ethereum';
    return { intent: 'TOKEN_PRICE', params: { tokenAddress, chain } };
  }

  return null;
}

function resolveChain(raw) {
  if (!raw) return null;
  return CHAIN_ALIASES[raw.toLowerCase()] || null;
}

export default {
  id: 'H5',
  name: 'monitoring',
  description: 'On-chain monitoring: whale movements, smart money tracking, mempool sniffing, price alerts',

  async execute(query, context) {
    // 1. Detect actionable monitoring command
    const intent = detectMonitorIntent(query);

    if (intent) {
      logger.info(`[H5] Monitor intent detected: ${intent.intent}`, intent.params);

      try {
        switch (intent.intent) {
          case 'TRACK_WALLET': {
            const { address, chain } = intent.params;

            // Start tracking — provide status update
            // Note: trackWallet is a live subscription (returns unsubscribe fn)
            // In a bot context, we register the tracker and confirm
            const unsub = trackWallet({
              address,
              chain,
              onTx: (txInfo) => {
                logger.info(`[H5] Tracked wallet tx: ${txInfo.tx.hash} (${txInfo.direction} ${txInfo.valueEth} ETH)`);
              },
            });

            // Store unsubscribe reference in context if available
            if (context?.trackingRegistry) {
              context.trackingRegistry.set(address, unsub);
            }

            return [
              `👁️ **Wallet Tracking Active**`,
              ``,
              `Address: \`${address}\``,
              `Chain: ${chain}`,
              `Status: ✅ Monitoring started`,
              ``,
              `Kamu akan mendapat alert setiap kali wallet ini:`,
              `• Mengirim transaksi (outbound)`,
              `• Menerima transfer (inbound)`,
              ``,
              `Untuk stop: \`stop tracking ${address}\``,
            ].join('\n');
          }

          case 'WHALE_MOVEMENTS': {
            const { chain, minValueEth } = intent.params;

            const result = await getWhaleMovements({ chain, minValueEth, limit: 10 });

            if (result?.data && Array.isArray(result.data) && result.data.length > 0) {
              const lines = result.data.map((tx, i) => {
                const from = `${tx.from?.slice(0, 6)}...${tx.from?.slice(-4)}`;
                const to = `${tx.to?.slice(0, 6)}...${tx.to?.slice(-4)}`;
                return `${i + 1}. **${tx.valueEth} ETH** — ${from} → ${to} (block ${tx.block})`;
              });

              return [
                `🐋 **Whale Movements (${chain})**`,
                `Min: ${minValueEth} ETH | Source: ${result.source || 'on-chain scan'}`,
                ``,
                ...lines,
              ].join('\n');
            }

            return [
              `🐋 **Whale Movements (${chain})**`,
              ``,
              `Tidak ada transaksi whale > ${minValueEth} ETH dalam 10 block terakhir.`,
              `Source: ${result?.source || 'on-chain scan'}`,
              ``,
              `Tip: Turunkan threshold dengan \`whale movements min 50\``,
            ].join('\n');
          }

          case 'SMART_MONEY': {
            const { address, source } = intent.params;

            const result = await getSmartMoneyActivity({ address, source });

            if (result?.data) {
              return [
                `🧠 **Smart Money Activity**`,
                ``,
                `Address: \`${address}\``,
                `Source: ${source}`,
                ``,
                typeof result.data === 'string' ? result.data : JSON.stringify(result.data, null, 2),
              ].join('\n');
            }

            return [
              `🧠 **Smart Money Activity**`,
              ``,
              `Address: \`${address}\``,
              `Source: ${source}`,
              ``,
              `⚠️ Tidak ada data tersedia. Pastikan API key ${source} sudah dikonfigurasi.`,
            ].join('\n');
          }

          case 'TOKEN_PRICE': {
            const { tokenAddress, chain } = intent.params;

            const price = await getTokenPrice(tokenAddress, chain);

            if (price) {
              return [
                `💲 **Token Price**`,
                ``,
                `Address: \`${tokenAddress}\``,
                `Chain: ${chain}`,
                `Price: $${price.priceUsd || price}`,
                price.priceChange24h ? `24h change: ${price.priceChange24h > 0 ? '+' : ''}${price.priceChange24h}%` : '',
                price.liquidity ? `Liquidity: $${price.liquidity}` : '',
                price.volume24h ? `Volume 24h: $${price.volume24h}` : '',
                ``,
                `Source: DexScreener`,
              ].filter(Boolean).join('\n');
            }

            return `⚠️ Tidak bisa mendapatkan harga untuk token \`${tokenAddress}\` di ${chain}. Token mungkin belum listed di DEX.`;
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[H5] Monitoring operation failed: ${err.message}`);
        return `❌ Monitoring gagal: ${err.message}`;
      }
    }

    // 2. Fallback: general monitoring question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H5 (Monitoring).
Mode: analytical, real-time.

Kamu menjawab pertanyaan tentang on-chain monitoring:
- Whale tracking strategies dan tools
- Smart money analysis (Nansen labels, Arkham entities)
- Mempool monitoring (pending tx, front-run detection)
- Price alerts setup (DexScreener, custom oracles)
- Portfolio tracking multi-chain
- Copy trading strategies dan risk
- On-chain analytics (Dune, Flipside, DefiLlama)

Untuk EXECUTE monitoring commands:
  track <0x...address> on <chain>
  whale movements [on <chain>] [min <ethAmount>]
  smart money <0x...address> [source nansen/arkham]
  price <0x...tokenAddress> on <chain>

Data sources:
- Keyless: Etherscan, DexScreener, DefiLlama, on-chain RPC
- Keyed: Nansen, Arkham, Dune Analytics, Birdeye

Alert delivery: via bot message push.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1200, temperature: 0.4 });
      return result.text;
    } catch (err) {
      logger.error(`[H5] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan monitoring: ${err.message}`;
    }
  },
};
