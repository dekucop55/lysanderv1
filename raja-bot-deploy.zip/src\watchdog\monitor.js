// src/watchdog/monitor.js — Process watchdog
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import { getBot } from '../telegram/bot.js';

const execAsync = promisify(exec);

let restartCount = 0;
let lastHourReset = Date.now();

/**
 * Initialize the watchdog heartbeat at boot.
 * Writes an initial heartbeat timestamp synchronously so the heartbeat
 * file exists before the interval timer starts.
 * Called from main() after skill registry init, before startWatchdog().
 */
export function initWatchdogHeartbeat() {
  try {
    const heartbeatDir = path.dirname(config.watchdog.heartbeatPath);
    fs.mkdirSync(heartbeatDir, { recursive: true });
    fs.writeFileSync(config.watchdog.heartbeatPath, Date.now().toString());
    logger.info('Watchdog heartbeat initialized');
  } catch (e) {
    logger.warn(`Watchdog heartbeat init failed: ${e.message}`);
  }
}

/**
 * Pure function: check if a heartbeat timestamp is stale.
 * @param {number} heartbeatTs - The heartbeat timestamp in milliseconds
 * @param {number} now - The current time in milliseconds
 * @returns {boolean} true if now - heartbeatTs > 90 seconds
 */
export function checkStaleness(heartbeatTs, now) {
  return (now - heartbeatTs) > 90_000;
}

export function startWatchdog() {
  // Touch heartbeat every 30s
  setInterval(touchHeartbeat, 30000);
  touchHeartbeat();
  
  // Monitor process
  setInterval(checkProcess, 60000);
  
  logger.info('Watchdog started');
}

function touchHeartbeat() {
  try {
    fs.writeFileSync(config.watchdog.heartbeatPath, Date.now().toString());
  } catch (e) {
    logger.warn(`Heartbeat write failed: ${e.message}`);
  }
}

async function checkProcess() {
  try {
    // Check if main bot process is running
    const { stdout } = await execAsync('pgrep -f "node src/index.js" || echo "0"');
    const pid = stdout.trim();
    
    if (pid === '0' || !pid) {
      logger.warn('Bot process not detected. Restarting...');
      await restartBot();
      await notifyIfExcessive('Bot process mati dan di-restart');
    }
  } catch (err) {
    logger.error(`Watchdog check error: ${err.message}`);
  }
}

async function restartBot() {
  // Reset counter every hour
  const now = Date.now();
  if (now - lastHourReset > 3600000) {
    restartCount = 0;
    lastHourReset = now;
  }
  
  restartCount++;
  
  if (restartCount > config.watchdog.maxRestartPerHour) {
    logger.error(`Too many restarts (${restartCount}). Giving up.`);
    await notifyIfExcessive(`Bot restart ${restartCount}x dalam 1 jam. Cek log!`);
    return;
  }
  
  try {
    await execAsync('systemctl restart raja-bot.service');
    logger.info(`Bot restarted (count: ${restartCount})`);
  } catch (e) {
    try {
      await execAsync('pm2 restart raja-bot');
    } catch (e2) {
      await execAsync('pkill -f "node src/index.js" || true');
    }
  }
}

async function notifyIfExcessive(message) {
  try {
    const bot = getBot();
    if (bot) {
      await bot.sendMessage(config.telegram.allowedUserId, 
        `🚨 *Watchdog Alert*\n\n${message}\n\nCek VPS sekarang.`,
        { parse_mode: 'Markdown' }
      );
    }
  } catch (e) {}
}