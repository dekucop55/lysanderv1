// src/skills/m5.js — Data handling, spreadsheets, analytics, snapshots
export default {
  id: 'm5',
  name: 'data',
  description: 'Data processing, spreadsheets, CSV/Excel, analytics, SQLite, snapshots, reporting',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m5 (Data).
Expert dalam:
- CSV/Excel processing (papaparse, exceljs, xlsx)
- SQLite operations (better-sqlite3)
- Data transformation, cleaning, normalization
- Snapshot dan versioning data
- Analytics queries dan aggregations
- Chart data preparation (Chart.js, Recharts)
- Large file processing (streaming)
- Data export: PDF, XLSX, CSV
- Pandas-style operations in JavaScript
- Time-series data patterns

Output: code + sample output kalau memungkinkan.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
    return result.text;
  },
};
