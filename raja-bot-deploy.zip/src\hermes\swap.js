// src/hermes/swap.js — Token swap via 1inch v6 + 0x fallback, governor-gated
import { ethers } from 'ethers';
import axios from 'axios';
import { config } from '../config.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { getPrivateKey, getWalletInfo } from './wallets.js';
import { logger } from '../utils/logger.js';

// ─── Constants ───────────────────────────────────────────────────────────────

const NATIVE = '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE';

const CHAIN_IDS = {
  ethereum: 1,
  base: 8453,
  arbitrum: 42161,
  optimism: 10,
  polygon: 137,
  bsc: 56,
  avalanche: 43114,
};

const EXPLORERS = {
  ethereum: 'https://etherscan.io/tx/',
  base: 'https://basescan.org/tx/',
  arbitrum: 'https://arbiscan.io/tx/',
  optimism: 'https://optimistic.etherscan.io/tx/',
  polygon: 'https://polygonscan.com/tx/',
  bsc: 'https://bscscan.com/tx/',
  avalanche: 'https://snowtrace.io/tx/',
};

// Well-known token decimals to avoid extra RPC calls
const KNOWN_DECIMALS = {
  // USDC
  '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48': 6,  // ETH
  '0xb97ef9ef8734c71904d8002f8b6bc66dd9c48a6e': 6,  // AVAX
  '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359': 6,  // Polygon
  '0xaf88d065e77c8cc2239327c5edb3a432268e5831': 6,  // Arbitrum
  // USDT
  '0xdac17f958d2ee523a2206206994597c13d831ec7': 6,  // ETH
  '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7': 6,  // AVAX
  // DAI
  '0x6b175474e89094c44da98b954eedeac495271d0f': 18, // ETH
  // WBTC
  '0x2260fac5e5542a773aa44fbcfedf7c193bc2c599': 8,  // ETH
};

const ERC20_DECIMALS_ABI = ['function decimals() view returns (uint8)'];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function getChainId(chain) {
  const id = CHAIN_IDS[chain];
  if (!id) throw new Error(`Unsupported chain: ${chain}. Supported: ${Object.keys(CHAIN_IDS).join(', ')}`);
  return id;
}

function getExplorer(chain, hash) {
  return (EXPLORERS[chain] || EXPLORERS.ethereum) + hash;
}

function resolveTokenAddress(symbol, chain) {
  if (symbol === 'ETH' || symbol === 'BNB' || symbol === 'AVAX' || symbol === 'MATIC') {
    return NATIVE;
  }
  // If it looks like an address already, return as-is
  if (symbol.startsWith('0x') && symbol.length === 42) return symbol;
  throw new Error(`Unknown token symbol "${symbol}". Pass the contract address instead.`);
}

async function getTokenDecimals(tokenAddress, provider) {
  if (tokenAddress === NATIVE) return 18;
  const lower = tokenAddress.toLowerCase();
  if (KNOWN_DECIMALS[lower] !== undefined) return KNOWN_DECIMALS[lower];
  try {
    const contract = new ethers.Contract(tokenAddress, ERC20_DECIMALS_ABI, provider);
    return await contract.decimals();
  } catch {
    logger.warn(`[swap] Could not fetch decimals for ${tokenAddress}, assuming 18`);
    return 18;
  }
}

/**
 * Fetch token USD price via DexScreener (keyless fallback)
 * Returns null if price unavailable — governor still works, just skips USD cap
 */
async function fetchTokenUsdPrice(tokenAddress, chain) {
  if (tokenAddress === NATIVE) {
    // Native token — fetch from CoinGecko (keyless)
    const coinMap = { ethereum: 'ethereum', base: 'ethereum', arbitrum: 'ethereum', optimism: 'ethereum', polygon: 'matic-network', bsc: 'binancecoin', avalanche: 'avalanche-2' };
    const coinId = coinMap[chain] || 'ethereum';
    try {
      const res = await axios.get(
        `https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd`,
        { timeout: 8000 }
      );
      return res.data?.[coinId]?.usd || null;
    } catch {
      return null;
    }
  }

  // ERC-20 — DexScreener
  try {
    const res = await axios.get(
      `https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`,
      { timeout: 8000 }
    );
    const pairs = res.data?.pairs;
    if (!pairs?.length) return null;
    const top = pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];
    return parseFloat(top.priceUsd) || null;
  } catch {
    return null;
  }
}

// ─── Quote ───────────────────────────────────────────────────────────────────

/**
 * Get swap quote from 1inch v6
 * @returns {{ toAmount: string, toAmountMin: string, estimatedGas: number, protocols: any[] }}
 */
export async function getSwapQuote({ chain, tokenIn, tokenOut, amount, slippage = 1.0 }) {
  const oneInchKey = config.cryptoApis.oneinch;
  if (!oneInchKey) throw new Error('ONEINCH_API_KEY not configured');

  const chainId = getChainId(chain);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);

  const srcAddress = resolveTokenAddress(tokenIn, chain);
  const dstAddress = resolveTokenAddress(tokenOut, chain);
  const decimals = await getTokenDecimals(srcAddress, provider);
  const amountWei = ethers.parseUnits(String(amount), decimals).toString();

  const res = await axios.get(
    `https://api.1inch.dev/swap/v6.0/${chainId}/quote`,
    {
      params: {
        src: srcAddress,
        dst: dstAddress,
        amount: amountWei,
      },
      headers: { Authorization: `Bearer ${oneInchKey}` },
      timeout: 20000,
    }
  );

  const dstDecimals = await getTokenDecimals(dstAddress, provider);
  const toAmount = ethers.formatUnits(res.data.dstAmount, dstDecimals);

  // Apply slippage to get minimum out
  const slippageFactor = 1 - slippage / 100;
  const toAmountMin = (parseFloat(toAmount) * slippageFactor).toFixed(dstDecimals);

  return {
    toAmount,
    toAmountMin,
    estimatedGas: res.data.estimatedGas,
    protocols: res.data.protocols,
    srcDecimals: decimals,
    dstDecimals,
    amountWei,
  };
}

// ─── Execute Swap ─────────────────────────────────────────────────────────────

/**
 * Execute a token swap via 1inch v6 with governor gate
 *
 * @param {Object} opts
 * @param {string} opts.walletLabel   - wallet label in vault
 * @param {string} opts.chain         - ethereum | base | arbitrum | optimism | polygon | bsc | avalanche
 * @param {string} opts.tokenIn       - symbol ('ETH') or contract address
 * @param {string} opts.tokenOut      - symbol or contract address
 * @param {number} opts.amount        - human-readable amount of tokenIn
 * @param {number} [opts.slippage]    - slippage % (default 1.0, max = governor cap)
 * @param {boolean} [opts.dryRun]     - if true, return quote only, no broadcast
 */
export async function swapToken({ walletLabel, chain, tokenIn, tokenOut, amount, slippage = 1.0, dryRun = false }) {
  if (!config.rpc.evm[chain]) {
    return { success: false, reason: `RPC not configured for chain: ${chain}` };
  }

  const oneInchKey = config.cryptoApis.oneinch;
  if (!oneInchKey) return { success: false, reason: 'ONEINCH_API_KEY not configured' };

  const chainId = getChainId(chain);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);

  // ── 1. Resolve addresses + decimals ──────────────────────────────────────
  let srcAddress, dstAddress, srcDecimals, dstDecimals;
  try {
    srcAddress = resolveTokenAddress(tokenIn, chain);
    dstAddress = resolveTokenAddress(tokenOut, chain);
    srcDecimals = await getTokenDecimals(srcAddress, provider);
    dstDecimals = await getTokenDecimals(dstAddress, provider);
  } catch (err) {
    return { success: false, reason: err.message };
  }

  const amountWei = ethers.parseUnits(String(amount), srcDecimals).toString();

  // ── 2. USD estimation for governor ───────────────────────────────────────
  let usdValue = null;
  try {
    const price = await fetchTokenUsdPrice(srcAddress, chain);
    if (price) usdValue = parseFloat(amount) * price;
  } catch { /* non-fatal */ }

  // ── 3. Governor gate ─────────────────────────────────────────────────────
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId,
    action: `swap:${tokenIn}->${tokenOut}`,
    usdValue,
    slippage,
    simulated: true,
  });

  if (!decision.allowed) {
    return { success: false, reason: `Governor blocked: ${decision.reason}`, verdict: decision.verdict };
  }

  // ── 4. Get wallet ─────────────────────────────────────────────────────────
  const info = getWalletInfo(walletLabel);
  if (!info) return { success: false, reason: `Wallet "${walletLabel}" not found` };

  // ── 5. Build swap tx via 1inch ────────────────────────────────────────────
  let txData;
  try {
    const swapRes = await axios.get(
      `https://api.1inch.dev/swap/v6.0/${chainId}/swap`,
      {
        params: {
          src: srcAddress,
          dst: dstAddress,
          amount: amountWei,
          from: info.address,
          slippage,
          disableEstimate: false,
          allowPartialFill: false,
        },
        headers: { Authorization: `Bearer ${oneInchKey}` },
        timeout: 30000,
      }
    );
    txData = swapRes.data.tx;
  } catch (err) {
    const status = err.response?.status;
    const msg = err.response?.data?.description || err.message;
    logger.warn(`[swap] 1inch failed (${status}): ${msg}. Trying 0x fallback...`);

    // ── 0x fallback ────────────────────────────────────────────────────────
    try {
      txData = await get0xSwapTx({ chainId, srcAddress, dstAddress, amountWei, fromAddress: info.address, slippage });
    } catch (fallbackErr) {
      return { success: false, reason: `Both 1inch and 0x failed. 1inch: ${msg} | 0x: ${fallbackErr.message}` };
    }
  }

  // ── 6. Dry run — return quote without broadcasting ────────────────────────
  if (dryRun) {
    const toAmount = ethers.formatUnits(txData.toAmount || '0', dstDecimals);
    return {
      success: true,
      dryRun: true,
      tokenIn,
      tokenOut,
      amount,
      toAmount,
      estimatedGas: txData.gas,
      usdValue,
      chain,
    };
  }

  // ── 7. Sign and broadcast ─────────────────────────────────────────────────
  const pk = await getPrivateKey(walletLabel);
  const signer = new ethers.Wallet(pk, provider);

  // Build transaction — prefer EIP-1559 if available
  const txRequest = {
    to: txData.to,
    data: txData.data,
    value: BigInt(txData.value || '0'),
  };

  // Gas limit — use 1inch estimate + 20% buffer
  const gasEstimate = txData.gas ? BigInt(txData.gas) : null;
  txRequest.gasLimit = gasEstimate ? (gasEstimate * 120n) / 100n : 350000n;

  // EIP-1559 vs legacy gas
  if (txData.maxFeePerGas && txData.maxPriorityFeePerGas) {
    txRequest.maxFeePerGas = BigInt(txData.maxFeePerGas);
    txRequest.maxPriorityFeePerGas = BigInt(txData.maxPriorityFeePerGas);
  } else if (txData.gasPrice) {
    // Legacy chains (BSC, etc.)
    const gp = BigInt(txData.gasPrice);
    const gpCap = config.governor.maxGasMultiple
      ? gp * BigInt(Math.ceil(config.governor.maxGasMultiple))
      : gp * 4n;
    txRequest.gasPrice = gp < gpCap ? gp : gpCap;
  }

  let tx, receipt;
  try {
    tx = await signer.sendTransaction(txRequest);
    logger.info(`[swap] Tx broadcast: ${tx.hash}`);
    receipt = await tx.wait(1); // wait for 1 confirmation
  } catch (err) {
    return { success: false, reason: `Tx failed: ${err.message}`, txHash: tx?.hash };
  }

  // ── 8. Record in governor ─────────────────────────────────────────────────
  try {
    governorRecord({
      wallet: walletLabel,
      chainId,
      action: `swap:${tokenIn}->${tokenOut}`,
      usdValue,
      txHash: tx.hash,
    });
  } catch (e) {
    logger.warn(`[swap] Governor record failed: ${e.message}`);
  }

  logger.info(`[swap] ✓ ${amount} ${tokenIn}→${tokenOut} on ${chain} | tx: ${tx.hash} | gas: ${receipt?.gasUsed}`);

  return {
    success: true,
    txHash: tx.hash,
    explorer: getExplorer(chain, tx.hash),
    gasUsed: receipt?.gasUsed?.toString(),
    status: receipt?.status === 1 ? 'confirmed' : 'reverted',
    chain,
    tokenIn,
    tokenOut,
    amount,
    usdValue,
  };
}

// ─── 0x Fallback ─────────────────────────────────────────────────────────────

async function get0xSwapTx({ chainId, srcAddress, dstAddress, amountWei, fromAddress, slippage }) {
  // 0x API is keyless for small volumes
  const baseUrls = {
    1: 'https://api.0x.org',
    8453: 'https://base.api.0x.org',
    42161: 'https://arbitrum.api.0x.org',
    10: 'https://optimism.api.0x.org',
    137: 'https://polygon.api.0x.org',
    56: 'https://bsc.api.0x.org',
  };

  const baseUrl = baseUrls[chainId];
  if (!baseUrl) throw new Error(`0x not supported on chainId ${chainId}`);

  const slippageDecimal = slippage / 100;

  const res = await axios.get(`${baseUrl}/swap/v1/quote`, {
    params: {
      sellToken: srcAddress,
      buyToken: dstAddress,
      sellAmount: amountWei,
      takerAddress: fromAddress,
      slippagePercentage: slippageDecimal,
      skipValidation: false,
    },
    timeout: 20000,
  });

  // Normalize to same shape as 1inch tx
  return {
    to: res.data.to,
    data: res.data.data,
    value: res.data.value,
    gas: res.data.estimatedGas || res.data.gas,
    gasPrice: res.data.gasPrice,
    maxFeePerGas: res.data.maxFeePerGas,
    maxPriorityFeePerGas: res.data.maxPriorityFeePerGas,
    toAmount: res.data.buyAmount,
  };
}

// ─── ERC-20 Allowance / Approve ──────────────────────────────────────────────

const ERC20_APPROVE_ABI = [
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
];

/**
 * Ensure sufficient ERC-20 allowance for spender (e.g. 1inch router)
 * Call this before swapToken when tokenIn is NOT native ETH
 */
export async function ensureAllowance({ walletLabel, chain, tokenAddress, spender, amount }) {
  if (tokenAddress === NATIVE) return { needed: false };

  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);
  const pk = await getPrivateKey(walletLabel);
  const signer = new ethers.Wallet(pk, provider);
  const info = getWalletInfo(walletLabel);
  const decimals = await getTokenDecimals(tokenAddress, provider);

  const token = new ethers.Contract(tokenAddress, ERC20_APPROVE_ABI, signer);
  const currentAllowance = await token.allowance(info.address, spender);
  const required = ethers.parseUnits(String(amount), decimals);

  if (currentAllowance >= required) {
    return { needed: false, currentAllowance: ethers.formatUnits(currentAllowance, decimals) };
  }

  // Approve max to avoid repeated approvals
  const tx = await token.approve(spender, ethers.MaxUint256);
  await tx.wait(1);

  logger.info(`[swap] Approved ${tokenAddress} for ${spender} | tx: ${tx.hash}`);
  return { needed: true, txHash: tx.hash };
}

// ─── 1inch Router Address (for allowance) ────────────────────────────────────

export function get1inchRouter(chain) {
  // 1inch v6 AggregationRouterV6 — same address across all EVM chains
  return '0x111111125421cA6dc452d289314280a0f8842A65';
}
