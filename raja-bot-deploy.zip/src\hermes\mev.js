// src/hermes/mev.js — MEV protection via Flashbots Protect & MEV Blocker
import axios from 'axios';
import { ethers } from 'ethers';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

// Flashbots Protect RPC — free, no signup needed, protects from frontrunning
const FLASHBOTS_RPC = 'https://rpc.flashbots.net';
// MEV Blocker by CoW Protocol — also free
const MEV_BLOCKER_RPC = 'https://rpc.mevblocker.io';

/**
 * Send a signed transaction via private relay (MEV protected)
 * Falls back to public RPC if private relay fails
 *
 * @param {string} signedTx - hex string of signed tx (from signer.signTransaction)
 * @param {string} chain - only 'ethereum' supported for Flashbots
 * @param {string} prefer - 'flashbots' | 'mevblocker' | 'auto' (default)
 */
export async function sendPrivateTx({ signedTx, chain = 'ethereum', prefer = 'auto' }) {
  if (chain !== 'ethereum') {
    // Non-ethereum chains tidak support private relay — fallback ke public
    logger.info(`[mev] Chain ${chain} tidak support private relay. Using public RPC.`);
    return sendViaPublicRpc(signedTx, chain);
  }

  const relays = prefer === 'flashbots'
    ? [FLASHBOTS_RPC, MEV_BLOCKER_RPC]
    : prefer === 'mevblocker'
    ? [MEV_BLOCKER_RPC, FLASHBOTS_RPC]
    : [FLASHBOTS_RPC, MEV_BLOCKER_RPC]; // auto: try flashbots first

  for (const relay of relays) {
    try {
      const result = await sendViaRelay(signedTx, relay);
      logger.info(`[mev] Tx sent via ${relay}: ${result.txHash}`);
      return { ...result, relay, protected: true };
    } catch (err) {
      logger.warn(`[mev] Relay ${relay} failed: ${err.message}. Trying next...`);
    }
  }

  // Last resort: public RPC (unprotected)
  logger.warn(`[mev] All private relays failed. Sending via public RPC (unprotected).`);
  const result = await sendViaPublicRpc(signedTx, chain);
  return { ...result, relay: 'public', protected: false };
}

async function sendViaRelay(signedTx, relayUrl) {
  const res = await axios.post(
    relayUrl,
    {
      jsonrpc: '2.0',
      id: 1,
      method: 'eth_sendRawTransaction',
      params: [signedTx],
    },
    {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000,
    }
  );

  if (res.data.error) {
    throw new Error(res.data.error.message || JSON.stringify(res.data.error));
  }

  return { txHash: res.data.result, success: true };
}

async function sendViaPublicRpc(signedTx, chain) {
  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`Public RPC not configured for ${chain}`);

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const tx = await provider.broadcastTransaction(signedTx);
  return { txHash: tx.hash, success: true };
}

/**
 * Estimate if a tx is at MEV risk (large swap, high value)
 * Returns recommendation: 'private' | 'public'
 */
export function assessMevRisk({ usdValue, action }) {
  // Swaps/snipes di atas $1000 lewat private relay
  if (usdValue && usdValue > 1000) return 'private';
  if (action?.includes('snipe')) return 'private';
  if (action?.includes('swap') && usdValue > 500) return 'private';
  return 'public';
}

/**
 * Simulate a transaction (eth_call) sebelum broadcast
 * Returns { success, revertReason } 
 */
export async function simulateTx({ chain, to, data, value = '0x0', from }) {
  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

  try {
    const res = await axios.post(
      rpcUrl,
      {
        jsonrpc: '2.0',
        id: 1,
        method: 'eth_call',
        params: [
          { to, data, value, from: from || ethers.ZeroAddress },
          'latest',
        ],
      },
      { timeout: 15000 }
    );

    if (res.data.error) {
      return {
        success: false,
        revertReason: decodeRevertReason(res.data.error.data) || res.data.error.message,
      };
    }

    return { success: true, result: res.data.result };
  } catch (err) {
    return { success: false, revertReason: err.message };
  }
}

function decodeRevertReason(hexData) {
  if (!hexData || hexData === '0x') return null;
  try {
    // Standard revert: 0x08c379a0 + ABI encoded string
    if (hexData.startsWith('0x08c379a0')) {
      const encoded = hexData.slice(10);
      const decoded = ethers.AbiCoder.defaultAbiCoder().decode(['string'], `0x${encoded}`);
      return decoded[0];
    }
    return hexData;
  } catch {
    return hexData;
  }
}
