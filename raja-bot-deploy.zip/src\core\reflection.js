// src/core/reflection.js — Daily self-improvement reflection loop (x4)
import { getRecent, rememberFact, reinforce, recallMemory, compactOldMemory } from './memory.js';
import { callCascade } from '../llm/cascade.js';
import { logger } from '../utils/logger.js';
import { getBot } from '../telegram/bot.js';
import { config } from '../config.js';

const REFLECTION_SYSTEM = `Kamu adalah RAJA — AI agent yang sedang melakukan refleksi harian terhadap sesi kemarin.
Analisis memories yang ada, identifikasi:
1. Pola yang sering muncul (topik, skill yang sering dipakai)
2. Kesalahan atau jawaban buruk yang harus dihindari
3. Peluang baru yang bisa dieksploitasi
4. Saran konkret untuk meningkatkan performa

Output dalam format JSON:
{
  "patterns": ["pattern1", "pattern2"],
  "improvements": [
    {"action": "reinforce|add_tag|pattern|modify_code|config|remove", "target": "...", "detail": "...", "reason": "..."}
  ],
  "opportunities": ["opportunity1"],
  "memory_to_reinforce": ["content to remember stronger"],
  "summary": "1-2 kalimat ringkasan"
}`;

const SAFE_ACTIONS = ['reinforce', 'add_tag', 'pattern', 'remember', 'weight'];
const UNSAFE_ACTIONS = ['modify_code', 'config', 'remove', 'disable', 'integration', 'install'];

/**
 * Classify an improvement suggestion as 'safe' or 'unsafe'.
 * Safe actions: reinforce, add_tag, pattern, remember, weight
 * Unsafe actions: modify_code, config, remove, disable, integration, install
 * Defaults to 'unsafe' on error or unknown.
 */
export function classifyImprovement(suggestion) {
  try {
    if (!suggestion || !suggestion.action) return 'unsafe';
    const action = String(suggestion.action).toLowerCase();

    if (SAFE_ACTIONS.some(safe => action.includes(safe))) return 'safe';
    if (UNSAFE_ACTIONS.some(unsafe => action.includes(unsafe))) return 'unsafe';

    // Unknown action defaults to unsafe
    return 'unsafe';
  } catch {
    return 'unsafe';
  }
}

/**
 * Apply a safe improvement directly:
 * - reinforce: find memory by content match, increase weight
 * - add_tag: find memory, update tags
 * - pattern: store new memory with kind='pattern'
 */
export async function applySafeImprovement(improvement) {
  const action = String(improvement.action).toLowerCase();

  if (action.includes('reinforce') || action.includes('remember') || action.includes('weight')) {
    // Find memory by target content match, reinforce it
    const matches = await recallMemory(improvement.target || improvement.detail, 1);
    if (matches.length > 0) {
      await reinforce(matches[0].id, 1.0);
      logger.info(`[reflection] Reinforced memory #${matches[0].id}: "${matches[0].content.substring(0, 50)}..."`);
    } else {
      // If no match found, store as new fact with higher weight
      await rememberFact({
        content: improvement.target || improvement.detail,
        kind: 'fact',
        tags: 'reinforced,auto',
        weight: 2.0,
      });
      logger.info(`[reflection] No match to reinforce, stored as new fact: "${(improvement.target || improvement.detail).substring(0, 50)}"`);
    }
  } else if (action.includes('add_tag')) {
    // Find memory, update tags
    const matches = await recallMemory(improvement.target || improvement.detail, 1);
    if (matches.length > 0) {
      const mem = matches[0];
      const existingTags = mem.tags || '';
      const newTag = improvement.detail || improvement.target;
      const updatedTags = existingTags ? `${existingTags},${newTag}` : newTag;
      // Store updated version (rememberFact handles dedup by reinforcing existing)
      await rememberFact({
        content: mem.content,
        kind: mem.kind,
        tags: updatedTags,
        weight: mem.weight,
      });
      logger.info(`[reflection] Added tag "${newTag}" to memory #${mem.id}`);
    }
  } else if (action.includes('pattern')) {
    // Store new memory with kind='pattern'
    await rememberFact({
      content: improvement.detail || improvement.target,
      kind: 'pattern',
      tags: 'auto,reflection',
      weight: 1.5,
    });
    logger.info(`[reflection] Stored new pattern: "${(improvement.detail || improvement.target).substring(0, 50)}"`);
  }
}

/**
 * Defer an unsafe improvement for operator review:
 * - Store as memory with kind='pending_improvement', weight=2.0
 * - Notify operator via Telegram
 */
export async function deferUnsafeImprovement(improvement) {
  // Store as pending improvement
  await rememberFact({
    content: `[PENDING] action=${improvement.action} target=${improvement.target || ''} detail=${improvement.detail || ''} reason=${improvement.reason || ''}`,
    kind: 'pending_improvement',
    tags: 'unsafe,needs_review',
    weight: 2.0,
  });

  // Notify operator via Telegram
  try {
    const bot = getBot();
    if (bot) {
      await bot.sendMessage(
        config.telegram.allowedUserId,
        `⚠️ *Improvement Perlu Review*\n\nAction: \`${improvement.action}\`\nTarget: ${improvement.target || '-'}\nDetail: ${improvement.detail || '-'}\nReason: ${improvement.reason || '-'}\n\n_Didefer karena termasuk kategori unsafe._`,
        { parse_mode: 'Markdown' }
      );
    }
  } catch (e) {
    logger.warn(`[reflection] Failed to notify operator about deferred improvement: ${e.message}`);
  }
}

export async function runDailyReflection() {
  logger.info('[reflection] Starting daily reflection loop...');

  try {
    // 1. Recall recent memories (last 24h activity)
    const recent = await getRecent(50, null);

    if (recent.length === 0) {
      logger.info('[reflection] No memories to reflect on. Skipping.');
      return;
    }

    // 2. Build reflection prompt
    const memoryDump = recent.slice(0, 30)
      .map(m => `[${m.kind}] ${m.content}`)
      .join('\n');

    const messages = [
      { role: 'system', content: REFLECTION_SYSTEM },
      { role: 'user', content: `Memories dari 24 jam terakhir:\n\n${memoryDump}\n\nBerikan refleksi dan saran perbaikan.` },
    ];

    // 3. Call LLM
    const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.5 });

    // 4. Parse reflection
    let reflection;
    try {
      const jsonMatch = result.text.match(/\{[\s\S]*\}/);
      reflection = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
    } catch {
      reflection = null;
    }

    // 5. Save reflection as memory
    await rememberFact({
      content: `Daily reflection: ${reflection?.summary || result.text.substring(0, 200)}`,
      kind: 'reflection',
      tags: 'daily,auto',
      weight: 2.0,
    });

    // 6. Process improvements array (auto-apply safe, defer unsafe)
    let appliedCount = 0;
    let deferredCount = 0;

    if (reflection?.improvements && Array.isArray(reflection.improvements)) {
      for (const improvement of reflection.improvements) {
        const classification = classifyImprovement(improvement);
        if (classification === 'safe') {
          await applySafeImprovement(improvement);
          appliedCount++;
        } else {
          await deferUnsafeImprovement(improvement);
          deferredCount++;
        }
      }
      logger.info(`[reflection] Applied ${appliedCount} safe, deferred ${deferredCount} unsafe improvements.`);
    }

    // 7. Compact old/low-weight memories
    const compacted = await compactOldMemory(config.memory?.retentionDays || 30);

    logger.info(`[reflection] Done. Compacted ${compacted} old memories.`);

    // 8. Notify operator via Telegram (optional)
    if (reflection?.summary) {
      try {
        const bot = getBot();
        if (bot) {
          await bot.sendMessage(
            config.telegram.allowedUserId,
            `🧠 *Refleksi Harian RAJA*\n\n${reflection.summary}\n\n📊 ${recent.length} memories, ${compacted} dicompact\n✅ ${appliedCount} safe applied, ⚠️ ${deferredCount} deferred`,
            { parse_mode: 'Markdown' }
          );
        }
      } catch (e) {
        // Non-critical
      }
    }

    return reflection;
  } catch (err) {
    logger.error(`[reflection] Failed: ${err.message}. Skipping entire cycle — no memory mutations.`);
    // If LLM call fails: skip entire cycle, no memory mutations
  }
}

/**
 * Manually trigger a reflection with custom prompt
 */
export async function runManualReflection(topic) {
  const recent = await getRecent(20, null);
  const memDump = recent.map(m => `[${m.kind}] ${m.content}`).join('\n');

  const messages = [
    { role: 'system', content: REFLECTION_SYSTEM },
    {
      role: 'user',
      content: `Topik refleksi: "${topic}"\n\nMemories relevan:\n${memDump}\n\nAnalisa dan berikan insight.`,
    },
  ];

  const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.6 });
  return result.text;
}
