// ecosystem.config.js — PM2 configuration
export default {
  apps: [
    {
      name: 'raja-bot',
      script: 'src/index.js',
      interpreter: 'node',
      interpreter_args: '--experimental-vm-modules',
      cwd: '/opt/raja-bot',
      watch: false,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      restart_delay: 5000,
      max_restarts: 10,
      min_uptime: '10s',
      env: {
        NODE_ENV: 'production',
      },
      env_development: {
        NODE_ENV: 'development',
      },
      error_file: '/opt/raja-bot/logs/pm2-error.log',
      out_file: '/opt/raja-bot/logs/pm2-out.log',
      merge_logs: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      kill_timeout: 5000,
    },
    {
      name: 'raja-watchdog',
      script: 'src/watchdog/monitor.js',
      interpreter: 'node',
      cwd: '/opt/raja-bot',
      watch: false,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      restart_delay: 10000,
      max_restarts: 5,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
