// src/utils/extractor.js — Archive extraction utility (zip, tar.gz, rar)
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { createGunzip } from 'zlib';
import { pipeline } from 'stream/promises';
import { logger } from './logger.js';

const execAsync = promisify(exec);

/**
 * Extract archive file to a temporary directory.
 * Supports: .zip, .tar.gz, .tgz, .tar, .rar
 * Returns array of { filename, content } for text files.
 *
 * @param {string} filePath - Path to the archive file
 * @param {string} fileName - Original filename (for type detection)
 * @returns {Promise<{files: Array<{name: string, content: string}>, extractDir: string}>}
 */
export async function extractArchive(filePath, fileName) {
  const tmpDir = path.join('/tmp', `raja-extract-${Date.now()}`);
  fs.mkdirSync(tmpDir, { recursive: true });

  const lowerName = fileName.toLowerCase();

  try {
    if (lowerName.endsWith('.zip')) {
      await extractZip(filePath, tmpDir);
    } else if (lowerName.endsWith('.tar.gz') || lowerName.endsWith('.tgz')) {
      await extractTarGz(filePath, tmpDir);
    } else if (lowerName.endsWith('.tar')) {
      await extractTar(filePath, tmpDir);
    } else if (lowerName.endsWith('.rar')) {
      await extractRar(filePath, tmpDir);
    } else {
      throw new Error(`Unsupported archive format: ${fileName}`);
    }

    // Read all text files from extracted directory
    const files = readExtractedFiles(tmpDir);
    return { files, extractDir: tmpDir };
  } catch (err) {
    // Cleanup on error
    cleanupDir(tmpDir);
    throw err;
  }
}

/**
 * Extract .zip file using adm-zip
 */
async function extractZip(filePath, outDir) {
  const AdmZip = (await import('adm-zip')).default;
  const zip = new AdmZip(filePath);
  zip.extractAllTo(outDir, true);
  logger.info(`[extractor] ZIP extracted to ${outDir}`);
}

/**
 * Extract .tar.gz / .tgz using system tar command
 */
async function extractTarGz(filePath, outDir) {
  await execAsync(`tar -xzf "${filePath}" -C "${outDir}"`, { timeout: 60000 });
  logger.info(`[extractor] TAR.GZ extracted to ${outDir}`);
}

/**
 * Extract .tar using system tar command
 */
async function extractTar(filePath, outDir) {
  await execAsync(`tar -xf "${filePath}" -C "${outDir}"`, { timeout: 60000 });
  logger.info(`[extractor] TAR extracted to ${outDir}`);
}

/**
 * Extract .rar using system unrar command
 */
async function extractRar(filePath, outDir) {
  try {
    await execAsync(`unrar x -o+ "${filePath}" "${outDir}/"`, { timeout: 60000 });
    logger.info(`[extractor] RAR extracted to ${outDir}`);
  } catch (err) {
    if (err.message.includes('not found') || err.message.includes('No such file')) {
      throw new Error('unrar not installed. Run: apt install unrar');
    }
    throw err;
  }
}

/**
 * Recursively read all text/code files from directory.
 * Returns array of { name, content } objects.
 * Skips binary files, node_modules, .git, etc.
 */
function readExtractedFiles(dir, basePath = '') {
  const results = [];
  const skipDirs = new Set(['node_modules', '.git', '__pycache__', '.DS_Store']);
  const textExtensions = new Set(['.js', '.ts', '.py', '.md', '.txt', '.json', '.yaml', '.yml', '.toml', '.sh', '.env.example', '.html', '.css', '.sol']);

  const entries = fs.readdirSync(dir, { withFileTypes: true });

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relativePath = basePath ? `${basePath}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      if (skipDirs.has(entry.name)) continue;
      results.push(...readExtractedFiles(fullPath, relativePath));
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      if (!textExtensions.has(ext) && ext !== '') continue;

      try {
        const content = fs.readFileSync(fullPath, 'utf8');
        // Skip binary-looking files
        if (content.includes('\0')) continue;
        results.push({ name: relativePath, content });
      } catch {
        // Skip unreadable files
      }
    }
  }

  return results;
}

/**
 * Cleanup extracted temporary directory
 */
export function cleanupDir(dir) {
  try {
    fs.rmSync(dir, { recursive: true, force: true });
  } catch {}
}

/**
 * Check if a filename is a supported archive
 */
export function isArchiveFile(fileName) {
  const lower = fileName.toLowerCase();
  return lower.endsWith('.zip') || lower.endsWith('.tar.gz') || lower.endsWith('.tgz') ||
         lower.endsWith('.tar') || lower.endsWith('.rar');
}
