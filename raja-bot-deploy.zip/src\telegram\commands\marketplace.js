// src/telegram/commands/marketplace.js — Marketplace command handlers
import { downloadSkill, auditSkill, activateSkill, getQuarantineStatus } from '../../core/skill-marketplace.js';
import { logger } from '../../utils/logger.js';

/**
 * /marketplace command router.
 * Subcommands: list, download <url>, audit <name>, activate <name>, status <name>
 */
export async function cmdMarketplace(bot, msg, args) {
  const chatId = msg.chat.id;

  try {
    if (!args || !args.trim()) {
      await bot.sendMessage(chatId, formatUsage());
      return;
    }

    const parts = args.trim().split(/\s+/);
    const subcommand = parts[0].toLowerCase();
    const param = parts.slice(1).join(' ');

    switch (subcommand) {
      case 'list':
        await handleList(bot, chatId);
        break;
      case 'download':
        await handleDownload(bot, chatId, param);
        break;
      case 'audit':
        await handleAudit(bot, chatId, param);
        break;
      case 'activate':
        await handleActivate(bot, chatId, param);
        break;
      case 'status':
        await handleStatus(bot, chatId, param);
        break;
      default:
        await bot.sendMessage(chatId, `❌ Unknown subcommand: "${subcommand}"\n\n${formatUsage()}`);
    }
  } catch (err) {
    logger.error(`[marketplace] Command error: ${err.message}`);
    await bot.sendMessage(chatId, `❌ Marketplace error: ${err.message}`);
  }
}

/**
 * /marketplace list — show quarantined skills and their status
 */
async function handleList(bot, chatId) {
  const status = getQuarantineStatus();

  if (status.total === 0) {
    await bot.sendMessage(chatId, '📦 Quarantine kosong. Tidak ada skill yang menunggu.');
    return;
  }

  let text = `📦 *Marketplace Quarantine*\n`;
  text += `Total: ${status.total} | ⏳ Pending: ${status.pending} | ✅ Approved: ${status.approved} | 🚫 Blocked: ${status.blocked}\n\n`;

  for (const [name, entry] of Object.entries(status.skills)) {
    const icon = entry.status === 'approved' ? '✅' : entry.status === 'blocked' ? '🚫' : '⏳';
    text += `${icon} \`${name}\` — ${entry.status}\n`;
    if (entry.violations.length > 0) {
      text += `   ⚠️ ${entry.violations.length} violation(s)\n`;
    }
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {
    bot.sendMessage(chatId, text);
  });
}

/**
 * /marketplace download <url> — download skill to quarantine
 */
async function handleDownload(bot, chatId, url) {
  if (!url) {
    await bot.sendMessage(chatId, '❌ Usage: `/marketplace download <url>`', { parse_mode: 'Markdown' });
    return;
  }

  await bot.sendMessage(chatId, `⏬ Downloading skill from:\n${url}`);

  const filename = await downloadSkill(url);
  await bot.sendMessage(chatId, `✅ Skill \`${filename}\` downloaded ke quarantine.\nJalankan \`/marketplace audit ${filename}\` untuk audit.`, { parse_mode: 'Markdown' });
}

/**
 * /marketplace audit <name> — trigger integrity audit
 */
async function handleAudit(bot, chatId, name) {
  if (!name) {
    await bot.sendMessage(chatId, '❌ Usage: `/marketplace audit <filename>`', { parse_mode: 'Markdown' });
    return;
  }

  await bot.sendMessage(chatId, `🔍 Auditing \`${name}\`...`, { parse_mode: 'Markdown' });

  const result = await auditSkill(name);

  let text = '';
  if (result.status === 'approved') {
    text = `✅ Skill \`${name}\` APPROVED — no violations found.\nJalankan \`/marketplace activate ${name}\` untuk aktivasi.`;
  } else {
    text = `🚫 Skill \`${name}\` BLOCKED — ${result.violations.length} violation(s):\n`;
    for (const v of result.violations) {
      text += `• ${v}\n`;
    }
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {
    bot.sendMessage(chatId, text);
  });
}

/**
 * /marketplace activate <name> — activate approved skill
 */
async function handleActivate(bot, chatId, name) {
  if (!name) {
    await bot.sendMessage(chatId, '❌ Usage: `/marketplace activate <filename>`', { parse_mode: 'Markdown' });
    return;
  }

  const result = await activateSkill(name);

  if (result.success) {
    await bot.sendMessage(chatId, `✅ ${result.message}`);
  } else {
    await bot.sendMessage(chatId, `❌ ${result.message}`);
  }
}

/**
 * /marketplace status <name> — check specific skill status
 */
async function handleStatus(bot, chatId, name) {
  if (!name) {
    await bot.sendMessage(chatId, '❌ Usage: `/marketplace status <filename>`', { parse_mode: 'Markdown' });
    return;
  }

  const { skills } = getQuarantineStatus();
  const entry = skills[name];

  if (!entry) {
    await bot.sendMessage(chatId, `❌ Skill \`${name}\` tidak ditemukan di quarantine.`, { parse_mode: 'Markdown' });
    return;
  }

  const icon = entry.status === 'approved' ? '✅' : entry.status === 'blocked' ? '🚫' : '⏳';
  let text = `${icon} *Skill Status: ${name}*\n\n`;
  text += `Status: ${entry.status}\n`;
  text += `Downloaded: ${entry.downloadedAt}\n`;
  text += `Source: ${entry.sourceUrl}\n`;
  text += `Hash: \`${entry.hash}\`\n`;

  if (entry.auditedAt) {
    text += `Audited: ${entry.auditedAt}\n`;
  }

  if (entry.violations.length > 0) {
    text += `\n⚠️ Violations:\n`;
    for (const v of entry.violations) {
      text += `• ${v}\n`;
    }
  }

  await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' }).catch(() => {
    bot.sendMessage(chatId, text);
  });
}

/**
 * Format usage/help text for the /marketplace command.
 */
function formatUsage() {
  return [
    '📦 *Marketplace Commands:*',
    '',
    '`/marketplace list` — Lihat skill di quarantine',
    '`/marketplace download <url>` — Download skill ke quarantine',
    '`/marketplace audit <name>` — Audit integritas skill',
    '`/marketplace activate <name>` — Aktivasi skill yang approved',
    '`/marketplace status <name>` — Cek status skill tertentu',
  ].join('\n');
}
