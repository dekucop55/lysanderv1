import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { extractPackageName, isPackageImport } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 7.3**
 * Property 17: Package name extraction.
 */
describe('Property 17: Package Name Extraction', () => {
  it('extracts regular package names correctly', () => {
    const packages = ['axios', 'lodash', 'express', 'fast-check', 'node-cron'];
    fc.assert(fc.property(
      fc.constantFrom(...packages),
      fc.option(fc.constantFrom('/get', '/utils', '/deep', '')),
      (pkg, subpath) => {
        const error = { message: `Cannot find module '${pkg}${subpath || ''}'` };
        assert.strictEqual(extractPackageName(error), pkg);
      }
    ), { numRuns: 50 });
  });

  it('extracts scoped package names correctly', () => {
    const scoped = ['@scope/pkg', '@ethersproject/abi', '@types/node'];
    fc.assert(fc.property(
      fc.constantFrom(...scoped),
      (pkg) => {
        const error = { message: `Cannot find module '${pkg}/subpath'` };
        assert.strictEqual(extractPackageName(error), pkg);
      }
    ), { numRuns: 30 });
  });

  it('returns null for local file paths', () => {
    const locals = ['./utils', '../core/brain', '/opt/raja-bot/src/x'];
    for (const local of locals) {
      const error = { message: `Cannot find module '${local}'` };
      assert.strictEqual(extractPackageName(error), null);
    }
  });

  it('isPackageImport returns false for relative paths', () => {
    const locals = ['./utils.js', '../core/brain.js', '/absolute/path.js'];
    for (const local of locals) {
      const error = { message: `Cannot find module '${local}'` };
      assert.strictEqual(isPackageImport(error), false);
    }
  });

  it('isPackageImport returns true for bare specifiers', () => {
    const pkgs = ['axios', 'lodash', '@scope/pkg'];
    for (const pkg of pkgs) {
      const error = { message: `Cannot find module '${pkg}'` };
      assert.strictEqual(isPackageImport(error), true);
    }
  });
});
