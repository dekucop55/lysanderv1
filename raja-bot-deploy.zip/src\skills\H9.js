// src/skills/H9.js — Hermes: Universal contract reader & writer
// TODO: Wire intent detection to hermes/contract.js — module already imported below.
// Already has partial integration. Expanding with proper intent detection.
// Expected additional patterns: "read <function> from <address> on <chain>",
// "call <function> on <address> args [...]", "fetch abi <address>"
import { logger } from '../utils/logger.js';

/**
 * Detect actionable contract R/W intent from natural language query.
 * Currently returns null (LLM-only) — will be wired to hermes/contract.js in future.
 *
 * TODO: Implement full intent detection for contract interactions:
 * - "read <functionName> from <contractAddress> on <chain> [args ...]"
 *   → readContract({ chain, contractAddress, functionName, args })
 * - "call/write <functionName> on <contractAddress> on <chain> wallet <label> [args ...]"
 *   → writeContract({ walletLabel, chain, contractAddress, functionName, args })
 * - "fetch abi <contractAddress> on <chain>"
 *   → fetchAbi({ contractAddress, chain })
 * - "deploy <template> on <chain> wallet <label>"
 *   → deployContract(...)
 *
 * hermes/contract.js exports:
 * - readContract({ chain, contractAddress, abi, functionName, args })
 * - writeContract({ walletLabel, chain, contractAddress, abi, functionName, args, value })
 * - fetchAbi({ contractAddress, chain })
 * - deployContract({ walletLabel, chain, abi, bytecode, constructorArgs })
 */
function detectContractIntent(query) {
  // TODO: Implement with regex patterns:
  // const q = query.trim();
  //
  // const readMatch = q.match(/(?:read|baca|get)\s+(\S+)\s+(?:from|dari)\s+(0x[a-fA-F0-9]{40})\s+(?:on|di)\s+(\S+)/i);
  // if (readMatch) return { intent: 'READ', params: { functionName: readMatch[1], contractAddress: readMatch[2], chain: readMatch[3] } };
  //
  // const abiMatch = q.match(/(?:fetch|get|ambil)\s+abi\s+(0x[a-fA-F0-9]{40})\s+(?:on|di)\s+(\S+)/i);
  // if (abiMatch) return { intent: 'FETCH_ABI', params: { contractAddress: abiMatch[1], chain: abiMatch[2] } };
  //
  return null;
}

export default {
  id: 'H9',
  name: 'contract-rw',
  description: 'Baca/tulis kontrak apa pun: ABI auto-fetch, read functions, write/call functions via governor, proxy detection',

  async execute(query, context) {
    // 1. Attempt intent detection (currently LLM-only, TODO: expand)
    const intent = detectContractIntent(query);

    if (intent) {
      // TODO: Handle actionable contract intents with hermes/contract.js
      logger.info(`[H9] Contract intent detected: ${intent.intent}`, intent.params);
    }

    // 2. LLM cascade for contract R/W queries
    try {
      const { callCascade } = await import('../llm/cascade.js');
      // Import available for when intent detection is wired
      // const { readContract, writeContract, fetchAbi, deployContract } = await import('../hermes/contract.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H9 (Contract R/W).
Mode: precise, methodical.

Kamu adalah expert smart contract interaction (read & write):

READ Operations (no signing needed):
- Call view/pure functions dari kontrak apapun
- Auto-fetch ABI dari Etherscan/Sourcify (verified contracts)
- Inspect storage slots & state variables
- Detect proxy patterns (EIP-1967, OpenZeppelin TransparentProxy, UUPS)
- Decode event logs & transaction input data
- Multi-call batching (Multicall3)

WRITE Operations (requires wallet + governor):
- Call any state-mutating function
- Auto-estimate gas + 20% buffer
- EIP-1559 gas pricing (base + priority)
- Simulation via eth_call BEFORE broadcast
- MEV protection for high-value transactions
- Nonce management (sequential, no gaps)

ABI Management:
- Auto-fetch from Etherscan API (verified contracts)
- Manual ABI input for unverified contracts
- Proxy implementation ABI detection
- Interface detection (ERC-20, ERC-721, ERC-1155)

DEPLOY Operations:
- Deploy from ABI + bytecode
- Constructor args encoding
- CREATE2 deterministic deployment
- Multi-chain same-address deploy
- Post-deploy verification on block explorer

Safety Protocol:
1. Selalu simulasi (eth_call) sebelum write
2. Governor authorization untuk semua write operations
3. Gas sanity check (reject jika > 10x normal)
4. Value sanity check (reject jika > daily cap)
5. Contract verification check (warn jika unverified)

Tools tersedia di hermes/contract.js:
- readContract({ chain, contractAddress, abi, functionName, args })
- writeContract({ walletLabel, chain, contractAddress, abi, functionName, args, value })
- deployContract({ walletLabel, chain, abi, bytecode, constructorArgs })
- fetchAbi({ contractAddress, chain })

Supported chains: ethereum, base, arbitrum, optimism, polygon, bsc, avalanche

Berikan code examples dengan ethers.js v6 syntax.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H9] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan contract R/W: ${err.message}`;
    }
  },
};
