// tests/unit/auto-push-scheduler.test.js
//
// Unit tests for AutoPushScheduler (Task 9.1, 9.2)
// Validates: Requirements 6.1, 6.2, 6.3, 6.8

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { AutoPushScheduler } from '../../src/core/auto-push.js';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

// Mock node-cron
vi.mock('node-cron', () => ({
  default: {
    schedule: vi.fn((schedule, callback) => {
      return {
        stop: vi.fn(),
        _callback: callback
      };
    })
  }
}));

// Mock child_process
vi.mock('child_process', () => ({
  execSync: vi.fn()
}));

// Mock logger
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn()
  }
}));

describe('AutoPushScheduler', () => {
  let scheduler;
  const testLogFile = path.join('logs', 'test-auto-push.log');

  beforeEach(() => {
    scheduler = new AutoPushScheduler({ logFile: testLogFile });
  });

  afterEach(() => {
    scheduler.stop();
    // Clean up test log file
    try {
      if (fs.existsSync(testLogFile)) {
        fs.unlinkSync(testLogFile);
      }
    } catch (e) { /* ignore */ }
  });

  describe('constructor', () => {
    it('should use default cron schedule 0 20 * * * (03:00 WIB = 20:00 UTC)', () => {
      const s = new AutoPushScheduler();
      expect(s.cronSchedule).toBe('0 20 * * *');
    });

    it('should accept custom cron schedule', () => {
      const s = new AutoPushScheduler({ cronSchedule: '30 14 * * *' });
      expect(s.cronSchedule).toBe('30 14 * * *');
    });

    it('should default maxRetries to 3', () => {
      expect(scheduler.maxRetries).toBe(3);
    });

    it('should default retryIntervalMs to 5 minutes (300000 ms)', () => {
      expect(scheduler.retryIntervalMs).toBe(300000);
    });

    it('should default pushTimeoutMs to 120 seconds (120000 ms)', () => {
      expect(scheduler.pushTimeoutMs).toBe(120000);
    });

    it('should initialize isRunning as false', () => {
      expect(scheduler.isRunning).toBe(false);
    });

    it('should initialize cronJob as null', () => {
      expect(scheduler.cronJob).toBeNull();
    });
  });

  describe('start()', () => {
    it('should create a cron job', async () => {
      const cron = await import('node-cron');
      scheduler.start();
      expect(cron.default.schedule).toHaveBeenCalledWith('0 20 * * *', expect.any(Function));
      expect(scheduler.cronJob).not.toBeNull();
    });

    it('should be idempotent — calling start() twice does not create a second job', async () => {
      const cron = await import('node-cron');
      const callsBefore = cron.default.schedule.mock.calls.length;
      scheduler.start();
      scheduler.start();
      expect(cron.default.schedule.mock.calls.length).toBe(callsBefore + 1);
    });
  });

  describe('stop()', () => {
    it('should stop the cron job and set cronJob to null', () => {
      scheduler.start();
      const job = scheduler.cronJob;
      scheduler.stop();
      expect(job.stop).toHaveBeenCalled();
      expect(scheduler.cronJob).toBeNull();
    });

    it('should be safe to call when not started', () => {
      expect(() => scheduler.stop()).not.toThrow();
    });
  });

  describe('triggerPush()', () => {
    it('should return skipped with no changes detected', async () => {
      execSync.mockReturnValue('');
      const result = await scheduler.triggerPush();
      expect(result.status).toBe('skipped');
      expect(result.codeFiles).toBe(0);
      expect(result.dataFiles).toBe(0);
      expect(result.error).toBeNull();
      expect(result.timestamp).toBeDefined();
    });

    it('should reject concurrent triggers (Requirement 6.8)', async () => {
      // Simulate a long-running push
      scheduler.detectChanges = () => new Promise(resolve => {
        setTimeout(() => resolve({ codeFiles: ['a.js'], dataFiles: [] }), 100);
      });

      // Start first push (don't await)
      const firstPush = scheduler.triggerPush();

      // Trigger second push while first is running
      const secondResult = await scheduler.triggerPush();

      expect(secondResult.status).toBe('skipped');
      expect(secondResult.error).toBe('concurrent push rejected');

      // Wait for first to finish
      await firstPush;
    });

    it('should release lock after successful completion', async () => {
      execSync.mockReturnValue('');
      await scheduler.triggerPush();
      expect(scheduler.isRunning).toBe(false);
    });

    it('should release lock after error', async () => {
      scheduler.detectChanges = () => Promise.reject(new Error('test error'));
      await scheduler.triggerPush();
      expect(scheduler.isRunning).toBe(false);
    });

    it('should return failed status on error', async () => {
      scheduler.detectChanges = () => Promise.reject(new Error('git push failed'));
      const result = await scheduler.triggerPush();
      expect(result.status).toBe('failed');
      expect(result.error).toBe('git push failed');
    });

    it('should return success when changes are detected', async () => {
      scheduler.detectChanges = () => Promise.resolve({
        codeFiles: ['src/index.js', 'src/utils.js'],
        dataFiles: ['data/memory.db']
      });

      const result = await scheduler.triggerPush();
      expect(result.status).toBe('success');
      expect(result.codeFiles).toBe(2);
      expect(result.dataFiles).toBe(1);
      expect(result.error).toBeNull();
    });

    it('should include ISO 8601 timestamp in result', async () => {
      execSync.mockReturnValue('');
      const result = await scheduler.triggerPush();
      const isoRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z$/;
      expect(result.timestamp).toMatch(isoRegex);
    });
  });

  describe('formatCommitMessage()', () => {
    it('should format message with correct structure', () => {
      const msg = scheduler.formatCommitMessage(3, 2);
      const dateRegex = /^\[auto-sync\] \d{4}-\d{2}-\d{2} \| code: 3 files \| data: 2 files$/;
      expect(msg).toMatch(dateRegex);
    });

    it('should use current date', () => {
      const today = new Date().toISOString().split('T')[0];
      const msg = scheduler.formatCommitMessage(1, 0);
      expect(msg).toContain(today);
    });

    it('should handle zero files', () => {
      const msg = scheduler.formatCommitMessage(0, 0);
      expect(msg).toContain('code: 0 files');
      expect(msg).toContain('data: 0 files');
    });
  });

  describe('classifyError()', () => {
    it('should classify timeout errors', () => {
      expect(scheduler.classifyError(new Error('request timeout'))).toBe('timeout');
      expect(scheduler.classifyError(new Error('ETIMEDOUT'))).toBe('timeout');
    });

    it('should classify network errors', () => {
      expect(scheduler.classifyError(new Error('ECONNREFUSED'))).toBe('network');
      expect(scheduler.classifyError(new Error('ENOTFOUND github.com'))).toBe('network');
      expect(scheduler.classifyError(new Error('network error'))).toBe('network');
    });

    it('should classify auth errors', () => {
      expect(scheduler.classifyError(new Error('authentication failed'))).toBe('auth');
      expect(scheduler.classifyError(new Error('403 Forbidden'))).toBe('auth');
      expect(scheduler.classifyError(new Error('permission denied'))).toBe('auth');
    });

    it('should classify conflict errors', () => {
      expect(scheduler.classifyError(new Error('merge conflict'))).toBe('conflict');
      expect(scheduler.classifyError(new Error('non-fast-forward update'))).toBe('conflict');
    });

    it('should return unknown for unrecognized errors', () => {
      expect(scheduler.classifyError(new Error('something weird happened'))).toBe('unknown');
    });
  });

  describe('writeLog()', () => {
    it('should create log directory if not exists', () => {
      const customLog = path.join('logs', 'subdir', 'test.log');
      const s = new AutoPushScheduler({ logFile: customLog });

      s.writeLog({ status: 'success', codeFiles: 1, dataFiles: 0, error: null, timestamp: '2025-01-01T00:00:00.000Z' });

      expect(fs.existsSync(path.dirname(customLog))).toBe(true);

      // Clean up
      fs.unlinkSync(customLog);
      fs.rmdirSync(path.dirname(customLog));
    });

    it('should append JSON entries to log file', () => {
      scheduler.writeLog({ status: 'success', codeFiles: 2, dataFiles: 1, error: null, timestamp: '2025-06-01T20:00:00.000Z' });
      scheduler.writeLog({ status: 'skipped', codeFiles: 0, dataFiles: 0, error: null, timestamp: '2025-06-02T20:00:00.000Z' });

      const content = fs.readFileSync(testLogFile, 'utf8');
      const lines = content.trim().split('\n');
      expect(lines).toHaveLength(2);

      const entry1 = JSON.parse(lines[0]);
      expect(entry1.status).toBe('success');
      expect(entry1.codeFiles).toBe(2);
      expect(entry1.dataFiles).toBe(1);

      const entry2 = JSON.parse(lines[1]);
      expect(entry2.status).toBe('skipped');
    });

    it('should include error message in log entry when failed', () => {
      scheduler.writeLog({ status: 'failed', codeFiles: 0, dataFiles: 0, error: 'push timeout', timestamp: '2025-06-01T20:00:00.000Z' });

      const content = fs.readFileSync(testLogFile, 'utf8');
      const entry = JSON.parse(content.trim());
      expect(entry.error).toBe('push timeout');
    });
  });

  describe('detectChanges()', () => {
    it('should return empty arrays when no changes (Requirement 6.3)', async () => {
      execSync.mockReturnValue('');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual([]);
      expect(result.dataFiles).toEqual([]);
    });

    it('should return empty arrays when output is only whitespace', async () => {
      execSync.mockReturnValue('   \n  ');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual([]);
      expect(result.dataFiles).toEqual([]);
    });

    it('should classify src/ files as codeFiles', async () => {
      execSync.mockReturnValue(' M src/core/brain.js\n M src/utils/logger.js\n');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['src/core/brain.js', 'src/utils/logger.js']);
      expect(result.dataFiles).toEqual([]);
    });

    it('should classify scripts/ files as codeFiles', async () => {
      execSync.mockReturnValue(' M scripts/deploy.sh\n');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['scripts/deploy.sh']);
    });

    it('should classify package.json as codeFiles', async () => {
      execSync.mockReturnValue(' M package.json\n');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['package.json']);
    });

    it('should classify data/ files as dataFiles', async () => {
      execSync.mockReturnValue(' M data/memory.db\n M data/backups/old.db\n');
      const result = await scheduler.detectChanges();
      expect(result.dataFiles).toEqual(['data/memory.db', 'data/backups/old.db']);
    });

    it('should separate code and data files correctly (Requirement 6.2)', async () => {
      execSync.mockReturnValue(
        ' M src/index.js\n' +
        '?? src/core/new-module.js\n' +
        ' M data/memory.db\n' +
        ' M scripts/backup.sh\n' +
        ' M package.json\n' +
        ' M data/config.json\n'
      );
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['src/index.js', 'src/core/new-module.js', 'scripts/backup.sh', 'package.json']);
      expect(result.dataFiles).toEqual(['data/memory.db', 'data/config.json']);
    });

    it('should ignore files not in tracked directories', async () => {
      execSync.mockReturnValue(
        ' M README.md\n' +
        ' M .env\n' +
        ' M logs/app.log\n' +
        ' M tests/unit/test.js\n'
      );
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual([]);
      expect(result.dataFiles).toEqual([]);
    });

    it('should handle renamed files (-> notation)', async () => {
      execSync.mockReturnValue('R  src/old-name.js -> src/new-name.js\n');
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['src/new-name.js']);
    });

    it('should handle various git status indicators (M, A, D, ??, R)', async () => {
      execSync.mockReturnValue(
        'M  src/modified.js\n' +
        'A  src/added.js\n' +
        'D  src/deleted.js\n' +
        '?? data/new-data.json\n'
      );
      const result = await scheduler.detectChanges();
      expect(result.codeFiles).toEqual(['src/modified.js', 'src/added.js', 'src/deleted.js']);
      expect(result.dataFiles).toEqual(['data/new-data.json']);
    });

    it('should throw and log error when git command fails', async () => {
      const { logger } = await import('../../src/utils/logger.js');
      execSync.mockImplementation(() => { throw new Error('git not found'); });
      await expect(scheduler.detectChanges()).rejects.toThrow('git not found');
      expect(logger.error).toHaveBeenCalledWith(expect.stringContaining('detectChanges failed'));
    });

    it('should call execSync with correct parameters', async () => {
      execSync.mockReturnValue('');
      await scheduler.detectChanges();
      expect(execSync).toHaveBeenCalledWith('git status --porcelain', {
        cwd: process.cwd(),
        encoding: 'utf8',
        timeout: 30000
      });
    });
  });
});
