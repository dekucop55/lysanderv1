// src/hermes/contract.js — Universal contract reader, writer, and deployer
import { ethers } from 'ethers';
import axios from 'axios';
import { config } from '../config.js';
import { getPrivateKey, getWalletInfo } from './wallets.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { logger } from '../utils/logger.js';

/**
 * Read from a smart contract (no signing required)
 */
export async function readContract({ chain, contractAddress, abi, functionName, args = [] }) {
  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const contract = new ethers.Contract(contractAddress, abi, provider);

  if (!contract[functionName]) {
    throw new Error(`Function "${functionName}" not found in ABI`);
  }

  const result = await contract[functionName](...args);
  return { success: true, result, chain, contract: contractAddress, function: functionName };
}

/**
 * Write to a smart contract (requires wallet)
 */
export async function writeContract({ walletLabel, chain, contractAddress, abi, functionName, args = [], value = '0', gasLimit = null }) {
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: `contract:${functionName}`,
    usdValue: null,
    slippage: 0,
    simulated: true,
  });
  if (!decision.allowed) return { success: false, reason: decision.reason };

  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);
  const signer = new ethers.Wallet(pk, provider);

  const contract = new ethers.Contract(contractAddress, abi, signer);

  const txOpts = {
    value: ethers.parseEther(String(value)),
  };
  if (gasLimit) txOpts.gasLimit = BigInt(gasLimit);

  const tx = await contract[functionName](...args, txOpts);
  const receipt = await tx.wait();

  governorRecord({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: `contract:${functionName}`,
    usdValue: null,
    txHash: tx.hash,
  });

  logger.info(`[contract] ${functionName} on ${contractAddress} | tx: ${tx.hash}`);
  return {
    success: true,
    txHash: tx.hash,
    receipt,
    chain,
    contract: contractAddress,
    function: functionName,
  };
}

/**
 * Deploy a new contract
 */
export async function deployContract({ walletLabel, chain, abi, bytecode, constructorArgs = [] }) {
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: 'deploy',
    usdValue: null,
    slippage: 0,
    simulated: true,
  });
  if (!decision.allowed) return { success: false, reason: decision.reason };

  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);
  const signer = new ethers.Wallet(pk, provider);

  const factory = new ethers.ContractFactory(abi, bytecode, signer);
  const contract = await factory.deploy(...constructorArgs);
  await contract.waitForDeployment();

  const address = await contract.getAddress();

  governorRecord({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: 'deploy',
    usdValue: null,
    txHash: contract.deploymentTransaction()?.hash,
  });

  logger.info(`[contract] Deployed to ${address} on ${chain}`);
  return {
    success: true,
    address,
    txHash: contract.deploymentTransaction()?.hash,
    chain,
  };
}

/**
 * Get contract ABI from Etherscan (auto-verified contracts)
 */
export async function fetchAbi({ contractAddress, chain = 'ethereum' }) {
  const apiKeyMap = {
    ethereum: process.env.ETHERSCAN_API_KEY,
    polygon: process.env.POLYGONSCAN_API_KEY,
    bsc: process.env.BSCSCAN_API_KEY,
  };
  const baseUrlMap = {
    ethereum: 'https://api.etherscan.io/api',
    polygon: 'https://api.polygonscan.com/api',
    bsc: 'https://api.bscscan.com/api',
    arbitrum: 'https://api.arbiscan.io/api',
    base: 'https://api.basescan.org/api',
  };

  const baseUrl = baseUrlMap[chain] || baseUrlMap.ethereum;
  const apiKey = apiKeyMap[chain] || '';

  const res = await axios.get(baseUrl, {
    params: {
      module: 'contract',
      action: 'getabi',
      address: contractAddress,
      apikey: apiKey,
    },
    timeout: 15000,
  });

  if (res.data.status !== '1') {
    throw new Error(`ABI fetch failed: ${res.data.message}`);
  }

  return JSON.parse(res.data.result);
}

function getChainId(chain) {
  const map = { ethereum: 1, base: 8453, arbitrum: 42161, optimism: 10, polygon: 137, bsc: 56 };
  return map[chain] || 1;
}
