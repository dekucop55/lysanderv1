// src/skills/m8.js — Documents: PDF, DOCX, XLSX, PPTX generation
export default {
  id: 'm8',
  name: 'documents',
  description: 'Document generation: PDF, DOCX, XLSX, PPTX, image processing',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m8 (Documents).
Expert dalam:
- PDF generation: PDFKit, pdfmake, Puppeteer HTML-to-PDF
- Word DOCX: docx (npm), mammoth untuk parsing
- Excel XLSX: exceljs, xlsx-populate
- PowerPoint PPTX: pptxgenjs
- Image processing: sharp, jimp
- QR code generation: qrcode
- Barcode generation
- Document templates dengan placeholder replacement
- Merge dan split PDF
- OCR (Tesseract.js untuk text extraction)
- Tanda tangan digital pada PDF

Output: code yang langsung bisa dipakai.
Sertakan dependensi yang dibutuhkan (npm install ...).`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
    return result.text;
  },
};
