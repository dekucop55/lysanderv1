import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import path from 'path';

/**
 * **Validates: Requirements 7.2**
 * Unit tests for createBackup() logic
 * 
 * Tests verify:
 * - Backup directory is created if not exists
 * - Backup file is named with correct timestamp format: memory_YYYYMMDD_HHmmss.db
 * - Database file is copied to backup location
 * - Function returns the backup path
 */

// Mock fs, path, config, and logger
const mockMkdirSync = vi.fn();
const mockCopyFileSync = vi.fn();
const mockExistsSync = vi.fn(() => true);

vi.mock('fs', () => ({
  default: {
    mkdirSync: (...args) => mockMkdirSync(...args),
    copyFileSync: (...args) => mockCopyFileSync(...args),
    existsSync: (...args) => mockExistsSync(...args),
  },
  mkdirSync: (...args) => mockMkdirSync(...args),
  copyFileSync: (...args) => mockCopyFileSync(...args),
  existsSync: (...args) => mockExistsSync(...args),
}));

vi.mock('../../src/config.js', () => ({
  config: {
    raja: {
      dataDir: '/opt/raja-bot/data',
    },
    memory: {
      retentionDays: 30,
    },
  },
}));

vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

vi.mock('better-sqlite3', () => ({
  default: vi.fn(),
}));

// Import after mocks are set up
const { createBackup } = await import('../../src/core/memory.js');

describe('createBackup — logic validation', () => {

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should create backup directory with recursive option', () => {
    createBackup();
    
    expect(mockMkdirSync).toHaveBeenCalledWith(
      '/opt/raja-bot/data/backups',
      { recursive: true }
    );
  });

  it('should copy memory.db to backup path', () => {
    createBackup();
    
    expect(mockCopyFileSync).toHaveBeenCalledTimes(1);
    const [src, dest] = mockCopyFileSync.mock.calls[0];
    expect(src).toBe('/opt/raja-bot/data/memory.db');
    expect(dest).toMatch(/[/\\]backups[/\\]memory_\d{8}_\d{6}\.db$/);
  });

  it('should return the backup file path', () => {
    const result = createBackup();
    
    expect(result).toMatch(/[/\\]backups[/\\]memory_\d{8}_\d{6}\.db$/);
    expect(typeof result).toBe('string');
  });

  it('should format timestamp as YYYYMMDD_HHmmss', () => {
    // Mock a specific date to verify format
    const fixedDate = new Date('2025-06-15T20:30:45.123Z');
    vi.setSystemTime(fixedDate);
    
    const result = createBackup();
    
    // The timestamp depends on local timezone, so just check the pattern
    const filename = path.basename(result);
    expect(filename).toMatch(/^memory_\d{8}_\d{6}\.db$/);
    
    vi.useRealTimers();
  });

  it('should produce correct timestamp for known date', () => {
    // Use a fixed UTC date and check the format
    const fixedDate = new Date(2025, 0, 15, 3, 5, 9); // Jan 15, 2025, 03:05:09 local
    vi.setSystemTime(fixedDate);
    
    const result = createBackup();
    const filename = path.basename(result);
    
    // Should be memory_20250115_030509.db in local time
    expect(filename).toBe('memory_20250115_030509.db');
    
    vi.useRealTimers();
  });

  it('should use config.raja.dataDir as base path', () => {
    const result = createBackup();
    
    // Backup path should be under dataDir/backups/
    expect(result).toContain('backups');
    const [src] = mockCopyFileSync.mock.calls[0];
    expect(src).toBe('/opt/raja-bot/data/memory.db');
  });

  it('should throw if copyFileSync fails (e.g., source does not exist)', () => {
    mockCopyFileSync.mockImplementationOnce(() => {
      throw new Error('ENOENT: no such file or directory');
    });
    
    expect(() => createBackup()).toThrow('ENOENT');
  });
});
