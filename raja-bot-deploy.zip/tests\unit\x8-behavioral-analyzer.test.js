import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { containsRefusalPattern, extractRefusalPhrase, findExpectedSkill, REFUSAL_PATTERNS } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 15.6, 15.7**
 * Property 21: Refusal pattern detection.
 * Property 22: findExpectedSkill routing analysis.
 */
describe('Property 21: Refusal Pattern Detection', () => {
  it('detects all known refusal patterns', () => {
    fc.assert(fc.property(
      fc.constantFrom(...REFUSAL_PATTERNS),
      fc.string({ minLength: 0, maxLength: 50 }),
      fc.string({ minLength: 0, maxLength: 50 }),
      (pattern, prefix, suffix) => {
        const text = `${prefix} ${pattern} ${suffix}`;
        assert.strictEqual(containsRefusalPattern(text), true);
      }
    ), { numRuns: 100 });
  });

  it('returns false for text without refusal patterns', () => {
    const safeTexts = ['Ini hasilnya bos', 'Done! File sudah dibuat', 'Swap berhasil', 'Balance ETH: 2.5'];
    for (const text of safeTexts) {
      assert.strictEqual(containsRefusalPattern(text), false);
    }
  });

  it('extractRefusalPhrase returns the matched phrase', () => {
    for (const pattern of REFUSAL_PATTERNS) {
      const text = `Bla bla ${pattern} bla bla`;
      assert.strictEqual(extractRefusalPhrase(text), pattern);
    }
  });

  it('extractRefusalPhrase returns null for non-refusal text', () => {
    assert.strictEqual(extractRefusalPhrase('Everything is fine'), null);
    assert.strictEqual(extractRefusalPhrase(null), null);
    assert.strictEqual(extractRefusalPhrase(''), null);
  });
});

describe('Property 22: findExpectedSkill', () => {
  it('finds skill for VPS-related messages', () => {
    const messages = ['deploy ke vps', 'nginx config', 'ssh ke server', 'docker compose up'];
    for (const msg of messages) {
      const result = findExpectedSkill(msg);
      if (result) assert.ok(result.score >= 2);
    }
  });

  it('returns null for gibberish with no keyword overlap', () => {
    // Use a truly random string that cannot match any keyword
    assert.strictEqual(findExpectedSkill('zzzqqq999'), null);
    assert.strictEqual(findExpectedSkill(''), null);
    assert.strictEqual(findExpectedSkill(null), null);
  });
});
