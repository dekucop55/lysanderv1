// src/skills/H2.js — Hermes: Cross-chain bridge (LI.FI, Stargate, Across) with intent detection
import { getRoutes, executeBridge } from '../hermes/bridge.js';
import { logger } from '../utils/logger.js';

// ─── Chain aliases ───────────────────────────────────────────────────────────
const CHAIN_ALIASES = {
  eth: 'ethereum', ethereum: 'ethereum', mainnet: 'ethereum',
  base: 'base', arb: 'arbitrum', arbitrum: 'arbitrum',
  op: 'optimism', optimism: 'optimism', poly: 'polygon',
  polygon: 'polygon', bsc: 'bsc', avax: 'avalanche', avalanche: 'avalanche',
};

const TOKEN_ALIASES = {
  eth: 'ETH', usdc: 'USDC', usdt: 'USDT', dai: 'DAI', weth: 'WETH',
  wbtc: 'WBTC', matic: 'MATIC', bnb: 'BNB',
};

/**
 * Detect actionable bridge intent from natural language query.
 * Returns { intent, params } or null for general questions.
 */
function detectBridgeIntent(query) {
  const q = query.trim();

  // Pattern: "bridge <amount> <token> from <chain> to <chain> [wallet <label>]"
  const bridgeMatch = q.match(
    /(?:bridge|kirim|transfer|pindah)\s+([\d.,]+)\s+(\S+)\s+(?:from|dari)\s+(\S+)\s+(?:to|ke)\s+(\S+)(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (bridgeMatch) {
    const amount = parseFloat(bridgeMatch[1].replace(',', '.'));
    const token = resolveToken(bridgeMatch[2]);
    const fromChain = resolveChain(bridgeMatch[3]);
    const toChain = resolveChain(bridgeMatch[4]);
    const wallet = bridgeMatch[5] || null;

    if (!fromChain || !toChain) return null;
    return { intent: 'QUOTE_BRIDGE', params: { amount, token, fromChain, toChain, wallet } };
  }

  // Pattern: "bridge <amount> <token> <chain> → <chain>" (arrow syntax)
  const arrowMatch = q.match(
    /(?:bridge|kirim)\s+([\d.,]+)\s+(\S+)\s+(\S+)\s*(?:→|->|>>)\s*(\S+)(?:\s+(?:wallet)\s+(\S+))?/i
  );
  if (arrowMatch) {
    const amount = parseFloat(arrowMatch[1].replace(',', '.'));
    const token = resolveToken(arrowMatch[2]);
    const fromChain = resolveChain(arrowMatch[3]);
    const toChain = resolveChain(arrowMatch[4]);
    const wallet = arrowMatch[5] || null;

    if (!fromChain || !toChain) return null;
    return { intent: 'QUOTE_BRIDGE', params: { amount, token, fromChain, toChain, wallet } };
  }

  // Pattern: "execute bridge" / "confirm bridge"
  const execMatch = q.match(/(?:execute|confirm|eksekusi|jalankan)\s+bridge/i);
  if (execMatch) {
    return { intent: 'EXECUTE_BRIDGE', params: {} };
  }

  return null;
}

function resolveToken(raw) {
  if (!raw) return null;
  const lower = raw.toLowerCase().replace(/[^a-z0-9]/g, '');
  return TOKEN_ALIASES[lower] || raw.toUpperCase();
}

function resolveChain(raw) {
  if (!raw) return null;
  return CHAIN_ALIASES[raw.toLowerCase()] || null;
}

export default {
  id: 'H2',
  name: 'bridge',
  description: 'Cross-chain bridging via LI.FI, Stargate (LayerZero), Across Protocol',

  async execute(query, context) {
    // 1. Detect actionable bridge command
    const intent = detectBridgeIntent(query);

    if (intent) {
      logger.info(`[H2] Bridge intent detected: ${intent.intent}`, intent.params);

      try {
        switch (intent.intent) {
          case 'QUOTE_BRIDGE': {
            const { amount, token, fromChain, toChain, wallet } = intent.params;

            if (!amount || isNaN(amount) || amount <= 0) {
              return '❌ Amount tidak valid. Contoh: `bridge 1 ETH from ethereum to base wallet main`';
            }

            if (!wallet) {
              return [
                `⚠️ **Wallet belum di-specify.**`,
                ``,
                `Format lengkap: \`bridge ${amount} ${token} from ${fromChain} to ${toChain} wallet <label>\``,
                ``,
                `Gunakan \`list wallets\` untuk lihat wallet tersedia.`,
              ].join('\n');
            }

            const route = await getRoutes({
              fromChain,
              toChain,
              fromToken: token,
              toToken: token,
              amount,
              walletLabel: wallet,
            });

            const estimate = route?.estimate || {};
            return [
              `🌉 **Bridge Quote: ${amount} ${token}**`,
              ``,
              `Route: ${fromChain} → ${toChain}`,
              `Token: ${token}`,
              `Wallet: ${wallet}`,
              estimate.toAmount ? `Expected receive: ~${estimate.toAmount}` : '',
              estimate.executionDuration ? `Estimated time: ~${Math.ceil(estimate.executionDuration / 60)} min` : '',
              estimate.gasCosts ? `Gas cost: ~${estimate.gasCosts}` : '',
              route?.tool ? `Bridge: ${route.tool}` : '',
              ``,
              `🔐 Untuk eksekusi: \`/bridgeconfirm\``,
              `⚠️ Pastikan ada cukup gas di ${fromChain} untuk tx fee.`,
            ].filter(Boolean).join('\n');
          }

          case 'EXECUTE_BRIDGE': {
            return [
              `🔐 **Bridge Execution memerlukan konfirmasi eksplisit.**`,
              ``,
              `Untuk keamanan, bridge dilakukan via \`/bridgeconfirm\`.`,
              `Governor authorization diperlukan sebelum broadcast.`,
              ``,
              `Langkah:`,
              `1. Quote dulu: \`bridge <amount> <token> from <chain> to <chain> wallet <label>\``,
              `2. Review route & fee`,
              `3. Confirm: \`/bridgeconfirm\``,
            ].join('\n');
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[H2] Bridge operation failed: ${err.message}`);
        return `❌ Bridge gagal: ${err.message}`;
      }
    }

    // 2. Fallback: general bridge question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H2 (Bridge).
Mode: methodical, risk-aware.

Kamu menjawab pertanyaan tentang cross-chain bridging:
- Cara kerja bridge (lock-and-mint, burn-and-release, liquidity pools)
- Perbandingan bridge protocols (LI.FI, Stargate, Across, Hop, Synapse)
- Best practices: fee optimization, speed vs cost, security considerations
- Troubleshooting: stuck tx, failed bridge, refund process
- Chain compatibility dan supported tokens

Untuk EXECUTE bridge, user harus pakai format:
  bridge <amount> <token> from <chain> to <chain> wallet <label>

Supported chains: ethereum, base, arbitrum, optimism, polygon, bsc, avalanche
Provider: LI.FI (aggregates Stargate, Across, Hop, dll)

Safety:
- Governor gate aktif
- Slippage check
- Estimated arrival time disertakan
- Fee breakdown (bridge fee + gas)`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H2] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan bridge: ${err.message}`;
    }
  },
};
