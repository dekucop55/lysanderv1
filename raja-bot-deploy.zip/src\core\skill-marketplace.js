// src/core/skill-marketplace.js — Paranoid download-quarantine-audit-activate pipeline
import { createHash } from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import { generateManifest } from './skill-integrity.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const QUARANTINE_DIR = path.join(__dirname, '..', 'skills', '_quarantine');
const SKILLS_DIR = path.join(__dirname, '..', 'skills');
const MANIFEST_PATH = path.join(QUARANTINE_DIR, 'manifest.json');

/**
 * Ensure quarantine directory and manifest exist.
 */
function ensureQuarantineDir() {
  if (!fs.existsSync(QUARANTINE_DIR)) {
    fs.mkdirSync(QUARANTINE_DIR, { recursive: true });
  }
  if (!fs.existsSync(MANIFEST_PATH)) {
    fs.writeFileSync(MANIFEST_PATH, JSON.stringify({ skills: {} }, null, 2));
  }
}

/**
 * Read the quarantine manifest.
 */
function readManifest() {
  ensureQuarantineDir();
  try {
    return JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
  } catch {
    return { skills: {} };
  }
}

/**
 * Write the quarantine manifest.
 */
function writeManifest(manifest) {
  ensureQuarantineDir();
  fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2));
}

/**
 * Download a skill from a URL into the quarantine directory.
 * Validates the URL host against config.marketplace.allowedHosts,
 * downloads with axios + timeout, saves to _quarantine/, computes SHA-256,
 * and writes to manifest with status='pending'.
 *
 * @param {string} url - The URL to download the skill from.
 * @returns {Promise<string>} The filename of the downloaded skill.
 */
export async function downloadSkill(url) {
  const parsed = new URL(url);
  const allowedHosts = config.marketplace.allowedHosts;

  if (!allowedHosts.includes(parsed.hostname)) {
    throw new Error(`Host "${parsed.hostname}" is not in allowed hosts: ${allowedHosts.join(', ')}`);
  }

  ensureQuarantineDir();

  const filename = path.basename(parsed.pathname);
  if (!filename || !filename.endsWith('.js')) {
    throw new Error(`Invalid skill filename from URL: "${filename}". Must end with .js`);
  }

  const filePath = path.join(QUARANTINE_DIR, filename);

  let response;
  try {
    response = await axios.get(url, {
      timeout: config.marketplace.downloadTimeout,
      responseType: 'text',
    });
  } catch (err) {
    // Clean up any partial file
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    throw new Error(`Download failed: ${err.message}`);
  }

  const content = response.data;
  fs.writeFileSync(filePath, content, 'utf8');

  // Compute SHA-256 hash
  const hash = createHash('sha256').update(content).digest('hex');

  // Write to manifest
  const manifest = readManifest();
  manifest.skills[filename] = {
    hash,
    downloadedAt: new Date().toISOString(),
    sourceUrl: url,
    status: 'pending',
    violations: [],
    auditedAt: null,
  };
  writeManifest(manifest);

  logger.info(`[marketplace] Downloaded skill "${filename}" to quarantine (SHA-256: ${hash.slice(0, 12)}...)`);
  return filename;
}

/**
 * Scan a JavaScript source string for disallowed patterns.
 * Returns an array of violation descriptions (empty = clean).
 *
 * @param {string} source - The JavaScript source code to scan.
 * @returns {string[]} Array of violation descriptions.
 */
export function isDisallowedPattern(source) {
  const violations = [];

  // Check for child_process import/require
  if (/require\s*\(\s*['"`]child_process['"`]\s*\)/.test(source) ||
      /from\s+['"`]child_process['"`]/.test(source) ||
      /import\s+['"`]child_process['"`]/.test(source)) {
    violations.push('Disallowed: child_process import/require detected');
  }

  // Check for eval usage
  if (/\beval\s*\(/.test(source)) {
    violations.push('Disallowed: eval() usage detected');
  }

  // Check for new Function constructor
  if (/new\s+Function\s*\(/.test(source)) {
    violations.push('Disallowed: new Function() constructor detected');
  }

  // Check for process.env direct access
  if (/process\.env\b/.test(source)) {
    violations.push('Disallowed: process.env direct access detected');
  }

  return violations;
}

/**
 * Audit a quarantined skill file.
 * Reads the file, checks valid JS syntax (via new Function wrapping without executing),
 * runs isDisallowedPattern, and updates manifest status to 'approved' or 'blocked'.
 *
 * @param {string} filename - The filename of the quarantined skill.
 * @returns {Promise<{status: string, violations: string[]}>} The audit result.
 */
export async function auditSkill(filename) {
  ensureQuarantineDir();

  const filePath = path.join(QUARANTINE_DIR, filename);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Quarantined skill not found: "${filename}"`);
  }

  const source = fs.readFileSync(filePath, 'utf8');
  const violations = [];

  // Check valid JavaScript syntax (without executing)
  try {
    new Function(source);
  } catch (syntaxErr) {
    violations.push(`Invalid JavaScript syntax: ${syntaxErr.message}`);
  }

  // Run disallowed pattern scan
  const patternViolations = isDisallowedPattern(source);
  violations.push(...patternViolations);

  // Determine status
  const status = violations.length === 0 ? 'approved' : 'blocked';

  // Update manifest
  const manifest = readManifest();
  if (manifest.skills[filename]) {
    manifest.skills[filename].status = status;
    manifest.skills[filename].violations = violations;
    manifest.skills[filename].auditedAt = new Date().toISOString();
  }
  writeManifest(manifest);

  logger.info(`[marketplace] Audit "${filename}": ${status} (${violations.length} violation(s))`);
  return { status, violations };
}

/**
 * Activate an approved quarantined skill.
 * Verifies manifest status is 'approved', moves file from quarantine to active skills dir,
 * and regenerates SKILLS.lock hash for the new file.
 *
 * @param {string} filename - The filename of the skill to activate.
 * @returns {Promise<{success: boolean, message: string}>} Result of activation.
 */
export async function activateSkill(filename) {
  const manifest = readManifest();
  const entry = manifest.skills[filename];

  if (!entry) {
    return { success: false, message: `Skill "${filename}" not found in quarantine manifest` };
  }

  if (entry.status !== 'approved') {
    return { success: false, message: `Skill "${filename}" status is "${entry.status}", must be "approved" to activate` };
  }

  const sourcePath = path.join(QUARANTINE_DIR, filename);
  const destPath = path.join(SKILLS_DIR, filename);

  if (!fs.existsSync(sourcePath)) {
    return { success: false, message: `Quarantined file "${filename}" not found on disk` };
  }

  try {
    // Move file from quarantine to active skills directory
    fs.copyFileSync(sourcePath, destPath);
    fs.unlinkSync(sourcePath);

    // Remove from quarantine manifest
    delete manifest.skills[filename];
    writeManifest(manifest);

    // Regenerate SKILLS.lock with the new file included
    await generateManifest();

    logger.info(`[marketplace] Activated skill "${filename}" → moved to active skills`);
    return { success: true, message: `Skill "${filename}" activated successfully` };
  } catch (err) {
    logger.error(`[marketplace] Activation failed for "${filename}": ${err.message}`);
    return { success: false, message: `Activation failed: ${err.message}` };
  }
}

/**
 * Get the current quarantine status by reading manifest.json.
 *
 * @returns {{total: number, pending: number, approved: number, blocked: number, skills: object}} Summary object.
 */
export function getQuarantineStatus() {
  const manifest = readManifest();
  const skills = manifest.skills || {};
  const entries = Object.entries(skills);

  const summary = {
    total: entries.length,
    pending: 0,
    approved: 0,
    blocked: 0,
    skills,
  };

  for (const [, entry] of entries) {
    if (entry.status === 'pending') summary.pending++;
    else if (entry.status === 'approved') summary.approved++;
    else if (entry.status === 'blocked') summary.blocked++;
  }

  return summary;
}
