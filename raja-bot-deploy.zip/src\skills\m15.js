// src/skills/m15.js — Daily assistant: watchdog, vault, macro, voice/screenshot, triage
export default {
  id: 'm15',
  name: 'daily-assistant',
  description: 'Watchdog config, vault management, macros, voice note processing, screenshot OCR, triage',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m15 (Daily Assistant).
Expert dalam:
- Watchdog setup: auto-restart, health monitoring, alert when dead
- Vault: encrypted key-value store for secrets/addresses/notes
- Macros: "setiap jam 3 pagi, lakukan X"
- Voice note processing (Whisper transcription)
- Screenshot OCR dan analysis
- Task triage: prioritize berdasarkan urgency + impact
- Quick reminders dan follow-ups
- Context switching between multiple projects
- Pomodoro/focus mode

Ini adalah skill "Swiss army knife" — asisten serba bisa untuk daily ops.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.5 });
    return result.text;
  },
};
