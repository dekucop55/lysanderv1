// src/telegram/middleware.js — Auth, rate limiting, and sanitization
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

// Rate limit state: userId → { count, windowStart }
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX = parseInt(process.env.RATE_LIMIT_MAX || '30');

export function isAuthorized(userId) {
  return userId === config.telegram.allowedUserId;
}

export function rateLimit(userId) {
  const now = Date.now();
  let state = rateLimitMap.get(userId);

  if (!state || now - state.windowStart > RATE_LIMIT_WINDOW_MS) {
    state = { count: 1, windowStart: now };
    rateLimitMap.set(userId, state);
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }

  state.count++;
  rateLimitMap.set(userId, state);

  const remaining = Math.max(0, RATE_LIMIT_MAX - state.count);
  const allowed = state.count <= RATE_LIMIT_MAX;
  return { allowed, remaining };
}

/**
 * Sanitize user input — strip control chars, limit length
 */
export function sanitizeInput(text) {
  if (!text) return '';
  return text
    .replace(/[\x00-\x1F\x7F]/g, ' ') // control chars → space
    .trim()
    .substring(0, 4096); // Telegram max message length
}

/**
 * Check middleware for all incoming messages
 * Returns { ok, reason } — bot.js decides whether to proceed
 */
export function checkMessage(msg) {
  const userId = msg?.from?.id;

  if (!userId) {
    return { ok: false, reason: 'no_user' };
  }

  if (!isAuthorized(userId)) {
    logger.warn(`[auth] Unauthorized access from userId=${userId}`);
    return { ok: false, reason: 'unauthorized' };
  }

  const rl = rateLimit(userId);
  if (!rl.allowed) {
    logger.warn(`[ratelimit] userId=${userId} exceeded rate limit`);
    return { ok: false, reason: 'rate_limited' };
  }

  return { ok: true, remaining: rl.remaining };
}

// Cleanup stale rate limit entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [userId, state] of rateLimitMap) {
    if (now - state.windowStart > RATE_LIMIT_WINDOW_MS * 2) {
      rateLimitMap.delete(userId);
    }
  }
}, 5 * 60 * 1000);
