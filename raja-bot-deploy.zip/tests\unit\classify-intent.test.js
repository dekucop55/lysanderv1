// tests/unit/classify-intent.test.js
//
// Unit tests for classifyIntent() (Task 5.1)
// Validates: Requirements 1.1, 1.3, 1.4

import { describe, it, expect, beforeEach } from 'vitest';
import { classifyIntent, EXECUTE_KEYWORDS, ActivePlanManager, planManager } from '../../src/core/brain.js';

describe('classifyIntent', () => {
  const sessionId = 'test-session-1';

  beforeEach(() => {
    // Clear all plans from planManager between tests
    planManager.sessions.clear();
  });

  describe('EXECUTE_KEYWORDS set', () => {
    it('should contain all specified execute keywords', () => {
      const expected = ['eksekusi', 'lakukan', 'jalankan', 'run', 'go', 'send it', 'execute', 'do it', 'gas', 'ok gas'];
      for (const kw of expected) {
        expect(EXECUTE_KEYWORDS.has(kw)).toBe(true);
      }
    });

    it('should be exported as a Set', () => {
      expect(EXECUTE_KEYWORDS).toBeInstanceOf(Set);
    });
  });

  describe('CONFIRM — agreement phrases', () => {
    it('should return CONFIRM for "ok"', () => {
      expect(classifyIntent('ok', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "oke"', () => {
      expect(classifyIntent('oke', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "setuju"', () => {
      expect(classifyIntent('setuju', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "yes"', () => {
      expect(classifyIntent('yes', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "deal"', () => {
      expect(classifyIntent('deal', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "sip"', () => {
      expect(classifyIntent('sip', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "lanjut"', () => {
      expect(classifyIntent('lanjut', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "gas" (agreement phrase takes priority)', () => {
      // "gas" is both AGREEMENT_PHRASES and EXECUTE_KEYWORDS
      // but isAgreementPhrase checks exact match first → CONFIRM
      expect(classifyIntent('gas', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "yoi"', () => {
      expect(classifyIntent('yoi', { id: sessionId })).toBe('CONFIRM');
    });

    it('should return CONFIRM for "mantap"', () => {
      expect(classifyIntent('mantap', { id: sessionId })).toBe('CONFIRM');
    });

    it('should be case-insensitive', () => {
      expect(classifyIntent('OK', { id: sessionId })).toBe('CONFIRM');
      expect(classifyIntent('SETUJU', { id: sessionId })).toBe('CONFIRM');
      expect(classifyIntent('Yes', { id: sessionId })).toBe('CONFIRM');
    });

    it('should handle whitespace', () => {
      expect(classifyIntent('  ok  ', { id: sessionId })).toBe('CONFIRM');
      expect(classifyIntent('\tyes\n', { id: sessionId })).toBe('CONFIRM');
    });
  });

  describe('EXECUTE — short command + exec keyword + active plan', () => {
    beforeEach(() => {
      // Set up an active plan
      planManager.setPlan(sessionId, {
        planId: 'plan-1',
        skillId: 'm2',
        description: 'Deploy bot',
        status: 'agreed',
      });
    });

    it('should return EXECUTE for "eksekusi" with active plan', () => {
      expect(classifyIntent('eksekusi', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for "jalankan sekarang" with active plan (2 words)', () => {
      expect(classifyIntent('jalankan sekarang', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for "run it now" with active plan (3 words)', () => {
      expect(classifyIntent('run it now', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for "lakukan sekarang bos" with active plan (3 words)', () => {
      expect(classifyIntent('lakukan sekarang bos', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for 5-word command with keyword + plan', () => {
      expect(classifyIntent('tolong jalankan rencana itu bos', { id: sessionId })).toBe('EXECUTE');
    });

    it('should NOT return EXECUTE for short command with exec keyword but NO active plan', () => {
      planManager.sessions.clear();
      // "eksekusi" alone without active plan: it's also a single word with exec keyword
      // but no active plan → hasExecKeyword is true → still returns EXECUTE (longer command rule)
      // Wait - "eksekusi" is 1 word, isShortCommand = true, hasExecKeyword = true, but activePlan = null
      // So first EXECUTE rule fails. Then it falls to: hasExecKeyword || containsActionVerb → EXECUTE
      expect(classifyIntent('eksekusi', { id: sessionId })).toBe('EXECUTE');
    });
  });

  describe('EXECUTE — longer command with exec keyword or action verb', () => {
    it('should return EXECUTE for longer message with exec keyword', () => {
      expect(classifyIntent('bisa tolong jalankan script backup database di server sekarang juga', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with "execute" keyword', () => {
      expect(classifyIntent('please execute the deployment script now', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "swap"', () => {
      expect(classifyIntent('swap ETH ke USDC di mainnet', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "deploy"', () => {
      expect(classifyIntent('deploy versi baru ke production server', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "transfer"', () => {
      expect(classifyIntent('transfer 100 USDC ke wallet gue', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "hapus"', () => {
      expect(classifyIntent('hapus semua file log yang lama', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "buat"', () => {
      expect(classifyIntent('buat skill baru untuk monitoring gas fee', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "monitor"', () => {
      expect(classifyIntent('monitor harga ETH setiap 5 menit', { id: sessionId })).toBe('EXECUTE');
    });

    it('should return EXECUTE for message with action verb "bridge"', () => {
      expect(classifyIntent('bridge 0.5 ETH dari Arbitrum ke Base', { id: sessionId })).toBe('EXECUTE');
    });
  });

  describe('CHAT — no keywords or action verbs', () => {
    it('should return CHAT for a simple question', () => {
      expect(classifyIntent('apa itu blockchain?', { id: sessionId })).toBe('CHAT');
    });

    it('should return CHAT for casual greeting', () => {
      expect(classifyIntent('halo raja apa kabar', { id: sessionId })).toBe('CHAT');
    });

    it('should return CHAT for informational query', () => {
      expect(classifyIntent('berapa harga bitcoin sekarang?', { id: sessionId })).toBe('CHAT');
    });

    it('should return CHAT for vague message without keywords', () => {
      expect(classifyIntent('gimana pendapat lo soal market hari ini?', { id: sessionId })).toBe('CHAT');
    });

    it('should return CHAT for empty-ish message', () => {
      expect(classifyIntent('hmm', { id: sessionId })).toBe('CHAT');
    });
  });

  describe('edge cases', () => {
    it('should handle empty string (returns CHAT)', () => {
      expect(classifyIntent('', { id: sessionId })).toBe('CHAT');
    });

    it('should handle whitespace-only message (returns CHAT)', () => {
      expect(classifyIntent('   ', { id: sessionId })).toBe('CHAT');
    });

    it('should be case-insensitive for keywords', () => {
      expect(classifyIntent('EKSEKUSI', { id: sessionId })).toBe('EXECUTE');
      expect(classifyIntent('RUN', { id: sessionId })).toBe('EXECUTE');
      expect(classifyIntent('Execute this', { id: sessionId })).toBe('EXECUTE');
    });

    it('should handle "gas" as CONFIRM (single word = agreement phrase)', () => {
      // "gas" is in both AGREEMENT_PHRASES and EXECUTE_KEYWORDS
      // isAgreementPhrase checks first → CONFIRM
      expect(classifyIntent('gas', { id: sessionId })).toBe('CONFIRM');
    });

    it('should handle "gas" within a longer sentence as EXECUTE', () => {
      // "ok gas kirim sekarang" → not an exact agreement phrase match
      expect(classifyIntent('ok gas kirim sekarang', { id: sessionId })).toBe('EXECUTE');
    });
  });
});
