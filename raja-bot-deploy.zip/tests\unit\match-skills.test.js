// tests/unit/match-skills.test.js — Unit tests for matchSkills()
import { describe, it, expect } from 'vitest';
import { matchSkills, SKILL_KEYWORDS } from '../../src/core/skill-registry.js';

describe('matchSkills', () => {
  it('should return empty array for empty or invalid input', () => {
    expect(matchSkills('')).toEqual([]);
    expect(matchSkills(null)).toEqual([]);
    expect(matchSkills(undefined)).toEqual([]);
    expect(matchSkills('   ')).toEqual([]);
  });

  it('should return SkillMatch objects with correct shape', () => {
    const results = matchSkills('swap token');
    expect(results.length).toBeGreaterThan(0);

    const match = results[0];
    expect(match).toHaveProperty('skillId');
    expect(match).toHaveProperty('score');
    expect(match).toHaveProperty('maxTheoreticalScore');
    expect(match).toHaveProperty('description');
    expect(typeof match.skillId).toBe('string');
    expect(typeof match.score).toBe('number');
    expect(typeof match.maxTheoreticalScore).toBe('number');
    expect(typeof match.description).toBe('string');
  });

  it('should sort results by score descending', () => {
    const results = matchSkills('deploy contract on vps server');
    expect(results.length).toBeGreaterThan(1);

    for (let i = 1; i < results.length; i++) {
      expect(results[i - 1].score).toBeGreaterThanOrEqual(results[i].score);
    }
  });

  it('should score higher for primary keywords (weight 3)', () => {
    // "swap" is weight 3 for H1
    const results = matchSkills('swap');
    const h1 = results.find(r => r.skillId === 'H1');
    expect(h1).toBeDefined();
    expect(h1.score).toBe(3); // 1 occurrence × weight 3
  });

  it('should accumulate score for multiple keyword occurrences', () => {
    // "swap dex swap" => for H1: swap(3)×2 + dex(2)×1 = 8
    const results = matchSkills('swap dex swap');
    const h1 = results.find(r => r.skillId === 'H1');
    expect(h1).toBeDefined();
    expect(h1.score).toBe(3 * 2 + 2 * 1); // swap(3)×2 + dex(2)×1 = 8
  });

  it('should handle multi-word keywords', () => {
    // "telegram bot" is weight 3 for m4
    const results = matchSkills('buat telegram bot baru');
    const m4 = results.find(r => r.skillId === 'm4');
    expect(m4).toBeDefined();
    expect(m4.score).toBeGreaterThanOrEqual(3); // At least "telegram bot" matched
  });

  it('should be case-insensitive', () => {
    const lower = matchSkills('swap token');
    const upper = matchSkills('SWAP TOKEN');
    const mixed = matchSkills('Swap Token');

    expect(lower).toEqual(upper);
    expect(lower).toEqual(mixed);
  });

  it('should not return skills with score 0', () => {
    // Use a very unrelated input
    const results = matchSkills('zzzzz xxxxx yyyyy');
    expect(results.length).toBe(0);
  });

  it('should compute maxTheoreticalScore correctly', () => {
    // For H1 (swap): keywords are swap:3, 1inch:3, jupiter:3, jual token:3, sell:3, dex:2, slippage:2, aggregator:2
    // maxTheoreticalScore = sum(weight × 3) = (3+3+3+3+3+2+2+2) × 3 = 21 × 3 = 63
    const results = matchSkills('swap');
    const h1 = results.find(r => r.skillId === 'H1');
    expect(h1).toBeDefined();

    // Verify against manual calculation from SKILL_KEYWORDS
    const h1Keywords = SKILL_KEYWORDS['H1'].weight;
    const expectedMax = Object.values(h1Keywords).reduce((sum, w) => sum + w * 3, 0);
    expect(h1.maxTheoreticalScore).toBe(expectedMax);
  });

  it('should match m10 (web3) for wallet-related queries', () => {
    const results = matchSkills('cek balance wallet eth');
    const m10 = results.find(r => r.skillId === 'm10');
    expect(m10).toBeDefined();
    expect(m10.score).toBeGreaterThan(0);
  });

  it('should match m11 (security) for audit queries', () => {
    const results = matchSkills('audit security vulnerability');
    const m11 = results.find(r => r.skillId === 'm11');
    expect(m11).toBeDefined();
    // audit:3 + security:2 + vulnerability:3 = 8
    expect(m11.score).toBe(8);
  });

  it('should handle overlapping keywords across skills', () => {
    // "deploy" appears in m2 (vps-deploy, weight 3) and "deploy kontrak" in H10
    // "solidity" is a single keyword in H10 (weight 2)
    const results = matchSkills('deploy solidity');
    const m2 = results.find(r => r.skillId === 'm2');
    const h10 = results.find(r => r.skillId === 'H10');
    expect(m2).toBeDefined();
    expect(h10).toBeDefined();
  });

  it('should score deterministically for same input', () => {
    const results1 = matchSkills('bridge cross-chain stargate');
    const results2 = matchSkills('bridge cross-chain stargate');
    expect(results1).toEqual(results2);
  });

  it('should include description in results', () => {
    const results = matchSkills('swap');
    const h1 = results.find(r => r.skillId === 'H1');
    expect(h1).toBeDefined();
    expect(h1.description.length).toBeGreaterThan(0);
  });
});
