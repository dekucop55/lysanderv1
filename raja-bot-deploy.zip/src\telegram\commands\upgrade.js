// src/telegram/commands/upgrade.js — SELF-UPGRADE COMMAND (MOST CRITICAL)
import { performUpgrade, gitStatus, rollback } from '../../self-upgrade/upgrade.js';
import { logger } from '../../utils/logger.js';

export async function cmdUpgrade(bot, msg) {
  const chatId = msg.chat.id;
  
  await bot.sendMessage(chatId, '🔄 *Self-upgrade dimulai...*\n\n1. Backup state\n2. Git pull\n3. Install deps\n4. Restart\n5. Health check\n6. Rollback kalau gagal', { parse_mode: 'Markdown' });
  
  try {
    const result = await performUpgrade({
      onProgress: async (step, status) => {
        await bot.sendMessage(chatId, `${status} ${step}`).catch(() => {});
      },
    });
    
    if (result.success) {
      await bot.sendMessage(chatId, 
        `✅ *Upgrade sukses*\n\n` +
        `• Version: ${result.oldVersion} → ${result.newVersion}\n` +
        `• Commits: ${result.commitsPulled}\n` +
        `• Files changed: ${result.filesChanged}\n` +
        `• Restart time: ${result.restartMs}ms\n` +
        `• Health: OK\n\n` +
        `Bot udah restart dengan kode baru. Honoring.`,
        { parse_mode: 'Markdown' }
      );
    } else {
      await bot.sendMessage(chatId,
        `❌ *Upgrade gagal, ROLLBACK dilakukan*\n\n` +
        `Error: ${result.error}\n\n` +
        `Bot balik ke versi sebelumnya (${result.oldVersion}). Aman.`,
        { parse_mode: 'Markdown' }
      );
    }
  } catch (err) {
    logger.error(`Upgrade error: ${err.message}`);
    await bot.sendMessage(chatId, `❌ Upgrade error: ${err.message}`);
  }
}

export async function cmdGitStatus(bot, msg) {
  const chatId = msg.chat.id;
  try {
    const status = await gitStatus();
    await bot.sendMessage(chatId,
      `📊 *Git status*\n\n` +
      `• Branch: ${status.branch}\n` +
      `• Commit: \`${status.commit.substring(0, 8)}\`\n` +
      `• Remote: ${status.remote}\n` +
      `• Behind: ${status.behind} commits\n` +
      `• Local changes: ${status.localChanges}\n` +
      `• Last commit: ${status.lastCommitMsg}`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Git error: ${err.message}`);
  }
}

export async function cmdRollback(bot, msg, target) {
  const chatId = msg.chat.id;
  await bot.sendMessage(chatId, '⏪ Rollback...');
  try {
    const result = await rollback(target || 'HEAD@{1}');
    await bot.sendMessage(chatId, `✅ Rollback ke ${result.target}\nBot restart.`);
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Rollback gagal: ${err.message}`);
  }
}