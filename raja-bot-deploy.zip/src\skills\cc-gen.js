// src/skills/cc-gen.js — CC Generator (BIN-based, Luhn-valid) for testing/dev gates
// Programmatic — does NOT go through LLM. Direct execution.

/**
 * Luhn algorithm to compute check digit
 */
function luhnCheckDigit(partialNumber) {
  const digits = partialNumber.split('').map(Number);
  let sum = 0;
  let alternate = true; // start from rightmost, alternate

  for (let i = digits.length - 1; i >= 0; i--) {
    let n = digits[i];
    if (alternate) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    alternate = !alternate;
  }

  return (10 - (sum % 10)) % 10;
}

/**
 * Generate random digits string of given length
 */
function randomDigits(len) {
  let s = '';
  for (let i = 0; i < len; i++) {
    s += Math.floor(Math.random() * 10).toString();
  }
  return s;
}

/**
 * Generate a single Luhn-valid CC number from BIN
 */
function generateCC(bin, length = 16) {
  const binStr = bin.toString().replace(/\D/g, '');
  const remaining = length - binStr.length - 1; // -1 for check digit
  const partial = binStr + randomDigits(remaining);
  const checkDigit = luhnCheckDigit(partial);
  return partial + checkDigit.toString();
}

/**
 * Generate expiry date (random future date)
 */
function generateExpiry() {
  const now = new Date();
  const month = Math.floor(Math.random() * 12) + 1;
  const year = now.getFullYear() + Math.floor(Math.random() * 5) + 1;
  return `${month.toString().padStart(2, '0')}/${year.toString().slice(-2)}`;
}

/**
 * Generate CVV
 */
function generateCVV(isAmex = false) {
  return randomDigits(isAmex ? 4 : 3);
}

/**
 * Detect intent from user query
 */
function detectCCIntent(query) {
  const lower = query.toLowerCase().trim();

  // Pattern: "generate cc", "gen cc", "bikin cc", "cc generator"
  const genPatterns = [
    /(?:generate|gen|bikin|buat|create)\s+(?:cc|kartu|card)/i,
    /^cc\s*(?:gen|generator|generate)?$/i,
    /(?:cc|kartu kredit|credit card)\s+(?:gen|generate|bikin|buat)/i,
  ];

  if (!genPatterns.some(p => p.test(lower))) return null;

  // Extract BIN if provided
  const binMatch = query.match(/(?:bin|BIN)[:\s]*(\d{4,8})/i) || query.match(/(\d{6,8})/);
  const bin = binMatch ? binMatch[1] : '411111'; // Default: Visa test BIN

  // Extract count
  const countMatch = query.match(/(\d+)\s*(?:buah|pcs|kartu|card|cc|biji)/i) || query.match(/(?:x|×)\s*(\d+)/i);
  const count = countMatch ? Math.min(parseInt(countMatch[1]), 25) : 5; // Max 25

  // Detect if Amex (BIN starts with 34 or 37)
  const isAmex = bin.startsWith('34') || bin.startsWith('37');
  const length = isAmex ? 15 : 16;

  return { bin, count, isAmex, length };
}

/**
 * Format CC list for display
 */
function formatCCList(cards) {
  const header = `🃏 **CC Generated (Luhn-valid)**\n\n`;
  const lines = cards.map((c, i) =>
    `${i + 1}. \`${c.number}\` | ${c.expiry} | ${c.cvv}`
  );
  const footer = `\n\n⚠️ Testing/dev only. Luhn-valid tapi bukan kartu real.`;
  return header + lines.join('\n') + footer;
}

export default {
  id: 'cc-gen',
  name: 'cc-generator',
  description: 'BIN-based CC generator (Luhn-valid) for testing and dev gates',
  keywords: { 'generate cc': 3, 'gen cc': 3, 'bikin cc': 3, 'cc gen': 3, 'cc generator': 3, 'kartu kredit': 2, 'credit card': 2, 'luhn': 3, 'bin': 2 },

  async execute(query, context) {
    const intent = detectCCIntent(query);

    if (!intent) {
      // Fallback ke LLM kalau bukan generate request
      const { callCascade } = await import('../llm/cascade.js');
      const messages = [
        { role: 'system', content: 'Kamu RAJA. Bantu soal CC generation untuk testing. Jelaskan Luhn algorithm, BIN structure, atau cara testing payment gateway.' },
        { role: 'user', content: query },
      ];
      const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.5 });
      return result.text;
    }

    const { bin, count, isAmex, length } = intent;
    const cards = [];

    for (let i = 0; i < count; i++) {
      cards.push({
        number: generateCC(bin, length),
        expiry: generateExpiry(),
        cvv: generateCVV(isAmex),
      });
    }

    return formatCCList(cards);
  },
};
