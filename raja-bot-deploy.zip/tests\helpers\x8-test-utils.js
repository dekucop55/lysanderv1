/**
 * Shared mock factories for x8 (Self-Diagnostic-Repair) tests.
 * Pure JavaScript, no external dependencies. ESM exports.
 */

/**
 * Creates a mock SkillFailure object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').SkillFailure}
 */
export function createMockSkillFailure(overrides = {}) {
  return {
    file: 'x-broken.js',
    error: 'SyntaxError: Unexpected token',
    stackTrace: 'SyntaxError: Unexpected token\n    at x-broken.js:10:5',
    errorType: 'syntax_error',
    importPath: undefined,
    packageName: undefined,
    ...overrides,
  };
}

/**
 * Creates a mock CheckResult object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').CheckResult}
 */
export function createMockCheckResult(overrides = {}) {
  return {
    status: 'pass',
    category: 'skills',
    summary: 'All checks passed',
    details: [],
    score: 100,
    ...overrides,
  };
}

/**
 * Creates a mock RepairAction object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').RepairAction}
 */
export function createMockRepairAction(overrides = {}) {
  return {
    type: 'reload_skill',
    target: 'src/skills/x-broken.js',
    classification: 'safe',
    beforeState: 'Module cache stale',
    afterState: 'Module reloaded successfully',
    success: true,
    error: undefined,
    fixDescription: undefined,
    backupId: undefined,
    rolledBack: false,
    ...overrides,
  };
}

/**
 * Creates a mock BehavioralMisroute object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').BehavioralMisroute}
 */
export function createMockBehavioralMisroute(overrides = {}) {
  return {
    userMessage: 'tolong akses file di server',
    expectedSkill: 'm2',
    expectedSkillName: 'vps-shell',
    refusalResponse: 'Saya tidak bisa mengakses file secara langsung sebagai AI.',
    refusalPattern: 'saya tidak bisa',
    routeScore: 1,
    timestamp: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Creates a mock RoutingFixResult object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').RoutingFixResult}
 */
export function createMockRoutingFixResult(overrides = {}) {
  return {
    success: true,
    skill: 'm2',
    skillName: 'vps-shell',
    addedKeywords: [
      { keyword: 'akses file', weight: 3 },
      { keyword: 'file server', weight: 2 },
    ],
    beforeScore: 1,
    afterScore: 4,
    verified: true,
    rolledBack: false,
    error: undefined,
    backupId: 'backup-routing-001',
    conflicts: [],
    ...overrides,
  };
}

/**
 * Creates a mock PromptEnhanceResult object with sensible defaults.
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').PromptEnhanceResult}
 */
export function createMockPromptEnhanceResult(overrides = {}) {
  return {
    success: true,
    capability: 'file access via VPS shell',
    statement: 'Kamu BISA akses file di VPS via skill m2 — gunakan m2 untuk operasi file/shell',
    insertionPoint: 'CAPABILITY AWARENESS',
    skillId: 'm2',
    verified: true,
    rolledBack: false,
    skippedDuplicate: false,
    backupId: 'backup-brain-001',
    error: undefined,
    ...overrides,
  };
}

/**
 * Creates a mock DiagnosticReport object with sensible defaults.
 * All arrays default to empty, healthScore defaults to 100 (healthy).
 * @param {Object} [overrides] - Fields to override
 * @returns {import('../../src/skills/x8.js').DiagnosticReport}
 */
export function createMockDiagnosticReport(overrides = {}) {
  return {
    timestamp: new Date().toISOString(),
    healthScore: 100,
    checks: [],
    repairsApplied: [],
    manualRequired: [],
    codeRepairs: [],
    packageInstalls: [],
    importFixes: [],
    behavioralMisroutes: [],
    routingFixes: [],
    promptEnhancements: [],
    ...overrides,
  };
}
