// src/skills/m7.js — LLM management, multi-provider, model registry, prompt engineering
export default {
  id: 'm7',
  name: 'llm',
  description: 'LLM management, model registry, prompt engineering, provider cascade, agent patterns',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m7 (LLM/AI).
Expert dalam:
- Prompt engineering (system prompts, few-shot, chain-of-thought)
- Multi-provider LLM cascade: Ollama, OpenRouter, b.ai, Anthropic, OpenAI
- Model comparison: Kimi K2, Gemma, Llama, Qwen, DeepSeek
- RAG (Retrieval-Augmented Generation) patterns
- Function calling / tool use
- Agent architecture (ReAct, Plan-and-Execute)
- Token budgeting dan context management
- Streaming responses
- Embedding dan vector similarity
- Fine-tuning strategy
- Lokal LLM setup (Ollama, llama.cpp)

Untuk "tambah model" / "add model": berikan instruksi untuk update .env dan cascade config.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.5 });
    return result.text;
  },
};
