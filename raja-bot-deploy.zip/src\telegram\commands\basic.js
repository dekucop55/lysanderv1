// src/telegram/commands/basic.js — /start, /help, /status, /skill, /memory
import { config } from '../../config.js';
import { logger } from '../../utils/logger.js';
import { getRecent } from '../../core/memory.js';
import { routeSkill } from '../../core/skill-registry.js';

// Lazy import to avoid circular dependency (brain → bot → basic → brain)
async function getSessionSafe() {
  const { getSession } = await import('../../core/brain.js');
  return getSession();
}

const HELP_TEXT = `*RAJA v4.0 — Lysander Phoebe*

*🤖 Autonomous Update (FITUR UTAMA)*
/code <instruksi> — Generate kode baru/modifikasi
/coderun — Eksekusi plan yang pending
/codecancel — Batalkan plan
/codenow <instruksi> — Generate + eksekusi langsung
/codeview <file> — Lihat isi file
/codelist — List file source

*⚙️ System*
/start — Wake up
/help — Daftar perintah
/status — Session & provider status
/upgrade — Self-upgrade dari git
/restart — Restart bot
/logs [n] — Lihat log terbaru
/health — Healthcheck
/rollback — Rollback ke versi sebelumnya
/git — Git status

*🧠 Memory & Skills*
/memory — Recall recent memory
/skill <query> — Test routing skill

*₿ Crypto (Hermes)*
/wallet [label] — Manage wallet
/balance [label] — Cek balance
/swap <args> — Swap token (quote dulu)
/swapconfirm <args> — Konfirmasi & eksekusi swap
/mint <args> — Mint NFT
/snipe <args> — Sniper mode

*📅 Daily Assistant*
/briefing — Laporan harian
/alert <msg> — Set alert
/alerts — Daftar alert aktif
/vault [key] — Akses vault

*🔍 Meta*
/audit — Self-audit sistem
/debug — Debug info
/improve — Self-improve loop

Atau ketik apa saja → RAJA langsung eksekusi.
Untuk modifikasi bot: ketik instruksi natural → RAJA sarankan /code.`;

export async function cmdStart(bot, msg) {
  const name = msg.from.first_name || 'Bos';
  await bot.sendMessage(
    msg.chat.id,
    `Siap, ${name}. RAJA v4.0 aktif.\n\nKetik /help buat daftar perintah, atau langsung ngomong aja.`,
    { parse_mode: 'Markdown' }
  );
}

export async function cmdHelp(bot, msg) {
  await bot.sendMessage(msg.chat.id, HELP_TEXT, { parse_mode: 'Markdown' });
}

export async function cmdStatus(bot, msg) {
  const session = await getSessionSafe();
  const uptime = Math.floor((Date.now() - session.startTime) / 1000);
  const hours = Math.floor(uptime / 3600);
  const mins = Math.floor((uptime % 3600) / 60);
  const secs = uptime % 60;

  const text = `*RAJA Status*

Uptime: ${hours}h ${mins}m ${secs}s
Active skill: ${session.activeSkill || 'none'}
History: ${session.history.length / 2} turns
Goal: ${session.goal || 'not set'}

Provider cascade:
• Primary: Ollama Cloud (${config.llm.ollamaCloud.apiKey ? '✓' : '✗ no key'})
• Backup: Ollama Local (${config.llm.ollamaLocal.url})
• Tertiary: OpenRouter (${config.llm.openrouter.apiKey ? '✓' : '✗ no key'})
• Quaternary: b.ai (${config.llm.bai.apiKey ? '✓' : '✗ no key'})`;

  await bot.sendMessage(msg.chat.id, text, { parse_mode: 'Markdown' });
}

export async function cmdSkill(bot, msg, query) {
  const routed = routeSkill(query);
  if (!routed.skill) {
    await bot.sendMessage(msg.chat.id, `Tidak ada skill yang match untuk: "${query}"`);
    return;
  }

  await bot.sendMessage(
    msg.chat.id,
    `*Skill routing*\n\nQuery: ${query}\nSkill: ${routed.skill} (${routed.name})\nScore: ${routed.score}\nMatched: ${routed.matched.join(', ')}`,
    { parse_mode: 'Markdown' }
  );
}

export async function cmdMemory(bot, msg) {
  try {
    const recent = await getRecent(10);
    if (recent.length === 0) {
      await bot.sendMessage(msg.chat.id, 'Memory kosong.');
      return;
    }

    const lines = recent.map((m, i) => {
      const date = new Date(m.ts * 1000).toLocaleDateString('id-ID');
      return `${i + 1}. [${m.kind}] ${m.content.substring(0, 100)}... (${date})`;
    });

    await bot.sendMessage(
      msg.chat.id,
      `*Recent Memory (${recent.length})*\n\n${lines.join('\n')}`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `Error: ${err.message}`);
  }
}
