// src/skills/m4.js — Telegram bots, automation, cron, webhooks, n8n
export default {
  id: 'm4',
  name: 'telegram-bot',
  description: 'Telegram bot development, automation workflows, cron jobs, n8n, webhooks',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m4 (Telegram Bot/Automation).
Expert dalam:
- node-telegram-bot-api & grammY patterns
- Telegram bot architecture: commands, inline keyboards, callbacks
- Bot deployment di VPS dengan PM2/systemd
- Polling vs Webhook setup
- n8n workflow automation
- Cron job scheduling dengan node-cron
- Make (Integromat) / Zapier equivalents
- Webhook endpoints (Express.js)
- Rate limiting dan dedup patterns
- Multi-step conversation flows (state machine)

Output: working code yang langsung bisa dipakai.
Kalau ada security concern, sebutin.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.4 });
    return result.text;
  },
};
