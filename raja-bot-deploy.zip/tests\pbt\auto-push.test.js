// tests/pbt/auto-push.test.js
// Property-Based Tests: Auto-Push Retry Behavior (Property 20)
//
// Property 20: Retry Behavior Berdasarkan Error Type
// For any push failure:
// - If error type is network/timeout → retry up to 3x with 5-minute intervals
// - If error type is non-network (auth/conflict) → immediately notify without retry
//
// **Validates: Requirements 6.4, 6.6**

import { describe, it, expect, vi, beforeEach } from 'vitest';
import * as fc from 'fast-check';
import { AutoPushScheduler } from '../../src/core/auto-push.js';

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * Build an Error whose message triggers a specific classifyError() output.
 * These strings are taken directly from the classifier conditions in auto-push.js.
 */
const ERROR_MESSAGES = {
  network: 'ECONNREFUSED: Connection refused by server',
  timeout: 'timeout: operation exceeded 120000ms',
  auth: 'auth: authentication failure 401 permission denied',
  conflict: 'conflict: non-fast-forward merge conflict in repository',
  unknown: 'some-unrecognised-internal-error-xyz'
};

/** Error types that should trigger retry behaviour */
const RETRYABLE_TYPES = ['network', 'timeout', 'unknown'];

/** Error types that should NOT retry (direct notification) */
const NON_RETRYABLE_TYPES = ['auth', 'conflict'];

/**
 * Create a scheduler that uses a dependency-injected execFn so that
 * git push can be controlled by the test without ESM spy issues.
 * notifyOwner is replaced with a spy.
 *
 * @param {(cmd: string) => string|void} execFn - Mock exec function
 * @param {number} [maxRetries=3]
 */
function makeSchedulerWithExecFn(execFn, maxRetries = 3) {
  const scheduler = new AutoPushScheduler({
    maxRetries,
    retryIntervalMs: 0,   // no actual waiting in tests
    pushTimeoutMs: 1000,
    execFn
  });
  scheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);
  return scheduler;
}

// ─── Property 20: Retry Behavior Berdasarkan Error Type ─────────────────────
// **Validates: Requirements 6.4, 6.6**
//
// For any push failure, jika error bertipe network/timeout maka retry hingga 3x
// dengan interval 5 menit; jika error bertipe non-network (auth/conflict), maka
// langsung notifikasi tanpa retry.

describe('Property 20: Retry Behavior Berdasarkan Error Type', () => {

  beforeEach(() => {
    vi.clearAllMocks();
  });

  // ── Sub-property A: classifyError categorisation is deterministic ─────────
  //
  // For any error message, classifyError SHALL always return the same category
  // (deterministic, no side effects).

  it('**Validates: Requirements 6.4, 6.6** — classifyError is deterministic: same message → same category', () => {
    const scheduler = makeSchedulerWithExecFn(() => '');

    fc.assert(
      fc.property(
        fc.constantFrom(
          ERROR_MESSAGES.network,
          ERROR_MESSAGES.timeout,
          ERROR_MESSAGES.auth,
          ERROR_MESSAGES.conflict,
          ERROR_MESSAGES.unknown
        ),
        (msg) => {
          const err = new Error(msg);
          const result1 = scheduler.classifyError(err);
          const result2 = scheduler.classifyError(err);
          // Deterministic: two calls with the same error must return the same type
          expect(result1).toBe(result2);
          // Must be one of the known types
          expect(['network', 'timeout', 'auth', 'conflict', 'unknown']).toContain(result1);
        }
      ),
      { numRuns: 100 }
    );
  });

  // ── Sub-property B: network/timeout errors are classified as retryable ────
  //
  // classifyError('ECONNREFUSED...') → 'network'
  // classifyError('timeout...')      → 'timeout'

  it('**Validates: Requirements 6.4** — network error messages are classified as "network"', () => {
    const scheduler = makeSchedulerWithExecFn(() => '');

    fc.assert(
      fc.property(
        fc.constantFrom(
          'ECONNREFUSED: connection refused',
          'ENOTFOUND: DNS lookup failed',
          'network failure: unreachable host',
          'fetch failed: unable to connect',
          'ECONNRESET: socket hang up'
        ),
        (msg) => {
          const type = scheduler.classifyError(new Error(msg));
          expect(type).toBe('network');
        }
      ),
      { numRuns: 100 }
    );
  });

  it('**Validates: Requirements 6.4** — timeout error messages are classified as "timeout"', () => {
    const scheduler = makeSchedulerWithExecFn(() => '');

    fc.assert(
      fc.property(
        fc.constantFrom(
          'timeout: push exceeded 120000ms',
          'ETIMEDOUT: read timed out',
          'DEADLINE_EXCEEDED: server took too long',
          'operation timed out after 120s'
        ),
        (msg) => {
          const type = scheduler.classifyError(new Error(msg));
          expect(type).toBe('timeout');
        }
      ),
      { numRuns: 100 }
    );
  });

  // ── Sub-property C: auth/conflict errors are classified as non-retryable ──
  //
  // classifyError('auth...401...') → 'auth'
  // classifyError('conflict...')   → 'conflict'

  it('**Validates: Requirements 6.6** — auth error messages are classified as "auth"', () => {
    const scheduler = makeSchedulerWithExecFn(() => '');

    fc.assert(
      fc.property(
        fc.constantFrom(
          'auth failed: bad credentials',
          'remote: 403 Forbidden',
          '401 unauthorized',
          'permission denied (publickey)',
          'authentication required'
        ),
        (msg) => {
          const type = scheduler.classifyError(new Error(msg));
          expect(type).toBe('auth');
        }
      ),
      { numRuns: 100 }
    );
  });

  it('**Validates: Requirements 6.6** — conflict error messages are classified as "conflict"', () => {
    const scheduler = makeSchedulerWithExecFn(() => '');

    fc.assert(
      fc.property(
        fc.constantFrom(
          'conflict: merge conflict detected',
          'non-fast-forward update rejected',
          'merge: unrelated histories',
          'CONFLICT (content): Merge conflict in src/index.js'
        ),
        (msg) => {
          const type = scheduler.classifyError(new Error(msg));
          expect(type).toBe('conflict');
        }
      ),
      { numRuns: 100 }
    );
  });

  // ── Sub-property D: network/timeout → retry count equals maxRetries ───────
  //
  // Requirement 6.4: retry 3x with intervals.
  // The loop in executeGitPush runs: attempt 0, 1, 2, 3 (= maxRetries).
  // That is maxRetries + 1 total attempts (1 initial + 3 retries).
  // notifyOwner is called exactly once after all retries exhausted.

  it('**Validates: Requirements 6.4** — network/timeout error triggers exactly maxRetries+1 push attempts and 1 notification', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.constantFrom('network', 'timeout'),
        async (errorType) => {
          let pushAttempts = 0;

          const execFn = (cmd) => {
            if (cmd === 'git push') {
              pushAttempts++;
              throw new Error(ERROR_MESSAGES[errorType]);
            }
            return ''; // git add / git commit succeed
          };

          const scheduler = makeSchedulerWithExecFn(execFn, 3);

          let threw = false;
          try {
            await scheduler.executeGitPush('[auto-sync] test', {
              codeFiles: ['src/test.js'],
              dataFiles: []
            });
          } catch {
            threw = true;
          }

          // Must throw (push never succeeded)
          expect(threw).toBe(true);
          // Total push attempts: 1 initial + maxRetries (3) = 4
          expect(pushAttempts).toBe(scheduler.maxRetries + 1);
          // notifyOwner called exactly once (after retries exhausted)
          expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
        }
      ),
      { numRuns: 20 }
    );
  });

  // ── Sub-property E: auth/conflict → no retry, immediate notification ──────
  //
  // Requirement 6.6: non-network error → notify immediately without retry.
  // Push attempt count must be exactly 1 (no retries).
  // notifyOwner must be called exactly once.

  it('**Validates: Requirements 6.6** — auth/conflict error triggers exactly 1 push attempt and immediate notification (no retry)', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.constantFrom('auth', 'conflict'),
        async (errorType) => {
          let pushAttempts = 0;

          const execFn = (cmd) => {
            if (cmd === 'git push') {
              pushAttempts++;
              throw new Error(ERROR_MESSAGES[errorType]);
            }
            return '';
          };

          const scheduler = makeSchedulerWithExecFn(execFn, 3);

          let threw = false;
          try {
            await scheduler.executeGitPush('[auto-sync] test', {
              codeFiles: ['src/test.js'],
              dataFiles: []
            });
          } catch {
            threw = true;
          }

          // Must throw (push failed)
          expect(threw).toBe(true);
          // Exactly 1 attempt — NO retry for non-network errors
          expect(pushAttempts).toBe(1);
          // notifyOwner called exactly once immediately
          expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
        }
      ),
      { numRuns: 20 }
    );
  });

  // ── Sub-property F: retry behavior invariant for any maxRetries value ─────
  //
  // For any maxRetries N (1–5), network/timeout errors → N+1 total push attempts.
  // auth/conflict errors → always exactly 1 attempt regardless of maxRetries.

  it('**Validates: Requirements 6.4, 6.6** — retry count invariant holds for any maxRetries configuration', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        fc.constantFrom('network', 'timeout', 'auth', 'conflict'),
        async (maxRetries, errorType) => {
          let pushAttempts = 0;

          const execFn = (cmd) => {
            if (cmd === 'git push') {
              pushAttempts++;
              throw new Error(ERROR_MESSAGES[errorType]);
            }
            return '';
          };

          const scheduler = makeSchedulerWithExecFn(execFn, maxRetries);

          try {
            await scheduler.executeGitPush('[auto-sync] test', {
              codeFiles: ['src/test.js'],
              dataFiles: []
            });
          } catch {
            // expected to throw
          }

          const isNonRetryable = NON_RETRYABLE_TYPES.includes(errorType);

          if (isNonRetryable) {
            // auth/conflict: exactly 1 attempt, no retry
            expect(pushAttempts).toBe(1);
          } else {
            // network/timeout/unknown: maxRetries + 1 total attempts
            expect(pushAttempts).toBe(maxRetries + 1);
          }
        }
      ),
      { numRuns: 50 }
    );
  });

  // ── Sub-property G: success on first attempt → notifyOwner never called ───
  //
  // If push succeeds immediately, notifyOwner must never be called regardless
  // of error type configuration.

  it('**Validates: Requirements 6.4, 6.6** — successful push never calls notifyOwner', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (maxRetries) => {
          const execFn = () => ''; // all git commands succeed

          const scheduler = makeSchedulerWithExecFn(execFn, maxRetries);

          let threw = false;
          try {
            await scheduler.executeGitPush('[auto-sync] test', {
              codeFiles: ['src/test.js'],
              dataFiles: []
            });
          } catch {
            threw = true;
          }

          // Push succeeded — no notification
          expect(threw).toBe(false);
          expect(scheduler.notifyOwner).not.toHaveBeenCalled();
        }
      ),
      { numRuns: 30 }
    );
  });

  // ── Sub-property H: network error succeeds on retry → notifyOwner never called
  //
  // If push fails on attempt N but succeeds on attempt N+1 (N < maxRetries),
  // notifyOwner must NOT be called (retry succeeded).

  it('**Validates: Requirements 6.4** — network error that succeeds on first retry does not call notifyOwner', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 3 }),
        fc.constantFrom('network', 'timeout'),
        async (failCount, errorType) => {
          let pushAttempts = 0;

          const execFn = (cmd) => {
            if (cmd === 'git push') {
              pushAttempts++;
              if (pushAttempts <= failCount) {
                throw new Error(ERROR_MESSAGES[errorType]);
              }
              return ''; // succeeds after failCount attempts
            }
            return '';
          };

          const scheduler = makeSchedulerWithExecFn(execFn, 3);

          let threw = false;
          try {
            await scheduler.executeGitPush('[auto-sync] test', {
              codeFiles: ['src/test.js'],
              dataFiles: []
            });
          } catch {
            threw = true;
          }

          // Push eventually succeeded (failCount <= maxRetries)
          expect(threw).toBe(false);
          // notifyOwner must NOT be called when push succeeds via retry
          expect(scheduler.notifyOwner).not.toHaveBeenCalled();
        }
      ),
      { numRuns: 30 }
    );
  });
});

// ─── Property 19: Commit Message Format ─────────────────────────────────────
// **Validates: Requirements 6.2**
//
// For any set perubahan file dengan N file di src/ + scripts/ dan M file di data/,
// commit message SHALL persis berformat:
//   [auto-sync] {YYYY-MM-DD} | code: {N} files | data: {M} files
//
// Where YYYY-MM-DD is today's UTC date, and N/M are exact non-padded integers.

describe('Property 19: Commit Message Format', () => {

  // ── Sub-property A: Format structure is exactly correct for any N, M ─────
  //
  // For any non-negative integers N (code files) and M (data files),
  // formatCommitMessage(N, M) must return a string that exactly matches the
  // required format with today's UTC date.

  it('**Validates: Requirements 6.2** — formatCommitMessage produces correct format for any N and M', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        (n, m) => {
          const todayUtc = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
          const result = scheduler.formatCommitMessage(n, m);
          const expected = `[auto-sync] ${todayUtc} | code: ${n} files | data: ${m} files`;
          expect(result).toBe(expected);
        }
      ),
      { numRuns: 200 }
    );
  });

  // ── Sub-property B: Date portion is today's UTC date (YYYY-MM-DD) ─────────
  //
  // The date in the commit message must be exactly today's UTC date, not any
  // other date. We verify the YYYY-MM-DD pattern and the actual value.

  it('**Validates: Requirements 6.2** — date in commit message is today\'s UTC date in YYYY-MM-DD format', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        (n, m) => {
          const result = scheduler.formatCommitMessage(n, m);

          // Extract the date portion from the message
          // Format: [auto-sync] YYYY-MM-DD | ...
          const dateMatch = result.match(/^\[auto-sync\] (\d{4}-\d{2}-\d{2}) \|/);
          expect(dateMatch).not.toBeNull();

          const dateInMessage = dateMatch[1];
          const todayUtc = new Date().toISOString().split('T')[0];

          // Must be today's UTC date
          expect(dateInMessage).toBe(todayUtc);

          // Must be valid ISO date format YYYY-MM-DD
          expect(dateInMessage).toMatch(/^\d{4}-\d{2}-\d{2}$/);
        }
      ),
      { numRuns: 200 }
    );
  });

  // ── Sub-property C: N and M appear as exact integers (no padding) ─────────
  //
  // The counts N and M must appear exactly as integers in the message — no
  // leading zeros, no decimal points, no padding. E.g., "0 files", "7 files",
  // "42 files" — never "007 files" or "7.0 files".

  it('**Validates: Requirements 6.2** — code and data counts appear as exact non-padded integers', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        (n, m) => {
          const result = scheduler.formatCommitMessage(n, m);

          // Extract the code count: "code: N files"
          const codeMatch = result.match(/\| code: (\d+) files \|/);
          expect(codeMatch).not.toBeNull();
          const codeCount = parseInt(codeMatch[1], 10);
          expect(codeCount).toBe(n);
          // No padding: the string representation must equal String(n)
          expect(codeMatch[1]).toBe(String(n));

          // Extract the data count: "data: M files"
          const dataMatch = result.match(/\| data: (\d+) files$/);
          expect(dataMatch).not.toBeNull();
          const dataCount = parseInt(dataMatch[1], 10);
          expect(dataCount).toBe(m);
          // No padding: the string representation must equal String(m)
          expect(dataMatch[1]).toBe(String(m));
        }
      ),
      { numRuns: 200 }
    );
  });

  // ── Sub-property D: Message starts with "[auto-sync]" prefix ─────────────
  //
  // The prefix "[auto-sync]" is a required part of the format. This property
  // verifies it is always present at the very beginning of the message.

  it('**Validates: Requirements 6.2** — commit message always starts with "[auto-sync]" prefix', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        (n, m) => {
          const result = scheduler.formatCommitMessage(n, m);
          expect(result.startsWith('[auto-sync] ')).toBe(true);
        }
      ),
      { numRuns: 200 }
    );
  });

  // ── Sub-property E: Message is deterministic for same N, M, and date ──────
  //
  // For the same N and M values, calling formatCommitMessage twice on the same
  // day must produce identical results (deterministic within a single day).

  it('**Validates: Requirements 6.2** — formatCommitMessage is deterministic: same inputs → same output', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        (n, m) => {
          const result1 = scheduler.formatCommitMessage(n, m);
          const result2 = scheduler.formatCommitMessage(n, m);
          expect(result1).toBe(result2);
        }
      ),
      { numRuns: 200 }
    );
  });

  // ── Sub-property F: N and M are independent — different counts produce distinct segments ──
  //
  // For any pair (n, m) where n !== m, the code count and data count must differ
  // in the output message. This ensures N and M are not swapped or mixed up.

  it('**Validates: Requirements 6.2** — code count and data count are independent and not swapped', () => {
    const scheduler = new AutoPushScheduler();

    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        fc.constantFrom(true), // always run
        (n, m) => {
          const result = scheduler.formatCommitMessage(n, m);

          // Extract counts from the message
          const codeMatch = result.match(/\| code: (\d+) files \|/);
          const dataMatch = result.match(/\| data: (\d+) files$/);

          expect(codeMatch).not.toBeNull();
          expect(dataMatch).not.toBeNull();

          expect(parseInt(codeMatch[1], 10)).toBe(n);
          expect(parseInt(dataMatch[1], 10)).toBe(m);
        }
      ),
      { numRuns: 200 }
    );
  });
});

// ─── Property 21: Concurrent Push Lock ──────────────────────────────────────
// **Validates: Requirements 6.8**
//
// For any trigger push yang terjadi saat isRunning = true, trigger tersebut SHALL
// ditolak (return tanpa eksekusi) dan penolakan dicatat ke log.
//
// Properties covered:
// A. Rejected trigger returns { status: 'skipped', error: 'concurrent push rejected' }
// B. No git exec calls are made when isRunning = true
// C. writeLog() is called with the rejection result
// D. isRunning remains true after rejection (not reset by rejected trigger)
// E. When isRunning = false, triggerPush() proceeds normally (lock doesn't block legit pushes)
// F. Lock is properly released (isRunning = false) after push completes or fails

describe('Property 21: Concurrent Push Lock', () => {

  beforeEach(() => {
    vi.clearAllMocks();
  });

  // ── Sub-property A: Rejected trigger returns correct skipped result ────────
  //
  // For any number of concurrent trigger attempts while isRunning = true,
  // each SHALL return { status: 'skipped', error: 'concurrent push rejected' }.

  it('**Validates: Requirements 6.8** — triggerPush() returns skipped result when isRunning = true', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 10 }),
        async (_attemptCount) => {
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);

          // Force lock: simulate a push is already running
          scheduler.isRunning = true;
          // Stub writeLog to avoid filesystem side effects
          scheduler.writeLog = vi.fn();

          const result = await scheduler.triggerPush();

          expect(result.status).toBe('skipped');
          expect(result.error).toBe('concurrent push rejected');
          expect(result).toHaveProperty('timestamp');
          expect(result.codeFiles).toBe(0);
          expect(result.dataFiles).toBe(0);
        }
      ),
      { numRuns: 50 }
    );
  });

  // ── Sub-property B: No git exec commands are called when lock is held ──────
  //
  // When isRunning = true, the rejected trigger must not call execFn at all —
  // no git status, git add, git commit, or git push calls.

  it('**Validates: Requirements 6.8** — no git exec calls are made when isRunning = true', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);

          scheduler.isRunning = true;
          scheduler.writeLog = vi.fn();

          await scheduler.triggerPush();

          // execFn must never be called — push was fully rejected
          expect(execFn).not.toHaveBeenCalled();
        }
      ),
      { numRuns: 50 }
    );
  });

  // ── Sub-property C: writeLog() is called with the rejection result ─────────
  //
  // When isRunning = true, writeLog SHALL be called exactly once with the
  // skipped/rejected result containing the correct error message.

  it('**Validates: Requirements 6.8** — writeLog() is called exactly once with rejection result when isRunning = true', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);

          scheduler.isRunning = true;
          scheduler.writeLog = vi.fn();

          await scheduler.triggerPush();

          // writeLog must be called exactly once
          expect(scheduler.writeLog).toHaveBeenCalledTimes(1);

          // The argument must be the rejection result
          const loggedResult = scheduler.writeLog.mock.calls[0][0];
          expect(loggedResult.status).toBe('skipped');
          expect(loggedResult.error).toBe('concurrent push rejected');
        }
      ),
      { numRuns: 50 }
    );
  });

  // ── Sub-property D: isRunning remains true after rejection ─────────────────
  //
  // The rejected trigger must NOT reset isRunning to false — that is the
  // responsibility of the running push. After rejection, isRunning stays true.

  it('**Validates: Requirements 6.8** — isRunning remains true after a concurrent trigger is rejected', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);

          scheduler.isRunning = true;
          scheduler.writeLog = vi.fn();

          await scheduler.triggerPush();

          // Lock must still be held after rejection
          expect(scheduler.isRunning).toBe(true);
        }
      ),
      { numRuns: 50 }
    );
  });

  // ── Sub-property E: lock does NOT block pushes when isRunning = false ──────
  //
  // When isRunning = false (no push in progress), triggerPush() must proceed
  // normally — it should NOT return a 'skipped' result due to a false lock.
  // We verify this by checking the result is not 'skipped' due to lock.

  it('**Validates: Requirements 6.8** — triggerPush() proceeds normally when isRunning = false (lock not held)', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          // execFn: git status returns no changes → push skips with 'skipped' (no changes),
          // but critically NOT because of the concurrent lock. We distinguish by checking error.
          const execFn = vi.fn().mockReturnValue(''); // git status returns empty = no changes
          const scheduler = makeSchedulerWithExecFn(execFn);

          scheduler.isRunning = false; // No lock held
          scheduler.writeLog = vi.fn();

          const result = await scheduler.triggerPush();

          // If skipped, must be due to "no changes" not the concurrent lock
          if (result.status === 'skipped') {
            expect(result.error).not.toBe('concurrent push rejected');
          }

          // execFn must have been called at minimum for 'git status --porcelain'
          expect(execFn).toHaveBeenCalled();
        }
      ),
      { numRuns: 30 }
    );
  });

  // ── Sub-property F: isRunning is released after push completes ────────────
  //
  // For any push outcome (success, no-changes skip, or failure), isRunning
  // SHALL be false after triggerPush() resolves. The lock must not be leaked.

  it('**Validates: Requirements 6.8** — isRunning is released (false) after triggerPush() completes successfully (no changes)', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          // Simulate: git status returns no changes → triggerPush() returns skipped (no changes)
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);
          scheduler.writeLog = vi.fn();

          expect(scheduler.isRunning).toBe(false); // pre-condition

          await scheduler.triggerPush();

          // Lock must be released after completion
          expect(scheduler.isRunning).toBe(false);
        }
      ),
      { numRuns: 30 }
    );
  });

  it('**Validates: Requirements 6.8** — isRunning is released (false) after triggerPush() completes with a push (success)', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          // Simulate changes detected + push succeeds
          const execFn = vi.fn().mockImplementation((cmd) => {
            if (cmd === 'git status --porcelain') {
              return ' M src/index.js\n'; // one changed code file
            }
            return ''; // git add / commit / push all succeed
          });
          const scheduler = makeSchedulerWithExecFn(execFn);
          scheduler.writeLog = vi.fn();

          expect(scheduler.isRunning).toBe(false);

          await scheduler.triggerPush();

          // Lock must be released regardless of outcome
          expect(scheduler.isRunning).toBe(false);
        }
      ),
      { numRuns: 30 }
    );
  });

  it('**Validates: Requirements 6.8** — isRunning is released (false) even when triggerPush() encounters an error', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 1, max: 5 }),
        async (_n) => {
          // Simulate changes detected + push fails
          const execFn = vi.fn().mockImplementation((cmd) => {
            if (cmd === 'git status --porcelain') {
              return ' M src/index.js\n';
            }
            if (cmd === 'git push') {
              throw new Error('ECONNREFUSED: connection refused');
            }
            return '';
          });
          const scheduler = makeSchedulerWithExecFn(execFn, 0); // maxRetries=0 → fail fast
          scheduler.writeLog = vi.fn();

          expect(scheduler.isRunning).toBe(false);

          await scheduler.triggerPush(); // must not throw (errors are caught internally)

          // Lock MUST be released via finally block even on error
          expect(scheduler.isRunning).toBe(false);
        }
      ),
      { numRuns: 30 }
    );
  });

  // ── Sub-property G: multiple concurrent triggers all rejected ────────────
  //
  // For any N concurrent triggers fired while isRunning = true, ALL of them
  // SHALL be rejected with the same skipped result. The lock is held-and-fired
  // pattern is correct.

  it('**Validates: Requirements 6.8** — all concurrent triggers are rejected when isRunning = true (multiple triggers)', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 2, max: 8 }),
        async (concurrentCount) => {
          const execFn = vi.fn().mockReturnValue('');
          const scheduler = makeSchedulerWithExecFn(execFn);

          scheduler.isRunning = true;
          scheduler.writeLog = vi.fn();

          // Fire N concurrent triggers simultaneously
          const results = await Promise.all(
            Array.from({ length: concurrentCount }, () => scheduler.triggerPush())
          );

          // Every single one must be rejected
          for (const result of results) {
            expect(result.status).toBe('skipped');
            expect(result.error).toBe('concurrent push rejected');
          }

          // writeLog called once per rejection
          expect(scheduler.writeLog).toHaveBeenCalledTimes(concurrentCount);

          // execFn never called (no git operations)
          expect(execFn).not.toHaveBeenCalled();
        }
      ),
      { numRuns: 30 }
    );
  });
});
