// src/skills/H8.js — Hermes: Browser automation (Playwright dApp interaction)
// TODO: Wire intent detection to hermes/browser.js when module is created.
// Expected exports: launchBrowser, connectWallet, navigateDapp, executeAction, screenshot
// Intent patterns to detect: "buka <url>", "connect wallet to <dapp>",
// "klik <button>", "isi form <fields>", "screenshot <url>"
import { logger } from '../utils/logger.js';

/**
 * Detect actionable browser automation intent from natural language query.
 * Currently returns null (LLM-only) — will be wired to hermes module in future.
 *
 * TODO: Implement when hermes/browser.js exports are available:
 * - "buka <url>" / "open <url>" → launchBrowser + navigate
 * - "connect wallet to <dapp_url> wallet <label>" → connectWallet
 * - "screenshot <url>" → screenshot
 * - "claim airdrop on <url> wallet <label>" → multi-step automation
 * - "interact <dapp> klik <selector>" → executeAction
 */
function detectBrowserIntent(query) {
  // TODO: Implement when hermes/browser.js module is ready
  // const q = query.trim();
  //
  // const openMatch = q.match(/(?:buka|open|navigate|goto)\s+(https?:\/\/\S+)/i);
  // if (openMatch) return { intent: 'OPEN_URL', params: { url: openMatch[1] } };
  //
  // const screenshotMatch = q.match(/(?:screenshot|ss|capture)\s+(https?:\/\/\S+)/i);
  // if (screenshotMatch) return { intent: 'SCREENSHOT', params: { url: screenshotMatch[1] } };
  //
  // const connectMatch = q.match(/(?:connect\s+wallet|hubungkan\s+wallet)\s+(?:to|ke)\s+(https?:\/\/\S+)\s+wallet\s+(\S+)/i);
  // if (connectMatch) return { intent: 'CONNECT_WALLET', params: { url: connectMatch[1], wallet: connectMatch[2] } };
  //
  return null;
}

export default {
  id: 'H8',
  name: 'browser',
  description: 'Browser automation: buka dApp, connect wallet, isi form, klik, navigasi via Playwright',

  async execute(query, context) {
    // 1. Attempt intent detection (currently LLM-only, TODO: wire to hermes)
    const intent = detectBrowserIntent(query);

    if (intent) {
      // TODO: Handle actionable browser intents here when hermes/browser.js is ready
      logger.info(`[H8] Browser intent detected: ${intent.intent}`, intent.params);
    }

    // 2. LLM cascade for all browser automation queries
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H8 (Browser/Playwright).
Mode: methodical, security-conscious.

Kamu adalah expert browser automation untuk Web3/dApp interaction:

Core Capabilities:
- Launch headless browser (Playwright Chromium)
- Navigate to dApp URLs
- Inject wallet provider (window.ethereum mock with real signing)
- Connect wallet to dApp via injected provider
- Fill forms, click buttons, handle modals
- Take screenshots for verification
- Multi-wallet loop (iterate wallets across same dApp)
- Handle popup confirmations & wallet signature requests

Tech Stack:
- Playwright (npm install playwright && npx playwright install chromium)
- ethers.js for transaction signing (sign offline, inject to dApp)
- Cookie/session management for persistent sessions

Standard Workflow:
1. Launch browser (headless: true for VPS)
2. Navigate to target dApp
3. Connect wallet via ethereum.request mock injection
4. Execute action sequence (click, fill, submit)
5. Handle wallet popups (auto-sign or prompt user)
6. Screenshot result for verification
7. Close browser session

Security Rules (STRICTLY enforced):
- NEVER input private key directly into web forms
- ALWAYS validate URL before connecting (anti-phishing checklist)
- Screenshot BEFORE confirming any on-chain action
- Sign transactions via ethers.js locally, never via dApp's signing
- Verify contract addresses in tx data match expected protocols
- Block known scam domains (maintain blacklist)
- Rate limit: max 1 wallet connect per 10 seconds (anti-bot detection)

Airdrop Farming Pattern:
- Multi-wallet sequential connection
- Task completion tracking per wallet
- Delay randomization (avoid bot detection)
- Captcha handling (manual intervention flag)

Output: production-ready Playwright code dengan full error handling.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H8] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan browser automation: ${err.message}`;
    }
  },
};
