// src/self-upgrade/healthcheck.js — Bot health verification
import { sleep } from '../utils/retry.js';
import { logger } from '../utils/logger.js';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import { config } from '../config.js';

const execAsync = promisify(exec);

/**
 * Check if bot process is alive and heartbeat is fresh
 * @param {Object} opts
 * @param {number} opts.retries - number of attempts (default 3)
 * @param {number} opts.interval - ms between attempts (default 10000)
 */
export async function healthCheck({ retries = 3, interval = 10000 } = {}) {
  for (let i = 1; i <= retries; i++) {
    logger.info(`[health] Check ${i}/${retries}...`);

    try {
      // 1. Check process is running
      const { stdout } = await execAsync('pgrep -f "node src/index.js" 2>/dev/null || echo ""');
      const pid = stdout.trim();
      if (!pid) {
        logger.warn(`[health] Process not found (attempt ${i})`);
        if (i < retries) await sleep(interval);
        continue;
      }

      // 2. Check heartbeat file is fresh (< 90 seconds old)
      const hbPath = config.watchdog.heartbeatPath;
      if (fs.existsSync(hbPath)) {
        const ts = parseInt(fs.readFileSync(hbPath, 'utf8').trim());
        const age = Date.now() - ts;
        if (age > 90000) {
          logger.warn(`[health] Heartbeat stale: ${Math.round(age / 1000)}s old`);
          if (i < retries) await sleep(interval);
          continue;
        }
      }

      logger.info(`[health] OK. PID: ${pid}`);
      return { ok: true, pid };
    } catch (err) {
      logger.warn(`[health] Check error: ${err.message}`);
      if (i < retries) await sleep(interval);
    }
  }

  return { ok: false, error: 'Health check failed after all retries' };
}
