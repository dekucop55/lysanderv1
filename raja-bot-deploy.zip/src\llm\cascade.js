// src/llm/cascade.js — Universal LLM Cascade (fully slot-based)
// ALL providers defined via env: LLM_1_* through LLM_9_*
// No hardcoded providers. Change model = change env + restart.
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import axios from 'axios';

// ─── Universal adapters ──────────────────────────────────────────────────────

/**
 * Ollama-native format (/api/chat)
 * Used when LLM_N_FORMAT=ollama
 */
async function callOllama(providerConfig, messages, options = {}) {
  const { url, key, model } = providerConfig;

  const headers = { 'Content-Type': 'application/json' };
  if (key) headers['Authorization'] = `Bearer ${key}`;

  const response = await axios.post(
    `${url}/api/chat`,
    {
      model,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      stream: false,
      options: {
        num_predict: options.maxTokens || 2000,
        temperature: options.temperature || 0.7,
      },
    },
    { headers, timeout: 120000 }
  );

  const text = response.data.message?.content || '';
  return {
    text,
    usage: {
      prompt_tokens: response.data.prompt_eval_count || 0,
      completion_tokens: response.data.eval_count || 0,
      total_tokens: (response.data.prompt_eval_count || 0) + (response.data.eval_count || 0),
    },
  };
}

/**
 * OpenAI-compatible format (/v1/chat/completions or custom endpoint)
 * Used when LLM_N_FORMAT=openai (default)
 * Supports custom auth via LLM_N_AUTH_HEADER env var
 */
async function callOpenAI(providerConfig, messages, options = {}) {
  const { url, key, model, authHeader } = providerConfig;

  const headers = { 'Content-Type': 'application/json' };
  if (key) {
    if (authHeader) {
      // Custom auth header (e.g. X-API-Key for Pioneer)
      headers[authHeader] = key;
    } else {
      headers['Authorization'] = `Bearer ${key}`;
    }
  }
  headers['HTTP-Referer'] = 'https://github.com/bbtpm2/raja-bot';
  headers['X-Title'] = 'RAJA Bot';

  const response = await axios.post(
    url,
    {
      model,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      max_tokens: options.maxTokens || 2000,
      temperature: options.temperature || 0.7,
      stream: false,
    },
    { headers, timeout: 90000 }
  );

  const text = response.data.choices?.[0]?.message?.content
    || response.data.message?.content
    || '';

  return { text, usage: response.data.usage || {} };
}

// ─── Build providers from env ────────────────────────────────────────────────

function buildProviders() {
  const providers = [];

  for (let i = 1; i <= 9; i++) {
    const name = process.env[`LLM_${i}_NAME`];
    const url = process.env[`LLM_${i}_URL`];
    const key = process.env[`LLM_${i}_KEY`];
    const model = process.env[`LLM_${i}_MODEL`];
    const format = (process.env[`LLM_${i}_FORMAT`] || 'openai').toLowerCase();
    const authHeader = process.env[`LLM_${i}_AUTH_HEADER`] || null;

    // Skip slots that don't have minimum config (url + model)
    if (!url || !model) continue;

    const providerConfig = { url, key, model, name: name || `provider-${i}`, format, authHeader };

    providers.push({
      name: name || `provider-${i}`,
      enabled: true,
      format,
      fn: (msgs, opts) => {
        if (format === 'ollama') return callOllama(providerConfig, msgs, opts);
        return callOpenAI(providerConfig, msgs, opts);
      },
    });
  }

  // Legacy fallback: if no LLM_1_* defined, check old OLLAMA_CLOUD / OPENROUTER vars
  if (providers.length === 0) {
    // Old format: OLLAMA_CLOUD_URL + GEMMA4_API_KEY
    const ollamaUrl = process.env.OLLAMA_CLOUD_URL;
    const ollamaKey = process.env.GEMMA4_API_KEY;
    const ollamaModel = process.env.OLLAMA_MODEL_PRIMARY;
    if (ollamaUrl && ollamaKey && ollamaModel) {
      const cfg = { url: ollamaUrl, key: ollamaKey, model: ollamaModel, name: 'ollama-cloud' };
      providers.push({
        name: 'ollama-cloud',
        enabled: true,
        format: 'ollama',
        fn: (msgs, opts) => callOllama(cfg, msgs, opts),
      });
    }

    // Old format: OPENROUTER
    const orUrl = process.env.OPENROUTER_BASE_URL;
    const orKey = process.env.OPENROUTER_API_KEY;
    const orModel = process.env.OPENROUTER_MODEL;
    if (orUrl && orKey && orModel) {
      const cfg = { url: `${orUrl}/chat/completions`, key: orKey, model: orModel, name: 'openrouter' };
      providers.push({
        name: 'openrouter',
        enabled: true,
        format: 'openai',
        fn: (msgs, opts) => callOpenAI(cfg, msgs, opts),
      });
    }

    // Old format: BAI
    const baiUrl = process.env.BAI_BASE_URL;
    const baiKey = process.env.BAI_API_KEY;
    const baiModel = process.env.BAI_MODEL;
    if (baiUrl && baiKey && baiModel) {
      const cfg = { url: `${baiUrl}/v1/chat/completions`, key: baiKey, model: baiModel, name: 'bai' };
      providers.push({
        name: 'bai',
        enabled: true,
        format: 'openai',
        fn: (msgs, opts) => callOpenAI(cfg, msgs, opts),
      });
    }
  }

  return providers;
}

let PROVIDERS = buildProviders();

export function reloadProviders() {
  PROVIDERS = buildProviders();
  logger.info(`[cascade] Providers reloaded: ${PROVIDERS.map(p => p.name).join(', ')}`);
}

// ─── Runtime provider switch ─────────────────────────────────────────────────

let forcedProvider = null;

export function switchProvider(providerName) {
  if (!providerName || providerName === 'auto' || providerName === 'cascade') {
    forcedProvider = null;
    logger.info(`[cascade] Switched to AUTO cascade mode`);
    return { success: true, message: 'Mode cascade otomatis (semua provider bergiliran)' };
  }

  const found = PROVIDERS.find(p =>
    p.name === providerName || p.name.toLowerCase().includes(providerName.toLowerCase())
  );
  if (!found) {
    const available = PROVIDERS.map(p => p.name).join(', ');
    return { success: false, message: `Provider "${providerName}" tidak ditemukan. Available: ${available}` };
  }

  forcedProvider = found.name;
  logger.info(`[cascade] Forced provider: ${found.name}`);
  return { success: true, message: `Model utama sekarang: ${found.name}` };
}

export function getProviderStatus() {
  return {
    forced: forcedProvider,
    mode: forcedProvider ? `forced: ${forcedProvider}` : 'auto-cascade',
    providers: PROVIDERS.map(p => ({
      name: p.name,
      enabled: p.enabled,
      format: p.format,
      active: forcedProvider ? p.name === forcedProvider : p.enabled,
    })),
  };
}

export function resolveProviderName(input) {
  const lower = input.toLowerCase().trim();
  for (const p of PROVIDERS) {
    if (lower.includes(p.name.toLowerCase())) return p.name;
  }
  if (lower.includes('auto') || lower.includes('cascade') || lower.includes('otomatis')) return 'auto';
  return null;
}

// ─── Main cascade function ───────────────────────────────────────────────────

export async function callCascade(messages, options = {}) {
  const errors = [];

  if (PROVIDERS.length === 0) {
    throw new Error('No LLM providers configured. Check .env (LLM_1_URL, LLM_1_MODEL, etc.)');
  }

  // If forced provider set, try it first
  if (forcedProvider) {
    const forced = PROVIDERS.find(p => p.name === forcedProvider);
    if (forced) {
      try {
        const result = await forced.fn(messages, options);
        logger.info(`✓ LLM from ${forced.name} (${result.usage?.total_tokens || '?'} tokens)`);
        return { ...result, provider: forced.name };
      } catch (err) {
        const errMsg = err.response?.status === 429 ? 'rate-limited'
          : err.response?.status === 403 ? 'forbidden/invalid-key'
          : err.response?.status === 404 ? 'model-not-found'
          : err.message;
        logger.warn(`✗ Forced ${forced.name} failed: ${errMsg}. Falling to cascade...`);
        errors.push(`${forced.name}: ${errMsg}`);
      }
    }
  }

  // Normal cascade: try each provider in order
  for (const provider of PROVIDERS) {
    if (!provider.enabled) continue;
    if (forcedProvider && provider.name === forcedProvider) continue; // already tried

    try {
      const result = await provider.fn(messages, options);
      logger.info(`✓ LLM from ${provider.name} (${result.usage?.total_tokens || '?'} tokens)`);
      return { ...result, provider: provider.name };
    } catch (err) {
      const errMsg = err.response?.status === 429 ? 'rate-limited'
        : err.response?.status === 403 ? 'forbidden/invalid-key'
        : err.response?.status === 404 ? 'model-not-found'
        : err.message;
      logger.warn(`✗ ${provider.name} failed: ${errMsg}`);
      errors.push(`${provider.name}: ${errMsg}`);
    }
  }

  throw new Error(`All LLM providers failed:\n${errors.join('\n')}`);
}
