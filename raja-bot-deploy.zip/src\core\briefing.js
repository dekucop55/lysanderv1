// src/core/briefing.js — Daily briefing generator & delivery
import { getRecent } from './memory.js';
import { callCascade } from '../llm/cascade.js';
import { getBot } from '../telegram/bot.js';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import fs from 'fs';
import path from 'path';

/**
 * Generate daily briefing content with metrics and LLM narrative.
 * On LLM failure, returns a minimal metrics-only briefing.
 * @returns {Promise<{ content: string, metrics: object }>}
 */
export async function generateBriefing() {
  // Gather metrics
  const uptime = process.uptime();
  const now = Date.now() / 1000;
  const oneDayAgo = now - 86400;

  // 24h memory count: get recent memories and filter by timestamp
  const recentMemories = await getRecent(1000, null);
  const last24hMemories = recentMemories.filter(m => m.ts > oneDayAgo);
  const memoryCount24h = last24hMemories.length;

  // Last reflection summary
  const reflections = await getRecent(1, 'reflection');
  const lastReflection = reflections.length > 0 ? reflections[0].content : 'Belum ada refleksi.';

  // Pending decisions/improvements
  const pendingImprovements = await getRecent(50, 'pending_improvement');

  const metrics = {
    uptime,
    uptimeHours: Math.round(uptime / 3600 * 10) / 10,
    memoryCount24h,
    lastReflection,
    pendingDecisions: pendingImprovements.length,
    pendingItems: pendingImprovements.map(p => p.content).slice(0, 5),
  };

  // Try to generate narrative via LLM
  try {
    const systemPrompt = `Kamu adalah RAJA Bot, AI assistant pribadi. Buat ringkasan briefing harian yang ringkas dalam Bahasa Indonesia. Berdasarkan data berikut:
- Uptime: ${metrics.uptimeHours} jam
- Memori baru 24 jam terakhir: ${metrics.memoryCount24h} entri
- Refleksi terakhir: ${metrics.lastReflection}
- Keputusan pending: ${metrics.pendingDecisions} item
${metrics.pendingItems.length > 0 ? '- Detail pending: ' + metrics.pendingItems.join('; ') : ''}

Buat briefing singkat, padat, informatif. Format Markdown. Mulai dengan greeting dan status kesehatan sistem.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: 'Generate daily briefing sekarang.' },
    ];

    const result = await callCascade(messages, { temperature: 0.7 });
    const content = result.content || result.message?.content || '';

    logger.info('[briefing] LLM briefing generated successfully');
    return { content, metrics };
  } catch (err) {
    // LLM failure: generate minimal metrics-only briefing
    logger.warn(`[briefing] LLM failed, using metrics-only fallback: ${err.message}`);

    const content = `📊 *Daily Briefing (Metrics Only)*

⏱ Uptime: ${metrics.uptimeHours} jam
🧠 Memori 24h: ${metrics.memoryCount24h} entri
🪞 Refleksi terakhir: ${metrics.lastReflection}
📋 Pending decisions: ${metrics.pendingDecisions}`;

    return { content, metrics };
  }
}

/**
 * Deliver briefing content via Telegram and write to daily file.
 * On Telegram failure, retries once after 60 seconds.
 * @param {string} content - The briefing content to deliver
 * @returns {Promise<{ deliveredAt: string, filePath: string, retried: boolean }>}
 */
export async function deliverBriefing(content) {
  const now = new Date();
  const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
  const dailyDir = path.join(config.raja.home, 'memory', 'daily');
  const filePath = path.join(dailyDir, `${dateStr}.md`);
  let retried = false;

  // Write to file (create directory if needed)
  fs.mkdirSync(dailyDir, { recursive: true });
  fs.writeFileSync(filePath, `# Daily Briefing ${dateStr}\n\n${content}\n`);
  logger.info(`[briefing] Written to ${filePath}`);

  // Send via Telegram
  const bot = getBot();
  const chatId = config.telegram.allowedUserId;

  try {
    await bot.sendMessage(chatId, content, { parse_mode: 'Markdown' });
    logger.info('[briefing] Delivered via Telegram');
  } catch (err) {
    logger.error(`[briefing] Telegram delivery failed: ${err.message}`);
    retried = true;

    // Retry once after 60 seconds
    setTimeout(async () => {
      try {
        const retryBot = getBot();
        await retryBot.sendMessage(chatId, content, { parse_mode: 'Markdown' });
        logger.info('[briefing] Telegram retry succeeded');
      } catch (retryErr) {
        logger.error(`[briefing] Telegram retry also failed: ${retryErr.message}`);
      }
    }, 60000);
  }

  return {
    deliveredAt: now.toISOString(),
    filePath,
    retried,
  };
}

/**
 * Orchestrate daily briefing: generate → deliver.
 * Entire operation targets completion within 30s budget.
 * @returns {Promise<void>}
 */
export async function runDailyBriefing() {
  try {
    logger.info('[briefing] Starting daily briefing...');
    const start = Date.now();

    const { content, metrics } = await generateBriefing();
    const result = await deliverBriefing(content);

    const elapsed = ((Date.now() - start) / 1000).toFixed(1);
    logger.info(`[briefing] Daily briefing complete in ${elapsed}s (retried: ${result.retried})`);
  } catch (err) {
    logger.error(`[briefing] runDailyBriefing failed: ${err.message}`);
  }
}
