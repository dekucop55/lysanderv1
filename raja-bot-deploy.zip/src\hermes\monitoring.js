// src/hermes/monitoring.js — Whale tracker, smart money, mempool monitoring
import { ethers } from 'ethers';
import axios from 'axios';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

const WHALE_THRESHOLD_ETH = 100;

/**
 * Track wallet activity (address → movements)
 * Returns unsubscribe function
 */
export function trackWallet({ address, chain = 'ethereum', onTx }) {
  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`RPC not configured for ${chain}`);

  const provider = new ethers.JsonRpcProvider(rpcUrl);

  // Poll for new blocks and check address
  const intervalId = setInterval(async () => {
    try {
      const block = await provider.getBlock('latest', true);
      if (!block?.transactions) return;

      for (const tx of block.transactions) {
        const isFrom = tx.from?.toLowerCase() === address.toLowerCase();
        const isTo = tx.to?.toLowerCase() === address.toLowerCase();
        if (isFrom || isTo) {
          const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
          onTx({ tx, valueEth, direction: isFrom ? 'out' : 'in', chain });
        }
      }
    } catch (e) {
      logger.debug(`[monitor] Block scan error: ${e.message}`);
    }
  }, 15000); // Check every 15s (1 block ~12s on ETH)

  return () => clearInterval(intervalId);
}

/**
 * Get whale transactions from Etherscan-compatible API
 */
export async function getWhaleMovements({ chain = 'ethereum', minValueEth = WHALE_THRESHOLD_ETH, limit = 20 }) {
  // Use Dune Analytics if key available, else fallback to basic scan
  const duneKey = config.cryptoApis.dune;

  if (duneKey) {
    try {
      // Query large ETH transfers
      const res = await axios.post(
        'https://api.dune.com/api/v1/query/3578516/execute',
        { query_parameters: { min_value_eth: minValueEth, limit } },
        { headers: { 'X-Dune-API-Key': duneKey }, timeout: 30000 }
      );
      return { source: 'dune', data: res.data };
    } catch (e) {
      logger.warn(`[monitor] Dune query failed: ${e.message}`);
    }
  }

  // Fallback: scan recent blocks manually
  const rpcUrl = config.rpc.evm[chain];
  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const latestBlock = await provider.getBlockNumber();
  const whales = [];

  for (let i = latestBlock; i > latestBlock - 10 && whales.length < limit; i--) {
    const block = await provider.getBlock(i, true);
    if (!block?.transactions) continue;

    for (const tx of block.transactions) {
      const valueEth = parseFloat(ethers.formatEther(tx.value || 0));
      if (valueEth >= minValueEth) {
        whales.push({
          txHash: tx.hash,
          from: tx.from,
          to: tx.to,
          valueEth,
          block: i,
        });
      }
    }
  }

  return { source: 'rpc', data: whales.slice(0, limit) };
}

/**
 * Get smart money wallet activity via Nansen/Arkham
 */
export async function getSmartMoneyActivity({ address, source = 'nansen' }) {
  if (source === 'nansen' && config.cryptoApis.nansen) {
    try {
      const res = await axios.get(
        `https://api.nansen.ai/v1/wallet/${address}/activity`,
        {
          headers: { 'api-key': config.cryptoApis.nansen },
          timeout: 15000,
        }
      );
      return { source: 'nansen', data: res.data };
    } catch (e) {
      logger.warn(`[monitor] Nansen failed: ${e.message}`);
    }
  }

  if (source === 'arkham' && config.cryptoApis.arkham) {
    try {
      const res = await axios.get(
        `https://api.arkhamintelligence.com/transfers?address=${address}&limit=20`,
        {
          headers: { 'API-Key': config.cryptoApis.arkham },
          timeout: 15000,
        }
      );
      return { source: 'arkham', data: res.data };
    } catch (e) {
      logger.warn(`[monitor] Arkham failed: ${e.message}`);
    }
  }

  return { source: 'none', data: null, reason: 'No API keys configured' };
}

/**
 * Get token price from DexScreener (keyless)
 */
export async function getTokenPrice(tokenAddress, chain = 'ethereum') {
  try {
    const chainMap = { ethereum: 'ethereum', base: 'base', arbitrum: 'arbitrum', bsc: 'bsc', polygon: 'polygon' };
    const chainSlug = chainMap[chain] || chain;

    const res = await axios.get(
      `https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`,
      { timeout: 10000 }
    );

    const pairs = res.data?.pairs;
    if (!pairs?.length) return null;

    const topPair = pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];
    return {
      priceUsd: topPair.priceUsd,
      liquidity: topPair.liquidity,
      volume24h: topPair.volume?.h24,
      priceChange24h: topPair.priceChange?.h24,
      dex: topPair.dexId,
      pairAddress: topPair.pairAddress,
    };
  } catch (e) {
    logger.warn(`[monitor] Price fetch failed: ${e.message}`);
    return null;
  }
}
