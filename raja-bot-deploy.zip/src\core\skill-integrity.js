// src/core/skill-integrity.js — SHA-256 skill manifest verifier (FROZEN)
import { createHash } from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const MANIFEST_PATH = path.join(ROOT, 'SKILLS.lock');
const SKILLS_DIR = path.join(ROOT, 'src', 'skills');

function hashFile(filePath) {
  try {
    const content = fs.readFileSync(filePath);
    return createHash('sha256').update(content).digest('hex');
  } catch {
    return null;
  }
}

function buildManifest() {
  const manifest = {};
  if (!fs.existsSync(SKILLS_DIR)) return manifest;

  const files = fs.readdirSync(SKILLS_DIR).filter((f) => f.endsWith('.js'));
  for (const file of files) {
    const full = path.join(SKILLS_DIR, file);
    manifest[file] = hashFile(full);
  }
  return manifest;
}

export async function generateManifest() {
  const manifest = buildManifest();
  const payload = {
    generated: new Date().toISOString(),
    skills: manifest,
  };
  fs.writeFileSync(MANIFEST_PATH, JSON.stringify(payload, null, 2));
  logger.info(`[integrity] Manifest generated: ${Object.keys(manifest).length} skills`);
  return payload;
}

export async function verifyIntegrity() {
  if (!fs.existsSync(MANIFEST_PATH)) {
    logger.warn('[integrity] SKILLS.lock not found. Running in unverified mode.');
    return { tampered: false, modified: [], missing: [], added: [], unverified: true };
  }

  let saved;
  try {
    saved = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
  } catch {
    return { tampered: true, modified: ['SKILLS.lock corrupted'], missing: [], added: [] };
  }

  const current = buildManifest();
  const savedSkills = saved.skills || {};

  const modified = [];
  const missing = [];
  const added = [];

  for (const [file, hash] of Object.entries(savedSkills)) {
    if (!current[file]) {
      missing.push(file);
    } else if (current[file] !== hash) {
      modified.push(file);
    }
  }

  for (const file of Object.keys(current)) {
    if (!savedSkills[file]) {
      added.push(file);
    }
  }

  const tampered = modified.length > 0 || missing.length > 0;
  return { tampered, modified, missing, added, unverified: false };
}

// CLI usage: node src/core/skill-integrity.js generate
if (process.argv[2] === 'generate') {
  generateManifest().then(() => process.exit(0));
}
