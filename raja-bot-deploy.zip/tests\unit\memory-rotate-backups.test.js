import { describe, it, expect, vi, beforeEach } from 'vitest';

/**
 * **Validates: Requirements 7.4**
 * Unit tests for rotateBackups() logic
 * 
 * Tests verify:
 * - Keeps max 7 backup files (the newest ones)
 * - Deletes oldest files when count exceeds 7
 * - Does nothing if backup directory doesn't exist
 * - Does nothing if 7 or fewer backups exist
 * - Only considers files matching memory_*.db pattern
 * - Handles deletion errors gracefully
 */

const mockExistsSync = vi.fn(() => true);
const mockReaddirSync = vi.fn(() => []);
const mockUnlinkSync = vi.fn();

vi.mock('fs', () => ({
  default: {
    existsSync: (...args) => mockExistsSync(...args),
    readdirSync: (...args) => mockReaddirSync(...args),
    unlinkSync: (...args) => mockUnlinkSync(...args),
    mkdirSync: vi.fn(),
    copyFileSync: vi.fn(),
  },
  existsSync: (...args) => mockExistsSync(...args),
  readdirSync: (...args) => mockReaddirSync(...args),
  unlinkSync: (...args) => mockUnlinkSync(...args),
  mkdirSync: vi.fn(),
  copyFileSync: vi.fn(),
}));

vi.mock('../../src/config.js', () => ({
  config: {
    raja: {
      dataDir: '/opt/raja-bot/data',
      backupDir: '/opt/raja-bot/data/backups',
    },
    memory: {
      retentionDays: 30,
    },
  },
}));

vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  },
}));

vi.mock('better-sqlite3', () => ({
  default: vi.fn(),
}));

const { rotateBackups } = await import('../../src/core/memory.js');

describe('rotateBackups — simpan max 7, hapus terlama', () => {

  beforeEach(() => {
    vi.clearAllMocks();
    mockExistsSync.mockReturnValue(true);
  });

  it('should do nothing if backup directory does not exist', () => {
    mockExistsSync.mockReturnValue(false);
    
    rotateBackups();
    
    expect(mockReaddirSync).not.toHaveBeenCalled();
    expect(mockUnlinkSync).not.toHaveBeenCalled();
  });

  it('should do nothing if 7 or fewer backup files exist', () => {
    mockReaddirSync.mockReturnValue([
      'memory_20250601_030000.db',
      'memory_20250602_030000.db',
      'memory_20250603_030000.db',
      'memory_20250604_030000.db',
      'memory_20250605_030000.db',
      'memory_20250606_030000.db',
      'memory_20250607_030000.db',
    ]);
    
    rotateBackups();
    
    expect(mockUnlinkSync).not.toHaveBeenCalled();
  });

  it('should do nothing if fewer than 7 backups exist', () => {
    mockReaddirSync.mockReturnValue([
      'memory_20250601_030000.db',
      'memory_20250602_030000.db',
      'memory_20250603_030000.db',
    ]);
    
    rotateBackups();
    
    expect(mockUnlinkSync).not.toHaveBeenCalled();
  });

  it('should delete oldest files when more than 7 backups exist', () => {
    mockReaddirSync.mockReturnValue([
      'memory_20250601_030000.db',
      'memory_20250602_030000.db',
      'memory_20250603_030000.db',
      'memory_20250604_030000.db',
      'memory_20250605_030000.db',
      'memory_20250606_030000.db',
      'memory_20250607_030000.db',
      'memory_20250608_030000.db',
      'memory_20250609_030000.db',
      'memory_20250610_030000.db',
    ]);
    
    rotateBackups();
    
    // 10 files - 7 kept = 3 deleted (the oldest ones)
    expect(mockUnlinkSync).toHaveBeenCalledTimes(3);
  });

  it('should keep the 7 newest backups (sorted by filename desc)', () => {
    const files = [
      'memory_20250601_030000.db', // oldest - should be deleted
      'memory_20250602_030000.db', // should be deleted
      'memory_20250603_030000.db',
      'memory_20250604_030000.db',
      'memory_20250605_030000.db',
      'memory_20250606_030000.db',
      'memory_20250607_030000.db',
      'memory_20250608_030000.db',
      'memory_20250609_030000.db',
    ];
    
    mockReaddirSync.mockReturnValue(files);
    
    rotateBackups();
    
    // 9 - 7 = 2 files deleted (the 2 oldest)
    expect(mockUnlinkSync).toHaveBeenCalledTimes(2);
    
    // Verify the deleted files are the 2 oldest ones (order: slice from sorted-desc array)
    // After sort desc: [09,08,07,06,05,04,03,02,01] → slice(7) = [02,01]
    const deletedPaths = mockUnlinkSync.mock.calls.map(c => c[0]);
    expect(deletedPaths.some(p => p.includes('memory_20250601_030000.db'))).toBe(true);
    expect(deletedPaths.some(p => p.includes('memory_20250602_030000.db'))).toBe(true);
  });

  it('should only consider files matching memory_*.db pattern', () => {
    mockReaddirSync.mockReturnValue([
      'memory_20250601_030000.db',
      'memory_20250602_030000.db',
      'memory_20250603_030000.db',
      'memory_20250604_030000.db',
      'memory_20250605_030000.db',
      'memory_20250606_030000.db',
      'memory_20250607_030000.db',
      'memory_20250608_030000.db',
      'other_file.db',         // not a memory backup
      'memory_something.txt',  // wrong extension
      'backup_20250609.db',    // wrong prefix
    ]);
    
    rotateBackups();
    
    // Only 8 memory_*.db files → delete 1 (oldest)
    expect(mockUnlinkSync).toHaveBeenCalledTimes(1);
    const deletedPath = mockUnlinkSync.mock.calls[0][0];
    expect(deletedPath).toContain('memory_20250601_030000.db');
  });

  it('should handle deletion errors gracefully without stopping rotation', () => {
    mockReaddirSync.mockReturnValue([
      'memory_20250601_030000.db',
      'memory_20250602_030000.db',
      'memory_20250603_030000.db',
      'memory_20250604_030000.db',
      'memory_20250605_030000.db',
      'memory_20250606_030000.db',
      'memory_20250607_030000.db',
      'memory_20250608_030000.db',
      'memory_20250609_030000.db',
    ]);
    
    // First deletion fails, second succeeds
    mockUnlinkSync.mockImplementationOnce(() => {
      throw new Error('EACCES: permission denied');
    });
    
    rotateBackups();
    
    // Should still attempt to delete both files despite first failure
    expect(mockUnlinkSync).toHaveBeenCalledTimes(2);
  });

  it('should delete exactly (N - 7) files when N > 7', () => {
    // 12 files total → delete 5
    const files = Array.from({ length: 12 }, (_, i) => {
      const day = String(i + 1).padStart(2, '0');
      return `memory_202506${day}_030000.db`;
    });
    
    mockReaddirSync.mockReturnValue(files);
    
    rotateBackups();
    
    expect(mockUnlinkSync).toHaveBeenCalledTimes(5);
  });

  it('should use config.raja.backupDir as the backup directory', () => {
    mockReaddirSync.mockReturnValue([]);
    
    rotateBackups();
    
    expect(mockExistsSync).toHaveBeenCalledWith('/opt/raja-bot/data/backups');
  });
});
