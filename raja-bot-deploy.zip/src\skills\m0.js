// src/skills/m0.js — Skill registry display, reflection loop, self-management
import { SKILL_KEYWORDS, skills } from '../core/skill-registry.js';
import { logger } from '../utils/logger.js';

// ─── Intent Detection ────────────────────────────────────────────────────────

const LIST_PATTERNS = [
  /^skills?$/i,
  /^daftar\s+skill/i,
  /^skill\s+list/i,
  /^kemampuan$/i,
  /^apa\s+(aja\s+)?skill/i,
  /^list\s+skills?/i,
  /^lihat\s+skill/i,
  /^modul\s+apa/i,
  /^bisa\s+apa\s+aja/i,
  /(?:daftar|list|lihat)\s*(?:skill|modul|kemampuan)/i,
  /skills?\s*(?:apa|list|daftar)/i,
  /^show\s+skills?/i,
];

/**
 * Detect whether user wants skill list or has a question about skills.
 * @param {string} query
 * @returns {'LIST' | 'OTHER'}
 */
function detectRegistryIntent(query) {
  const trimmed = query.trim();
  for (const pattern of LIST_PATTERNS) {
    if (pattern.test(trimmed)) return 'LIST';
  }
  return 'OTHER';
}

// ─── Skill List Formatter ────────────────────────────────────────────────────

/**
 * Format skill list from the LIVE registry (includes dynamic skills).
 * Uses `skills` object (populated after initSkillRegistry) as primary source,
 * falls back to SKILL_KEYWORDS for skills without loaded modules.
 * @returns {string} - Telegram Markdown formatted string
 */
function formatSkillList() {
  // Merge: SKILL_KEYWORDS (hardcoded) + skills (runtime, includes auto-discovered)
  const allSkills = {};

  // 1. Start with SKILL_KEYWORDS
  for (const [id, meta] of Object.entries(SKILL_KEYWORDS)) {
    allSkills[id] = { id, name: meta.name || id };
  }

  // 2. Override/add from runtime skills object (includes dynamic skills like crypto-ta, cc-gen)
  for (const [id, skill] of Object.entries(skills)) {
    allSkills[id] = { id, name: skill.name || skill.module?.name || id };
  }

  // Group by prefix
  const groups = { m: [], x: [], H: [], C: [], other: [] };

  for (const [id, meta] of Object.entries(allSkills)) {
    // Determine category from id prefix
    if (id.startsWith('H') || id.startsWith('h')) {
      groups.H.push(meta);
    } else if (id.startsWith('m') && /^m\d/.test(id)) {
      groups.m.push(meta);
    } else if (id.startsWith('x') && /^x\d/.test(id)) {
      groups.x.push(meta);
    } else if (id.startsWith('C') || id.startsWith('c')) {
      groups.C.push(meta);
    } else {
      groups.other.push(meta);
    }
  }

  // Sort each group by numeric suffix (or alphabetically for non-numeric)
  for (const key of Object.keys(groups)) {
    groups[key].sort((a, b) => {
      const numA = parseInt(a.id.replace(/\D/g, ''), 10);
      const numB = parseInt(b.id.replace(/\D/g, ''), 10);
      if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
      return a.id.localeCompare(b.id);
    });
  }

  const categoryMeta = {
    m: '🔧 *Main Modules*',
    x: '🧪 *Experimental*',
    H: '⛓️ *Hermes / Crypto*',
    C: '📊 *Crypto Analysis*',
    other: '📦 *Tools & Extras*',
  };

  let output = '📋 *RAJA SKILLS REGISTRY (v4.1 IRONCLAW)*\n\n';

  for (const [prefix, label] of Object.entries(categoryMeta)) {
    if (!groups[prefix] || groups[prefix].length === 0) continue;
    output += `${label}\n`;
    for (const skill of groups[prefix]) {
      output += `• ${skill.id}: ${skill.name}\n`;
    }
    output += '\n';
  }

  const total = Object.keys(allSkills).length;
  output += `Total: ${total} skills | Status: All modules ONLINE.\n`;
  output += `\nKetik kode skill (contoh: m10) atau kasih perintah langsung.`;

  return output;
}

// ─── Skill Module Export ─────────────────────────────────────────────────────

export default {
  id: 'm0',
  name: 'registry',
  description: 'Skill registry display, system reflection, and self-management operations',

  async execute(query, context) {
    // 1. Detect intent
    const intent = detectRegistryIntent(query);

    if (intent === 'LIST') {
      try {
        return formatSkillList();
      } catch (err) {
        logger.error(`[m0] Failed to format skill list: ${err.message}`);
        return '❌ Gagal memuat daftar skill. Coba lagi.';
      }
    }

    // 2. Fallback: questions about skills → LLM
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Skill aktif: m0 (Registry & Reflection).
Bantu operator dengan:
- Jelaskan fungsi skill tertentu (m0–m29, x1–x7, H1–H10)
- Rekomendasi skill yang tepat untuk suatu task
- Info tentang routing dan keyword matching
- Trigger reflection manual
- Audit kondisi sistem secara ringkas

Skill yang tersedia (${Object.keys(skills).length} total):
${Object.entries(skills).map(([id, s]) => `${id}: ${s.name}`).join(', ')}

Jawab konkret, langsung. Jangan list semua skill kecuali diminta.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.5 });
      return result.text;
    } catch (err) {
      logger.error(`[m0] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan: ${err.message}`;
    }
  },
};
