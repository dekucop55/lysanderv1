// tests/pbt/preference-conflict.test.js
// Property-Based Test: Property 16 — Preferensi Conflict Resolution
// **Validates: Requirements 5.4**
//
// Property 16: *For any* preferensi baru dengan key K yang sudah ada di database
// untuk user yang sama, `preference_value` SHALL diupdate ke nilai baru,
// `confidence` ke nilai sumber baru, dan `last_updated` ke timestamp saat ini.
// Tidak ada duplikasi key per user.

import { describe, it, expect, beforeEach } from 'vitest';
import * as fc from 'fast-check';

// === Mock DB layer (mirrors real SQLite UPSERT behavior in memory.js) ===

class MockPreferenceDB {
  constructor() {
    this.rows = [];
    this.nextId = 1;
  }

  clear() {
    this.rows = [];
    this.nextId = 1;
  }

  findByUserAndKey(userId, key) {
    return this.rows.find(r => r.user_id === userId && r.preference_key === key) || null;
  }

  countByUser(userId) {
    return this.rows.filter(r => r.user_id === userId).length;
  }

  findLowestConfidence(userId) {
    const userRows = this.rows.filter(r => r.user_id === userId);
    if (userRows.length === 0) return null;
    userRows.sort((a, b) => a.confidence - b.confidence || a.last_updated.localeCompare(b.last_updated));
    return userRows[0];
  }

  insert(row) {
    const newRow = { ...row, id: this.nextId++ };
    this.rows.push(newRow);
    return newRow.id;
  }

  update(id, fields) {
    const idx = this.rows.findIndex(r => r.id === id);
    if (idx >= 0) {
      this.rows[idx] = { ...this.rows[idx], ...fields };
    }
  }

  getAllForUser(userId) {
    return this.rows.filter(r => r.user_id === userId);
  }
}

const MAX_PREFERENCES_PER_USER = 50;

let mockDb;

/**
 * savePreference — mirrors the real implementation logic in src/core/memory.js
 */
function savePreference({ userId, key, value, confidence, source = null }) {
  if (!userId || !key || value === undefined || value === null) {
    throw new Error('savePreference requires userId, key, and value');
  }

  const safeKey = String(key).slice(0, 64);
  const safeValue = String(value).slice(0, 256);
  const safeConfidence = Math.max(0, Math.min(1, Number(confidence) || 0));
  const now = new Date().toISOString();

  const existing = mockDb.findByUserAndKey(userId, safeKey);

  if (existing) {
    // UPSERT: update existing preference — Requirement 5.4
    mockDb.update(existing.id, {
      preference_value: safeValue,
      confidence: safeConfidence,
      last_updated: now,
      source_message_id: source
    });
    return existing.id;
  }

  const count = mockDb.countByUser(userId);

  if (count >= MAX_PREFERENCES_PER_USER) {
    const lowest = mockDb.findLowestConfidence(userId);
    if (lowest) {
      mockDb.update(lowest.id, {
        preference_key: safeKey,
        preference_value: safeValue,
        confidence: safeConfidence,
        last_updated: now,
        source_message_id: source
      });
      return lowest.id;
    }
  }

  return mockDb.insert({
    user_id: userId,
    preference_key: safeKey,
    preference_value: safeValue,
    confidence: safeConfidence,
    last_updated: now,
    source_message_id: source
  });
}

// === Generators (compatible with fast-check v4) ===

/** Generate valid user IDs */
const userIdArb = fc.string({ minLength: 1, maxLength: 20, unit: 'grapheme' })
  .filter(s => /^[a-zA-Z0-9]+$/.test(s));

/** Generate valid preference keys (1-64 chars, non-empty alphanumeric with underscores) */
const prefKeyArb = fc.constantFrom(
  'language', 'theme', 'format', 'timezone', 'currency',
  'response_style', 'code_lang', 'notification', 'greeting',
  'output_format', 'detail_level', 'preferred_chain',
  'swap_slippage', 'gas_limit', 'default_token',
  'alert_threshold', 'backup_freq', 'log_level'
);

/** Generate valid preference values */
const prefValueArb = fc.constantFrom(
  'python', 'javascript', 'typescript', 'rust', 'golang',
  'dark', 'light', 'auto', 'json', 'yaml', 'markdown',
  'concise', 'detailed', 'bullet_points', 'step_by_step',
  'bahasa', 'english', '0.5', '1.0', '100', 'high', 'low',
  'ethereum', 'polygon', 'arbitrum', 'bsc', 'solana'
);

/** Generate valid confidence (0.0 to 1.0) */
const confidenceArb = fc.double({ min: 0, max: 1, noNaN: true });

// === Property Tests ===

describe('Property 16: Preferensi Conflict Resolution', () => {
  beforeEach(() => {
    mockDb = new MockPreferenceDB();
  });

  it('on conflict (same user+key): value updated to new value', () => {
    // **Validates: Requirements 5.4**
    fc.assert(
      fc.property(
        userIdArb,
        prefKeyArb,
        prefValueArb,
        confidenceArb,
        prefValueArb,
        confidenceArb,
        (userId, key, value1, confidence1, value2, confidence2) => {
          mockDb.clear();

          // Step 1: Save initial preference
          const id1 = savePreference({ userId, key, value: value1, confidence: confidence1 });

          // Verify initial save
          const afterFirst = mockDb.findByUserAndKey(userId, key);
          expect(afterFirst).not.toBeNull();
          expect(afterFirst.preference_value).toBe(String(value1).slice(0, 256));

          // Step 2: Save conflicting preference (same user, same key, different value)
          const id2 = savePreference({ userId, key, value: value2, confidence: confidence2 });

          // Property: Same ID returned (upsert, not insert)
          expect(id2).toBe(id1);

          // Property: Updated record has new value
          const updated = mockDb.findByUserAndKey(userId, key);
          expect(updated.preference_value).toBe(String(value2).slice(0, 256));
        }
      ),
      { numRuns: 200 }
    );
  });

  it('on conflict: confidence updated to new source confidence', () => {
    // **Validates: Requirements 5.4**
    fc.assert(
      fc.property(
        userIdArb,
        prefKeyArb,
        prefValueArb,
        confidenceArb,
        prefValueArb,
        confidenceArb,
        (userId, key, value1, confidence1, value2, confidence2) => {
          mockDb.clear();

          // Save initial preference
          savePreference({ userId, key, value: value1, confidence: confidence1 });

          // Save conflicting preference (same key)
          savePreference({ userId, key, value: value2, confidence: confidence2 });

          // Property: confidence updated to new source's value (clamped [0,1])
          const updated = mockDb.findByUserAndKey(userId, key);
          const expectedConfidence = Math.max(0, Math.min(1, Number(confidence2) || 0));
          expect(updated.confidence).toBe(expectedConfidence);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('on conflict: last_updated refreshed to current time', () => {
    // **Validates: Requirements 5.4**
    fc.assert(
      fc.property(
        userIdArb,
        prefKeyArb,
        prefValueArb,
        confidenceArb,
        prefValueArb,
        confidenceArb,
        (userId, key, value1, confidence1, value2, confidence2) => {
          mockDb.clear();

          // Save initial preference
          savePreference({ userId, key, value: value1, confidence: confidence1 });

          const timeBefore = new Date().toISOString();

          // Save conflicting preference (same key)
          savePreference({ userId, key, value: value2, confidence: confidence2 });

          const timeAfter = new Date().toISOString();

          // Property: last_updated is refreshed to current time
          const updated = mockDb.findByUserAndKey(userId, key);
          expect(updated.last_updated >= timeBefore).toBe(true);
          expect(updated.last_updated <= timeAfter).toBe(true);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('no duplicate keys per user after any number of upserts', () => {
    // **Validates: Requirements 5.4**
    fc.assert(
      fc.property(
        userIdArb,
        prefKeyArb,
        fc.array(fc.tuple(prefValueArb, confidenceArb), { minLength: 2, maxLength: 10 }),
        (userId, key, updates) => {
          mockDb.clear();

          let lastId = null;

          // Apply all updates sequentially
          for (const [value, confidence] of updates) {
            const id = savePreference({ userId, key, value, confidence });
            if (lastId !== null) {
              // After first insert, all subsequent saves should return same ID
              expect(id).toBe(lastId);
            }
            lastId = id;
          }

          // After all updates, there should be exactly one record for this (userId, key)
          const allForUser = mockDb.getAllForUser(userId);
          const matchingKey = allForUser.filter(r => r.preference_key === String(key).slice(0, 64));
          expect(matchingKey.length).toBe(1);

          // The final value should be from the last update
          const [lastValue, lastConfidence] = updates[updates.length - 1];
          const final = mockDb.findByUserAndKey(userId, String(key).slice(0, 64));
          expect(final.preference_value).toBe(String(lastValue).slice(0, 256));
          expect(final.confidence).toBe(Math.max(0, Math.min(1, Number(lastConfidence) || 0)));
        }
      ),
      { numRuns: 200 }
    );
  });
});
