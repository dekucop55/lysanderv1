// src/core/memory.js — Compounding memory engine + Conversation Store
import Database from 'better-sqlite3';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import path from 'path';
import fs from 'fs';

let db;

// === In-Memory Write Buffer for DB write failures ===
const writeBuffer = [];
const WRITE_BUFFER_MAX = 100;
let retryTimer = null;
let retryCount = 0;
const MAX_RETRIES = 3;
const RETRY_INTERVAL_MS = 5000;

export async function initMemory() {
  const dbPath = config.raja.dataDir + '/memory.db';
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  
  // Original memories table
  db.exec(`
    CREATE TABLE IF NOT EXISTS memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts REAL NOT NULL,
      kind TEXT NOT NULL,
      tags TEXT,
      content TEXT NOT NULL,
      weight REAL DEFAULT 1.0,
      uses INTEGER DEFAULT 0
    );
    CREATE INDEX IF NOT EXISTS idx_kind ON memories(kind);
    CREATE INDEX IF NOT EXISTS idx_ts ON memories(ts);
  `);

  // Conversation history table (Task 1.1)
  db.exec(`
    CREATE TABLE IF NOT EXISTS conversation_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
      content TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      session_id TEXT NOT NULL,
      intent_classified TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_conv_history_user_ts ON conversation_history(user_id, timestamp DESC);
    CREATE INDEX IF NOT EXISTS idx_conv_history_session ON conversation_history(session_id);
  `);

  // Conversation archive table (Task 1.1)
  db.exec(`
    CREATE TABLE IF NOT EXISTS conversation_archive (
      id INTEGER PRIMARY KEY,
      user_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      timestamp TEXT NOT NULL,
      session_id TEXT NOT NULL,
      intent_classified TEXT,
      archived_at TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_conv_archive_user ON conversation_archive(user_id);
  `);

  // User preferences table (Task 1.1)
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      preference_key TEXT NOT NULL,
      preference_value TEXT NOT NULL,
      confidence REAL NOT NULL DEFAULT 1.0,
      last_updated TEXT NOT NULL,
      source_message_id TEXT,
      UNIQUE(user_id, preference_key)
    );
    CREATE INDEX IF NOT EXISTS idx_user_prefs_user ON user_preferences(user_id, confidence DESC);
  `);

  // Push log table (Task 1.1)
  db.exec(`
    CREATE TABLE IF NOT EXISTS push_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('success', 'failed', 'skipped')),
      code_files INTEGER DEFAULT 0,
      data_files INTEGER DEFAULT 0,
      error_message TEXT,
      retry_count INTEGER DEFAULT 0
    );
  `);
  
  logger.info(`Memory DB ready: ${dbPath}`);

  // Auto-compact old memories on boot
  try {
    const compacted = await compactOldMemory();
    if (compacted > 0) logger.info(`Boot compact: ${compacted} old memories pruned`);
  } catch (e) {
    logger.warn(`Memory compact on boot failed (non-critical): ${e.message}`);
  }
}

// === Conversation Store Functions (Tasks 1.2 - 1.5) ===

const MAX_CONTENT_LENGTH = 65535;

/**
 * Menyimpan pesan ke conversation_history (Task 1.2)
 * Content di-truncate pada 65.535 karakter jika melebihi batas.
 * Implements WriteBuffer (in-memory max 100 msg) untuk handle write failure.
 * Retry mekanisme: 3x percobaan dengan interval 5 detik.
 * 
 * @param {Object} message
 * @param {string} message.userId
 * @param {'user'|'assistant'} message.role
 * @param {string} message.content - Max 65535 chars, truncated if exceeded
 * @param {string} message.sessionId
 * @param {string} [message.intentClassified]
 * @returns {number|null} Message ID or null if buffered
 */
export function saveMessage({ userId, role, content, sessionId, intentClassified = null }) {
  // Truncate content at 65535 characters
  const truncatedContent = content && content.length > MAX_CONTENT_LENGTH
    ? content.substring(0, MAX_CONTENT_LENGTH)
    : content;

  const timestamp = new Date().toISOString();

  try {
    const stmt = db.prepare(`
      INSERT INTO conversation_history (user_id, role, content, timestamp, session_id, intent_classified)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const result = stmt.run(userId, role, truncatedContent, timestamp, sessionId, intentClassified);
    
    // Flush any buffered messages on successful write
    if (writeBuffer.length > 0) {
      flushWriteBuffer();
    }
    
    return result.lastInsertRowid;
  } catch (err) {
    logger.error(`saveMessage failed: ${err.message}`);
    // Buffer the message for retry
    bufferMessage({ userId, role, content: truncatedContent, timestamp, sessionId, intentClassified });
    return null;
  }
}

/**
 * Buffer message when DB write fails (Task 1.2)
 */
function bufferMessage(message) {
  if (writeBuffer.length >= WRITE_BUFFER_MAX) {
    writeBuffer.shift(); // Drop oldest if buffer full
  }
  writeBuffer.push(message);
  
  // Start retry timer if not already running
  if (!retryTimer) {
    retryCount = 0;
    scheduleRetry();
  }
}

function scheduleRetry() {
  if (retryCount >= MAX_RETRIES) {
    logger.error(`Write buffer retry exhausted after ${MAX_RETRIES} attempts. ${writeBuffer.length} messages remain buffered.`);
    retryTimer = null;
    retryCount = 0;
    return;
  }
  
  retryTimer = setTimeout(() => {
    retryCount++;
    flushWriteBuffer();
  }, RETRY_INTERVAL_MS);
}

function flushWriteBuffer() {
  const toFlush = [...writeBuffer];
  let flushed = 0;
  
  for (const msg of toFlush) {
    try {
      const stmt = db.prepare(`
        INSERT INTO conversation_history (user_id, role, content, timestamp, session_id, intent_classified)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      stmt.run(msg.userId, msg.role, msg.content, msg.timestamp, msg.sessionId, msg.intentClassified);
      writeBuffer.shift();
      flushed++;
    } catch (err) {
      // Stop flushing on first failure, schedule next retry
      logger.warn(`Write buffer flush failed: ${err.message}. ${writeBuffer.length} messages remaining.`);
      scheduleRetry();
      return;
    }
  }
  
  if (flushed > 0) {
    logger.info(`Write buffer flushed: ${flushed} messages written`);
  }
  
  retryTimer = null;
  retryCount = 0;
}

/**
 * Mengambil N pesan terakhir untuk user (Task 1.3)
 * Jika limit > 1000, gunakan 1000.
 * Return pesan terurut timestamp ASC.
 * 
 * @param {string} userId
 * @param {number} [limit=50] - Max 1000, capped if exceeded
 * @returns {Object[]} Messages sorted by timestamp ASC
 */
export function getRecentHistory(userId, limit = 50) {
  // Cap limit: minimum 1, maximum 1000
  const cappedLimit = Math.min(Math.max(limit, 1), 1000);
  
  const stmt = db.prepare(`
    SELECT * FROM conversation_history
    WHERE user_id = ?
    ORDER BY timestamp DESC
    LIMIT ?
  `);
  
  const messages = stmt.all(userId, cappedLimit);
  // Return sorted ASC (oldest first)
  return messages.reverse();
}

/**
 * Memuat ulang session setelah restart — 50 pesan terakhir per user (Task 1.4)
 * Dipanggil saat PM2 restart. Target: selesai dalam < 2 detik.
 * 
 * @param {string} userId
 * @returns {Object[]}
 */
export function loadSessionOnRestart(userId) {
  return getRecentHistory(userId, 50);
}

/**
 * Cek dan jalankan archival jika threshold terlampaui (Task 1.5)
 * 
 * Requirements:
 * - 3.4: WHEN riwayat > 10.000 pesan, archival memindahkan pesan > 30 hari ke conversation_archive
 * - 3.7: IF archival gagal, THEN rollback tanpa hapus dari history, log error, retry pada pengecekan berikutnya
 * 
 * Logic:
 * 1. Check if user has > 10,000 messages in conversation_history
 * 2. Move messages older than 30 days to conversation_archive
 * 3. Use transaction — rollback if anything fails (don't delete from history if archive insert fails)
 * 4. Log errors if archival fails, retry on next threshold check
 * 
 * @param {string} userId
 * @returns {{archived: number, remaining: number}}
 */
export function checkAndArchive(userId) {
  try {
    // Step 1: Check if user has > 10,000 messages
    const countStmt = db.prepare(
      'SELECT COUNT(*) as total FROM conversation_history WHERE user_id = ?'
    );
    const { total } = countStmt.get(userId);

    if (total <= 10000) {
      return { archived: 0, remaining: total };
    }

    // Step 2: Calculate the 30-day cutoff (ISO 8601 format)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

    // Step 3: Count messages eligible for archival (older than 30 days)
    const eligibleStmt = db.prepare(
      'SELECT COUNT(*) as count FROM conversation_history WHERE user_id = ? AND timestamp < ?'
    );
    const { count: eligibleCount } = eligibleStmt.get(userId, thirtyDaysAgo);

    if (eligibleCount === 0) {
      return { archived: 0, remaining: total };
    }

    // Step 4: Use transaction — rollback if anything fails
    const archiveTransaction = db.transaction(() => {
      // Insert old messages into conversation_archive
      const insertStmt = db.prepare(`
        INSERT INTO conversation_archive (id, user_id, role, content, timestamp, session_id, intent_classified)
        SELECT id, user_id, role, content, timestamp, session_id, intent_classified
        FROM conversation_history
        WHERE user_id = ? AND timestamp < ?
      `);
      const insertResult = insertStmt.run(userId, thirtyDaysAgo);

      // Delete archived messages from conversation_history
      const deleteStmt = db.prepare(
        'DELETE FROM conversation_history WHERE user_id = ? AND timestamp < ?'
      );
      const deleteResult = deleteStmt.run(userId, thirtyDaysAgo);

      // Verify consistency: inserted count must match deleted count
      if (insertResult.changes !== deleteResult.changes) {
        throw new Error(
          `Archival mismatch: inserted ${insertResult.changes} but deleted ${deleteResult.changes}`
        );
      }

      return insertResult.changes;
    });

    // Execute the transaction
    const archivedCount = archiveTransaction();

    // Get remaining count after archival
    const { total: remaining } = countStmt.get(userId);

    logger.info(`[ARCHIVE] userId=${userId} archived=${archivedCount} remaining=${remaining}`);
    return { archived: archivedCount, remaining };

  } catch (err) {
    // Requirement 3.7: Log error, do not delete from history, retry on next threshold check
    // Transaction auto-rollback ensures no data loss
    logger.error(`[ARCHIVE] Archival failed for userId=${userId}: ${err.message}`);
    
    // Return 0 archived — transaction was rolled back, history is intact
    // Retry will happen on the next call to checkAndArchive (next threshold check)
    let remaining = 0;
    try {
      const countStmt = db.prepare(
        'SELECT COUNT(*) as total FROM conversation_history WHERE user_id = ?'
      );
      remaining = countStmt.get(userId)?.total || 0;
    } catch (_) {
      // If we can't even count, something is very wrong with DB
    }
    return { archived: 0, remaining };
  }
}

// === Backup & Integrity Functions ===

/**
 * Backup memory.db ke data/backups/memory_{timestamp}.db
 * Format timestamp: YYYYMMDD_HHmmss
 * Called before each auto-push.
 * 
 * Requirements: 7.2
 * 
 * @returns {string} Path file backup yang dibuat
 */
export function createBackup() {
  const dbPath = config.raja.dataDir + '/memory.db';
  const backupDir = config.raja.dataDir + '/backups';
  
  // Ensure backup directory exists
  fs.mkdirSync(backupDir, { recursive: true });
  
  // Format timestamp: YYYYMMDD_HHmmss
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  const formattedTs = `${year}${month}${day}_${hours}${minutes}${seconds}`;
  
  const backupPath = path.join(backupDir, `memory_${formattedTs}.db`);
  
  // Copy database file (fs.copyFileSync is atomic enough for SQLite WAL)
  fs.copyFileSync(dbPath, backupPath);
  
  logger.info(`[BACKUP] Created backup: ${backupPath}`);
  return backupPath;
}

/**
 * Jalankan PRAGMA integrity_check pada database (Task 10.2)
 * Buka DB dalam readonly mode, jalankan pragma, tutup.
 * 
 * Requirements: 7.3, 7.5
 * 
 * @param {string} dbPath - Path to database file
 * @returns {boolean} true if integrity check passes
 */
export function checkIntegrity(dbPath) {
  try {
    if (!fs.existsSync(dbPath)) {
      logger.error(`[INTEGRITY] File not found: ${dbPath}`);
      return false;
    }
    const testDb = new Database(dbPath, { readonly: true });
    const result = testDb.pragma('integrity_check');
    testDb.close();
    return result[0]?.integrity_check === 'ok';
  } catch (err) {
    logger.error(`[INTEGRITY] Check failed for ${dbPath}: ${err.message}`);
    return false;
  }
}

/**
 * Restore dari backup terbaru yang valid (Task 10.2)
 * Tries backups from newest to oldest. Uses first one that passes integrity_check.
 * If all fail: creates empty database with full schema, notifies owner.
 * If restore succeeds: notifies owner with backup timestamp used.
 * 
 * Requirements: 7.3, 7.5, 7.6
 * 
 * @returns {{success: boolean, backupUsed: string|null}}
 */
export function restoreFromBackup() {
  const dbPath = config.raja.dataDir + '/memory.db';
  const backupDir = config.raja.backupDir || (config.raja.dataDir + '/backups');
  
  // Get backup files sorted newest first
  if (!fs.existsSync(backupDir)) {
    logger.error('[RESTORE] No backup directory found');
    createEmptyDatabase(dbPath);
    notifyOwnerRestore({ success: false, backupUsed: null });
    return { success: false, backupUsed: null };
  }
  
  const backupFiles = fs.readdirSync(backupDir)
    .filter(f => f.startsWith('memory_') && f.endsWith('.db'))
    .sort((a, b) => b.localeCompare(a)); // Newest first by timestamp in filename
  
  if (backupFiles.length === 0) {
    logger.error('[RESTORE] No backup files available');
    createEmptyDatabase(dbPath);
    notifyOwnerRestore({ success: false, backupUsed: null });
    return { success: false, backupUsed: null };
  }
  
  // Try each backup from newest to oldest
  for (const backupFile of backupFiles) {
    const backupPath = path.join(backupDir, backupFile);
    
    if (checkIntegrity(backupPath)) {
      // Copy backup to main database path
      fs.copyFileSync(backupPath, dbPath);
      logger.info(`[RESTORE] Database restored from: ${backupFile}`);
      notifyOwnerRestore({ success: true, backupUsed: backupFile });
      return { success: true, backupUsed: backupFile };
    }
    
    logger.warn(`[RESTORE] Backup failed integrity check: ${backupFile}`);
  }
  
  // All backups failed integrity check
  logger.error('[RESTORE] All backups failed integrity check, creating empty database');
  createEmptyDatabase(dbPath);
  notifyOwnerRestore({ success: false, backupUsed: null });
  return { success: false, backupUsed: null };
}

/**
 * Create a fresh empty database with full schema (same as initMemory).
 * Used as last resort when all backups fail.
 * 
 * @param {string} dbPath - Path for the new database
 */
function createEmptyDatabase(dbPath) {
  try {
    // Ensure directory exists
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    
    // Remove corrupt file if exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const freshDb = new Database(dbPath);
    freshDb.pragma('journal_mode = WAL');
    
    // All tables from initMemory
    freshDb.exec(`
      CREATE TABLE IF NOT EXISTS memories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts REAL NOT NULL,
        kind TEXT NOT NULL,
        tags TEXT,
        content TEXT NOT NULL,
        weight REAL DEFAULT 1.0,
        uses INTEGER DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_kind ON memories(kind);
      CREATE INDEX IF NOT EXISTS idx_ts ON memories(ts);
    `);

    freshDb.exec(`
      CREATE TABLE IF NOT EXISTS conversation_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
        content TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        session_id TEXT NOT NULL,
        intent_classified TEXT,
        created_at TEXT DEFAULT (datetime('now'))
      );
      CREATE INDEX IF NOT EXISTS idx_conv_history_user_ts ON conversation_history(user_id, timestamp DESC);
      CREATE INDEX IF NOT EXISTS idx_conv_history_session ON conversation_history(session_id);
    `);

    freshDb.exec(`
      CREATE TABLE IF NOT EXISTS conversation_archive (
        id INTEGER PRIMARY KEY,
        user_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        session_id TEXT NOT NULL,
        intent_classified TEXT,
        archived_at TEXT DEFAULT (datetime('now'))
      );
      CREATE INDEX IF NOT EXISTS idx_conv_archive_user ON conversation_archive(user_id);
    `);

    freshDb.exec(`
      CREATE TABLE IF NOT EXISTS user_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        preference_key TEXT NOT NULL,
        preference_value TEXT NOT NULL,
        confidence REAL NOT NULL DEFAULT 1.0,
        last_updated TEXT NOT NULL,
        source_message_id TEXT,
        UNIQUE(user_id, preference_key)
      );
      CREATE INDEX IF NOT EXISTS idx_user_prefs_user ON user_preferences(user_id, confidence DESC);
    `);

    freshDb.exec(`
      CREATE TABLE IF NOT EXISTS push_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('success', 'failed', 'skipped')),
        code_files INTEGER DEFAULT 0,
        data_files INTEGER DEFAULT 0,
        error_message TEXT,
        retry_count INTEGER DEFAULT 0
      );
    `);

    freshDb.close();
    logger.info(`[RESTORE] Created fresh empty database at: ${dbPath}`);
  } catch (err) {
    logger.error(`[RESTORE] Failed to create empty database: ${err.message}`);
  }
}

/**
 * Send notification to owner about restore result via Telegram.
 * Non-blocking — notification failure doesn't affect restore flow.
 * 
 * @param {{success: boolean, backupUsed: string|null}} result
 */
async function notifyOwnerRestore(result) {
  try {
    const botToken = config.telegram?.token || process.env.BOT_TOKEN;
    const ownerChatId = config.telegram?.allowedUserId || process.env.ALLOWED_USER_ID;

    if (!botToken || !ownerChatId) {
      logger.warn('[RESTORE] No Telegram credentials configured, skipping notification');
      return;
    }

    let message;
    if (result.success) {
      message = `✅ *Database Restored*\n` +
        `📁 Backup used: \`${result.backupUsed}\`\n` +
        `⏱ Timestamp: ${new Date().toISOString()}`;
    } else {
      message = `⚠️ *Database Restore Failed*\n` +
        `All backups failed integrity check or no backups available.\n` +
        `A fresh empty database has been created.\n` +
        `⏱ Timestamp: ${new Date().toISOString()}`;
    }

    const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: ownerChatId,
        text: message,
        parse_mode: 'Markdown'
      })
    });

    logger.info(`[RESTORE] Owner notified: ${result.success ? 'restore success' : 'restore failed'}`);
  } catch (err) {
    // Don't throw — notification failure shouldn't break the restore flow
    logger.error(`[RESTORE] Failed to notify owner: ${err.message}`);
  }
}

// === Original Memory Functions ===

export async function rememberFact({ content, kind = 'fact', tags = '', weight = 1.0 }) {
  // Dedupe check
  const existing = db.prepare(
    'SELECT id FROM memories WHERE content = ? AND kind = ?'
  ).get(content, kind);
  
  if (existing) {
    reinforce(existing.id);
    return existing.id;
  }
  
  const stmt = db.prepare(
    'INSERT INTO memories(ts, kind, tags, content, weight, uses) VALUES (?, ?, ?, ?, ?, 0)'
  );
  const result = stmt.run(Date.now() / 1000, kind, tags, content, weight);
  return result.lastInsertRowid;
}

export async function reinforce(memoryId, by = 0.5) {
  db.prepare(
    'UPDATE memories SET weight = weight + ?, uses = uses + 1 WHERE id = ?'
  ).run(by, memoryId);
}

export async function recallMemory(query, k = 5) {
  // Simple token overlap scoring
  const queryTokens = query.toLowerCase().split(/\W+/).filter(t => t.length > 2);
  if (queryTokens.length === 0) return [];
  
  const allMemories = db.prepare('SELECT * FROM memories ORDER BY ts DESC LIMIT 500').all();
  const now = Date.now() / 1000;
  
  const scored = allMemories.map(mem => {
    const memTokens = (mem.content + ' ' + (mem.tags || '')).toLowerCase().split(/\W+/).filter(t => t.length > 2);
    const overlap = queryTokens.filter(t => memTokens.includes(t)).length;
    if (overlap === 0) return { ...mem, score: 0 };
    
    const ageDays = (now - mem.ts) / 86400;
    const recency = 0.5 ** (ageDays / 30); // half-life 30 days
    const score = overlap * (1 + Math.log1p(mem.weight)) * (0.5 + 0.5 * recency);
    
    return { ...mem, score };
  }).filter(m => m.score > 0).sort((a, b) => b.score - a.score).slice(0, k);
  
  // Reinforce recalled memories
  for (const mem of scored) {
    reinforce(mem.id, 0.1);
  }
  
  return scored;
}

export async function getRecent(k = 10, kind = null) {
  let query = 'SELECT * FROM memories';
  if (kind) query += ' WHERE kind = ?';
  query += ' ORDER BY ts DESC LIMIT ?';
  
  return kind 
    ? db.prepare(query).all(kind, k)
    : db.prepare(query).all(k);
}

export async function compactOldMemory(daysOld = config.memory.retentionDays) {
  const cutoff = Date.now() / 1000 - (daysOld * 86400);
  const result = db.prepare('DELETE FROM memories WHERE ts < ? AND weight < 1.0').run(cutoff);
  logger.info(`Compacted ${result.changes} old memories`);
  return result.changes;
}

/**
 * Get the database instance (for testing/internal use)
 */
export function getDb() {
  return db;
}

// === Preference Store (Task 2.1) ===

/**
 * Maximum number of active preferences per user
 */
const MAX_PREFERENCES_PER_USER = 50;

/**
 * Menyimpan atau update preferensi user (UPSERT).
 * Jika key sudah ada untuk user, update value + confidence + last_updated.
 * Jika max 50 preferensi tercapai, replace yang confidence-nya paling rendah.
 * 
 * Requirements: 5.1, 5.4, 5.5
 * 
 * @param {Object} pref
 * @param {string} pref.userId - User ID
 * @param {string} pref.key - Preference key (max 64 chars)
 * @param {string} pref.value - Preference value (max 256 chars)
 * @param {number} pref.confidence - Confidence score 0.0 to 1.0
 * @param {string} [pref.source] - Source message ID
 * @returns {number} The preference row ID
 */
export function savePreference({ userId, key, value, confidence, source = null }) {
  if (!userId || !key || value === undefined || value === null) {
    throw new Error('savePreference requires userId, key, and value');
  }

  // Enforce max lengths
  const safeKey = String(key).slice(0, 64);
  const safeValue = String(value).slice(0, 256);
  
  // Clamp confidence to valid range [0.0, 1.0]
  const safeConfidence = Math.max(0, Math.min(1, Number(confidence) || 0));
  
  const now = new Date().toISOString();

  // Check if preference already exists for this user+key (UPSERT logic)
  const existing = db.prepare(
    'SELECT id FROM user_preferences WHERE user_id = ? AND preference_key = ?'
  ).get(userId, safeKey);

  if (existing) {
    // UPSERT: update existing preference — Requirement 5.4
    db.prepare(
      `UPDATE user_preferences 
       SET preference_value = ?, confidence = ?, last_updated = ?, source_message_id = ?
       WHERE id = ?`
    ).run(safeValue, safeConfidence, now, source, existing.id);
    return existing.id;
  }

  // Check if user already has max preferences — Requirement 5.1 (max 50 per user)
  const count = db.prepare(
    'SELECT COUNT(*) as cnt FROM user_preferences WHERE user_id = ?'
  ).get(userId).cnt;

  if (count >= MAX_PREFERENCES_PER_USER) {
    // Replace the one with lowest confidence (then oldest last_updated as tiebreak)
    const lowest = db.prepare(
      `SELECT id FROM user_preferences 
       WHERE user_id = ? 
       ORDER BY confidence ASC, last_updated ASC 
       LIMIT 1`
    ).get(userId);

    if (lowest) {
      db.prepare(
        `UPDATE user_preferences 
         SET preference_key = ?, preference_value = ?, confidence = ?, 
             last_updated = ?, source_message_id = ?
         WHERE id = ?`
      ).run(safeKey, safeValue, safeConfidence, now, source, lowest.id);
      return lowest.id;
    }
  }

  // Insert new preference
  const result = db.prepare(
    `INSERT INTO user_preferences (user_id, preference_key, preference_value, confidence, last_updated, source_message_id)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(userId, safeKey, safeValue, safeConfidence, now, source);
  
  return Number(result.lastInsertRowid);
}

/**
 * Menjalankan decay confidence untuk preferensi yang tidak diupdate > 90 hari.
 * Decay: -0.1 per 30 hari (sejak last update, dihitung dari hari ke-90).
 * Delete preferensi yang confidence-nya mencapai 0.0 (compact cycle).
 * 
 * Formula: decayAmount = floor((daysSinceUpdate - 90) / 30) * 0.1
 * newConfidence = currentConfidence - decayAmount
 * If newConfidence <= 0.0 → delete
 * 
 * Requirements: 5.6
 * 
 * @returns {{decayed: number, deleted: number}} Count of decayed and deleted preferences
 */
export function runPreferenceDecay() {
  const now = Date.now();
  const ninetyDaysMs = 90 * 24 * 60 * 60 * 1000;
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

  // Find all preferences where last_updated is > 90 days ago
  const ninetyDaysAgo = new Date(now - ninetyDaysMs).toISOString();

  const stalePreferences = db.prepare(
    `SELECT id, user_id, preference_key, confidence, last_updated
     FROM user_preferences
     WHERE last_updated < ?`
  ).all(ninetyDaysAgo);

  if (stalePreferences.length === 0) {
    return { decayed: 0, deleted: 0 };
  }

  let decayed = 0;
  let deleted = 0;

  const updateStmt = db.prepare(
    'UPDATE user_preferences SET confidence = ? WHERE id = ?'
  );
  const deleteStmt = db.prepare(
    'DELETE FROM user_preferences WHERE id = ?'
  );

  const decayTransaction = db.transaction(() => {
    for (const pref of stalePreferences) {
      const lastUpdatedMs = new Date(pref.last_updated).getTime();
      const daysSinceUpdate = (now - lastUpdatedMs) / (24 * 60 * 60 * 1000);

      // Calculate decay: floor((D - 90) / 30) * 0.1
      const decayPeriods = Math.floor((daysSinceUpdate - 90) / 30);
      if (decayPeriods <= 0) continue; // Safety check (shouldn't happen due to query filter)

      const decayAmount = decayPeriods * 0.1;
      const newConfidence = Math.round((pref.confidence - decayAmount) * 100) / 100; // Avoid floating point issues

      if (newConfidence <= 0) {
        // Delete preferences that reach confidence = 0.0 (compact cycle)
        deleteStmt.run(pref.id);
        deleted++;
      } else {
        // Update confidence
        updateStmt.run(newConfidence, pref.id);
        decayed++;
      }
    }
  });

  try {
    decayTransaction();
    if (decayed > 0 || deleted > 0) {
      logger.info(`[PREFERENCE_DECAY] decayed=${decayed} deleted=${deleted}`);
    }
  } catch (err) {
    logger.error(`[PREFERENCE_DECAY] Failed: ${err.message}`);
  }

  return { decayed, deleted };
}

/**
 * Rotasi backup — simpan max 7, hapus terlama (Task 10.3)
 * After rotation, only the 7 most recent backup files remain.
 * Sorts by filename (contains timestamp) so newest files are kept.
 * 
 * Requirements: 7.4
 */
export function rotateBackups() {
  const backupDir = config.raja.backupDir || (config.raja.dataDir + '/backups');
  
  if (!fs.existsSync(backupDir)) return;
  
  const backupFiles = fs.readdirSync(backupDir)
    .filter(f => f.startsWith('memory_') && f.endsWith('.db'))
    .sort((a, b) => b.localeCompare(a)); // Newest first
  
  const MAX_BACKUPS = 7;
  
  if (backupFiles.length <= MAX_BACKUPS) return;
  
  // Delete oldest files beyond the limit
  const toDelete = backupFiles.slice(MAX_BACKUPS);
  for (const file of toDelete) {
    const filePath = path.join(backupDir, file);
    try {
      fs.unlinkSync(filePath);
      logger.info(`[BACKUP] Rotated (deleted): ${file}`);
    } catch (err) {
      logger.error(`[BACKUP] Failed to delete ${file}: ${err.message}`);
    }
  }
}

/**
 * Mengambil preferensi aktif user.
 * Filter: confidence >= 0.5 DAN last_updated dalam 90 hari terakhir.
 * Sort: confidence DESC.
 * 
 * Requirements: 5.5
 * 
 * @param {string} userId
 * @returns {Object[]} Array of preference objects sorted by confidence DESC
 */
export function getPreferences(userId) {
  if (!userId) return [];

  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();

  const rows = db.prepare(
    `SELECT id, user_id, preference_key, preference_value, confidence, last_updated, source_message_id
     FROM user_preferences
     WHERE user_id = ? AND confidence >= 0.5 AND last_updated >= ?
     ORDER BY confidence DESC`
  ).all(userId, ninetyDaysAgo);

  return rows.map(row => ({
    id: row.id,
    userId: row.user_id,
    key: row.preference_key,
    value: row.preference_value,
    confidence: row.confidence,
    lastUpdated: row.last_updated,
    source: row.source_message_id
  }));
}
