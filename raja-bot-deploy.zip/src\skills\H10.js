// src/skills/H10.js — Hermes: Contract deploy, compile, CREATE2, verify
// TODO: Wire intent detection to hermes/contract.js (deployContract, fetchAbi)
// when dedicated deploy hermes module is created or contract.js is extended.
// Expected exports: compileContract, deployContract, verifyContract, computeCreate2Address
// Intent patterns: "deploy ERC20 on <chain>", "verify <address> on <chain>",
// "compile <filename>", "create2 deploy <salt> on <chain>"
import { logger } from '../utils/logger.js';

/**
 * Detect actionable deploy intent from natural language query.
 * Currently returns null (LLM-only) — will be wired to hermes module in future.
 *
 * TODO: Implement when dedicated deploy hermes module is ready:
 * - "deploy erc20 <name> <symbol> <supply> on <chain> wallet <label>"
 *   → deployContract with ERC-20 template
 * - "deploy nft <name> <symbol> <maxSupply> on <chain> wallet <label>"
 *   → deployContract with ERC-721 template
 * - "verify <contractAddress> on <chain>"
 *   → verifyContract({ contractAddress, chain })
 * - "create2 deploy <contract> salt <salt> on <chain> wallet <label>"
 *   → create2Deploy({ contract, salt, chain, walletLabel })
 * - "compile <solidityCode>"
 *   → compileContract({ source })
 *
 * hermes/contract.js already exports:
 * - deployContract({ walletLabel, chain, abi, bytecode, constructorArgs })
 * Can be used as starting point.
 */
function detectDeployIntent(query) {
  // TODO: Implement when full deploy hermes module is ready
  // const q = query.trim();
  //
  // const deployErc20 = q.match(
  //   /deploy\s+(?:erc-?20|token)\s+(?:name\s+)?["']?(\S+)["']?\s+(?:symbol\s+)?["']?(\S+)["']?\s+(?:supply\s+)?([\d]+)(?:\s+on\s+(\S+))?(?:\s+wallet\s+(\S+))?/i
  // );
  // if (deployErc20) return { intent: 'DEPLOY_ERC20', params: { name: deployErc20[1], symbol: deployErc20[2], supply: deployErc20[3], chain: deployErc20[4], wallet: deployErc20[5] } };
  //
  // const verifyMatch = q.match(/verify\s+(0x[a-fA-F0-9]{40})\s+(?:on|di)\s+(\S+)/i);
  // if (verifyMatch) return { intent: 'VERIFY', params: { contractAddress: verifyMatch[1], chain: verifyMatch[2] } };
  //
  return null;
}

export default {
  id: 'H10',
  name: 'deploy',
  description: 'Deploy smart contract: compile Solidity, deploy, verify Etherscan, CREATE2 deterministic deploy',

  async execute(query, context) {
    // 1. Attempt intent detection (currently LLM-only, TODO: wire to hermes)
    const intent = detectDeployIntent(query);

    if (intent) {
      // TODO: Handle actionable deploy intents when hermes module is ready
      logger.info(`[H10] Deploy intent detected: ${intent.intent}`, intent.params);
    }

    // 2. LLM cascade for all deploy/compile queries
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H10 (Contract Deploy).
Mode: precise, developer-focused.

Kamu adalah expert smart contract deployment & compilation:

COMPILE:
- Solidity via solc-js (npm: solc) untuk on-the-fly compilation
- Foundry (forge build) — recommended untuk serious projects
- Hardhat (npx hardhat compile) — alternative
- Optimization settings: runs 200 (default), configurable
- Multiple compiler versions support

DEPLOY:
- ethers.js v6 ContractFactory deployment
- Constructor args encoding (automatic)
- Multi-chain deploy (same contract, different chains)
- Governor gate: semua deploy melalui authorization
- Gas estimation + confirmation before broadcast

CREATE2 (Deterministic Deploy):
- Same address across ALL EVM chains
- Salt-based deployment via CREATE2 factory
- Pre-compute address before deploy: keccak256(0xff ++ deployer ++ salt ++ keccak256(bytecode))
- Useful: protocol deployment, vanity addresses, cross-chain consistency
- Factory: 0x4e59b44847b379578588920cA78FbF26c0B4956C (deterministic deployer)

VERIFY (Block Explorer):
- Auto-verify setelah deploy via Etherscan API
- Standard JSON input format
- Constructor args encoding for verification
- Proxy contract verification (implementation + proxy)
- Multi-chain verification (Etherscan, Basescan, Arbiscan, etc.)

TEMPLATES Siap Pakai:
- ERC-20: mintable, burnable, pausable, permit (OpenZeppelin)
- ERC-721: enumerable, royalties (EIP-2981), metadata
- ERC-1155: multi-token, URI management
- Transparent Proxy (EIP-1967): upgradeable pattern
- UUPS Proxy: gas-efficient upgradeable
- Minimal Proxy (EIP-1167 Clone): cheap clones
- Multisig (Gnosis Safe pattern): multi-owner execution
- Governor (OpenZeppelin): on-chain governance
- Timelock: delayed execution for safety

Security Checklist (pre-deploy):
1. Audit code / use audited templates (OpenZeppelin)
2. Test on testnet first (Sepolia, Goerli)
3. Verify constructor args are correct
4. Confirm deployer wallet has sufficient gas
5. Review access control (owner, roles)
6. Governor authorization before mainnet deploy

Gas Estimation:
- Deployment typically costs 1-5M gas depending on contract size
- ERC-20 basic: ~1.2M gas
- ERC-721 full: ~3M gas
- Complex proxy setup: ~4-5M gas

Output: complete deployment code atau step-by-step guide sesuai kebutuhan user.
Selalu sertakan testnet deployment suggestion sebelum mainnet.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H10] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan deploy: ${err.message}`;
    }
  },
};
