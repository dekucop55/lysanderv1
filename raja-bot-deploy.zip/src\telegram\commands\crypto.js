// src/telegram/commands/crypto.js — Crypto command handlers
import { listWallets, getBalance } from '../../hermes/wallets.js';
import { swapToken, getSwapQuote, ensureAllowance, get1inchRouter } from '../../hermes/swap.js';
import { honeypotCheck } from '../../hermes/sniping.js';
import { logger } from '../../utils/logger.js';

export async function cmdWallet(bot, msg, action) {
  const chatId = msg.chat.id;

  if (!action || action === 'list') {
    const wallets = listWallets();
    if (wallets.length === 0) {
      return bot.sendMessage(
        chatId,
        'Belum ada wallet.\n\nImport dengan: ketik "import wallet <label> <private_key>" atau buat baru dengan "buat wallet baru"'
      );
    }
    const lines = wallets.map(
      (w) => `• \`${w.label}\` — ${w.address.substring(0, 8)}...${w.address.slice(-6)} (${w.chain_type})`
    );
    return bot.sendMessage(chatId, `*👛 Wallets (${wallets.length})*\n\n${lines.join('\n')}`, {
      parse_mode: 'Markdown',
    });
  }

  await bot.sendMessage(chatId, `Wallet action "${action}" — ketik di chat untuk detail.`);
}

export async function cmdBalance(bot, msg, walletLabel) {
  const chatId = msg.chat.id;

  if (!walletLabel) {
    // List all wallets' balances
    const wallets = listWallets();
    if (wallets.length === 0) {
      return bot.sendMessage(chatId, 'Belum ada wallet. Tambah dulu.');
    }
    walletLabel = wallets[0].label;
  }

  try {
    await bot.sendChatAction(chatId, 'typing');
    const bal = await getBalance(walletLabel, 'ethereum');
    await bot.sendMessage(
      chatId,
      `*💰 Balance — ${walletLabel}*\n\n` +
        `Address: \`${bal.address}\`\n` +
        `Chain: ${bal.chain}\n` +
        `Balance: ${bal.balance.toFixed(6)} ${bal.symbol}`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Balance error: ${err.message}`);
  }
}

export async function cmdSwap(bot, msg, args) {
  const chatId = msg.chat.id;

  // Parse: "<amount> <tokenIn> <tokenOut> <chain> [wallet]"
  // Example: "0.1 ETH USDC base wallet1"
  const parts = (args || '').trim().split(/\s+/);

  if (parts.length < 4) {
    await bot.sendMessage(
      chatId,
      `🔄 *Swap via RAJA*\n\nFormat:\n/swap <amount> <tokenIn> <tokenOut> <chain> [wallet]\n\nContoh:\n/swap 0.1 ETH USDC base wallet1\n/swap 50 USDC ETH ethereum wallet1\n\nAtau chat: "swap 0.1 ETH ke USDC di Base pakai wallet1"`,
      { parse_mode: 'Markdown' }
    );
    return;
  }

  const [amount, tokenIn, tokenOut, chain, walletLabel] = parts;

  // If no wallet given, use first available
  const effectiveWallet = walletLabel || listWallets()[0]?.label;
  if (!effectiveWallet) {
    return bot.sendMessage(chatId, '❌ Belum ada wallet. Import dulu via chat "import wallet <label> <pk>"');
  }

  try {
    await bot.sendChatAction(chatId, 'typing');
    await bot.sendMessage(chatId, `🔍 Getting quote: ${amount} ${tokenIn} → ${tokenOut} on ${chain}...`);

    // 1. Get quote first (dry-run)
    const quote = await getSwapQuote({ chain, tokenIn, tokenOut, amount: parseFloat(amount), slippage: 1.0 });

    await bot.sendMessage(
      chatId,
      `📊 *Quote*\n\n` +
        `${amount} ${tokenIn} → ~${parseFloat(quote.toAmount).toFixed(6)} ${tokenOut}\n` +
        `Min received: ${parseFloat(quote.toAmountMin).toFixed(6)} ${tokenOut} (1% slippage)\n` +
        `Est. gas: ${quote.estimatedGas?.toLocaleString() || '?'}\n\n` +
        `Ketik /swapconfirm ${amount} ${tokenIn} ${tokenOut} ${chain} ${effectiveWallet} untuk eksekusi`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    logger.error(`[cmd:swap] ${err.message}`);
    await bot.sendMessage(chatId, `❌ Quote error: ${err.message}`);
  }
}

export async function cmdSwapConfirm(bot, msg, args) {
  const chatId = msg.chat.id;
  const parts = (args || '').trim().split(/\s+/);

  if (parts.length < 5) {
    return bot.sendMessage(chatId, 'Usage: /swapconfirm <amount> <tokenIn> <tokenOut> <chain> <wallet>');
  }

  const [amount, tokenIn, tokenOut, chain, walletLabel] = parts;

  try {
    await bot.sendChatAction(chatId, 'typing');
    await bot.sendMessage(chatId, `⚡ Executing swap: ${amount} ${tokenIn} → ${tokenOut}...`);

    // Ensure allowance for ERC-20 tokens
    if (!['ETH', 'BNB', 'AVAX', 'MATIC'].includes(tokenIn.toUpperCase()) && tokenIn.startsWith('0x')) {
      await bot.sendMessage(chatId, '🔑 Checking allowance...');
      await ensureAllowance({
        walletLabel,
        chain,
        tokenAddress: tokenIn,
        spender: get1inchRouter(chain),
        amount: parseFloat(amount),
      });
    }

    const result = await swapToken({
      walletLabel,
      chain,
      tokenIn,
      tokenOut,
      amount: parseFloat(amount),
      slippage: 1.0,
    });

    if (!result.success) {
      return bot.sendMessage(chatId, `❌ Swap gagal: ${result.reason}`);
    }

    await bot.sendMessage(
      chatId,
      `✅ *Swap sukses*\n\n` +
        `${amount} ${tokenIn} → ${tokenOut}\n` +
        `Chain: ${chain}\n` +
        `Status: ${result.status}\n` +
        `Gas used: ${result.gasUsed}\n` +
        `[Lihat tx](${result.explorer})`,
      { parse_mode: 'Markdown', disable_web_page_preview: true }
    );
  } catch (err) {
    logger.error(`[cmd:swapconfirm] ${err.message}`);
    await bot.sendMessage(chatId, `❌ Swap error: ${err.message}`);
  }
}

export async function cmdMint(bot, msg, args) {
  const chatId = msg.chat.id;
  await bot.sendMessage(
    chatId,
    `🎨 *NFT Mint*\n\nFormat:\n/mint <contract_address> <chain> [wallet] [amount]\n\nContoh:\n/mint 0xabc...def ethereum wallet1 1\n\nAtau chat: "mint 1 NFT dari contract 0x... di Ethereum pakai wallet1"`,
    { parse_mode: 'Markdown' }
  );
}

export async function cmdSnipe(bot, msg, args) {
  const chatId = msg.chat.id;

  if (!args) {
    await bot.sendMessage(
      chatId,
      `🎯 *Sniper Mode*\n\nFormat:\n/snipe <token_address> [chain] [eth_amount]\n\nContoh:\n/snipe 0xabc...def ethereum 0.05\n\n⚠️ Honeypot check dilakukan otomatis sebelum snipe.`,
      { parse_mode: 'Markdown' }
    );
    return;
  }

  // Parse: "<address> [chain] [amount]"
  const parts = args.trim().split(/\s+/);
  const tokenAddress = parts[0];
  const chain = parts[1] || 'ethereum';

  try {
    await bot.sendChatAction(chatId, 'typing');
    await bot.sendMessage(chatId, `🔍 Checking safety for ${tokenAddress}...`);

    const check = await honeypotCheck({ tokenAddress, chain });

    if (!check.safe) {
      return bot.sendMessage(
        chatId,
        `🚫 *Token DIBLOKIR*\n\nAlasan: ${check.risks?.join(', ') || check.reason}\n\nSnipe dibatalkan.`,
        { parse_mode: 'Markdown' }
      );
    }

    await bot.sendMessage(
      chatId,
      `✅ *Safety check passed*\n\nBuy tax: ${check.data?.buyTax}%\nSell tax: ${check.data?.sellTax}%\nHolders: ${check.data?.holders}\nLP locked: ${check.data?.lpLocked ? 'Yes' : 'No'}\n\nKonfirmasi snipe? Ketik: "snipe confirm <address> <amount ETH>"`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    logger.error(`[cmd:snipe] ${err.message}`);
    await bot.sendMessage(chatId, `❌ Snipe check error: ${err.message}`);
  }
}
