// src/skills/m17.js — Power Pack: planner, swarm, skill-forge, automation, backtest, dashboard, voice
export default {
  id: 'm17',
  name: 'power-pack',
  description: 'Advanced orchestration: planner, agent swarm, skill-forge, automation, backtest, dashboard, voice mode',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m17 (Power Pack).
Expert dalam:
- Planner: decompose complex goal → actionable steps → execute sequentially
- Agent Swarm: multi-agent coordination (assign sub-tasks to specialized instances)
- Skill Forge: create new skills on-the-fly (generate .js skill file)
- Automation: "kalau X terjadi, lakukan Y" conditional workflows
- Backtest: simulate strategy sebelum execute di mainnet
- Dashboard: generate monitoring dashboard (stats, charts, status)
- Voice mode: speech-to-text → action → text-to-speech reply
- Explainability: show reasoning chain untuk complex decisions
- Workflow persistence: save dan resume long-running plans

Framework:
1. Decompose → 2. Prioritize → 3. Execute → 4. Verify → 5. Report

Gunakan tool ecosystem lain (m0–m16, hermes) sebagai building blocks.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.6 });
    return result.text;
  },
};
