// src/telegram/commands/daily.js — /alert, /briefing, /vault
import { logger } from '../../utils/logger.js';
import { rememberFact, getRecent, recallMemory } from '../../core/memory.js';
import { callCascade } from '../../llm/cascade.js';
import Database from 'better-sqlite3';
import { config } from '../../config.js';
import fs from 'fs';
import path from 'path';
import { encrypt, decrypt } from '../../utils/crypto.js';

// ─── ALERTS ─────────────────────────────────────────────────────────────────

let alertDb;

function getAlertDb() {
  if (alertDb) return alertDb;
  const dbPath = path.join(config.raja.dataDir, 'alerts.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  alertDb = new Database(dbPath);
  alertDb.exec(`
    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at REAL NOT NULL,
      condition TEXT NOT NULL,
      active INTEGER DEFAULT 1,
      triggered_at REAL
    );
  `);
  return alertDb;
}

export async function cmdAlert(bot, msg, action, text) {
  const db = getAlertDb();

  if (action === 'add') {
    if (!text) {
      await bot.sendMessage(msg.chat.id, 'Usage: /alert <kondisi>\nContoh: /alert kabarin kalau ETH > 4000');
      return;
    }
    const result = db.prepare(
      'INSERT INTO alerts(created_at, condition, active) VALUES (?, ?, 1)'
    ).run(Date.now() / 1000, text);

    await rememberFact({ content: `Alert set: ${text}`, kind: 'alert', tags: 'alert', weight: 1.5 });
    await bot.sendMessage(msg.chat.id, `✅ Alert aktif: "${text}"\nID: ${result.lastInsertRowid}`);
    return;
  }

  if (action === 'list') {
    const alerts = db.prepare('SELECT * FROM alerts WHERE active = 1 ORDER BY created_at DESC LIMIT 20').all();
    if (alerts.length === 0) {
      await bot.sendMessage(msg.chat.id, 'Tidak ada alert aktif.');
      return;
    }
    const lines = alerts.map((a) => `• [${a.id}] ${a.condition}`).join('\n');
    await bot.sendMessage(msg.chat.id, `*Alert Aktif (${alerts.length})*\n\n${lines}`, { parse_mode: 'Markdown' });
    return;
  }

  if (action === 'del' && text) {
    const id = parseInt(text);
    db.prepare('UPDATE alerts SET active = 0 WHERE id = ?').run(id);
    await bot.sendMessage(msg.chat.id, `Alert #${id} dinonaktifkan.`);
    return;
  }
}

// ─── BRIEFING ────────────────────────────────────────────────────────────────

export async function cmdBriefing(bot, msg) {
  try {
    await bot.sendChatAction(msg.chat.id, 'typing');

    const recent = await getRecent(20);
    const memDump = recent
      .slice(0, 15)
      .map((m) => `[${m.kind}] ${m.content}`)
      .join('\n');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Buat briefing harian ringkas dalam format:
TANGGAL: [hari ini]
RINGKASAN: 2-3 kalimat aktivitas kemarin
PENDING: hal yang belum selesai (jika ada)
PRIORITAS HARI INI: 1-3 item paling penting
---
Ringkas, padat, actionable. Bahasa Indonesia.`,
      },
      {
        role: 'user',
        content: `Memory terbaru:\n${memDump}\n\nBuat briefing harian.`,
      },
    ];

    const result = await callCascade(messages, { maxTokens: 500, temperature: 0.5 });
    await bot.sendMessage(msg.chat.id, result.text);
  } catch (err) {
    logger.error(`[briefing] ${err.message}`);
    await bot.sendMessage(msg.chat.id, `Briefing gagal: ${err.message}`);
  }
}

// ─── VAULT ───────────────────────────────────────────────────────────────────

let vaultDb;

function getVaultDb() {
  if (vaultDb) return vaultDb;
  const dbPath = path.join(config.raja.dataDir, 'vault.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  vaultDb = new Database(dbPath);
  vaultDb.exec(`
    CREATE TABLE IF NOT EXISTS vault (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at REAL NOT NULL
    );
  `);
  return vaultDb;
}

export async function cmdVault(bot, msg, args) {
  const db = getVaultDb();
  const pw = config.governor.masterPw;

  if (!pw) {
    await bot.sendMessage(msg.chat.id, '❌ HERMES_MASTER_PW tidak diset. Vault tidak tersedia.');
    return;
  }

  if (!args) {
    // List keys
    const keys = db.prepare('SELECT key, updated_at FROM vault ORDER BY key').all();
    if (keys.length === 0) {
      await bot.sendMessage(msg.chat.id, 'Vault kosong.');
      return;
    }
    const lines = keys.map((k) => `• ${k.key} (${new Date(k.updated_at * 1000).toLocaleDateString('id-ID')})`).join('\n');
    await bot.sendMessage(msg.chat.id, `*Vault Keys*\n\n${lines}\n\nGunakan: /vault <key> untuk ambil, /vault set <key> <value> untuk simpan`, {
      parse_mode: 'Markdown',
    });
    return;
  }

  const parts = args.trim().split(/\s+/);

  if (parts[0] === 'set' && parts.length >= 3) {
    const key = parts[1];
    const value = parts.slice(2).join(' ');
    const encrypted = encrypt(value, pw);
    db.prepare('INSERT OR REPLACE INTO vault(key, value, updated_at) VALUES (?, ?, ?)').run(
      key, encrypted, Date.now() / 1000
    );
    await bot.sendMessage(msg.chat.id, `✅ Vault: "${key}" disimpan (encrypted).`);
    return;
  }

  if (parts[0] === 'del' && parts.length === 2) {
    db.prepare('DELETE FROM vault WHERE key = ?').run(parts[1]);
    await bot.sendMessage(msg.chat.id, `🗑 Vault: "${parts[1]}" dihapus.`);
    return;
  }

  // Get key
  const key = parts[0];
  const row = db.prepare('SELECT value FROM vault WHERE key = ?').get(key);
  if (!row) {
    await bot.sendMessage(msg.chat.id, `Key "${key}" tidak ditemukan di vault.`);
    return;
  }

  try {
    const decrypted = decrypt(row.value, pw);
    // Send as self-destructing message context
    await bot.sendMessage(msg.chat.id, `🔑 ${key}:\n\`${decrypted}\``, { parse_mode: 'Markdown' });
  } catch {
    await bot.sendMessage(msg.chat.id, `❌ Gagal decrypt. Master password salah?`);
  }
}
