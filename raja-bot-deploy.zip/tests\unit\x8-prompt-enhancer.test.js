import { describe, it } from 'vitest';
import assert from 'node:assert';
import { generateCapabilityStatement, isDuplicateCapability, findInsertionPoint } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 17.6, 17.7, 17.8**
 * Property 25: System Prompt additive only.
 * Property 26: No duplicate capability.
 * Property 27: findInsertionPoint.
 */
describe('Property 25: System Prompt Additive Only', () => {
  it('generateCapabilityStatement returns a non-empty string', () => {
    const result = generateCapabilityStatement('m2', 'vps-deploy', 'akses file VPS');
    assert.ok(result.length > 0);
    assert.ok(result.includes('m2'));
    assert.ok(result.includes('BISA'));
  });
});

describe('Property 26: No Duplicate Capability', () => {
  it('detects existing capability statement', () => {
    const prompt = `Some text\n- Kamu BISA akses file via skill m2 (vps-deploy) — gunakan m2 untuk akses file\nMore text`;
    assert.strictEqual(isDuplicateCapability(prompt, 'm2', 'akses file'), true);
  });

  it('returns false for non-existent capability', () => {
    const prompt = 'Kamu adalah RAJA. Skill aktif: x8.';
    assert.strictEqual(isDuplicateCapability(prompt, 'm2', 'akses file VPS'), false);
  });

  it('returns false for empty prompt', () => {
    assert.strictEqual(isDuplicateCapability('', 'm2', 'anything'), false);
    assert.strictEqual(isDuplicateCapability(null, 'm2', 'anything'), false);
  });
});

describe('Property 27: findInsertionPoint', () => {
  it('finds CAPABILITY AWARENESS section if exists', () => {
    const prompt = 'blah\nCAPABILITY AWARENESS\nblah';
    assert.strictEqual(findInsertionPoint(prompt), 'CAPABILITY AWARENESS');
  });

  it('finds INFRASTRUKTUR section', () => {
    const prompt = 'blah\n═══ INFRASTRUKTUR ═══\nblah';
    assert.strictEqual(findInsertionPoint(prompt), 'AFTER_INFRASTRUKTUR');
  });

  it('returns END as fallback', () => {
    assert.strictEqual(findInsertionPoint('simple prompt'), 'END');
  });
});
