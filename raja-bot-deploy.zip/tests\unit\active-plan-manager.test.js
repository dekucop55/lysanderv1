// tests/unit/active-plan-manager.test.js
//
// Unit tests for ActivePlanManager (Task 4.1)
// Validates: Requirements 1.6, 1.8

import { describe, it, expect, beforeEach, vi } from 'vitest';
import { ActivePlanManager } from '../../src/core/brain.js';

describe('ActivePlanManager', () => {
  let manager;

  beforeEach(() => {
    manager = new ActivePlanManager();
  });

  describe('constructor', () => {
    it('should use default TTL of 30 minutes (1800000 ms)', () => {
      expect(manager.ttlMs).toBe(30 * 60 * 1000);
      expect(manager.ttlMs).toBe(1800000);
    });

    it('should accept custom TTL', () => {
      const custom = new ActivePlanManager(60000);
      expect(custom.ttlMs).toBe(60000);
    });

    it('should start with empty sessions', () => {
      expect(manager.sessions.size).toBe(0);
    });
  });

  describe('setPlan', () => {
    it('should add a plan to a new session', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' };
      manager.setPlan('session1', plan);

      const plans = manager.sessions.get('session1');
      expect(plans).toHaveLength(1);
      expect(plans[0].planId).toBe('p1');
    });

    it('should set lastInteraction to current time', () => {
      const now = Date.now();
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' };
      manager.setPlan('session1', plan);

      expect(plan.lastInteraction).toBeGreaterThanOrEqual(now);
      expect(plan.lastInteraction).toBeLessThanOrEqual(now + 50);
    });

    it('should set default ttlMs if not provided on plan', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' };
      manager.setPlan('session1', plan);

      expect(plan.ttlMs).toBe(1800000);
    });

    it('should preserve custom ttlMs on plan if provided', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed', ttlMs: 60000 };
      manager.setPlan('session1', plan);

      expect(plan.ttlMs).toBe(60000);
    });

    it('should allow multiple plans in same session', () => {
      manager.setPlan('session1', { planId: 'p1', skillId: 's1', description: 'a', status: 'proposed' });
      manager.setPlan('session1', { planId: 'p2', skillId: 's2', description: 'b', status: 'agreed' });

      const plans = manager.sessions.get('session1');
      expect(plans).toHaveLength(2);
    });
  });

  describe('getActivePlan', () => {
    it('should return null when no plans exist', () => {
      expect(manager.getActivePlan('session1')).toBeNull();
    });

    it('should return the single agreed plan', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);

      const result = manager.getActivePlan('session1');
      expect(result).not.toBeNull();
      expect(result.planId).toBe('p1');
      expect(result.status).toBe('agreed');
    });

    it('should return null when no agreed plans (only proposed)', () => {
      manager.setPlan('session1', { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' });

      expect(manager.getActivePlan('session1')).toBeNull();
    });

    it('should return null when multiple agreed plans exist (disambiguation needed)', () => {
      manager.setPlan('session1', { planId: 'p1', skillId: 's1', description: 'a', status: 'agreed' });
      manager.setPlan('session1', { planId: 'p2', skillId: 's2', description: 'b', status: 'agreed' });

      expect(manager.getActivePlan('session1')).toBeNull();
    });

    it('should prune expired plans before returning', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);
      // Manually expire the plan
      plan.lastInteraction = Date.now() - 1900000; // > 30 min ago

      expect(manager.getActivePlan('session1')).toBeNull();
    });
  });

  describe('getActivePlans', () => {
    it('should return empty array when no plans', () => {
      expect(manager.getActivePlans('session1')).toEqual([]);
    });

    it('should return agreed and proposed plans', () => {
      manager.setPlan('session1', { planId: 'p1', skillId: 's1', description: 'a', status: 'agreed' });
      manager.setPlan('session1', { planId: 'p2', skillId: 's2', description: 'b', status: 'proposed' });

      const plans = manager.getActivePlans('session1');
      expect(plans).toHaveLength(2);
    });

    it('should not return expired plans', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);
      plan.lastInteraction = Date.now() - 1900000;

      const plans = manager.getActivePlans('session1');
      expect(plans).toHaveLength(0);
    });
  });

  describe('agreePlan', () => {
    it('should change plan status to agreed', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' };
      manager.setPlan('session1', plan);

      manager.agreePlan('session1', 'p1');
      expect(plan.status).toBe('agreed');
    });

    it('should refresh lastInteraction on agree', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' };
      manager.setPlan('session1', plan);
      const oldTs = plan.lastInteraction;

      // Small delay to get different timestamp
      plan.lastInteraction = oldTs - 1000;
      manager.agreePlan('session1', 'p1');

      expect(plan.lastInteraction).toBeGreaterThan(oldTs - 1000);
    });

    it('should do nothing if planId not found', () => {
      manager.setPlan('session1', { planId: 'p1', skillId: 's1', description: 'test', status: 'proposed' });
      manager.agreePlan('session1', 'nonexistent');

      const plans = manager.sessions.get('session1');
      expect(plans[0].status).toBe('proposed');
    });

    it('should do nothing if session does not exist', () => {
      // Should not throw
      manager.agreePlan('nonexistent', 'p1');
    });
  });

  describe('pruneExpired', () => {
    it('should remove plans that exceeded TTL', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);
      plan.lastInteraction = Date.now() - 1900000; // > 30 min

      const expired = manager.pruneExpired('session1');
      expect(expired).toHaveLength(1);
      expect(expired[0].planId).toBe('p1');
      expect(expired[0].status).toBe('expired');
    });

    it('should keep plans within TTL', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);

      const expired = manager.pruneExpired('session1');
      expect(expired).toHaveLength(0);
      expect(manager.sessions.get('session1')).toHaveLength(1);
    });

    it('should use plan-specific TTL if available', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed', ttlMs: 5000 };
      manager.setPlan('session1', plan);
      plan.lastInteraction = Date.now() - 6000; // > 5s custom TTL

      const expired = manager.pruneExpired('session1');
      expect(expired).toHaveLength(1);
    });

    it('should return empty array for non-existent session', () => {
      expect(manager.pruneExpired('nonexistent')).toEqual([]);
    });

    it('should set status to expired on pruned plans', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'agreed' };
      manager.setPlan('session1', plan);
      plan.lastInteraction = Date.now() - 1900000;

      const expired = manager.pruneExpired('session1');
      expect(expired[0].status).toBe('expired');
    });
  });

  describe('touchPlan', () => {
    it('should refresh lastInteraction for all non-expired plans', () => {
      const plan1 = { planId: 'p1', skillId: 's1', description: 'a', status: 'agreed' };
      const plan2 = { planId: 'p2', skillId: 's2', description: 'b', status: 'proposed' };
      manager.setPlan('session1', plan1);
      manager.setPlan('session1', plan2);

      // Set old timestamps
      plan1.lastInteraction = Date.now() - 500000;
      plan2.lastInteraction = Date.now() - 500000;

      const before = Date.now();
      manager.touchPlan('session1');

      expect(plan1.lastInteraction).toBeGreaterThanOrEqual(before);
      expect(plan2.lastInteraction).toBeGreaterThanOrEqual(before);
    });

    it('should not touch expired plans', () => {
      const plan = { planId: 'p1', skillId: 's1', description: 'test', status: 'expired' };
      manager.setPlan('session1', plan);
      const oldTs = plan.lastInteraction;

      // Manually set to old and mark as expired
      plan.lastInteraction = 1000;
      plan.status = 'expired';

      manager.touchPlan('session1');
      expect(plan.lastInteraction).toBe(1000); // Unchanged
    });

    it('should do nothing for non-existent session', () => {
      // Should not throw
      manager.touchPlan('nonexistent');
    });
  });
});
