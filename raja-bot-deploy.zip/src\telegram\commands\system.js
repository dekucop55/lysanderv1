// src/telegram/commands/system.js — /upgrade, /restart, /logs, /health
import { exec } from 'child_process';
import { promisify } from 'util';
import { logger } from '../../utils/logger.js';
import { config } from '../../config.js';
import { performUpgrade } from '../../self-upgrade/upgrade.js';
import { healthCheck } from '../../self-upgrade/healthcheck.js';
import fs from 'fs';

const execAsync = promisify(exec);

export async function cmdUpgrade(bot, msg) {
  const chatId = msg.chat.id;

  await bot.sendMessage(
    chatId,
    '🔄 *Self-upgrade dimulai...*\n\n1. Backup\n2. Git pull\n3. Deps install\n4. Restart\n5. Health check',
    { parse_mode: 'Markdown' }
  );

  try {
    const result = await performUpgrade({
      onProgress: async (step, status) => {
        await bot.sendMessage(chatId, `${status} ${step}`).catch(() => {});
      },
    });

    if (result.success) {
      await bot.sendMessage(
        chatId,
        `✅ *Upgrade sukses*\n\n• ${result.oldVersion?.substring(0, 8)} → ${result.newVersion?.substring(0, 8)}\n• Commits: ${result.commitsPulled}\n• Restart: ${result.restartMs}ms`,
        { parse_mode: 'Markdown' }
      );
    } else {
      await bot.sendMessage(
        chatId,
        `❌ *Upgrade gagal — rollback dilakukan*\n\nError: ${result.error}`,
        { parse_mode: 'Markdown' }
      );
    }
  } catch (err) {
    logger.error(`[cmd:upgrade] ${err.message}`);
    await bot.sendMessage(chatId, `❌ Upgrade error: ${err.message}`);
  }
}

export async function cmdRestart(bot, msg) {
  await bot.sendMessage(msg.chat.id, '🔄 Restarting...');
  try {
    await execAsync('systemctl restart raja-bot.service');
  } catch {
    try {
      await execAsync('pm2 restart raja-bot');
    } catch {
      process.exit(0); // Let watchdog/systemd restart
    }
  }
}

export async function cmdLogs(bot, msg, arg) {
  const n = parseInt(arg) || 50;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const logFile = `${config.raja.logDir}/raja-${today}.log`;

    if (!fs.existsSync(logFile)) {
      await bot.sendMessage(msg.chat.id, 'Log file tidak ditemukan hari ini.');
      return;
    }

    const content = fs.readFileSync(logFile, 'utf8');
    const lines = content.trim().split('\n').slice(-n).join('\n');
    const truncated = lines.length > 3500 ? '...(truncated)\n' + lines.slice(-3000) : lines;

    await bot.sendMessage(msg.chat.id, `\`\`\`\n${truncated}\n\`\`\``, { parse_mode: 'Markdown' });
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `❌ Log error: ${err.message}`);
  }
}

export async function cmdHealth(bot, msg) {
  try {
    let disk = 'N/A', mem = 'N/A', load = 'N/A';
    try { ({ stdout: disk } = await execAsync('df -h / | tail -1')); } catch {}
    try { ({ stdout: mem } = await execAsync('free -h | grep Mem')); } catch {}
    try { ({ stdout: load } = await execAsync('uptime')); } catch {}

    const botHealth = await healthCheck({ retries: 1, interval: 0 });

    await bot.sendMessage(
      msg.chat.id,
      `*🏥 Health*\n\n` +
        `Bot: ${botHealth.ok ? '✅ OK' : '❌ Down'}\n` +
        `Disk: ${disk.trim()}\n` +
        `RAM: ${mem.trim()}\n` +
        `Load: ${load.trim()}`,
      { parse_mode: 'Markdown' }
    );
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `❌ Health check error: ${err.message}`);
  }
}
