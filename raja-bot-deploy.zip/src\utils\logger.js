// src/utils/logger.js — Winston logger with daily rotation
import winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { config } from '../config.js';
import path from 'path';
import fs from 'fs';

const logDir = config?.raja?.logDir || './logs';
fs.mkdirSync(logDir, { recursive: true });

const fmt = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.printf(({ level, message, timestamp, stack }) => {
    const base = `[${timestamp}] ${level.toUpperCase().padEnd(5)} ${message}`;
    return stack ? `${base}\n${stack}` : base;
  })
);

const colorFmt = winston.format.combine(
  winston.format.colorize(),
  winston.format.timestamp({ format: 'HH:mm:ss' }),
  winston.format.printf(({ level, message, timestamp }) =>
    `${timestamp} ${level} ${message}`
  )
);

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  transports: [
    new winston.transports.Console({
      format: colorFmt,
    }),
    new DailyRotateFile({
      dirname: logDir,
      filename: 'raja-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      maxSize: '20m',
      maxFiles: '14d',
      format: fmt,
    }),
    new DailyRotateFile({
      dirname: logDir,
      filename: 'error-%DATE%.log',
      datePattern: 'YYYY-MM-DD',
      level: 'error',
      maxSize: '10m',
      maxFiles: '30d',
      format: fmt,
    }),
  ],
});
