import { describe, it } from 'vitest';
import assert from 'node:assert';
import { classifySkillError, isPackageImport } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 6.4**
 * Properties 14, 15, 16, 18: Code repair error classification.
 */
describe('Property 14-16: Code Repair Classification', () => {
  it('classifies SyntaxError correctly', () => {
    const err = new Error('SyntaxError: Unexpected token }');
    assert.strictEqual(classifySkillError(err), 'syntax_error');
  });

  it('classifies missing module (local) correctly', () => {
    const err = new Error("Cannot find module './nonexistent.js'");
    err.code = 'ERR_MODULE_NOT_FOUND';
    assert.strictEqual(classifySkillError(err), 'missing_import');
  });

  it('classifies missing module (package) correctly', () => {
    const err = new Error("Cannot find module 'nonexistent-package'");
    err.code = 'ERR_MODULE_NOT_FOUND';
    assert.strictEqual(classifySkillError(err), 'missing_package');
  });

  it('classifies missing export correctly', () => {
    const err = new Error("does not provide an export named 'foo'");
    assert.strictEqual(classifySkillError(err), 'missing_export');
  });

  it('classifies runtime error correctly', () => {
    const err = new Error('someFunc is not a function');
    assert.strictEqual(classifySkillError(err), 'runtime_error');
  });

  it('defaults unknown errors to unknown', () => {
    const err = new Error('Something completely different');
    assert.strictEqual(classifySkillError(err), 'unknown');
  });
});
