// src/hermes/airdrop.js — Multi-wallet airdrop automation runner
import { ethers } from 'ethers';
import { config } from '../config.js';
import { getPrivateKey, getWalletInfo, listWallets } from './wallets.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { logger } from '../utils/logger.js';
import Database from 'better-sqlite3';
import { sleep } from '../utils/retry.js';
import fs from 'fs';
import path from 'path';

let airdropDb;

function getAirdropDb() {
  if (airdropDb) return airdropDb;
  const dbPath = path.join(config.raja.dataDir, 'airdrop.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  airdropDb = new Database(dbPath);
  airdropDb.exec(`
    CREATE TABLE IF NOT EXISTS airdrop_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign TEXT NOT NULL,
      wallet_label TEXT NOT NULL,
      action TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      tx_hash TEXT,
      error TEXT,
      created_at REAL NOT NULL,
      executed_at REAL
    );
    CREATE INDEX IF NOT EXISTS idx_campaign ON airdrop_tasks(campaign);
    CREATE INDEX IF NOT EXISTS idx_status ON airdrop_tasks(status);
  `);
  return airdropDb;
}

/**
 * Setup campaign airdrop multi-wallet
 * @param {string} campaign - nama campaign
 * @param {string[]} walletLabels - labels wallet yang ikut
 * @param {Object[]} actions - list aksi per wallet
 */
export function setupCampaign(campaign, walletLabels, actions) {
  const db = getAirdropDb();
  const now = Date.now() / 1000;

  // Clear existing tasks for campaign
  db.prepare('DELETE FROM airdrop_tasks WHERE campaign = ? AND status = ?').run(campaign, 'pending');

  // Insert tasks
  const stmt = db.prepare(
    'INSERT INTO airdrop_tasks(campaign, wallet_label, action, status, created_at) VALUES (?, ?, ?, ?, ?)'
  );

  let count = 0;
  for (const label of walletLabels) {
    for (const action of actions) {
      stmt.run(campaign, label, JSON.stringify(action), 'pending', now);
      count++;
    }
  }

  logger.info(`[airdrop] Campaign "${campaign}": ${count} tasks queued`);
  return { campaign, tasks: count };
}

/**
 * Jalankan campaign airdrop dengan jitter (anti-sybil detection)
 * @param {string} campaign
 * @param {Object} opts
 * @param {number} opts.minDelayMs - min delay antar wallet (default 3000ms)
 * @param {number} opts.maxDelayMs - max delay antar wallet (default 15000ms)
 * @param {Function} opts.onProgress - callback progress
 */
export async function runCampaign(campaign, opts = {}) {
  const {
    minDelayMs = 3000,
    maxDelayMs = 15000,
    onProgress = () => {},
    dryRun = false,
  } = opts;

  const db = getAirdropDb();
  const tasks = db.prepare(
    "SELECT * FROM airdrop_tasks WHERE campaign = ? AND status = 'pending' ORDER BY id"
  ).all(campaign);

  if (tasks.length === 0) {
    return { success: false, reason: `Tidak ada pending tasks untuk campaign "${campaign}"` };
  }

  onProgress(`🚀 Starting campaign "${campaign}" — ${tasks.length} tasks`);

  const results = { done: 0, failed: 0, skipped: 0 };

  for (const task of tasks) {
    const action = JSON.parse(task.action);

    try {
      onProgress(`⏳ Wallet ${task.wallet_label}: ${action.type}...`);

      if (!dryRun) {
        const txHash = await executeAirdropAction(task.wallet_label, action);

        db.prepare(
          'UPDATE airdrop_tasks SET status = ?, tx_hash = ?, executed_at = ? WHERE id = ?'
        ).run('done', txHash, Date.now() / 1000, task.id);

        governorRecord({
          wallet: task.wallet_label,
          chainId: action.chainId || 1,
          action: `airdrop:${campaign}:${action.type}`,
          usdValue: null,
          txHash,
        });

        onProgress(`✅ ${task.wallet_label}: ${action.type} — tx: ${txHash?.substring(0, 10)}...`);
        results.done++;
      } else {
        onProgress(`[dry-run] Would execute: ${task.wallet_label} → ${action.type}`);
        results.done++;
      }

      // Jitter delay — anti-sybil pattern
      const delay = minDelayMs + Math.random() * (maxDelayMs - minDelayMs);
      await sleep(Math.round(delay));

    } catch (err) {
      logger.error(`[airdrop] Task ${task.id} failed: ${err.message}`);
      db.prepare(
        'UPDATE airdrop_tasks SET status = ?, error = ?, executed_at = ? WHERE id = ?'
      ).run('failed', err.message.substring(0, 200), Date.now() / 1000, task.id);

      onProgress(`❌ ${task.wallet_label}: ${err.message.substring(0, 80)}`);
      results.failed++;

      // Lanjut ke wallet berikutnya, jangan stop
    }
  }

  onProgress(`\n📊 Campaign "${campaign}" selesai:\n✅ Done: ${results.done}\n❌ Failed: ${results.failed}`);
  return { success: true, results, campaign };
}

/**
 * Eksekusi satu aksi airdrop
 */
async function executeAirdropAction(walletLabel, action) {
  const pk = await getPrivateKey(walletLabel);
  const info = getWalletInfo(walletLabel);
  const chain = action.chain || 'ethereum';
  const rpcUrl = config.rpc.evm[chain];
  if (!rpcUrl) throw new Error(`RPC tidak dikonfigurasi untuk ${chain}`);

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const signer = new ethers.Wallet(pk, provider);

  switch (action.type) {
    case 'transfer': {
      // Transfer ETH/token ke address
      const tx = await signer.sendTransaction({
        to: action.to,
        value: ethers.parseEther(String(action.amount || '0.001')),
      });
      await tx.wait(1);
      return tx.hash;
    }

    case 'contract_call': {
      // Call contract function
      const contract = new ethers.Contract(action.contractAddress, action.abi, signer);
      const args = action.args || [];
      const value = action.value ? ethers.parseEther(String(action.value)) : 0n;
      const tx = await contract[action.functionName](...args, { value });
      await tx.wait(1);
      return tx.hash;
    }

    case 'approve': {
      // Approve token
      const ERC20_ABI = ['function approve(address spender, uint256 amount) returns (bool)'];
      const token = new ethers.Contract(action.tokenAddress, ERC20_ABI, signer);
      const amount = action.amount === 'max' ? ethers.MaxUint256 : ethers.parseUnits(String(action.amount), action.decimals || 18);
      const tx = await token.approve(action.spender, amount);
      await tx.wait(1);
      return tx.hash;
    }

    case 'sign_message': {
      // Sign message (SIWE / proof)
      const sig = await signer.signMessage(action.message);
      return sig; // return signature as "tx hash"
    }

    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}

/**
 * Status campaign
 */
export function getCampaignStatus(campaign) {
  const db = getAirdropDb();
  const stats = db.prepare(`
    SELECT status, COUNT(*) as count 
    FROM airdrop_tasks 
    WHERE campaign = ? 
    GROUP BY status
  `).all(campaign);

  const tasks = db.prepare(
    'SELECT * FROM airdrop_tasks WHERE campaign = ? ORDER BY id DESC LIMIT 20'
  ).all(campaign);

  return { campaign, stats, recentTasks: tasks };
}

/**
 * List semua campaigns
 */
export function listCampaigns() {
  const db = getAirdropDb();
  return db.prepare(
    "SELECT campaign, COUNT(*) as total, SUM(status='done') as done, SUM(status='failed') as failed, SUM(status='pending') as pending FROM airdrop_tasks GROUP BY campaign"
  ).all();
}

/**
 * Helper: buat campaign dari natural language
 * Dipakai oleh brain.js untuk parse instruksi seperti
 * "farming 5 wallet di zkSync, bridge 0.01 ETH masing-masing"
 */
export async function createCampaignFromDescription(description, walletLabels) {
  const { callCascade } = await import('../llm/cascade.js');

  const messages = [
    {
      role: 'system',
      content: `Kamu adalah RAJA. Parse instruksi airdrop farming ke JSON.

Output format:
{
  "campaign": "nama_campaign",
  "actions": [
    {
      "type": "transfer" | "contract_call" | "approve" | "sign_message",
      "chain": "ethereum|base|arbitrum|polygon|bsc",
      "chainId": 1,
      // ... fields sesuai type
    }
  ]
}

Untuk transfer: tambah "to", "amount"
Untuk contract_call: tambah "contractAddress", "abi", "functionName", "args", "value"
Jawab JSON saja.`,
    },
    { role: 'user', content: `Instruksi: ${description}\nWallets tersedia: ${walletLabels.join(', ')}` },
  ];

  const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.2 });
  const jsonMatch = result.text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error('LLM tidak menghasilkan JSON valid');

  return JSON.parse(jsonMatch[0]);
}
