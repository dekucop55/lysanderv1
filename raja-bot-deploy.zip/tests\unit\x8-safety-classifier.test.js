import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { classifyRepairAction, FROZEN_FILES } from '../../src/skills/x8.js';

/**
 * **Validates: Requirements 2.4**
 * Property 9: classifyRepairAction rejects all dangerous targets.
 */
describe('Property 9: Safety Classifier', () => {
  it('rejects FROZEN file targets as unsafe', () => {
    fc.assert(fc.property(
      fc.constantFrom(...FROZEN_FILES),
      fc.constantFrom('code_fix_via_llm', 'fix_import_path', 'reload_skill'),
      (frozenPath, type) => {
        const result = classifyRepairAction({ type, target: frozenPath });
        assert.strictEqual(result, 'unsafe');
      }
    ), { numRuns: 100 });
  });

  it('rejects delete operations as unsafe', () => {
    fc.assert(fc.property(
      fc.string({ minLength: 1, maxLength: 50 }),
      (target) => {
        assert.strictEqual(classifyRepairAction({ type: 'delete', target }), 'unsafe');
        assert.strictEqual(classifyRepairAction({ type: 'delete_file', target }), 'unsafe');
      }
    ), { numRuns: 100 });
  });

  it('rejects governor/wallet/spend-cap patterns as unsafe', () => {
    const dangerous = ['governor.js', 'wallet_config', 'spend_cap_setting', 'private_key_store', 'signing_key.json'];
    fc.assert(fc.property(
      fc.constantFrom(...dangerous),
      fc.constantFrom('code_fix_via_llm', 'enhance_system_prompt'),
      (target, type) => {
        assert.strictEqual(classifyRepairAction({ type, target }), 'unsafe');
      }
    ), { numRuns: 50 });
  });

  it('accepts safe action types with non-dangerous targets', () => {
    const safeTypes = ['reload_skill', 'regen_manifest', 'switch_provider', 'refresh_heartbeat', 'npm_install_package', 'add_routing_keywords'];
    fc.assert(fc.property(
      fc.constantFrom(...safeTypes),
      (type) => {
        assert.strictEqual(classifyRepairAction({ type, target: 'src/skills/m1.js' }), 'safe');
      }
    ), { numRuns: 50 });
  });

  it('defaults null/undefined to unsafe', () => {
    assert.strictEqual(classifyRepairAction(null), 'unsafe');
    assert.strictEqual(classifyRepairAction(undefined), 'unsafe');
    assert.strictEqual(classifyRepairAction({}), 'unsafe');
    assert.strictEqual(classifyRepairAction({ type: null }), 'unsafe');
  });
});
