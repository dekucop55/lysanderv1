// src/telegram/commands/autonomous.js — Autonomous self-update commands
// User kirim instruksi natural language → bot tulis kode sendiri → restart
import { selfModify, generateCodeChanges, executePlan } from '../../self-upgrade/code-engine.js';
import { logger } from '../../utils/logger.js';

// State mesin konfirmasi per-chat
const pendingPlans = new Map(); // chatId → { plan, timestamp }
const PLAN_TTL = 5 * 60 * 1000; // 5 menit sebelum plan expired

// Cleanup expired plans
setInterval(() => {
  const now = Date.now();
  for (const [chatId, p] of pendingPlans) {
    if (now - p.timestamp > PLAN_TTL) pendingPlans.delete(chatId);
  }
}, 60000);

/**
 * /code <instruksi>
 * Contoh: /code tambahkan fitur price alert untuk ETH
 * Contoh: /code perbaiki bug di swap.js dimana decimals tidak dicek
 * Contoh: /code buat skill baru H8 untuk browser automation dengan Playwright
 */
export async function cmdCode(bot, msg, instruction) {
  const chatId = msg.chat.id;

  if (!instruction?.trim()) {
    return bot.sendMessage(
      chatId,
      `*Autonomous Code Engine*\n\n` +
        `Format: /code <instruksi natural language>\n\n` +
        `Contoh:\n` +
        `/code tambahkan H8 browser automation skill\n` +
        `/code perbaiki swap agar support WETH symbol\n` +
        `/code buat command /price untuk cek harga token\n` +
        `/code tambahkan Solana wallet support\n\n` +
        `Bot akan generate kode, tunjukkan plannya, lalu tunggu konfirmasi lo sebelum eksekusi.`,
      { parse_mode: 'Markdown' }
    );
  }

  try {
    await bot.sendChatAction(chatId, 'typing');
    await bot.sendMessage(chatId, `🧠 Analyzing: "${instruction}"\nGenerating code plan...`);

    // Generate plan dari LLM
    const plan = await generateCodeChanges(instruction);

    // Validasi minimal
    if (!plan.files?.length) {
      return bot.sendMessage(chatId, '❌ LLM tidak menghasilkan perubahan file. Coba instruksi lebih spesifik.');
    }

    // Simpan plan untuk konfirmasi
    pendingPlans.set(chatId, { plan, timestamp: Date.now(), instruction });

    // Format summary
    const lines = [
      `📋 *Code Plan*`,
      ``,
      plan.plan,
      ``,
      `*Files (${plan.files.length}):*`,
    ];

    for (const f of plan.files) {
      const icon = f.action === 'create' ? '🆕' : f.action === 'modify' ? '✏️' : '🗑';
      lines.push(`${icon} \`${f.action}\` ${f.path}`);
      if (f.reason) lines.push(`   _${f.reason}_`);
    }

    if (plan.npmInstallRequired && plan.newPackages?.length) {
      lines.push(``, `📦 New packages: ${plan.newPackages.join(', ')}`);
    }
    if (plan.restartRequired) lines.push(`🔄 Restart required`);

    lines.push(
      ``,
      `Ketik /coderun untuk eksekusi, atau /codecancel untuk batal.`,
      `_(Plan expired dalam 5 menit)_`
    );

    await bot.sendMessage(chatId, lines.join('\n'), { parse_mode: 'Markdown' });

  } catch (err) {
    logger.error(`[cmd:code] ${err.message}`);
    await bot.sendMessage(chatId, `❌ Code generation error: ${err.message}`);
  }
}

/**
 * /coderun — Eksekusi plan yang sedang pending
 */
export async function cmdCodeRun(bot, msg) {
  const chatId = msg.chat.id;
  const pending = pendingPlans.get(chatId);

  if (!pending) {
    return bot.sendMessage(chatId, '❌ Tidak ada plan yang pending. Jalankan /code <instruksi> dulu.');
  }

  pendingPlans.delete(chatId);

  await bot.sendMessage(chatId, `⚡ Executing plan...\n\n_${pending.instruction}_`, { parse_mode: 'Markdown' });

  const result = await executePlan(pending.plan, async (progress) => {
    await bot.sendMessage(chatId, progress).catch(() => {});
  });

  if (result.success) {
    const lines = [
      `✅ *Code update selesai!*`,
      ``,
      result.changes.join('\n'),
    ];
    if (result.plan.restartRequired) {
      lines.push(``, `Bot sudah restart. Kirim /status untuk konfirmasi.`);
    }
    await bot.sendMessage(chatId, lines.join('\n'), { parse_mode: 'Markdown' });
  } else {
    await bot.sendMessage(
      chatId,
      `❌ *Gagal*\n\n${result.error}\n\n${result.changes?.join('\n') || ''}`,
      { parse_mode: 'Markdown' }
    );
  }
}

/**
 * /codecancel — Batalkan plan yang pending
 */
export async function cmdCodeCancel(bot, msg) {
  const chatId = msg.chat.id;
  if (pendingPlans.has(chatId)) {
    pendingPlans.delete(chatId);
    await bot.sendMessage(chatId, '✅ Plan dibatalkan.');
  } else {
    await bot.sendMessage(chatId, 'Tidak ada plan yang pending.');
  }
}

/**
 * /codenow <instruksi> — Generate + langsung eksekusi tanpa konfirmasi
 * Hanya untuk operator yang percaya penuh sama bot
 */
export async function cmdCodeNow(bot, msg, instruction) {
  const chatId = msg.chat.id;

  if (!instruction?.trim()) {
    return bot.sendMessage(chatId, 'Usage: /codenow <instruksi>\nEksekusi langsung tanpa konfirmasi.');
  }

  await bot.sendMessage(chatId, `⚡ Auto-executing: "${instruction}"`);

  const result = await selfModify({
    instruction,
    autoConfirm: true,
    onProgress: async (msg) => {
      await bot.sendMessage(chatId, msg).catch(() => {});
    },
  });

  if (result.success) {
    await bot.sendMessage(
      chatId,
      `✅ *Done*\n\n${result.changes.join('\n')}`,
      { parse_mode: 'Markdown' }
    );
  } else {
    await bot.sendMessage(chatId, `❌ ${result.error}`);
  }
}

/**
 * /codelist — List file yang bisa dilihat/dimodifikasi
 */
export async function cmdCodeList(bot, msg, pathArg) {
  const chatId = msg.chat.id;
  const { execSync } = await import('child_process');
  const { config } = await import('../../config.js');

  try {
    const targetPath = pathArg
      ? `${config.raja.home}/${pathArg.replace(/^\//, '')}`
      : `${config.raja.home}/src`;

    const result = execSync(`find "${targetPath}" -name "*.js" -not -path "*/node_modules/*" | head -50`, {
      timeout: 5000,
      encoding: 'utf8',
    });

    const files = result.trim().split('\n')
      .map(f => f.replace(config.raja.home + '/', ''))
      .join('\n');

    await bot.sendMessage(chatId, `📁 *Files di ${pathArg || 'src/'}:*\n\n\`\`\`\n${files}\n\`\`\``, {
      parse_mode: 'Markdown',
    });
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
}

/**
 * /codeview <filepath> — Lihat isi file
 */
export async function cmdCodeView(bot, msg, filePath) {
  const chatId = msg.chat.id;

  if (!filePath) {
    return bot.sendMessage(chatId, 'Usage: /codeview <path>\nContoh: /codeview src/hermes/swap.js');
  }

  const { config } = await import('../../config.js');
  const fs = await import('fs');
  const path = await import('path');

  try {
    const fullPath = path.join(config.raja.home, filePath.replace(/^\//, ''));

    // Security: pastikan path di dalam raja home
    if (!fullPath.startsWith(config.raja.home)) {
      return bot.sendMessage(chatId, '❌ Path tidak valid.');
    }

    if (!fs.existsSync(fullPath)) {
      return bot.sendMessage(chatId, `❌ File tidak ditemukan: ${filePath}`);
    }

    const content = fs.readFileSync(fullPath, 'utf8');
    const truncated = content.length > 3000 ? content.substring(0, 3000) + '\n...(truncated)' : content;

    // Split kalau terlalu panjang untuk satu pesan
    const chunks = splitIntoChunks(truncated, 3500);
    for (const chunk of chunks) {
      await bot.sendMessage(chatId, `\`\`\`javascript\n${chunk}\n\`\`\``, { parse_mode: 'Markdown' });
    }
  } catch (err) {
    await bot.sendMessage(chatId, `❌ Error: ${err.message}`);
  }
}

function splitIntoChunks(text, maxLen) {
  const chunks = [];
  let i = 0;
  while (i < text.length) {
    chunks.push(text.slice(i, i + maxLen));
    i += maxLen;
  }
  return chunks;
}
