// tests/unit/detect-pattern-preference.test.js
// Unit tests for detectPatternPreference (Task 2.4)
// Validates: Requirements 5.3

import { describe, it, expect } from 'vitest';
import { detectPatternPreference } from '../../src/core/conversation-learner.js';

// Helper: create a message within 30 days
function makeMsg(content, daysAgo = 0) {
  const ts = Date.now() - (daysAgo * 24 * 60 * 60 * 1000);
  return { content, role: 'user', timestamp: ts };
}

describe('detectPatternPreference', () => {
  describe('Input validation', () => {
    it('returns [] for null input', () => {
      expect(detectPatternPreference(null)).toEqual([]);
    });

    it('returns [] for undefined input', () => {
      expect(detectPatternPreference(undefined)).toEqual([]);
    });

    it('returns [] for non-array input', () => {
      expect(detectPatternPreference('not an array')).toEqual([]);
    });

    it('returns [] for empty array', () => {
      expect(detectPatternPreference([])).toEqual([]);
    });

    it('returns [] when fewer than 3 valid user messages', () => {
      const messages = [
        makeMsg('hello python'),
        makeMsg('use python please'),
      ];
      expect(detectPatternPreference(messages)).toEqual([]);
    });

    it('returns [] when messages are older than 30 days', () => {
      const messages = [
        makeMsg('use python', 31),
        makeMsg('use python', 32),
        makeMsg('use python', 33),
      ];
      expect(detectPatternPreference(messages)).toEqual([]);
    });

    it('ignores assistant messages', () => {
      const messages = [
        { content: 'python python python', role: 'assistant', timestamp: Date.now() },
        { content: 'python python python', role: 'assistant', timestamp: Date.now() },
        { content: 'python python python', role: 'assistant', timestamp: Date.now() },
        makeMsg('hello world'),
        makeMsg('how are you'),
        makeMsg('nice day'),
      ];
      expect(detectPatternPreference(messages)).toEqual([]);
    });
  });

  describe('Language pattern detection', () => {
    it('detects repeated language mentions (>= 3 times)', () => {
      const messages = [
        makeMsg('write me a python script'),
        makeMsg('can you do this in python'),
        makeMsg('python version please'),
        makeMsg('hello there'),
      ];
      const result = detectPatternPreference(messages);
      expect(result.length).toBeGreaterThan(0);
      const pythonPref = result.find(p => p.key === 'preferred_language' && p.value === 'python');
      expect(pythonPref).toBeDefined();
      expect(pythonPref.count).toBe(3);
    });

    it('does not detect language with count < 3', () => {
      const messages = [
        makeMsg('write python script'),
        makeMsg('another python thing'),
        makeMsg('hello world'),
        makeMsg('random stuff'),
      ];
      const result = detectPatternPreference(messages);
      const pythonPref = result.find(p => p.key === 'preferred_language' && p.value === 'python');
      expect(pythonPref).toBeUndefined();
    });
  });

  describe('Format pattern detection', () => {
    it('detects repeated format requests', () => {
      const messages = [
        makeMsg('kasih dalam format json'),
        makeMsg('format json please'),
        makeMsg('tolong format json'),
        makeMsg('do something'),
      ];
      const result = detectPatternPreference(messages);
      const formatPref = result.find(p => p.key === 'response_format' && p.value === 'json');
      expect(formatPref).toBeDefined();
      expect(formatPref.count).toBeGreaterThanOrEqual(3);
    });

    it('detects concise preference', () => {
      const messages = [
        makeMsg('jawab singkat aja'),
        makeMsg('yang singkat please'),
        makeMsg('singkat aja gpp'),
        makeMsg('another message'),
      ];
      const result = detectPatternPreference(messages);
      const concisePref = result.find(p => p.key === 'response_format' && p.value === 'concise');
      expect(concisePref).toBeDefined();
      expect(concisePref.count).toBeGreaterThanOrEqual(3);
    });

    it('detects step-by-step preference', () => {
      const messages = [
        makeMsg('tolong step by step'),
        makeMsg('bisa step-by-step?'),
        makeMsg('kasih step by step'),
        makeMsg('thanks'),
      ];
      const result = detectPatternPreference(messages);
      const stepPref = result.find(p => p.key === 'response_format' && p.value === 'step-by-step');
      expect(stepPref).toBeDefined();
      expect(stepPref.count).toBeGreaterThanOrEqual(3);
    });
  });

  describe('Tool/action pattern detection', () => {
    it('detects repeated tool usage', () => {
      const messages = [
        makeMsg('swap ETH to USDC'),
        makeMsg('swap BTC to ETH'),
        makeMsg('swap USDC to DAI'),
        makeMsg('hello'),
      ];
      const result = detectPatternPreference(messages);
      const swapPref = result.find(p => p.key === 'frequent_action' && p.value === 'swap');
      expect(swapPref).toBeDefined();
      expect(swapPref.count).toBe(3);
    });
  });

  describe('Threshold and sorting', () => {
    it('only includes patterns with count >= 3', () => {
      const messages = [
        makeMsg('python script'),
        makeMsg('python code'),
        makeMsg('python function'),
        makeMsg('javascript once'),
        makeMsg('random msg'),
      ];
      const result = detectPatternPreference(messages);
      for (const pattern of result) {
        expect(pattern.count).toBeGreaterThanOrEqual(3);
      }
    });

    it('returns results sorted by count descending', () => {
      const messages = [
        makeMsg('swap ETH'),
        makeMsg('swap BTC'),
        makeMsg('swap USDC'),
        makeMsg('swap DAI'),
        makeMsg('python script'),
        makeMsg('python code'),
        makeMsg('python function'),
      ];
      const result = detectPatternPreference(messages);
      for (let i = 0; i < result.length - 1; i++) {
        expect(result[i].count).toBeGreaterThanOrEqual(result[i + 1].count);
      }
    });
  });

  describe('Timestamp handling', () => {
    it('works with ISO string timestamps', () => {
      const now = new Date();
      const messages = [
        { content: 'swap ETH', role: 'user', timestamp: now.toISOString() },
        { content: 'swap BTC', role: 'user', timestamp: new Date(now - 86400000).toISOString() },
        { content: 'swap USDC', role: 'user', timestamp: new Date(now - 172800000).toISOString() },
      ];
      const result = detectPatternPreference(messages);
      const swapPref = result.find(p => p.key === 'frequent_action' && p.value === 'swap');
      expect(swapPref).toBeDefined();
    });

    it('works with numeric timestamps', () => {
      const now = Date.now();
      const messages = [
        { content: 'swap ETH', role: 'user', timestamp: now },
        { content: 'swap BTC', role: 'user', timestamp: now - 86400000 },
        { content: 'swap USDC', role: 'user', timestamp: now - 172800000 },
      ];
      const result = detectPatternPreference(messages);
      const swapPref = result.find(p => p.key === 'frequent_action' && p.value === 'swap');
      expect(swapPref).toBeDefined();
    });

    it('filters out messages with invalid timestamps', () => {
      const messages = [
        { content: 'swap ETH', role: 'user', timestamp: 'invalid-date' },
        { content: 'swap BTC', role: 'user', timestamp: 'not-a-date' },
        { content: 'swap USDC', role: 'user', timestamp: 'garbage' },
      ];
      const result = detectPatternPreference(messages);
      expect(result).toEqual([]);
    });
  });

  describe('Return type guarantee', () => {
    it('always returns an array (never null)', () => {
      // Various inputs that previously returned null
      expect(detectPatternPreference(null)).toEqual([]);
      expect(detectPatternPreference([])).toEqual([]);
      expect(detectPatternPreference([makeMsg('a'), makeMsg('b')])).toEqual([]);
      expect(detectPatternPreference([makeMsg('no patterns here'), makeMsg('random'), makeMsg('stuff')])).toEqual([]);
    });
  });
});
