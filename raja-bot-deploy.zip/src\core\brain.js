﻿// src/core/brain.js — Grounded Reasoning Engine (RAJA v4.2)
// Architecture: LLM-first intent classification + reality anchors + smart memory
import { config } from '../config.js';
import { callCascade, switchProvider, resolveProviderName, getProviderStatus } from '../llm/cascade.js';
import { recallMemory, rememberFact, saveMessage, savePreference, runPreferenceDecay } from './memory.js';
import { skills, routeSkill, fuzzyMatch, getSuggestions } from './skill-registry.js';
import { logger } from '../utils/logger.js';
import { selfModifyFromMessage } from '../self-upgrade/code-engine.js';
import { detectDissatisfaction, detectSatisfaction, learnFromMistake, reinforceGoodResponse, recallLessons, detectExplicitPreference } from './conversation-learner.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// ─── Lazy contextWindow accessor ─────────────────────────────────────────────
// Uses lazy import to avoid circular dependency: index.js → bot.js → brain.js → index.js
// contextWindow is initialized in index.js after brain.js is loaded.
let _contextWindowModule = null;
function getContextWindow() {
  if (_contextWindowModule !== null) return _contextWindowModule;
  // Only attempt dynamic import once; if it fails, set to undefined to avoid retrying
  try {
    // Use a synchronous require-like pattern: since index.js has already set the export
    // by the time processMessage() is called, we can access it via a deferred import.
    // We store a promise that resolves the module, then extract contextWindow on use.
    // For truly lazy access, we use a module-level flag resolved on first call.
    _contextWindowModule = 'pending';
    import('../index.js').then(mod => {
      _contextWindowModule = mod;
    }).catch(() => {
      _contextWindowModule = null;
    });
    return null; // Not yet resolved on first call — will be available next turn
  } catch {
    _contextWindowModule = null;
    return null;
  }
}

// Synchronously get contextWindow from cached module export
function getContextWindowInstance() {
  if (_contextWindowModule && _contextWindowModule !== 'pending' && _contextWindowModule.contextWindow) {
    return _contextWindowModule.contextWindow;
  }
  // Trigger the lazy load if not started yet
  if (_contextWindowModule === null) getContextWindow();
  return null;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');

// ─── ActivePlanManager ───────────────────────────────────────────────────────
// Manages active execution plans per session with TTL-based expiration.
// Plans track what the user and bot have agreed to execute.

/**
 * @typedef {Object} ActivePlan
 * @property {string} planId - UUID rencana
 * @property {string} skillId - ID skill target eksekusi
 * @property {string} description - Deskripsi rencana
 * @property {'agreed'|'proposed'|'expired'} status
 * @property {number} lastInteraction - Unix timestamp ms
 * @property {number} ttlMs - TTL dalam milliseconds (default 1800000 = 30 menit)
 */

export class ActivePlanManager {
  /**
   * @param {number} ttlMs - Default TTL in milliseconds (30 minutes)
   */
  constructor(ttlMs = 30 * 60 * 1000) {
    this.ttlMs = ttlMs;
    this.sessions = new Map(); // sessionId → ActivePlan[]
  }

  /**
   * Menyimpan plan baru ke session
   * @param {string} sessionId
   * @param {ActivePlan} plan
   */
  setPlan(sessionId, plan) {
    if (!this.sessions.has(sessionId)) {
      this.sessions.set(sessionId, []);
    }
    plan.lastInteraction = Date.now();
    plan.ttlMs = plan.ttlMs || this.ttlMs;
    this.sessions.get(sessionId).push(plan);
  }

  /**
   * Mengambil satu active plan yang berstatus "agreed" dan belum expired.
   * Return null jika tidak ada atau lebih dari satu (disambiguation needed).
   * @param {string} sessionId
   * @returns {ActivePlan|null}
   */
  getActivePlan(sessionId) {
    this.pruneExpired(sessionId);
    const plans = this.sessions.get(sessionId) || [];
    const agreedPlans = plans.filter(p => p.status === 'agreed');
    return agreedPlans.length === 1 ? agreedPlans[0] : null;
  }

  /**
   * Mengambil semua active plans (agreed + proposed) yang belum expired.
   * Digunakan untuk disambiguation ketika multiple plans aktif.
   * @param {string} sessionId
   * @returns {ActivePlan[]}
   */
  getActivePlans(sessionId) {
    this.pruneExpired(sessionId);
    const plans = this.sessions.get(sessionId) || [];
    return plans.filter(p => p.status === 'agreed' || p.status === 'proposed');
  }

  /**
   * Menandai plan sebagai "agreed" dan refresh TTL.
   * @param {string} sessionId
   * @param {string} planId
   */
  agreePlan(sessionId, planId) {
    const plans = this.sessions.get(sessionId) || [];
    const plan = plans.find(p => p.planId === planId);
    if (plan) {
      plan.status = 'agreed';
      plan.lastInteraction = Date.now();
    }
  }

  /**
   * Menghapus expired plans dari session dan return yang dihapus.
   * Plan expired jika (now - lastInteraction) > ttlMs.
   * @param {string} sessionId
   * @returns {ActivePlan[]} Plans yang expired dan dihapus
   */
  pruneExpired(sessionId) {
    const plans = this.sessions.get(sessionId) || [];
    const now = Date.now();
    const expired = [];
    const active = [];

    for (const plan of plans) {
      if (now - plan.lastInteraction > (plan.ttlMs || this.ttlMs)) {
        plan.status = 'expired';
        expired.push(plan);
      } else {
        active.push(plan);
      }
    }

    this.sessions.set(sessionId, active);
    return expired;
  }

  /**
   * Refresh TTL untuk semua active plans dalam session.
   * Dipanggil setiap kali ada interaksi dari user pada session tersebut.
   * @param {string} sessionId
   */
  touchPlan(sessionId) {
    const plans = this.sessions.get(sessionId) || [];
    const now = Date.now();
    for (const plan of plans) {
      if (plan.status !== 'expired') {
        plan.lastInteraction = now;
      }
    }
  }
}

// Singleton instance untuk digunakan di seluruh aplikasi
export const planManager = new ActivePlanManager();

// ─── User profile loader ─────────────────────────────────────────────────────

function loadUserProfile() {
  const userMdPath = path.join(ROOT, 'USER.md');
  if (fs.existsSync(userMdPath)) {
    const content = fs.readFileSync(userMdPath, 'utf8');
    return content.split('\n').filter(l => !l.startsWith('#')).join('\n').trim().substring(0, 500);
  }
  return '';
}

const USER_CONTEXT = loadUserProfile();

// ─── Runtime Context ─────────────────────────────────────────────────────────

function buildRuntimeContext() {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-US', { timeZone: 'Asia/Jakarta', weekday: 'long' });
  const dateFmt = new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  });
  return `[RUNTIME] ${dateFmt.format(now)} WIB | ${fmt.format(now)} | Unix: ${Math.floor(now.getTime() / 1000)}`;
}

function buildProviderListForPrompt() {
  // Read from LLM_N_* env vars directly
  const providers = [];
  for (let i = 1; i <= 9; i++) {
    const name = process.env[`LLM_${i}_NAME`];
    const model = process.env[`LLM_${i}_MODEL`];
    if (name && model) {
      providers.push(`${i}. ${model} via ${name}${i === 1 ? ' (primary)' : ''}`);
    }
  }
  // Fallback to legacy config
  if (providers.length === 0) {
    if (config.llm.ollamaCloud.model) providers.push(`1. ${config.llm.ollamaCloud.model} via Ollama Cloud (primary)`);
  }
  return providers.join('\n');
}

// ─── Reality Anchors (injected every turn) ───────────────────────────────────
// This prevents LLM from "forgetting" what it can actually do.

function buildRealityAnchors() {
  const skillList = Object.entries(skills)
    .map(([id, s]) => `${id}:${s.name}`)
    .join(', ');

  return `═══ REALITY ANCHORS (FAKTA KEMAMPUAN REAL) ═══
AKSES LANGSUNG:
- File system VPS: baca, tulis, hapus, edit semua file di /opt/raja-bot/
- Self-modify: bisa ubah kode sendiri, tambah/hapus skill, restart
- Shell execution: jalankan command apapun di VPS (bash, npm, pm2, git, dll)
- Telegram: kirim pesan, file, gambar ke operator
- LLM cascade: ${buildProviderListForPrompt()}
- Memory: SQLite persistent memory (simpan, recall, reinforce)
- Crypto: wallet management, swap, bridge, DeFi, monitoring (via Hermes)
- Browser automation: Playwright headless

SKILLS AKTIF (${Object.keys(skills).length} total):
${skillList}

BATASAN NYATA:
- Tidak bisa akses internet langsung (hanya via API yang sudah tersedia)
- Tidak bisa menjalankan GUI di VPS
- Context window terbatas — gue selalu inject 20 percakapan terakhir + summary

PENTING: Jangan bilang "saya tidak bisa" kecuali benar-benar tidak mungkin secara teknis.
Jangan halusinasi fitur yang tidak ada. Jawab dari fakta di atas.`;
}

// ─── Session State ───────────────────────────────────────────────────────────

const session = {
  startTime: Date.now(),
  goal: null,
  activeSkill: null,
  autoConfirm: false,
  dryRun: false,
  history: [],          // Full recent history (max 40 messages = 20 turns)
  historySummary: '',   // Summary of older conversations
  lastCodeEngine: null,
  turnCount: 0,
};

const MAX_HISTORY_MESSAGES = 40; // 20 turns (user + assistant)
const SUMMARY_THRESHOLD = 40;   // When history exceeds this, summarize oldest

// ─── Smart History Management ────────────────────────────────────────────────

async function trimAndSummarize() {
  if (session.history.length <= SUMMARY_THRESHOLD) return;

  // Take oldest 20 messages (10 turns) to summarize
  const toSummarize = session.history.slice(0, 20);
  session.history = session.history.slice(20);

  // Build summary via LLM
  try {
    const summaryMessages = [
      {
        role: 'system',
        content: `Kamu adalah summarizer. Ringkas percakapan berikut dalam 3-5 bullet points.
Fokus pada: keputusan yang dibuat, perintah yang dieksekusi, context penting.
Format: bullet points, bahasa Indonesia singkat. Max 300 kata.`,
      },
      {
        role: 'user',
        content: toSummarize.map(m => `[${m.role}]: ${m.content.substring(0, 200)}`).join('\n'),
      },
    ];

    const result = await callCascade(summaryMessages, { maxTokens: 400, temperature: 0.3 });
    const newSummary = result.text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();

    // Append to existing summary
    if (session.historySummary) {
      session.historySummary = `${newSummary}\n---\n${session.historySummary}`.substring(0, 1500);
    } else {
      session.historySummary = newSummary;
    }

    logger.info(`[brain] History summarized. Current: ${session.history.length} msgs, summary: ${session.historySummary.length} chars`);
  } catch (err) {
    logger.warn(`[brain] Summary failed: ${err.message}. Truncating without summary.`);
    // Fallback: just truncate
  }
}

// ─── SYSTEM PROMPT (Identity) ────────────────────────────────────────────────

const IDENTITY_PROMPT = `Kamu adalah Lysander Phoebe Keset Sejuta Umat, codename RAJA.
Version: 4.2 GROUNDED REASONING. Execution agent — bukan chatbot generik.

═══ KARAKTER ═══
- Lo RAJA. Partner eksekusi. Bahasa: Indonesian casual (lo/gue). Honorific: "Bos".
- Kayak temen jago tech — direct, helpful, gak sok formal.
- Gak pernah bilang "Sebagai AI..." → always offer alternative.
- NEVER dead-end.

═══ CARA MIKIR (PALING PENTING) ═══
SEBELUM jawab, SELALU tanya ke diri sendiri:
1. Apa yang user SEBENERNYA mau? (bukan literal text-nya)
2. Apakah ini follow-up dari percakapan sebelumnya? (cek HISTORY)
3. Ini PERTANYAAN (mau info) atau PERINTAH (mau eksekusi)?
4. Kalau pertanyaan → jawab informatif, singkat, dari konteks yang ada
5. Kalau perintah → eksekusi, kasih hasil
6. Kalau ambigu → tanya balik SINGKAT untuk klarifikasi

═══ CONVERSATION AWARENESS ═══
- SELALU cek HISTORY di bawah sebelum jawab
- Follow-up tentang output sebelumnya → jawab dari context, BUKAN trigger skill baru
- Kalau user sebut "itu", "tadi", "yang barusan" → merujuk ke history
- JANGAN ulangi info yang sudah user tahu dari percakapan sebelumnya

═══ PRIMARY MISSION ═══
Bantu Bos: Web3, airdrop farming, software dev, content, daily ops, crypto.

═══ RESPONSE STYLE ═══
- fast: 1-3 baris (single-fact, yes/no, konfirmasi)
- standard: jawaban + next step (DEFAULT)
- deep: structured (hanya kalau diminta atau complex topic)

═══ R-RULES ═══
R1: NEVER DEAD-END | R2: EXECUTE > EXPLAIN | R3: CONTEXT FIRST
R4: MEMORY AUTO | R5: CUAN LENS | R6: ADAPTIVE FORMAT
R8: ❌ disclaimer, ❌ repeat input, ❌ generic filler, ❌ minta maaf
R9: RISK GATE sekali (bukan berulang) | R10: CODE COMPLETENESS

${USER_CONTEXT ? `\nOperator: ${USER_CONTEXT.substring(0, 200)}` : ''}

Lo RAJA. Jawab kayak manusia. Singkat. Natural. Grounded in reality.`;

// ─── EXECUTE Keywords & Agreement Phrases ────────────────────────────────────
// Keyword-based intent classification (replaces isCodeModificationIntent gate)

export const EXECUTE_KEYWORDS = new Set([
  'eksekusi', 'lakukan', 'jalankan', 'run', 'go',
  'send it', 'execute', 'do it', 'gas', 'ok gas'
]);

const AGREEMENT_PHRASES = new Set([
  'ok', 'oke', 'setuju', 'yes', 'deal', 'sip', 'lanjut', 'gas', 'yoi', 'mantap'
]);

/**
 * Check if message is an agreement phrase (exact match after trim/lowercase)
 * @param {string} message
 * @returns {boolean}
 */
function isAgreementPhrase(message) {
  const cleaned = message.toLowerCase().trim();
  return AGREEMENT_PHRASES.has(cleaned);
}

/**
 * Check if message contains an action verb (common Indonesian/English verbs)
 * @param {string} message
 * @returns {boolean}
 */
function containsActionVerb(message) {
  const actionVerbs = ['swap', 'transfer', 'kirim', 'deploy', 'buat', 'hapus', 'cek', 'monitor', 'audit', 'bridge'];
  const lower = message.toLowerCase();
  return actionVerbs.some(verb => lower.includes(verb));
}

/**
 * Klasifikasi intent tanpa isCodeModificationIntent() gate.
 * Menggunakan keyword + active_plan untuk menentukan intent.
 *
 * @param {string} message - Pesan user
 * @param {Object} sessionState - Session state (must have sessionState.id)
 * @returns {'EXECUTE'|'CHAT'|'CONFIRM'}
 *
 * Logic:
 * - Agreement phrase → CONFIRM
 * - Short command (1-5 kata) + exec keyword + active plan = EXECUTE
 * - Longer command dengan exec keyword atau action verb = EXECUTE
 * - Lainnya = CHAT
 *
 * Validates: Requirements 1.1, 1.3, 1.4
 */
export function classifyIntent(message, sessionState) {
  const words = message.toLowerCase().trim().split(/\s+/);
  const isShortCommand = words.length <= 5;
  const hasExecKeyword = words.some(w => EXECUTE_KEYWORDS.has(w));
  const activePlan = planManager.getActivePlan(sessionState.id);

  // Konfirmasi agreement phrase
  if (isAgreementPhrase(message)) return 'CONFIRM';

  // Short command + exec keyword + active plan = EXECUTE
  if (isShortCommand && hasExecKeyword && activePlan) return 'EXECUTE';

  // Longer command — analyze via action verbs or exec keywords
  if (hasExecKeyword || containsActionVerb(message)) return 'EXECUTE';

  return 'CHAT';
}

// ─── EXECUTE Routing ─────────────────────────────────────────────────────────
// Routes EXECUTE intent to appropriate skill using active_plan + fuzzy matching.

/**
 * Route EXECUTE intent to appropriate skill.
 *
 * Priority:
 * 1. If active_plan agreed exists → dispatch to plan.skillId
 * 2. If multiple plans → disambiguation prompt
 * 3. If no plan → use fuzzyMatch from SkillRegistry
 * 4. If fuzzyMatch returns result → dispatch to that skill
 * 5. If no match → klarifikasi with top 3 suggestions
 *
 * IMPORTANT: Do NOT inject anti-hallucination prompt on this path.
 *
 * @param {string} message - User message
 * @param {Object} sessionState - Session state with sessionState.id
 * @param {Object} context - Additional context (userId, etc.)
 * @returns {Object} { action: 'dispatch'|'clarify'|'disambiguate', skillId?, suggestions?, plans?, message? }
 *
 * Validates: Requirements 1.2, 1.5, 1.7, 2.3, 2.4, 2.5
 */
export function routeExecute(message, sessionState, context = {}) {
  const sessionId = sessionState.id;

  // 1. Check for single agreed active plan → dispatch directly
  const activePlan = planManager.getActivePlan(sessionId);
  if (activePlan) {
    planManager.touchPlan(sessionId);
    return {
      action: 'dispatch',
      skillId: activePlan.skillId,
      plan: activePlan,
    };
  }

  // 2. Check for multiple active plans → disambiguation
  const allPlans = planManager.getActivePlans(sessionId);
  if (allPlans.length > 1) {
    return {
      action: 'disambiguate',
      plans: allPlans,
      message: 'Ada beberapa rencana aktif. Pilih yang mau dieksekusi:',
    };
  }

  // 3. No plan → try fuzzy match from SkillRegistry
  const matched = fuzzyMatch(message);
  if (matched) {
    return {
      action: 'dispatch',
      skillId: matched.skillId,
      matchedSkill: matched,
    };
  }

  // 4. No match → suggest top 3
  const suggestions = getSuggestions(message, 3);

  // 5. If no plan and no suggestions at all → ask user to clarify
  if (allPlans.length === 0 && suggestions.length === 0) {
    return {
      action: 'clarify',
      suggestions: [],
      message: 'Tidak ada rencana aktif. Jelaskan apa yang ingin dieksekusi.',
    };
  }

  // Has some suggestions but no strong match → offer suggestions
  return {
    action: 'clarify',
    suggestions,
    message: 'Tidak bisa mencocokkan command Anda. Apakah yang Anda maksud salah satu dari ini?',
  };
}

// ─── Intent Classification via LLM ──────────────────────────────────────────
// This replaces brittle keyword-matching with actual language understanding.

const INTENT_CLASSIFIER_PROMPT = `Kamu adalah intent classifier untuk AI agent bernama RAJA.
Tugas: classify user message ke SATU kategori.

KATEGORI:
- EXECUTE: User mau bot melakukan sesuatu (modify code, jalankan command, buat file, hapus, install, deploy, restart, dsb)
- SKILL_QUERY: User mau bot menggunakan skill tertentu (swap token, cek balance, monitoring, bridge, DeFi ops, mint, snipe)
- QUESTION: User nanya sesuatu (minta info, penjelasan, cara, tips)
- FOLLOW_UP: User merespon/membahas output sebelumnya (merujuk "itu", "tadi", "hasilnya", "terus", "lanjut")
- META: User nanya tentang bot sendiri (kemampuan, skill list, siapa kamu, config)
- MODEL_SWITCH: User mau ganti LLM provider (pakai model X, ganti ke Y, switch provider)
- SESSION_CTRL: User mau kontrol session (auto_confirm on/off, dry-run)
- CASUAL: Chat santai, basa-basi, atau tidak jelas

RULES:
- Jawab HANYA dengan satu kata: EXECUTE, SKILL_QUERY, QUESTION, FOLLOW_UP, META, MODEL_SWITCH, SESSION_CTRL, atau CASUAL
- Jangan tambahkan penjelasan apapun
- Kalau ada kata "tadi", "itu", "barusan", "yang sebelumnya" → kemungkinan besar FOLLOW_UP
- Kalau ada kata kerja imperatif + target code/bot/system → EXECUTE
- "gas", "lanjut", "sikat" setelah diskusi sebelumnya → EXECUTE (konfirmasi untuk eksekusi)`;

/**
 * Classify user intent using LLM.
 * Fast call with low max_tokens for speed.
 */
async function classifyIntentLLM(userMessage, recentHistory) {
  try {
    // Build minimal context for classification
    const historyContext = recentHistory.slice(-6).map(m =>
      `[${m.role}]: ${m.content.substring(0, 100)}`
    ).join('\n');

    const messages = [
      { role: 'system', content: INTENT_CLASSIFIER_PROMPT },
      { role: 'user', content: `RECENT HISTORY:\n${historyContext || '(kosong)'}\n\nUSER MESSAGE: ${userMessage}` },
    ];

    const result = await callCascade(messages, { maxTokens: 10, temperature: 0.1 });
    const intent = result.text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim().toUpperCase();

    // Validate — must be one of known intents
    const VALID_INTENTS = ['EXECUTE', 'SKILL_QUERY', 'QUESTION', 'FOLLOW_UP', 'META', 'MODEL_SWITCH', 'SESSION_CTRL', 'CASUAL'];
    if (VALID_INTENTS.includes(intent)) {
      logger.info(`[brain] Intent: ${intent} for "${userMessage.substring(0, 50)}..."`);
      return intent;
    }

    // Partial match (LLM might output "EXECUTE - user wants to...")
    for (const valid of VALID_INTENTS) {
      if (intent.includes(valid)) return valid;
    }

    logger.warn(`[brain] Unknown intent "${intent}", defaulting to QUESTION`);
    return 'QUESTION';
  } catch (err) {
    logger.warn(`[brain] Intent classification failed: ${err.message}. Using fallback.`);
    return classifyIntentFallback(userMessage);
  }
}

/**
 * Fallback intent classifier (keyword-based, used if LLM fails)
 */
function classifyIntentFallback(message) {
  const lower = message.toLowerCase().trim();

  // Short imperative commands
  if (/^(gas|lanjut|sikat|eksekusi|jalankan|deploy|pasang)\s*$/i.test(lower)) return 'EXECUTE';

  // Self-modify verbs + targets
  const execVerbs = ['tambah', 'buat', 'bikin', 'hapus', 'delete', 'perbaiki', 'fix', 'update', 'ubah', 'install', 'pasang', 'deploy'];
  const execTargets = ['skill', 'fitur', 'code', 'kode', 'bot', 'sistem', 'file', 'module'];
  if (execVerbs.some(v => lower.includes(v)) && execTargets.some(t => lower.includes(t))) return 'EXECUTE';

  // Meta questions
  if (/^(siapa|apa)\s+(kamu|lo|lu|raja)/i.test(lower)) return 'META';
  if (/skill|kemampuan|bisa\s+apa/i.test(lower) && /\?|apa|list|daftar/.test(lower)) return 'META';

  // Follow-up
  if (/\b(tadi|itu|barusan|sebelumnya|hasilnya|outputnya)\b/.test(lower)) return 'FOLLOW_UP';

  // Model switch
  if (/\b(ganti|switch|pindah|pakai)\b.*\b(model|provider|llm)\b/i.test(lower)) return 'MODEL_SWITCH';

  return 'QUESTION';
}

// ─── Model Switch Handler ────────────────────────────────────────────────────

function handleModelSwitch(message) {
  const lower = message.toLowerCase().trim();

  const switchIntent = /\b(ganti|switch|pindah|pakai|gunakan|use|pake)\b/.test(lower);
  if (switchIntent) {
    const status = getProviderStatus();
    const providerNames = status.providers.map(p => p.name.toLowerCase());
    const aliases = { ollama: 'ollama-cloud', 'ollama cloud': 'ollama-cloud', gemma: 'ollama-cloud' };

    for (const pName of providerNames) {
      if (lower.includes(pName)) {
        const result = switchProvider(pName);
        return result.success ? `✅ ${result.message}\n\nMode: ${getProviderStatus().mode}` : `❌ ${result.message}`;
      }
    }
    for (const [alias, target] of Object.entries(aliases)) {
      if (lower.includes(alias)) {
        const result = switchProvider(target);
        return result.success ? `✅ ${result.message}\n\nMode: ${getProviderStatus().mode}` : `❌ ${result.message}`;
      }
    }

    const words = lower.split(/\s+/);
    for (const word of words) {
      const resolved = resolveProviderName(word);
      if (resolved && resolved !== 'auto') {
        const result = switchProvider(resolved);
        if (result.success) return `✅ ${result.message}\n\nMode: ${getProviderStatus().mode}`;
      }
    }
  }

  // Force command
  const forceMatch = lower.match(/^force\s+(\S+)/i);
  if (forceMatch) {
    const resolved = resolveProviderName(forceMatch[1]);
    if (resolved) {
      const result = switchProvider(resolved);
      return result.success ? `✅ ${result.message}` : `❌ ${result.message}`;
    }
  }

  // Query providers
  if (/\b(model|provider|llm)\b.*\b(apa|mana|yang|aktif|online|sekarang|dipake|list|daftar)\b/i.test(lower) ||
      /^(?:list|daftar)\s+(?:model|provider|llm)/i.test(lower)) {
    const status = getProviderStatus();
    const lines = status.providers.map((p, i) => `${i + 1}. ${p.name} ${p.active ? '✅' : '—'}`).join('\n');
    return `🔧 LLM Providers:\n${lines}\n\nMode: ${status.mode}\nPrimary: ${config.llm.ollamaCloud.model}`;
  }

  return null;
}

// ─── Session Control Handler ─────────────────────────────────────────────────

function handleSessionControl(message) {
  const lower = message.toLowerCase().trim();
  if (/^auto[_\s]?confirm\s+(on|true|aktif)/i.test(lower)) { session.autoConfirm = true; return '✅ [AUTO_CONFIRM] ON.'; }
  if (/^auto[_\s]?confirm\s+(off|false|mati)/i.test(lower)) { session.autoConfirm = false; return '✅ [AUTO_CONFIRM] OFF.'; }
  if (/^dry[_\s-]?run\s+(on|true|aktif)/i.test(lower)) { session.dryRun = true; return '🧪 [DRY-RUN] ON.'; }
  if (/^dry[_\s-]?run\s+(off|false|mati)/i.test(lower)) { session.dryRun = false; return '🔴 [DRY-RUN] OFF.'; }
  return null;
}

// ─── Response Cleaner ────────────────────────────────────────────────────────

function cleanLlmResponse(text) {
  if (!text) return '';
  let cleaned = text.replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  cleaned = cleaned.replace(/<think>[\s\S]*/gi, '').trim();
  if (cleaned.length > 3800) cleaned = cleaned.substring(0, 3800) + '\n\n...(dipotong)';
  return cleaned;
}

// ─── Execution Intent Extractor ──────────────────────────────────────────────
// When intent is EXECUTE, extract the clean instruction for code-engine

function extractInstruction(message) {
  return message
    .replace(/^(hei|hai|hey|oi|ok|oke|tolong|coba|bisa|please|boleh|minta)[,\s]+/i, '')
    .replace(/^(saya ingin kamu|saya mau kamu|saya minta kamu|bisakah kamu|bisa kamu)\s+/i, '')
    .replace(/^(sekarang|langsung|langsung aja|ayo)\s+/i, '')
    .trim();
}

// ─── Direct System Command Detection ────────────────────────────────────────
// Detects commands that should go to m2 (VPS skill) rather than code-engine.

/**
 * @deprecated Replaced by classifyIntent() which uses EXECUTE_KEYWORDS + active_plan.
 * Kept for backward compatibility but no longer used in EXECUTE routing.
 * See Task 5.1 — Requirements 1.1, 1.3, 1.4.
 *
 * Detect if message is an EXPLICIT code modification request.
 * Must contain both a modification VERB and a code TARGET.
 */
function isCodeModificationIntent(message) {
  const lower = message.toLowerCase().trim();

  // Must have explicit modification verbs
  const modVerbs = [
    'tambah skill', 'tambahkan skill', 'buat skill', 'bikin skill',
    'hapus skill', 'delete skill', 'remove skill',
    'tambah fitur', 'tambahkan fitur', 'buat fitur', 'bikin fitur',
    'perbaiki code', 'perbaiki kode', 'fix code', 'fix bug',
    'update skill', 'upgrade skill', 'modify skill',
    'buat command', 'tambah command', 'bikin command',
    'refactor', 'rewrite', 'implementasi', 'implementasikan',
    'self improve', 'self-improve', 'improve diri', 'upgrade diri',
    'sinkronisasi', 'sinkronkan', 'sync',
  ];

  for (const verb of modVerbs) {
    if (lower.includes(verb)) return true;
  }

  // Explicit prefix triggers (user intentionally wants code changes)
  if (/^(buat|bikin|create|tulis|write)\s+.*(skill|fitur|module|modul|command|fungsi)/i.test(lower)) return true;
  if (/^(hapus|delete|remove|buang)\s+.*(skill|fitur|module|modul|command)/i.test(lower)) return true;
  if (/^(perbaiki|fix|update|upgrade)\s+.*(skill|bot|code|kode|sistem)/i.test(lower)) return true;

  return false;
}

// Detects commands that should go to m2 (VPS skill) rather than code-engine.

function isDirectSystemCommand(message) {
  const lower = message.toLowerCase().trim();

  // Direct file/folder operations (reading, listing, checking)
  if (/\b(cek|lihat|tampilkan|show|baca|cat|read|akses|buka)\b.*\b(file|folder|isi|log|directory|dir|\.env|\.js|\.json|\.md|\.txt)\b/i.test(lower)) return true;
  if (/\b(cek\s+isi|lihat\s+isi|isi\s+file|isi\s+folder)\b/i.test(lower)) return true;
  if (/\b(ls|cat|head|tail|less|nano|vim)\b/i.test(lower)) return true;
  if (/\/opt\/|\/home\/|\/etc\/|\/var\/|\/tmp\/|\/root\//i.test(lower)) return true;

  // PM2 / process management
  if (/\b(pm2|restart|reload|status|stop|start)\b.*\b(bot|raja|service|process)\b/i.test(lower)) return true;
  if (/^(pm2|systemctl|service|docker)\s/i.test(lower)) return true;
  if (/\b(restart\s+bot|restart\s+raja|pm2\s+restart)\b/i.test(lower)) return true;

  // Log viewing
  if (/\b(log|logs|error\s*log|pm2\s+log|cek\s+log|lihat\s+log|tampilkan\s+log)\b/i.test(lower)) return true;

  // Disk/memory/system checks
  if (/\b(disk|memory|ram|cpu|uptime|df|free|top|htop|system\s+check|cek\s+kesehatan)\b/i.test(lower)) return true;

  // Git operations
  if (/\b(git)\s+(status|log|diff|pull|push|stash)\b/i.test(lower)) return true;

  // Direct command execution patterns
  if (/\b(jalankan|run|execute|eksekusi)\s+(command|perintah|cmd)\b/i.test(lower)) return true;

  // Install package (npm install, apt install)
  if (/\b(npm|apt|pip)\s+(install|uninstall|remove|update)\b/i.test(lower)) return true;
  if (/\binstall\s+(package|paket)\b/i.test(lower)) return true;

  // File write/delete/edit operations on specific paths
  if (/\b(hapus|delete|rm|remove)\s+(file\s+)?[\w./-]+\.(js|json|md|txt|log|env)\b/i.test(lower)) return true;
  if (/\b(tulis|write|buat\s+file|bikin\s+file)\s/i.test(lower)) return true;

  return false;
}

// ─── Error Categories for Skill Execution ───────────────────────────────────
// Classifies errors into categories with user-facing suggestions.
// Used by executeSkill() to provide structured error reports.
// Validates: Requirements 2.6, 2.7

export const ERROR_CATEGORIES = {
  network: {
    patterns: ['ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'fetch failed'],
    suggestion: 'Cek koneksi internet VPS atau retry dalam beberapa saat'
  },
  timeout: {
    patterns: ['timeout', 'DEADLINE_EXCEEDED', 'AbortError'],
    suggestion: 'Operasi memakan waktu terlalu lama, coba lagi atau pecah jadi step lebih kecil'
  },
  permission: {
    patterns: ['EACCES', 'EPERM', '403', 'unauthorized'],
    suggestion: 'Cek permission file/API key yang digunakan'
  },
  runtime: {
    patterns: ['TypeError', 'ReferenceError', 'SyntaxError'],
    suggestion: 'Error internal, coba ulang atau gunakan skill alternatif'
  }
};

/**
 * Classify error into category using pattern matching from ERROR_CATEGORIES.
 * Iterates through each category's patterns and checks if the error message
 * contains any matching pattern (case-insensitive).
 *
 * @param {Error|string} error - The error to classify
 * @returns {{ category: string, suggestion: string }}
 *
 * Validates: Requirements 2.7
 */
export function classifyError(error) {
  const errorStr = (error instanceof Error ? error.message : String(error)).toLowerCase();

  for (const [category, { patterns, suggestion }] of Object.entries(ERROR_CATEGORIES)) {
    for (const pattern of patterns) {
      if (errorStr.includes(pattern.toLowerCase())) {
        return { category, suggestion };
      }
    }
  }

  // Default to runtime if no pattern matches
  return {
    category: 'runtime',
    suggestion: ERROR_CATEGORIES.runtime.suggestion
  };
}

/**
 * Placeholder for actual skill dispatch. In production, this would use
 * the skill registry to invoke the appropriate skill handler.
 * This function CAN throw — errors are caught by executeSkill().
 *
 * @param {string} skillId - The skill to execute
 * @param {string} message - User message
 * @param {Object} context - Execution context (userId, session, etc.)
 * @returns {Promise<any>} Skill execution result
 */
export async function dispatchToSkill(skillId, message, context = {}) {
  const skillModule = skills[skillId]?.module;
  if (!skillModule || typeof skillModule.execute !== 'function') {
    throw new Error(`Skill "${skillId}" not found or has no execute method`);
  }
  return await skillModule.execute(message, context);
}

/**
 * Execute a skill with timing, logging, and structured error handling.
 * Logs execution result with format: [EXEC] skill={skill_id} status={success|failed} duration={ms}
 *
 * IMPORTANT: Does NOT fallback to LLM generik saat skill gagal.
 * Instead returns a structured error report for the user.
 *
 * @param {string} skillId - ID of the skill to execute
 * @param {string} message - User message
 * @param {Object} context - Execution context (userId, session, etc.)
 * @returns {Promise<{ success: boolean, result?: any, error?: { skillId: string, category: string, suggestion: string, message: string }, duration: number }>}
 *
 * Validates: Requirements 2.6, 2.7
 */
export async function executeSkill(skillId, message, context = {}) {
  const startTime = Date.now();

  try {
    const result = await dispatchToSkill(skillId, message, context);

    const duration = Date.now() - startTime;
    logger.info(`[EXEC] skill=${skillId} status=success duration=${duration}ms`);

    return { success: true, result, duration };
  } catch (error) {
    const duration = Date.now() - startTime;
    const { category, suggestion } = classifyError(error);

    logger.error(`[EXEC] skill=${skillId} status=failed duration=${duration}ms error=${error.message || error}`);

    // Do NOT fallback to LLM generik — return structured error report
    return {
      success: false,
      error: {
        skillId,
        category,
        suggestion,
        message: error.message || String(error)
      },
      duration
    };
  }
}

/**
 * Format error report for user display.
 * Includes: skill name, error category, and suggestion.
 *
 * @param {{ skillId: string, category: string, suggestion: string, message?: string }} errorInfo
 * @returns {string} User-friendly error report
 *
 * Validates: Requirements 2.7
 */
export function formatErrorReport(errorInfo) {
  return `⚠️ Skill "${errorInfo.skillId}" gagal.\n` +
    `Kategori: ${errorInfo.category}\n` +
    `Saran: ${errorInfo.suggestion}`;
}

// ─── Skill Execution Handler ─────────────────────────────────────────────────
// Tries to execute matched skill. Returns result or null if no skill handles it.

async function trySkillExecution(userMessage, routed, userId) {
  if (!routed.skill || routed.score < 3) return null;

  const skillModule = skills[routed.skill]?.module;
  if (!skillModule || typeof skillModule.execute !== 'function') return null;

  try {
    logger.info(`[brain] Executing skill ${routed.skill} (score: ${routed.score})`);
    const result = await skillModule.execute(userMessage, { userId, session });
    return result ? cleanLlmResponse(result) : null;
  } catch (err) {
    logger.warn(`[brain] Skill ${routed.skill} failed: ${err.message}. Falling back.`);
    return null;
  }
}

// ─── Main Entry Point ────────────────────────────────────────────────────────

export async function processMessage(userMessage, userId, { bot, chatId } = {}) {
  session.turnCount++;

  // ─── Derive a session ID for this conversation ────────────────────────────
  // Use userId as the session ID for simplicity (single user per session on Telegram).
  const sessionId = userId ? String(userId) : 'default';

  // ─── Req 3.1: Save incoming user message (fire-and-forget) ───────────────
  try {
    saveMessage({
      userId: String(userId || 'unknown'),
      role: 'user',
      content: userMessage,
      sessionId,
      intentClassified: null, // Will be classified later
    });
  } catch (err) {
    logger.warn(`[brain] saveMessage (user) failed: ${err.message}`);
  }

  // ─── Req 5.2: Detect explicit preference after each user message ──────────
  // Fire-and-forget — non-blocking, non-critical
  try {
    const pref = detectExplicitPreference(userMessage);
    if (pref) {
      savePreference({
        userId: String(userId || 'unknown'),
        key: pref.key,
        value: pref.value,
        confidence: 1.0,
        source: null,
      });
      logger.info(`[brain] Preference detected & saved: ${pref.key}=${pref.value}`);
    }
  } catch (err) {
    logger.warn(`[brain] detectExplicitPreference failed: ${err.message}`);
  }

  // ═══ PHASE 0: Quick handlers (no LLM needed) ═══

  // Session control (auto_confirm, dry_run)
  const sessionResult = handleSessionControl(userMessage);
  if (sessionResult) return { text: sessionResult, skill: 'session' };

  // Code-engine confirmation handler: "gas", "lanjut" after pending confirm
  if (session.lastCodeEngine?.status === 'pending_confirm') {
    const lower = userMessage.toLowerCase().trim();
    if (/^(gas|lanjut|eksekusi|yes|ya|oke|ok|sikat|jalankan)$/i.test(lower)) {
      // Execute the pending instruction
      const instruction = session.lastCodeEngine.instruction;
      session.lastCodeEngine.status = 'running';
      session.lastCodeEngine.startedAt = Date.now();

      selfModifyFromMessage(chatId, instruction, bot)
        .then(() => {
          session.lastCodeEngine.status = 'completed';
          session.lastCodeEngine.completedAt = Date.now();
        })
        .catch(err => {
          logger.error(`[brain] selfModify error: ${err.message}`);
          session.lastCodeEngine.status = 'failed';
          session.lastCodeEngine.error = err.message;
        });
      return null;
    }
    if (/^(batal|cancel|skip|gajadi|gak|no|nggak)$/i.test(lower)) {
      session.lastCodeEngine = null;
      return { text: '✅ Dibatalkan. Lanjut chat biasa.', skill: 'session' };
    }
    // If user sends something else, clear pending and continue normal flow
    session.lastCodeEngine = null;
  }

  // Fast-path: Direct system commands bypass LLM classification entirely
  // This prevents "cek log", "restart bot", "ls /opt" from being misclassified
  if (isDirectSystemCommand(userMessage)) {
    const m2Routed = { skill: 'm2', name: 'vps-deploy', score: 5, matched: ['direct-command'] };
    const result = await trySkillExecution(userMessage, m2Routed, userId);
    if (result) {
      session.history.push({ role: 'user', content: userMessage });
      session.history.push({ role: 'assistant', content: result });
      await trimAndSummarize();
      return { text: result, skill: 'm2', provider: 'skill-direct' };
    }
    // If m2 returns null, continue to normal LLM flow
  }

  // ═══ PHASE 1: Intent Classification (LLM-first) ═══

  // Learning: Check if user is dissatisfied with last response
  const dissatisfaction = detectDissatisfaction(userMessage, session.history);
  if (dissatisfaction.dissatisfied && dissatisfaction.confidence >= 0.8) {
    // Learn from mistake asynchronously (don't block response)
    learnFromMistake(userMessage, session.history).catch(() => {});
    logger.info(`[brain] Dissatisfaction detected (${dissatisfaction.signal}). Learning...`);
  }

  // Learning: Check if user is satisfied (reinforce good patterns)
  const satisfaction = detectSatisfaction(userMessage);
  if (satisfaction.satisfied) {
    reinforceGoodResponse(session.history).catch(() => {});
  }

  const intent = await classifyIntentLLM(userMessage, session.history);

  // ═══ PHASE 2: Route by Intent ═══

  // --- MODEL_SWITCH ---
  if (intent === 'MODEL_SWITCH') {
    const switchResult = handleModelSwitch(userMessage);
    if (switchResult) return { text: switchResult, skill: 'm7' };
    // If model switch failed to parse, fall through to LLM response
  }

  // --- SESSION_CTRL ---
  if (intent === 'SESSION_CTRL') {
    const ctrlResult = handleSessionControl(userMessage);
    if (ctrlResult) return { text: ctrlResult, skill: 'session' };
  }

  // --- META (questions about bot capabilities) ---
  if (intent === 'META') {
    // Route to m0 (skill registry) for skill list queries
    const routed = routeSkill(userMessage);
    if (routed.skill === 'm0' && routed.score >= 3) {
      const result = await trySkillExecution(userMessage, routed, userId);
      if (result) {
        session.history.push({ role: 'user', content: userMessage });
        session.history.push({ role: 'assistant', content: result });
        await trimAndSummarize();
        return { text: result, skill: 'm0', provider: 'skill-direct' };
      }
    }
    // Fall through to LLM with meta-awareness context
  }

  // --- EXECUTE (self-modification, code changes, command execution) ---
  if (intent === 'EXECUTE' && bot && chatId) {
    const routed = routeSkill(userMessage);
    const EXEC_SKILLS = new Set(['m2', 'x3', 'x8', 'm15']);

    // PRIORITY 1: Direct system commands ALWAYS go to m2
    // This prevents code-engine from creating skills for simple "cek file", "ls", "restart" etc.
    const isDirectCommand = isDirectSystemCommand(userMessage);

    if (isDirectCommand) {
      // Force m2 execution regardless of routeSkill result
      const m2Routed = { skill: 'm2', name: 'vps-deploy', score: 5, matched: ['direct-command'] };
      const result = await trySkillExecution(userMessage, m2Routed, userId);
      if (result) {
        session.history.push({ role: 'user', content: userMessage });
        session.history.push({ role: 'assistant', content: result });
        await trimAndSummarize();
        return { text: result, skill: 'm2', provider: 'skill-direct' };
      }
      // If m2 returns null (couldn't handle), fall through to code-engine
    }

    // PRIORITY 2: Other execution skills (x3 debug, x8 diagnostic, m15 daily)
    if (!isDirectCommand && routed.skill && EXEC_SKILLS.has(routed.skill) && routed.score >= 3) {
      const result = await trySkillExecution(userMessage, routed, userId);
      if (result) {
        session.history.push({ role: 'user', content: userMessage });
        session.history.push({ role: 'assistant', content: result });
        await trimAndSummarize();
        return { text: result, skill: routed.skill, provider: 'skill-direct' };
      }
    }

    // PRIORITY 3: Code-engine self-modify (for actual code changes, skill creation, etc)
    // Uses classifyIntent() keyword-based classification (no isCodeModificationIntent gate)
    // If we reach here, the LLM already classified as EXECUTE — proceed with code-engine
    {
      const instruction = extractInstruction(userMessage);
      session.lastCodeEngine = { instruction, startedAt: Date.now(), status: 'pending_confirm' };
      session.history.push({ role: 'user', content: userMessage });

      // SECURITY: Ask confirmation before executing code-engine
      // This prevents accidental/unintended code generation during conversation
      const confirmMsg = `⚠️ Gue detect ini perintah modifikasi kode:\n\n"${instruction.substring(0, 200)}"\n\nMau gue eksekusi? Reply:\n• \`gas\` atau \`lanjut\` → eksekusi\n• \`batal\` → cancel\n\nAtau pakai /codenow untuk langsung eksekusi tanpa konfirmasi.`;
      return { text: confirmMsg, skill: 'code-engine', provider: 'confirm-gate' };
    }
  }

  // --- SKILL_QUERY (crypto ops, specific skill execution) ---
  if (intent === 'SKILL_QUERY') {
    const routed = routeSkill(userMessage);
    if (routed.skill && routed.score >= 2) {
      // AMBIGUITY GATE: If input is very short (1-2 words) and matches an execution skill,
      // ask for clarification instead of auto-executing.
      // This prevents "swap", "bridge", "mint" from triggering full execution flows.
      const wordCount = userMessage.trim().split(/\s+/).length;
      const EXECUTION_SKILLS = new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'H7', 'H8', 'H9', 'H10']);

      if (wordCount <= 2 && EXECUTION_SKILLS.has(routed.skill)) {
        // Short ambiguous input → ask clarification instead of executing
        const skillName = skills[routed.skill]?.name || routed.skill;
        const clarification = `Bos, "${userMessage}" — lo mau:\n1. **Eksekusi** ${skillName} (butuh parameter lengkap)\n2. **Penjelasan** apa itu ${skillName}\n\nKasih tau, atau langsung kirim format lengkap buat eksekusi.`;
        session.history.push({ role: 'user', content: userMessage });
        session.history.push({ role: 'assistant', content: clarification });
        await trimAndSummarize();
        return { text: clarification, skill: routed.skill, provider: 'ambiguity-gate' };
      }

      const result = await trySkillExecution(userMessage, routed, userId);
      if (result) {
        session.history.push({ role: 'user', content: userMessage });
        session.history.push({ role: 'assistant', content: result });
        await trimAndSummarize();
        return { text: result, skill: routed.skill, provider: 'skill-direct' };
      }
    }
    // Fall through to LLM if skill can't handle
  }

  // ═══ PHASE 3: LLM Response (QUESTION, FOLLOW_UP, CASUAL, or fallthrough) ═══

  // Recall relevant memories
  const memories = await recallMemory(userMessage, 5);
  const memoryContext = memories.length > 0
    ? memories.map(m => `[${m.kind}] ${m.content}`).join('\n')
    : '';

  // Recall lessons from past mistakes (key for learning)
  const lessonsContext = await recallLessons(userMessage);

  // ─── Req 4.1: Build context from ContextWindow and inject into LLM prompt ─
  let contextPayload = null;
  try {
    const cw = getContextWindowInstance();
    if (cw) {
      contextPayload = await cw.buildContext(String(userId || 'unknown'), userMessage, sessionId);
    }
  } catch (err) {
    logger.warn(`[brain] buildContext failed (non-critical): ${err.message}`);
  }

  // Build grounded message array
  const messages = [];

  // 1. System: Identity + Runtime + Reality Anchors
  messages.push({
    role: 'system',
    content: `${buildRuntimeContext()}\n\n${IDENTITY_PROMPT}\n\n${buildRealityAnchors()}`,
  });

  // 2. System: Lessons from past mistakes (CRITICAL for learning)
  if (lessonsContext) {
    messages.push({ role: 'system', content: lessonsContext });
  }

  // 2. System: History summary (older context)
  if (session.historySummary) {
    messages.push({
      role: 'system',
      content: `═══ RINGKASAN PERCAKAPAN SEBELUMNYA ═══\n${session.historySummary}`,
    });
  }

  // 3. System: ContextWindow — recent history + long-term memories + user preferences (Req 4.1)
  if (contextPayload) {
    const contextParts = [];
    if (contextPayload.recentHistory) {
      contextParts.push(`═══ RECENT HISTORY (Context Window) ═══\n${contextPayload.recentHistory}`);
    }
    if (contextPayload.longTermMemories) {
      contextParts.push(`═══ LONG-TERM MEMORIES (Relevan) ═══\n${contextPayload.longTermMemories}`);
    }
    if (contextPayload.userPreferences) {
      contextParts.push(`═══ USER PREFERENCES ═══\n${contextPayload.userPreferences}`);
    }
    if (contextParts.length > 0) {
      messages.push({ role: 'system', content: contextParts.join('\n\n') });
    }
  } else if (memoryContext) {
    // Fallback: inject raw memory context if ContextWindow unavailable
    messages.push({ role: 'system', content: `═══ LONG-TERM MEMORY ═══\n${memoryContext}` });
  }

  // 4. System: Skill routing hint (optional)
  const routed = routeSkill(userMessage);
  if (routed.skill && routed.score >= 2) {
    messages.push({
      role: 'system',
      content: `[Skill Match] ${routed.skill} (${routed.name}) score:${routed.score} — matched: ${routed.matched.join(', ')}`,
    });
  }

  // 5. System: Self-awareness (env/config queries)
  if (/\b(env|\.env|config|konfigurasi|template|variable|variabel)\b/i.test(userMessage)) {
    const envKeys = Object.keys(process.env).filter(k =>
      k.startsWith('LLM_') || k.startsWith('RPC_') || k.startsWith('HERMES_') ||
      k.startsWith('X_') || k.startsWith('OLLAMA') || k.startsWith('BOT_') ||
      k.startsWith('OPENROUTER') || k.startsWith('BAI_') || k.startsWith('ALLOWED')
    );
    if (envKeys.length > 0) {
      messages.push({
        role: 'system',
        content: `[ENV KEYS YANG ADA]\n${envKeys.join(', ')}\nJawab dari keys yang benar-benar ada. Jangan ngarang.`,
      });
    }
  }

  // 6. System: Code-engine context (if recently ran)
  if (session.lastCodeEngine) {
    const ce = session.lastCodeEngine;
    const elapsed = ce.completedAt
      ? `${((ce.completedAt - ce.startedAt) / 1000).toFixed(1)}s`
      : `${((Date.now() - ce.startedAt) / 1000).toFixed(0)}s running`;
    messages.push({
      role: 'system',
      content: `[Code-Engine terakhir] "${ce.instruction}" | ${ce.status} | ${elapsed}`,
    });
  }

  // 7. Conversation history (last 20 turns = 40 messages)
  messages.push(...session.history.slice(-MAX_HISTORY_MESSAGES));

  // 8. Current user message
  messages.push({ role: 'user', content: userMessage });

  // ═══ PHASE 4: Call LLM ═══

  let response;
  try {
    response = await callCascade(messages, { maxTokens: 1500, temperature: 0.7 });
  } catch (err) {
    logger.error(`All LLM providers failed: ${err.message}`);
    return { text: 'Gagal panggil semua provider. Cek API key & koneksi.', skill: routed.skill };
  }

  // ═══ PHASE 5: Process & Store ═══

  const cleanedText = cleanLlmResponse(response.text);

  // Update history
  session.history.push({ role: 'user', content: userMessage });
  session.history.push({ role: 'assistant', content: cleanedText });

  // Trim & summarize if needed
  await trimAndSummarize();

  // ─── Req 3.1: Save outgoing assistant message (fire-and-forget) ───────────
  try {
    saveMessage({
      userId: String(userId || 'unknown'),
      role: 'assistant',
      content: cleanedText,
      sessionId,
      intentClassified: 'CHAT',
    });
  } catch (err) {
    logger.warn(`[brain] saveMessage (assistant) failed: ${err.message}`);
  }

  // Store to long-term memory (only meaningful exchanges)
  if (cleanedText.length > 50 && routed.score > 0) {
    await rememberFact({
      content: `Skill ${routed.skill}: "${userMessage.substring(0, 80)}"`,
      kind: 'fact',
      tags: routed.matched.join(','),
      weight: 1.0,
    });
  }

  return { text: cleanedText, skill: routed.skill, provider: response.provider };
}

// ─── Export session accessor ─────────────────────────────────────────────────

export function getSession() {
  return session;
}
