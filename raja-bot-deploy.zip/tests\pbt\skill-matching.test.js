// tests/pbt/skill-matching.test.js
// Property-Based Test: Property 5 — Keyword-Weighted Scoring Formula
// **Validates: Requirements 2.1**
//
// Property 5: *For any* input text dan *for any* skill keyword set,
// skor yang dihitung SHALL sama persis dengan `Σ(keyword_weight × occurrence_count_in_input)`.
// Skor ini SHALL bersifat deterministik — input dan keywords yang sama selalu menghasilkan skor identik.

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import { matchSkills } from '../../src/core/skill-registry.js';

// ─── Pure scoring formula (reference implementation from design doc) ─────────

/**
 * Reference implementation of the scoring formula.
 * Score = Σ (keyword_weight × occurrence_count_in_input)
 *
 * For single-word keywords: count tokens that contain the keyword
 * For multi-word keywords: count substring occurrences in full normalized input
 *
 * @param {string[]} inputTokens - Tokenized input (lowercase, split on whitespace)
 * @param {string} normalizedInput - Full input string (lowercase)
 * @param {{keyword: string, weight: number}[]} keywords - Skill keywords with weights
 * @returns {number} Computed score
 */
function calculateScoreReference(inputTokens, normalizedInput, keywords) {
  let score = 0;
  for (const { keyword, weight } of keywords) {
    const keywordParts = keyword.split(/\s+/);

    if (keywordParts.length === 1) {
      // Single-word keyword: count tokens that contain the keyword
      const occurrences = inputTokens.filter(t => t.includes(keyword)).length;
      score += weight * occurrences;
    } else {
      // Multi-word keyword: count substring occurrences in full input
      let occurrences = 0;
      let searchFrom = 0;
      while (true) {
        const idx = normalizedInput.indexOf(keyword, searchFrom);
        if (idx === -1) break;
        occurrences++;
        searchFrom = idx + keyword.length;
      }
      score += weight * occurrences;
    }
  }
  return score;
}

// ─── Generators ─────────────────────────────────────────────────────────────

// Single-word token vocabulary (realistic domain terms)
const singleWordTokens = fc.constantFrom(
  'swap', 'token', 'bridge', 'deploy', 'audit',
  'wallet', 'mint', 'nft', 'defi', 'staking',
  'hello', 'world', 'other', 'test', 'check',
  'bot', 'cron', 'api', 'webhook', 'data'
);

// Input as array of tokens (simulates tokenized user input)
const inputTokensArb = fc.array(singleWordTokens, { minLength: 1, maxLength: 20 });

// Keyword entry: single-word keyword with weight 1-3
const keywordEntryArb = fc.record({
  keyword: fc.constantFrom('swap', 'token', 'bridge', 'deploy', 'audit', 'wallet', 'mint', 'bot', 'api', 'data'),
  weight: fc.integer({ min: 1, max: 3 })
});

// Keyword set for a skill (1-8 keywords)
const keywordSetArb = fc.array(keywordEntryArb, { minLength: 1, maxLength: 8 });

// ─── Property Tests ─────────────────────────────────────────────────────────

describe('Property 5: Keyword-Weighted Scoring Formula', () => {

  it('**Validates: Requirements 2.1** — score = Σ(keyword_weight × occurrence_count) for any input and keywords', () => {
    fc.assert(
      fc.property(
        inputTokensArb,
        keywordSetArb,
        (inputTokens, keywords) => {
          const inputStr = inputTokens.join(' ');
          const normalizedInput = inputStr.toLowerCase();
          const tokens = normalizedInput.split(/\s+/).filter(t => t.length > 0);

          // Calculate expected score using reference formula
          const expectedScore = calculateScoreReference(tokens, normalizedInput, keywords);

          // Verify: score is non-negative integer
          expect(expectedScore).toBeGreaterThanOrEqual(0);

          // Verify: manual re-computation matches
          let manualScore = 0;
          for (const { keyword, weight } of keywords) {
            const count = tokens.filter(t => t.includes(keyword)).length;
            manualScore += weight * count;
          }
          expect(expectedScore).toBe(manualScore);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.1** — scoring is deterministic — same input always gives same score', () => {
    fc.assert(
      fc.property(
        inputTokensArb,
        keywordSetArb,
        (inputTokens, keywords) => {
          const inputStr = inputTokens.join(' ');
          const normalizedInput = inputStr.toLowerCase();
          const tokens = normalizedInput.split(/\s+/).filter(t => t.length > 0);

          // Calculate score twice
          const score1 = calculateScoreReference(tokens, normalizedInput, keywords);
          const score2 = calculateScoreReference(tokens, normalizedInput, keywords);

          // Must be identical
          expect(score1).toBe(score2);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.1** — score is always non-negative for valid inputs', () => {
    fc.assert(
      fc.property(
        fc.array(fc.constantFrom('swap', 'token', 'bridge', 'x', 'y', 'unknown'), { minLength: 0, maxLength: 15 }),
        fc.array(
          fc.record({
            keyword: fc.constantFrom('swap', 'token', 'bridge'),
            weight: fc.integer({ min: 1, max: 3 })
          }),
          { minLength: 1, maxLength: 5 }
        ),
        (inputTokens, keywords) => {
          const inputStr = inputTokens.join(' ');
          const normalizedInput = inputStr.toLowerCase();
          const tokens = normalizedInput.split(/\s+/).filter(t => t.length > 0);

          const score = calculateScoreReference(tokens, normalizedInput, keywords);
          expect(score).toBeGreaterThanOrEqual(0);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.1** — matchSkills returns consistent scores across multiple calls', () => {
    fc.assert(
      fc.property(
        inputTokensArb,
        (inputTokens) => {
          const inputStr = inputTokens.join(' ');

          // Call matchSkills twice with same input
          const results1 = matchSkills(inputStr);
          const results2 = matchSkills(inputStr);

          // Same number of results
          expect(results1.length).toBe(results2.length);

          // Same scores for each skill
          for (let i = 0; i < results1.length; i++) {
            expect(results1[i].skillId).toBe(results2[i].skillId);
            expect(results1[i].score).toBe(results2[i].score);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.1** — matchSkills scores are sorted descending', () => {
    fc.assert(
      fc.property(
        inputTokensArb,
        (inputTokens) => {
          const inputStr = inputTokens.join(' ');
          const results = matchSkills(inputStr);

          // Results should be sorted by score descending
          for (let i = 1; i < results.length; i++) {
            expect(results[i - 1].score).toBeGreaterThanOrEqual(results[i].score);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.1** — score increases monotonically with keyword repetition', () => {
    fc.assert(
      fc.property(
        fc.constantFrom('swap', 'token', 'bridge', 'deploy', 'audit'),
        fc.integer({ min: 1, max: 10 }),
        (keyword, repeatCount) => {
          // Single occurrence
          const singleInput = keyword;
          const singleResults = matchSkills(singleInput);

          // Multiple occurrences
          const multiInput = Array(repeatCount).fill(keyword).join(' ');
          const multiResults = matchSkills(multiInput);

          // Find the skill(s) that match this keyword in both result sets
          // The score with more repetitions should be >= score with single occurrence
          for (const multiResult of multiResults) {
            const singleResult = singleResults.find(r => r.skillId === multiResult.skillId);
            if (singleResult) {
              expect(multiResult.score).toBeGreaterThanOrEqual(singleResult.score);
            }
          }
        }
      ),
      { numRuns: 200 }
    );
  });
});


// ─── Property 6: Fuzzy Matching Threshold ───────────────────────────────────
// **Validates: Requirements 2.2, 2.3**
//
// Property 6: *For any* skill dan *for any* input, jika `score / maxTheoreticalScore >= 0.5`
// maka skill tersebut SHALL dianggap match; jika rasio < 0.5 untuk semua skills,
// maka tidak ada match dan fallback ke klarifikasi.

describe('Property 6: Fuzzy Matching Threshold', () => {

  it('**Validates: Requirements 2.2, 2.3** — score/maxTheoreticalScore >= 0.5 → skill is considered a match', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1, max: 100 }), // score
        fc.integer({ min: 1, max: 200 }), // maxTheoreticalScore
        (score, maxTheoreticalScore) => {
          const ratio = score / maxTheoreticalScore;
          const isMatch = ratio >= 0.5;

          if (score >= 0.5 * maxTheoreticalScore) {
            expect(isMatch).toBe(true);
          } else {
            expect(isMatch).toBe(false);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.2, 2.3** — when no skill reaches threshold → fuzzyMatch returns null', () => {
    fc.assert(
      fc.property(
        fc.array(
          fc.record({
            score: fc.integer({ min: 1, max: 10 }),
            maxTheoreticalScore: fc.integer({ min: 30, max: 100 })
          }),
          { minLength: 1, maxLength: 5 }
        ),
        (results) => {
          // Filter: only results below threshold
          const belowThreshold = results.filter(r => r.score < 0.5 * r.maxTheoreticalScore);
          if (belowThreshold.length === results.length) {
            // All below threshold → no match
            const aboveThreshold = results.filter(r => r.score >= 0.5 * r.maxTheoreticalScore);
            expect(aboveThreshold.length).toBe(0);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.2, 2.3** — threshold comparison is deterministic', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 200 }),
        fc.integer({ min: 1, max: 200 }),
        (score, maxScore) => {
          const result1 = score >= 0.5 * maxScore;
          const result2 = score >= 0.5 * maxScore;
          expect(result1).toBe(result2);
        }
      ),
      { numRuns: 200 }
    );
  });
});
