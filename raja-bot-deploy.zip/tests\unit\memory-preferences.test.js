// tests/unit/memory-preferences.test.js
// Unit tests for savePreference() and getPreferences() logic
// Uses a lightweight in-memory store to validate the algorithm
// (better-sqlite3 native binary not available in this test environment)
import { describe, it, expect, beforeEach } from 'vitest';

/**
 * Simulated database layer that mirrors the SQLite behavior.
 * This validates the LOGIC of savePreference/getPreferences without native deps.
 */
class MockPreferenceDB {
  constructor() {
    this.rows = [];
    this.nextId = 1;
  }

  clear() {
    this.rows = [];
    this.nextId = 1;
  }

  findByUserAndKey(userId, key) {
    return this.rows.find(r => r.user_id === userId && r.preference_key === key) || null;
  }

  countByUser(userId) {
    return this.rows.filter(r => r.user_id === userId).length;
  }

  findLowestConfidence(userId) {
    const userRows = this.rows.filter(r => r.user_id === userId);
    if (userRows.length === 0) return null;
    userRows.sort((a, b) => a.confidence - b.confidence || a.last_updated.localeCompare(b.last_updated));
    return userRows[0];
  }

  insert(row) {
    const newRow = { ...row, id: this.nextId++ };
    this.rows.push(newRow);
    return newRow.id;
  }

  update(id, fields) {
    const idx = this.rows.findIndex(r => r.id === id);
    if (idx >= 0) {
      this.rows[idx] = { ...this.rows[idx], ...fields };
    }
  }

  query(userId, minConfidence, minDate) {
    return this.rows
      .filter(r => 
        r.user_id === userId && 
        r.confidence >= minConfidence && 
        r.last_updated >= minDate
      )
      .sort((a, b) => b.confidence - a.confidence);
  }
}

const MAX_PREFERENCES_PER_USER = 50;

let mockDb;

/**
 * savePreference implementation that uses the mock DB
 * — mirrors the real implementation logic exactly
 */
function savePreference({ userId, key, value, confidence, source = null }) {
  if (!userId || !key || value === undefined || value === null) {
    throw new Error('savePreference requires userId, key, and value');
  }

  const safeKey = String(key).slice(0, 64);
  const safeValue = String(value).slice(0, 256);
  const safeConfidence = Math.max(0, Math.min(1, Number(confidence) || 0));
  const now = new Date().toISOString();

  const existing = mockDb.findByUserAndKey(userId, safeKey);

  if (existing) {
    mockDb.update(existing.id, {
      preference_value: safeValue,
      confidence: safeConfidence,
      last_updated: now,
      source_message_id: source
    });
    return existing.id;
  }

  const count = mockDb.countByUser(userId);

  if (count >= MAX_PREFERENCES_PER_USER) {
    const lowest = mockDb.findLowestConfidence(userId);
    if (lowest) {
      mockDb.update(lowest.id, {
        preference_key: safeKey,
        preference_value: safeValue,
        confidence: safeConfidence,
        last_updated: now,
        source_message_id: source
      });
      return lowest.id;
    }
  }

  return mockDb.insert({
    user_id: userId,
    preference_key: safeKey,
    preference_value: safeValue,
    confidence: safeConfidence,
    last_updated: now,
    source_message_id: source
  });
}

/**
 * getPreferences implementation that uses the mock DB
 * — mirrors the real implementation logic exactly
 */
function getPreferences(userId) {
  if (!userId) return [];

  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();

  const rows = mockDb.query(userId, 0.5, ninetyDaysAgo);

  return rows.map(row => ({
    id: row.id,
    userId: row.user_id,
    key: row.preference_key,
    value: row.preference_value,
    confidence: row.confidence,
    lastUpdated: row.last_updated,
    source: row.source_message_id
  }));
}

beforeEach(() => {
  mockDb = new MockPreferenceDB();
});

describe('savePreference()', () => {
  it('should insert a new preference', () => {
    const id = savePreference({
      userId: 'user1',
      key: 'language',
      value: 'typescript',
      confidence: 1.0,
      source: 'msg-123'
    });
    expect(id).toBeGreaterThan(0);

    const row = mockDb.findByUserAndKey('user1', 'language');
    expect(row.user_id).toBe('user1');
    expect(row.preference_key).toBe('language');
    expect(row.preference_value).toBe('typescript');
    expect(row.confidence).toBe(1.0);
    expect(row.source_message_id).toBe('msg-123');
  });

  it('should UPSERT: update value, confidence, last_updated when key exists', () => {
    const id1 = savePreference({
      userId: 'user1',
      key: 'format',
      value: 'json',
      confidence: 0.7
    });

    const id2 = savePreference({
      userId: 'user1',
      key: 'format',
      value: 'yaml',
      confidence: 1.0,
      source: 'msg-456'
    });

    // Same ID (upsert)
    expect(id2).toBe(id1);

    const row = mockDb.findByUserAndKey('user1', 'format');
    expect(row.preference_value).toBe('yaml');
    expect(row.confidence).toBe(1.0);
    expect(row.source_message_id).toBe('msg-456');
  });

  it('should enforce max 64 chars for key', () => {
    const longKey = 'a'.repeat(100);
    savePreference({
      userId: 'user1',
      key: longKey,
      value: 'test',
      confidence: 0.8
    });

    const row = mockDb.rows.find(r => r.user_id === 'user1');
    expect(row.preference_key.length).toBe(64);
  });

  it('should enforce max 256 chars for value', () => {
    const longValue = 'b'.repeat(300);
    savePreference({
      userId: 'user1',
      key: 'test',
      value: longValue,
      confidence: 0.8
    });

    const row = mockDb.rows.find(r => r.user_id === 'user1');
    expect(row.preference_value.length).toBe(256);
  });

  it('should clamp confidence to 0-1 range', () => {
    savePreference({ userId: 'user1', key: 'k1', value: 'v1', confidence: 2.5 });
    savePreference({ userId: 'user1', key: 'k2', value: 'v2', confidence: -0.5 });

    const k1 = mockDb.findByUserAndKey('user1', 'k1');
    const k2 = mockDb.findByUserAndKey('user1', 'k2');
    expect(k1.confidence).toBe(1.0); // clamped from 2.5
    expect(k2.confidence).toBe(0.0); // clamped from -0.5
  });

  it('should replace lowest confidence when max 50 reached', () => {
    // Insert 50 preferences
    for (let i = 0; i < 50; i++) {
      savePreference({
        userId: 'user1',
        key: `pref_${String(i).padStart(3, '0')}`,
        value: `val_${i}`,
        confidence: 0.5 + (i * 0.01) // 0.50, 0.51, ... 0.99
      });
    }

    expect(mockDb.countByUser('user1')).toBe(50);

    // Insert 51st — should replace the one with lowest confidence (pref_000, confidence=0.50)
    savePreference({
      userId: 'user1',
      key: 'new_pref',
      value: 'new_val',
      confidence: 0.95
    });

    expect(mockDb.countByUser('user1')).toBe(50); // Still 50

    // The new preference should exist
    const newPref = mockDb.findByUserAndKey('user1', 'new_pref');
    expect(newPref).not.toBeNull();
    expect(newPref.preference_value).toBe('new_val');

    // The old lowest-confidence one should be gone (its key was replaced)
    const oldPref = mockDb.findByUserAndKey('user1', 'pref_000');
    expect(oldPref).toBeNull();
  });

  it('should throw error when required fields are missing', () => {
    expect(() => savePreference({ userId: '', key: 'k', value: 'v', confidence: 1 })).toThrow();
    expect(() => savePreference({ userId: 'u', key: '', value: 'v', confidence: 1 })).toThrow();
    expect(() => savePreference({ userId: 'u', key: 'k', value: null, confidence: 1 })).toThrow();
    expect(() => savePreference({ userId: 'u', key: 'k', value: undefined, confidence: 1 })).toThrow();
  });

  it('should keep different users preferences separate', () => {
    savePreference({ userId: 'alice', key: 'lang', value: 'python', confidence: 1.0 });
    savePreference({ userId: 'bob', key: 'lang', value: 'rust', confidence: 0.9 });

    const alicePref = mockDb.findByUserAndKey('alice', 'lang');
    const bobPref = mockDb.findByUserAndKey('bob', 'lang');

    expect(alicePref.preference_value).toBe('python');
    expect(bobPref.preference_value).toBe('rust');
  });

  it('should not create duplicate keys for same user', () => {
    savePreference({ userId: 'user1', key: 'theme', value: 'dark', confidence: 0.8 });
    savePreference({ userId: 'user1', key: 'theme', value: 'light', confidence: 1.0 });
    savePreference({ userId: 'user1', key: 'theme', value: 'auto', confidence: 0.6 });

    const userPrefs = mockDb.rows.filter(r => r.user_id === 'user1' && r.preference_key === 'theme');
    expect(userPrefs.length).toBe(1);
    expect(userPrefs[0].preference_value).toBe('auto');
    expect(userPrefs[0].confidence).toBe(0.6);
  });
});

describe('getPreferences()', () => {
  it('should return preferences with confidence >= 0.5', () => {
    savePreference({ userId: 'user1', key: 'k1', value: 'v1', confidence: 0.8 });
    savePreference({ userId: 'user1', key: 'k2', value: 'v2', confidence: 0.3 }); // below threshold
    savePreference({ userId: 'user1', key: 'k3', value: 'v3', confidence: 0.5 }); // exactly at threshold

    const prefs = getPreferences('user1');
    expect(prefs.length).toBe(2);
    expect(prefs.map(p => p.key)).toContain('k1');
    expect(prefs.map(p => p.key)).toContain('k3');
    expect(prefs.map(p => p.key)).not.toContain('k2');
  });

  it('should sort by confidence DESC', () => {
    savePreference({ userId: 'user1', key: 'low', value: 'v', confidence: 0.5 });
    savePreference({ userId: 'user1', key: 'high', value: 'v', confidence: 1.0 });
    savePreference({ userId: 'user1', key: 'mid', value: 'v', confidence: 0.7 });

    const prefs = getPreferences('user1');
    expect(prefs[0].key).toBe('high');
    expect(prefs[1].key).toBe('mid');
    expect(prefs[2].key).toBe('low');
  });

  it('should filter out preferences older than 90 days', () => {
    // Manually insert a preference with old timestamp
    const oldDate = new Date(Date.now() - 100 * 24 * 60 * 60 * 1000).toISOString();
    mockDb.insert({
      user_id: 'user1',
      preference_key: 'old_pref',
      preference_value: 'old_val',
      confidence: 0.9,
      last_updated: oldDate,
      source_message_id: null
    });

    // Insert a recent preference
    savePreference({ userId: 'user1', key: 'new_pref', value: 'new_val', confidence: 0.8 });

    const prefs = getPreferences('user1');
    expect(prefs.length).toBe(1);
    expect(prefs[0].key).toBe('new_pref');
  });

  it('should return empty array for unknown user', () => {
    const prefs = getPreferences('nonexistent');
    expect(prefs).toEqual([]);
  });

  it('should return empty array for null/empty userId', () => {
    expect(getPreferences('')).toEqual([]);
    expect(getPreferences(null)).toEqual([]);
    expect(getPreferences(undefined)).toEqual([]);
  });

  it('should return correct object shape', () => {
    savePreference({ userId: 'user1', key: 'lang', value: 'js', confidence: 0.9, source: 'msg-1' });

    const prefs = getPreferences('user1');
    expect(prefs.length).toBe(1);
    
    const pref = prefs[0];
    expect(pref).toHaveProperty('id');
    expect(pref).toHaveProperty('userId', 'user1');
    expect(pref).toHaveProperty('key', 'lang');
    expect(pref).toHaveProperty('value', 'js');
    expect(pref).toHaveProperty('confidence', 0.9);
    expect(pref).toHaveProperty('lastUpdated');
    expect(pref).toHaveProperty('source', 'msg-1');
  });

  it('should only return preferences for the specified user', () => {
    savePreference({ userId: 'alice', key: 'theme', value: 'dark', confidence: 1.0 });
    savePreference({ userId: 'bob', key: 'theme', value: 'light', confidence: 0.8 });

    const alicePrefs = getPreferences('alice');
    const bobPrefs = getPreferences('bob');

    expect(alicePrefs.length).toBe(1);
    expect(alicePrefs[0].value).toBe('dark');
    expect(bobPrefs.length).toBe(1);
    expect(bobPrefs[0].value).toBe('light');
  });

  it('should include preferences at exactly confidence=0.5 boundary', () => {
    savePreference({ userId: 'user1', key: 'exact', value: 'v', confidence: 0.5 });
    
    const prefs = getPreferences('user1');
    expect(prefs.length).toBe(1);
    expect(prefs[0].key).toBe('exact');
  });

  it('should exclude preferences at confidence just below 0.5', () => {
    savePreference({ userId: 'user1', key: 'below', value: 'v', confidence: 0.49 });
    
    const prefs = getPreferences('user1');
    expect(prefs.length).toBe(0);
  });
});
