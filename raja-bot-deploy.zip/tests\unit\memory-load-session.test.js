import { describe, it, expect } from 'vitest';

/**
 * **Validates: Requirements 3.3**
 * Unit tests for loadSessionOnRestart logic
 * 
 * Requirements:
 * - WHEN PM2 melakukan restart, THE Memory_System SHALL memuat kembali
 *   50 pesan terakhir per user dari conversation_history
 * - Target: selesai dalam < 2 detik
 * - Delegates to getRecentHistory(userId, 50)
 */

// === Mock Database that simulates SQLite behavior ===
class MockDb {
  constructor() {
    this.history = [];
  }
  
  prepare(sql) {
    return {
      all: (...args) => this._all(sql, args),
    };
  }
  
  _all(sql, args) {
    if (sql.includes('conversation_history') && sql.includes('ORDER BY timestamp DESC')) {
      const userId = args[0];
      const limit = args[1];
      
      return this.history
        .filter(m => m.user_id === userId)
        .sort((a, b) => b.timestamp.localeCompare(a.timestamp))
        .slice(0, limit);
    }
    return [];
  }
}

/**
 * getRecentHistory logic (mirrors src/core/memory.js)
 */
function getRecentHistory(db, userId, limit = 50) {
  const cappedLimit = Math.min(Math.max(limit, 1), 1000);
  
  const stmt = db.prepare(`
    SELECT * FROM conversation_history
    WHERE user_id = ?
    ORDER BY timestamp DESC
    LIMIT ?
  `);
  
  const messages = stmt.all(userId, cappedLimit);
  return messages.reverse();
}

/**
 * loadSessionOnRestart logic (mirrors src/core/memory.js)
 * Simply delegates to getRecentHistory with limit=50
 */
function loadSessionOnRestart(db, userId) {
  return getRecentHistory(db, userId, 50);
}

// Helper to generate test messages
function generateMessages(userId, count) {
  const messages = [];
  const baseTime = new Date('2025-01-01T00:00:00.000Z').getTime();
  
  for (let i = 0; i < count; i++) {
    messages.push({
      id: i + 1,
      user_id: userId,
      role: i % 2 === 0 ? 'user' : 'assistant',
      content: `Message ${i}`,
      timestamp: new Date(baseTime + i * 1000).toISOString(),
      session_id: 'session-1',
      intent_classified: 'CHAT'
    });
  }
  
  return messages;
}

describe('loadSessionOnRestart — reload 50 last messages per user', () => {

  it('should return exactly 50 messages when user has more than 50', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('user1', 200);
    
    const result = loadSessionOnRestart(mockDb, 'user1');
    
    expect(result.length).toBe(50);
  });

  it('should return all messages when user has fewer than 50', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('user2', 30);
    
    const result = loadSessionOnRestart(mockDb, 'user2');
    
    expect(result.length).toBe(30);
  });

  it('should return messages sorted by timestamp ASC (oldest first)', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('user3', 100);
    
    const result = loadSessionOnRestart(mockDb, 'user3');
    
    for (let i = 0; i < result.length - 1; i++) {
      expect(result[i].timestamp <= result[i + 1].timestamp).toBe(true);
    }
  });

  it('should return the 50 most recent messages (not the first 50)', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('user4', 100);
    
    const result = loadSessionOnRestart(mockDb, 'user4');
    
    // Should contain messages 50-99 (last 50), sorted ASC
    expect(result[0].content).toBe('Message 50');
    expect(result[49].content).toBe('Message 99');
  });

  it('should return empty array when user has no messages', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('otherUser', 100);
    
    const result = loadSessionOnRestart(mockDb, 'nonexistent');
    
    expect(result.length).toBe(0);
  });

  it('should only return messages for the specified userId', () => {
    const mockDb = new MockDb();
    mockDb.history = [
      ...generateMessages('userA', 80),
      ...generateMessages('userB', 60)
    ];
    
    const result = loadSessionOnRestart(mockDb, 'userA');
    
    expect(result.length).toBe(50);
    expect(result.every(m => m.user_id === 'userA')).toBe(true);
  });

  it('should complete within 2 seconds (performance target)', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('perfUser', 5000);
    
    const start = performance.now();
    const result = loadSessionOnRestart(mockDb, 'perfUser');
    const duration = performance.now() - start;
    
    expect(result.length).toBe(50);
    expect(duration).toBeLessThan(2000);
  });

  it('should handle single message correctly', () => {
    const mockDb = new MockDb();
    mockDb.history = generateMessages('user5', 1);
    
    const result = loadSessionOnRestart(mockDb, 'user5');
    
    expect(result.length).toBe(1);
    expect(result[0].content).toBe('Message 0');
  });
});
