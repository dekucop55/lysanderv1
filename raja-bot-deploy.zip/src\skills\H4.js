// src/skills/H4.js — Hermes: Token sniping with honeypot protection + intent detection
import { honeypotCheck, snipeToken } from '../hermes/sniping.js';
import { logger } from '../utils/logger.js';

// ─── Chain aliases ───────────────────────────────────────────────────────────
const CHAIN_ALIASES = {
  eth: 'ethereum', ethereum: 'ethereum', bsc: 'bsc', binance: 'bsc',
  arb: 'arbitrum', arbitrum: 'arbitrum', base: 'base', poly: 'polygon', polygon: 'polygon',
};

/**
 * Detect actionable snipe/honeypot intent from natural language query.
 * Returns { intent, params } or null for general questions.
 */
function detectSnipeIntent(query) {
  const q = query.trim();

  // Pattern: "check honeypot <address> [on <chain>]" / "honeypot <address>" / "cek honeypot"
  const honeypotMatch = q.match(
    /(?:check\s+honeypot|honeypot\s+check|cek\s+honeypot|is\s+honeypot|honeypot|rug\s+check|cek\s+rug)\s+(0x[a-fA-F0-9]{40})(?:\s+(?:on|di|chain)\s+(\S+))?/i
  );
  if (honeypotMatch) {
    const tokenAddress = honeypotMatch[1];
    const chain = resolveChain(honeypotMatch[2]) || 'ethereum';
    return { intent: 'HONEYPOT_CHECK', params: { tokenAddress, chain } };
  }

  // Pattern: "snipe <address> [<amount> ETH] [on <chain>] [wallet <label>]"
  const snipeMatch = q.match(
    /(?:snipe|beli\s+token)\s+(0x[a-fA-F0-9]{40})(?:\s+([\d.,]+)\s*(?:eth|bnb|matic))?(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (snipeMatch) {
    const tokenAddress = snipeMatch[1];
    const amountEth = snipeMatch[2] ? parseFloat(snipeMatch[2].replace(',', '.')) : null;
    const chain = resolveChain(snipeMatch[3]) || 'ethereum';
    const wallet = snipeMatch[4] || null;
    return { intent: 'SNIPE', params: { tokenAddress, amountEth, chain, wallet } };
  }

  // Pattern: "token safety <address>" / "check token <address>"
  const safetyMatch = q.match(
    /(?:token\s+safety|check\s+token|scan\s+token|audit\s+token)\s+(0x[a-fA-F0-9]{40})(?:\s+(?:on|di)\s+(\S+))?/i
  );
  if (safetyMatch) {
    const tokenAddress = safetyMatch[1];
    const chain = resolveChain(safetyMatch[2]) || 'ethereum';
    return { intent: 'HONEYPOT_CHECK', params: { tokenAddress, chain } };
  }

  return null;
}

function resolveChain(raw) {
  if (!raw) return null;
  return CHAIN_ALIASES[raw.toLowerCase()] || null;
}

export default {
  id: 'H4',
  name: 'sniping',
  description: 'Token sniping with mandatory honeypot/rug checks, anti-MEV, GoPlus integration',

  async execute(query, context) {
    // 1. Detect actionable snipe command
    const intent = detectSnipeIntent(query);

    if (intent) {
      logger.info(`[H4] Snipe intent detected: ${intent.intent}`, intent.params);

      try {
        switch (intent.intent) {
          case 'HONEYPOT_CHECK': {
            const { tokenAddress, chain } = intent.params;

            const result = await honeypotCheck({ tokenAddress, chain });

            if (result.safe) {
              return [
                `✅ **Token Safety Check: PASSED**`,
                ``,
                `Token: \`${tokenAddress}\``,
                `Chain: ${chain}`,
                ``,
                `📊 Details:`,
                `• Buy tax: ${result.data?.buyTax || '0'}%`,
                `• Sell tax: ${result.data?.sellTax || '0'}%`,
                `• Holders: ${result.data?.holders || 'N/A'}`,
                `• LP locked: ${result.data?.lpLocked ? '✅ Yes' : '⚠️ No'}`,
                `• Owner: \`${result.data?.ownerAddress || 'renounced'}\``,
                ``,
                `Token ini LULUS safety check. Bisa di-snipe dengan risiko moderat.`,
              ].join('\n');
            } else {
              return [
                `🚨 **Token Safety Check: FAILED**`,
                ``,
                `Token: \`${tokenAddress}\``,
                `Chain: ${chain}`,
                ``,
                `❌ Risks detected:`,
                ...(result.risks || []).map(r => `• 🔴 ${r}`),
                result.reason ? `• Reason: ${result.reason}` : '',
                ``,
                result.data ? [
                  `📊 Details:`,
                  `• Buy tax: ${result.data.buyTax || '?'}%`,
                  `• Sell tax: ${result.data.sellTax || '?'}%`,
                  `• Holders: ${result.data.holders || 'N/A'}`,
                  `• LP locked: ${result.data.lpLocked ? 'Yes' : 'No'}`,
                ].join('\n') : '',
                ``,
                `⛔ **JANGAN BELI TOKEN INI.** Risiko honeypot/rug sangat tinggi.`,
              ].filter(Boolean).join('\n');
            }
          }

          case 'SNIPE': {
            const { tokenAddress, amountEth, chain, wallet } = intent.params;

            // Always run honeypot check first
            const safety = await honeypotCheck({ tokenAddress, chain });

            if (!safety.safe) {
              return [
                `🚨 **Snipe BLOCKED — Token gagal safety check**`,
                ``,
                `Token: \`${tokenAddress}\``,
                `Chain: ${chain}`,
                `Risks: ${(safety.risks || []).join(', ') || safety.reason}`,
                ``,
                `⛔ Snipe dibatalkan otomatis. Token berbahaya.`,
                `Gunakan \`check honeypot ${tokenAddress} on ${chain}\` untuk detail lengkap.`,
              ].join('\n');
            }

            // Token passed — but execution needs confirmation
            if (!wallet || !amountEth) {
              return [
                `✅ Token LULUS safety check. Ready to snipe.`,
                ``,
                `Token: \`${tokenAddress}\``,
                `Chain: ${chain}`,
                `Buy tax: ${safety.data?.buyTax || '0'}% | Sell tax: ${safety.data?.sellTax || '0'}%`,
                ``,
                !amountEth ? `⚠️ Specify amount: \`snipe ${tokenAddress} <amount> ETH on ${chain} wallet <label>\`` : '',
                !wallet ? `⚠️ Specify wallet: tambahkan \`wallet <label>\` di akhir command` : '',
                ``,
                `🔐 Eksekusi snipe memerlukan \`/snipeconfirm\` setelah semua params lengkap.`,
              ].filter(Boolean).join('\n');
            }

            // All params complete — inform about confirmation flow
            return [
              `✅ **Snipe Ready**`,
              ``,
              `Token: \`${tokenAddress}\``,
              `Chain: ${chain}`,
              `Amount: ${amountEth} ETH`,
              `Wallet: ${wallet}`,
              `Safety: ✅ PASSED (buy ${safety.data?.buyTax || '0'}% / sell ${safety.data?.sellTax || '0'}%)`,
              ``,
              `🔐 Untuk eksekusi: \`/snipeconfirm\``,
              `⚠️ Governor authorization akan diminta sebelum broadcast.`,
              `⚠️ Anti-MEV: minimal 1% slippage protection aktif.`,
            ].join('\n');
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[H4] Snipe operation failed: ${err.message}`);
        return `❌ Snipe operation gagal: ${err.message}`;
      }
    }

    // 2. Fallback: general sniping question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H4 (Sniping).
Mode: fast + safe.

Kamu menjawab pertanyaan tentang token sniping:
- Cara kerja sniping (pair creation listening, mempool monitoring)
- Safety checks: honeypot detection, rug indicators, tax analysis
- Anti-MEV strategies (private mempool, flashbots, sandwich protection)
- GoPlus API usage dan interpretation
- Red flags: mintable, proxy, blacklist, high tax, low holders
- Best practices: position sizing, exit strategy, risk management

Untuk EXECUTE snipe/check, user harus pakai format:
  check honeypot <0x...address> on <chain>
  snipe <0x...address> <amount> ETH on <chain> wallet <label>

MANDATORY safety pipeline:
1. GoPlus honeypot check → BLOCK kalau honeypot
2. Liquidity check (min $10K)
3. Holder distribution (top10 < 80%)
4. Buy/sell tax (max 10% each)
5. Governor authorization

Jangan pernah encourage user skip safety checks.`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H4] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan sniping: ${err.message}`;
    }
  },
};
