// src/telegram/bot.js — Main Telegram bot
import TelegramBot from 'node-telegram-bot-api';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import { processMessage } from '../core/brain.js';
import { cmdStart, cmdHelp, cmdStatus, cmdSkill, cmdMemory } from './commands/basic.js';
import { cmdUpgrade, cmdRestart, cmdLogs, cmdHealth } from './commands/system.js';
import { cmdRollback, cmdGitStatus } from './commands/upgrade.js';
import { cmdWallet, cmdBalance, cmdSwap, cmdSwapConfirm, cmdMint, cmdSnipe } from './commands/crypto.js';
import { cmdAlert, cmdBriefing, cmdVault } from './commands/daily.js';
import { cmdAudit, cmdDebug, cmdSelfImprove } from './commands/meta.js';
import { cmdCode, cmdCodeRun, cmdCodeCancel, cmdCodeNow, cmdCodeList, cmdCodeView } from './commands/autonomous.js';
import { cmdMarketplace } from './commands/marketplace.js';
import { checkMessage, sanitizeInput } from './middleware.js';
import { analyzeImage, fetchTelegramPhoto, fetchImageAsBase64, extractImageUrl, hasImageUrl } from '../core/vision.js';
import { selfModifyFromMessage } from '../self-upgrade/code-engine.js';

let bot;

export async function startBot() {
  bot = new TelegramBot(config.telegram.token, {
    polling: {
      interval: 300,
      autoStart: true,
      params: { timeout: 10 },
    },
  });

  // Dedupe
  const seen = new Map();
  const SEEN_TTL = 5 * 60 * 1000;
  setInterval(() => {
    const now = Date.now();
    for (const [k, t] of seen) if (now - t > SEEN_TTL) seen.delete(k);
  }, 60000);
  
  function isDuplicate(msg) {
    const key = `${msg.chat.id}:${msg.message_id}`;
    if (seen.has(key)) return true;
    seen.set(key, Date.now());
    return false;
  }

  // Command handlers
  bot.onText(/^\/start$/, (msg) => cmdStart(bot, msg));
  bot.onText(/^\/help$/, (msg) => cmdHelp(bot, msg));
  bot.onText(/^\/status$/, (msg) => cmdStatus(bot, msg));
  bot.onText(/^\/skill (.+)/, (msg, match) => cmdSkill(bot, msg, match[1]));
  bot.onText(/^\/memory/, (msg) => cmdMemory(bot, msg));
  
  // System commands
  bot.onText(/^\/upgrade$/, (msg) => cmdUpgrade(bot, msg));
  bot.onText(/^\/update$/, (msg) => cmdUpgrade(bot, msg));
  bot.onText(/^\/pull$/, (msg) => cmdUpgrade(bot, msg));
  bot.onText(/^\/restart$/, (msg) => cmdRestart(bot, msg));
  bot.onText(/^\/logs(?: (.+))?$/, (msg, match) => cmdLogs(bot, msg, match?.[1]));
  bot.onText(/^\/health$/, (msg) => cmdHealth(bot, msg));
  bot.onText(/^\/rollback(?: (.+))?$/, (msg, match) => cmdRollback(bot, msg, match?.[1]));
  bot.onText(/^\/git$/, (msg) => cmdGitStatus(bot, msg));
  
  // Crypto commands
  bot.onText(/^\/wallet(?: (.+))?$/, (msg, match) => cmdWallet(bot, msg, match?.[1]));
  bot.onText(/^\/balance(?: (.+))?$/, (msg, match) => cmdBalance(bot, msg, match?.[1]));
  bot.onText(/^\/swap (.+)/, (msg, match) => cmdSwap(bot, msg, match[1]));
  bot.onText(/^\/swapconfirm (.+)/, (msg, match) => cmdSwapConfirm(bot, msg, match[1]));
  bot.onText(/^\/mint (.+)/, (msg, match) => cmdMint(bot, msg, match[1]));
  bot.onText(/^\/snipe (.+)/, (msg, match) => cmdSnipe(bot, msg, match[1]));
  
  // Daily assistant
  bot.onText(/^\/alert (.+)/, (msg, match) => cmdAlert(bot, msg, 'add', match[1]));
  bot.onText(/^\/alerts$/, (msg) => cmdAlert(bot, msg, 'list'));
  bot.onText(/^\/briefing$/, (msg) => cmdBriefing(bot, msg));
  bot.onText(/^\/vault(?: (.+))?$/, (msg, match) => cmdVault(bot, msg, match?.[1]));
  
  // Meta commands
  bot.onText(/^\/audit$/, (msg) => cmdAudit(bot, msg));
  bot.onText(/^\/debug$/, (msg) => cmdDebug(bot, msg));
  bot.onText(/^\/improve$/, (msg) => cmdSelfImprove(bot, msg));

  // Autonomous self-update commands
  bot.onText(/^\/code(?:\s+(.+))?$/, (msg, match) => cmdCode(bot, msg, match?.[1]));
  bot.onText(/^\/coderun$/, (msg) => cmdCodeRun(bot, msg));
  bot.onText(/^\/codecancel$/, (msg) => cmdCodeCancel(bot, msg));
  bot.onText(/^\/codenow\s+(.+)$/, (msg, match) => cmdCodeNow(bot, msg, match[1]));
  bot.onText(/^\/codelist(?:\s+(.+))?$/, (msg, match) => cmdCodeList(bot, msg, match?.[1]));
  bot.onText(/^\/codeview\s+(.+)$/, (msg, match) => cmdCodeView(bot, msg, match[1]));

  // Marketplace commands
  bot.onText(/^\/marketplace(?:\s+(.+))?$/, (msg, match) => cmdMarketplace(bot, msg, match?.[1]));

  // ─── Document/File upload handler ──────────────────────────────────────────
  bot.on('document', async (msg) => {
    if (isDuplicate(msg)) return;
    const check = checkMessage(msg);
    if (!check.ok) return;

    const doc = msg.document;
    const caption = msg.caption || '';
    const fileName = doc.file_name || 'unknown';

    try {
      await bot.sendChatAction(msg.chat.id, 'typing');

      // Download file from Telegram
      const fileLink = await bot.getFileLink(doc.file_id);
      const { default: axios } = await import('axios');

      // Check if archive file
      const { isArchiveFile, extractArchive, cleanupDir } = await import('../utils/extractor.js');

      if (isArchiveFile(fileName)) {
        // Download as binary to tmp
        const tmpPath = `/tmp/raja-upload-${Date.now()}-${fileName}`;
        const binRes = await axios.get(fileLink, { responseType: 'arraybuffer', timeout: 60000 });
        const fs2 = await import('fs');
        fs2.default.writeFileSync(tmpPath, Buffer.from(binRes.data));

        await bot.sendMessage(msg.chat.id, `📦 Extracting \`${fileName}\`...`, { parse_mode: 'Markdown' });

        const { files, extractDir } = await extractArchive(tmpPath, fileName);
        fs2.default.unlinkSync(tmpPath); // cleanup downloaded archive

        if (files.length === 0) {
          cleanupDir(extractDir);
          await bot.sendMessage(msg.chat.id, `❌ Archive kosong atau tidak ada file yang bisa dibaca.`);
          return;
        }

        // Deploy .js skill files directly
        const path2 = await import('path');
        const deployed = [];
        const contextFiles = [];

        for (const f of files) {
          if (f.name.endsWith('.js') && (f.content.includes('export default') || f.content.includes('module.exports'))) {
            const skillName = path2.default.basename(f.name);
            const skillPath = path2.default.join(config.raja.home, 'src', 'skills', skillName);
            fs2.default.writeFileSync(skillPath, f.content, 'utf8');
            deployed.push(skillName);
          } else {
            contextFiles.push(f);
          }
        }

        // Reload registry if skills were deployed
        if (deployed.length > 0) {
          const { initSkillRegistry } = await import('../core/skill-registry.js');
          await initSkillRegistry();
          try {
            const { promisify } = await import('util');
            const { exec } = await import('child_process');
            await promisify(exec)('node src/core/skill-integrity.js generate', { cwd: config.raja.home });
          } catch {}
        }

        // If there are non-skill files, pass to code-engine as context
        if (contextFiles.length > 0 && caption) {
          const contextStr = contextFiles.slice(0, 5).map(f => `--- ${f.name} ---\n${f.content.substring(0, 3000)}`).join('\n\n');
          const fullInstruction = `${caption}\n\nFiles dari archive "${fileName}":\n${contextStr}`;
          selfModifyFromMessage(msg.chat.id, fullInstruction, bot).catch(() => {});
        }

        cleanupDir(extractDir);

        let report = `📦 Archive \`${fileName}\` processed:\n`;
        report += `📄 ${files.length} files found\n`;
        if (deployed.length > 0) report += `✅ Deployed skills: ${deployed.map(d => `\`${d}\``).join(', ')}\n`;
        if (contextFiles.length > 0 && caption) report += `🧠 ${contextFiles.length} files sent to code-engine\n`;
        if (contextFiles.length > 0 && !caption) report += `ℹ️ ${contextFiles.length} non-skill files ignored (kasih caption/instruksi untuk proses)\n`;

        await bot.sendMessage(msg.chat.id, report, { parse_mode: 'Markdown' });
        return;
      }

      // Non-archive: download as text
      const response = await axios.get(fileLink, { responseType: 'text', timeout: 30000 });
      const fileContent = response.data;

      // If .js skill file and caption suggests install/upgrade → deploy directly
      if (fileName.endsWith('.js') && /(?:upgrade|update|install|deploy|tambah|pasang|gunakan)/i.test(caption)) {
        const fs3 = await import('fs');
        const path3 = await import('path');
        const skillPath = path3.default.join(config.raja.home, 'src', 'skills', fileName);

        fs3.default.writeFileSync(skillPath, fileContent, 'utf8');

        const { initSkillRegistry } = await import('../core/skill-registry.js');
        await initSkillRegistry();

        try {
          const { promisify } = await import('util');
          const { exec } = await import('child_process');
          await promisify(exec)('node src/core/skill-integrity.js generate', { cwd: config.raja.home });
        } catch {}

        await bot.sendMessage(msg.chat.id,
          `✅ Skill deployed: \`${fileName}\`\n🔄 Registry reloaded. Skill aktif.`,
          { parse_mode: 'Markdown' }
        );
        return;
      }

      // .md files → save to bot root + hot-reload into LLM context immediately
      if (fileName.endsWith('.md')) {
        const fs4 = await import('fs');
        const path4 = await import('path');
        const mdPath = path4.default.join(config.raja.home, fileName);
        fs4.default.writeFileSync(mdPath, fileContent, 'utf8');

        // Save full content to memory with high weight (always recalled)
        const { rememberFact } = await import('../core/memory.js');
        await rememberFact({
          content: `[REF:${fileName}] ${fileContent.substring(0, 2000)}`,
          kind: 'reference',
          tags: `file,${fileName},system`,
          weight: 5.0,
        });

        // Hot-inject: add to session history so LLM immediately knows about this file
        const { getSession } = await import('../core/brain.js');
        const session = getSession();
        session.history.push({
          role: 'system',
          content: `[FILE UPLOADED: ${fileName}] Operator baru upload file referensi. Isi file:\n\n${fileContent.substring(0, 3000)}\n\nGunakan informasi ini untuk update behavior/pengetahuan kamu sekarang juga. Adaptasi langsung tanpa restart.`,
        });

        await bot.sendMessage(msg.chat.id,
          `✅ File \`${fileName}\` loaded & applied.\n\nGue udah baca isinya dan langsung adapt. Behavior updated. Gas.`,
          { parse_mode: 'Markdown' }
        );
        logger.info(`[document] Hot-loaded reference: ${fileName} (${fileContent.length} chars)`);
        return;
      }

      // Text files → pass to code-engine
      if (fileName.endsWith('.js') || fileName.endsWith('.py') || fileName.endsWith('.md') || fileName.endsWith('.txt') || fileName.endsWith('.json')) {
        const instruction = caption || `User uploaded file "${fileName}". Gunakan file ini untuk upgrade/modifikasi bot.`;
        const fullInstruction = `${instruction}\n\n--- FILE: ${fileName} ---\n${fileContent.substring(0, 8000)}`;

        selfModifyFromMessage(msg.chat.id, fullInstruction, bot).catch(err => {
          logger.error(`[document] selfModify error: ${err.message}`);
        });
        return;
      }

      // Other file types
      await bot.sendMessage(msg.chat.id,
        `📄 File diterima: \`${fileName}\` (${(doc.file_size / 1024).toFixed(1)} KB)\n\nSupported: .js, .py, .md, .txt, .json, .zip, .tar.gz, .rar\nKasih caption instruksi untuk proses file.`,
        { parse_mode: 'Markdown' }
      );
    } catch (err) {
      logger.error(`[document] Error: ${err.message}`);
      await bot.sendMessage(msg.chat.id, `❌ Gagal proses file: ${err.message}`);
    }
  });

  // ─── Photo message handler (vision) ────────────────────────────────────────
  bot.on('photo', async (msg) => {
    if (isDuplicate(msg)) return;
    const check = checkMessage(msg);
    if (!check.ok) return;

    try {
      await bot.sendChatAction(msg.chat.id, 'typing');
      const photo = msg.photo[msg.photo.length - 1]; // highest resolution
      const caption = msg.caption || 'Analisis gambar ini secara detail.';

      const { base64, mimeType } = await fetchTelegramPhoto(bot, photo.file_id);
      const analysis = await analyzeImage(base64, mimeType, caption);

      if (analysis.length <= 4000) {
        await bot.sendMessage(msg.chat.id, analysis, { parse_mode: 'Markdown' }).catch(() => {
          bot.sendMessage(msg.chat.id, analysis);
        });
      } else {
        const chunks = splitMessage(analysis, 4000);
        for (const chunk of chunks) {
          await bot.sendMessage(msg.chat.id, chunk, { parse_mode: 'Markdown' }).catch(() => {
            bot.sendMessage(msg.chat.id, chunk);
          });
        }
      }
    } catch (err) {
      logger.error(`Photo processing error: ${err.message}`);
      await bot.sendMessage(msg.chat.id, `❌ Gagal analisis gambar: ${err.message}`);
    }
  });

  // Generic text message → brain
  bot.on('message', async (msg) => {
    if (msg.text?.startsWith('/')) return;
    if (!msg.text) return; // Skip non-text (photos, documents handled by their own handlers)
    if (isDuplicate(msg)) return;

    const check = checkMessage(msg);
    if (!check.ok) {
      if (check.reason === 'unauthorized') {
        await bot.sendMessage(msg.chat.id, 'Akses ditolak. Bot ini private.');
      } else if (check.reason === 'rate_limited') {
        await bot.sendMessage(msg.chat.id, 'Terlalu banyak pesan. Tunggu sebentar.');
      }
      return;
    }
    
    try {
      await bot.sendChatAction(msg.chat.id, 'typing');
      const clean = sanitizeInput(msg.text);

      // Check if message contains an image URL → vision analysis
      if (hasImageUrl(clean)) {
        const imageUrl = extractImageUrl(clean);
        const textWithoutUrl = clean.replace(imageUrl, '').trim();
        const prompt = textWithoutUrl || 'Analisis gambar ini secara detail.';

        try {
          const { base64, mimeType } = await fetchImageAsBase64(imageUrl);
          const analysis = await analyzeImage(base64, mimeType, prompt);
          
          if (analysis.length <= 4000) {
            await bot.sendMessage(msg.chat.id, analysis, { parse_mode: 'Markdown' }).catch(() => {
              bot.sendMessage(msg.chat.id, analysis);
            });
          } else {
            const chunks = splitMessage(analysis, 4000);
            for (const chunk of chunks) {
              await bot.sendMessage(msg.chat.id, chunk, { parse_mode: 'Markdown' }).catch(() => {
                bot.sendMessage(msg.chat.id, chunk);
              });
            }
          }
          return;
        } catch (visionErr) {
          logger.warn(`[bot] Vision fetch failed for URL, falling back to LLM: ${visionErr.message}`);
          // Fall through to normal processing if vision fails
        }
      }

      const result = await processMessage(clean, msg.from.id, { bot, chatId: msg.chat.id });

      // Kalau result null → self-modify dihandle async di background, jangan kirim apa-apa
      if (result === null) return;

      // Split pesan panjang (Telegram limit 4096 chars)
      const text = result.text || '';
      if (text.length <= 4000) {
        await bot.sendMessage(msg.chat.id, text, { parse_mode: 'Markdown' }).catch(() => {
          // Fallback tanpa Markdown kalau formatting error
          bot.sendMessage(msg.chat.id, text);
        });
      } else {
        const chunks = splitMessage(text, 4000);
        for (const chunk of chunks) {
          await bot.sendMessage(msg.chat.id, chunk, { parse_mode: 'Markdown' }).catch(() => {
            bot.sendMessage(msg.chat.id, chunk);
          });
        }
      }
    } catch (err) {
      logger.error(`Message processing error: ${err.message}`);
      await bot.sendMessage(msg.chat.id, `❌ Error: ${err.message.substring(0, 200)}`);
    }
  });

  // Polling error recovery
  bot.on('polling_error', (err) => {
    logger.error(`[polling] ${err.code} ${err.message}`);
    if (err.code === 'ETELEGRAM' && err.response?.body?.error_code === 409) {
      logger.error('Another bot instance running. Exiting.');
      process.exit(1);
    }
  });

  logger.info(`Telegram bot started. Authorized user: ${config.telegram.allowedUserId}`);
  return bot;
}

export function getBot() {
  return bot;
}

function splitMessage(text, maxLen = 4000) {
  const chunks = [];
  let remaining = text;
  while (remaining.length > 0) {
    if (remaining.length <= maxLen) {
      chunks.push(remaining);
      break;
    }
    // Cari newline terdekat sebelum limit untuk split bersih
    let splitAt = remaining.lastIndexOf('\n', maxLen);
    if (splitAt < maxLen * 0.5) splitAt = maxLen; // fallback kalau tidak ada newline
    chunks.push(remaining.substring(0, splitAt));
    remaining = remaining.substring(splitAt).trimStart();
  }
  return chunks;
}
