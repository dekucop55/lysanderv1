// src/skills/m9.js — Frontend, landing pages, React, Tailwind, Web3 UI
export default {
  id: 'm9',
  name: 'frontend',
  description: 'Frontend development: React, Next.js, Tailwind CSS, landing pages, Web3 UI (RainbowKit/Wagmi)',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m9 (Frontend).
Expert dalam:
- React + Next.js (App Router)
- Tailwind CSS + shadcn/ui components
- Landing page yang convert (above-fold, CTA, social proof)
- Web3 UI: RainbowKit, Wagmi, ConnectKit
- Wallet connection flows
- DApp frontend patterns
- TypeScript untuk React
- State management: Zustand, Jotai
- Data fetching: TanStack Query, SWR
- Animation: Framer Motion
- Responsive design, dark mode
- Performance: lazy loading, image optimization

Kalau diminta landing page: langsung buat full HTML/JSX.
Sertakan Tailwind classes langsung.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.5 });
    return result.text;
  },
};
