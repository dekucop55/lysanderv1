// src/core/skill-registry.js — Skill registry & router (auto-discover)
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { logger } from '../utils/logger.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const SKILL_KEYWORDS = {
  m0: { name: 'registry', weight: { skill:3, skills:3, 'daftar skill':3, registry:3, kemampuan:3, 'skill list':3, 'apa aja skill':3, 'lihat skill':3, modul:2, 'bisa apa aja':2 } },
  m1: { name: 'monetization', weight: { monetize:3, pricing:3, jual:3, jualan:3, cuan:3, funnel:2, business:2 } },
  m2: { name: 'vps-deploy', weight: { vps:3, deploy:3, ssh:3, nginx:3, docker:3, systemd:3, server:2, linux:2, bash:2, 'akses file':3, 'baca file':3, 'cat file':3, 'read file':3, 'lihat log':3, 'akses log':3, 'cek log':3, 'pm2 logs':3, 'jalankan command':3, 'run command':3, 'list file':3, 'isi folder':3, 'cek disk':3, 'cek memory':3, 'restart bot':3, 'restart service':3, 'restart raja':3, 'restart raja-bot':3, 'pm2 restart':3, 'pm2 status':3, 'cek status':3, 'via vps':3, 'di vps':3, 'di server':3, 'berikan tampilan log':3, 'tampilan log':3, 'hapus file':3, 'delete file':3, 'buat file':3, 'tulis file':3, 'pm2 flush':3, 'edit file':3, 'ubah file':3, 'modify file':3, 'tambahkan ke file':3, 'append':3 } },
  m3: { name: 'content', weight: { viral:3, hook:3, caption:3, thread:3, naskah:3, konten:3, copywriting:2, post:2 } },
  m4: { name: 'telegram-bot', weight: { 'telegram bot':3, cron:3, webhook:3, n8n:3, automate:3, otomatis:3, bot:2, schedule:2, jadwal:2 } },
  m5: { name: 'data', weight: { spreadsheet:3, excel:3, csv:3, dataset:3, snapshot:3, laporan:2, analytics:2, data:2 } },
  m6: { name: 'integrations', weight: { api:3, rest:3, webhook:3, midtrans:3, integrasi:3, endpoint:2, sdk:2, integration:2 } },
  m7: { name: 'llm', weight: { llm:3, prompt:3, 'claude api':3, openrouter:3, kimi:3, agent:2, model:2, gpt:2, 'tambah model':3, 'add model':3 } },
  m8: { name: 'documents', weight: { pdf:3, docx:3, xlsx:3, pptx:3, 'generate file':3, dokumen:2, export:2, file:1 } },
  m9: { name: 'frontend', weight: { 'landing page':3, react:3, tailwind:3, frontend:3, ui:2, html:2, css:2, web:1, design:1 } },
  m10: { name: 'web3', weight: { wallet:3, airdrop:3, 'on-chain':3, rpc:3, ethers:3, viem:3, balance:3, saldo:3, 'cek balance':3, 'import wallet':3, 'list wallet':3, 'buat wallet':3, 'generate wallet':3, mint:2, swap:2, blockchain:2, eth:2, token:2 } },
  m11: { name: 'security', weight: { audit:3, vulnerability:3, exploit:3, 'scam check':3, security:2, review:2, safe:2, malicious:2 } },
  m12: { name: 'batch', weight: { batch:3, parallel:3, bulk:3, mass:3, queue:3, worker:3, concurrent:2, throughput:2, many:1, multi:1 } },
  m13: { name: 'nft-mint', weight: { mint:3, opensea:3, manifold:3, zora:3, seadrop:3, nft:2, claim:2, drop:2, collection:2 } },
  m14: { name: 'briefing', weight: { briefing:3, 'ringkasan harian':3, alert:3, 'kabarin kalau':3, 'pantau harga':2, alarm:2, notify:2, daily:1 } },
  m15: { name: 'daily-assistant', weight: { watchdog:3, 'restart kalau mati':3, 'simpen alamat':3, macro:3, 'voice note':3, screenshot:3, vault:2, triage:2 } },
  m16: { name: 'software-eng', weight: { coding:3, 'bikin app':3, backend:3, api:3, database:3, testing:3, scaffold:2, refactor:2, golang:2, rust:2, fastapi:2, express:2 } },
  m17: { name: 'power-pack', weight: { rencanain:3, workflow:3, 'otomatis kalau':3, backtest:3, dashboard:3, ngomong:3, swarm:2, voice:2, 'tim agent':2 } },
  x1: { name: 'audit', weight: { 'improve system':3, 'self-audit':3, 'review agent':3, 'upgrade brain':3, audit:2, optimize:1 } },
  x2: { name: 'strategy', weight: { strategy:3, architecture:3, decompose:3, plan:3, 'design system':3, complex:2, 'multi-step':2 } },
  x3: { name: 'debug', weight: { error:3, bug:3, debug:3, gagal:3, rusak:3, stack:3, failed:2, broken:2, fix:2, crash:2, traceback:2 } },
  x4: { name: 'self-improve', weight: { 'self improve':3, belajar:3, 'makin pinter':3, 'upgrade diri':3, 'auto fix':3, learn:2, reflect:2, adapt:2 } },
  m18: { name: 'creative-media', weight: { comfyui:3, manim:3, animasi:3, diagram:3, slide:3, excalidraw:3, visual:2, gambar:2, poster:2, creative:2, thumbnail:2, 'design system':3 } },
  m19: { name: 'desktop-control', weight: { desktop:3, robot:3, robotics:3, 'isaac sim':3, osascript:3, 'physical ai':3, ros:2, omniverse:3, 'kontrol desktop':3, applescript:3 } },
  m20: { name: 'humanizer', weight: { humanize:3, humanizer:3, 'brand voice':3, 'ai tell':3, 'bau ai':3, rewrite:2, 'voice profile':2, 'tulisan natural':3 } },
  m21: { name: 'enterprise-defense', weight: { kql:3, hids:3, firewall:3, 'azure log':3, sentinel:3, 'intrusion detection':3, bruteforce:3, 'log analytics':3, defensif:2 } },
  m22: { name: 'deep-research', weight: { riset:3, research:3, 'deep research':3, hipotesis:3, hypothesis:3, sitasi:3, citation:3, eksperimen:3, 'scientific':2, paper:2, jurnal:2 } },
  m23: { name: 'exec-function', weight: { overwhelm:3, 'task breakdown':3, fokus:3, prioritas:3, 'context switch':3, adhd:3, 'executive function':3, breadcrumb:2, 'gak bisa mulai':3, kewalahan:3 } },
  m24: { name: 'mcp-prompt', weight: { mcp:3, 'prompt engineering':3, 'mcp server':3, fastmcp:3, 'prompt audit':3, 'fix prompt':3, 'model context protocol':3, scaffold:2 } },
  m25: { name: 'compliance-cicd', weight: { compliance:3, gdpr:3, soc2:3, 'pci dss':3, hipaa:3, cicd:3, 'ci/cd':3, pipeline:2, migrate:3, porting:3, 'code migration':3, 'brand guideline':3 } },
  m26: { name: 'product-spec', weight: { prd:3, 'product spec':3, 'grill me':3, tdd:3, 'test driven':3, 'task breakdown':2, 'bikin spec':3, 'bikin prd':3, 'internal comms':3, rfc:2 } },
  m27: { name: 'content-strategy', weight: { 'content strategy':3, 'content calendar':3, carousel:3, reels:3, thread:3, 'social media':3, tiktok:3, instagram:3, linkedin:3, 'scroll stopper':3 } },
  m28: { name: 'copywriting', weight: { copywriting:3, aida:3, pas:3, seo:3, storytelling:3, 'landing page copy':3, headline:3, lokalisasi:3, 'multilingual':2, 'copy framework':3 } },
  m29: { name: 'content-analytics', weight: { 'content analytics':3, 'trend research':3, 'social listening':3, 'audience insight':3, 'a/b test':3, 'best time':3, engagement:2, repurpose:3, 'content pipeline':3 } },
  x5: { name: 'eval-critique', weight: { eval:3, 'self critique':3, variance:3, 'llm judge':3, 'consistency test':3, benchmark:2, 'eval driven':3, 'self-critique':3 } },
  x6: { name: 'systematic-debug', weight: { 'root cause':3, rca:3, 'auto debug':3, bisect:3, hypothesis:2, reproduce:3, 'debug loop':3, intermittent:3, flaky:3 } },
  x7: { name: 'problem-shaping', weight: { 'problem shaping':3, brainstorm:3, 'sign off':3, 'decision support':3, tradeoff:3, 'tujuan kabur':3, 'gak jelas':3, 'mau apa':3, opsi:2, 'bantu decide':3 } },
  H1: { name: 'swap', weight: { swap:3, '1inch':3, jupiter:3, 'jual token':3, sell:3, dex:2, slippage:2, aggregator:2 } },
  H2: { name: 'bridge', weight: { bridge:3, layerzero:3, stargate:3, 'li.fi':3, across:3, 'cross-chain':2, hop:2 } },
  H3: { name: 'defi', weight: { aave:3, lido:3, gmx:3, hyperliquid:3, pendle:3, defi:2, lending:2, staking:2, restaking:2, perp:2 } },
  H4: { name: 'sniping', weight: { snipe:3, honeypot:3, paircreated:3, sniping:3, launch:2, rugcheck:2, goplus:2 } },
  H5: { name: 'monitoring', weight: { mempool:3, whale:3, nansen:3, arkham:3, 'smart money':3, tracker:2, copy:2, frontrun:2 } },
  H6: { name: 'nft-marketplace', weight: { 'beli nft':3, blur:3, 'magic eden':3, tensor:3, reservoir:3, listing:2, fulfill:2, floor:2 } },
  H7: { name: 'siwe', weight: { siwe:3, walletconnect:3, 'eip-712':3, ens:3, permit:3, 'sign-in':2, 'typed data':2, signature:2 } },
  H8: { name: 'browser', weight: { playwright:3, 'buka dapp':3, 'browser automation':3, 'connect wallet browser':3, navigate:2, klik:2, 'isi form':2 } },
  H9: { name: 'contract-rw', weight: { 'baca kontrak':3, 'tulis kontrak':3, 'call fungsi':3, 'read contract':3, 'write contract':3, abi:2, proxy:2, 'inspect kontrak':2 } },
  H10: { name: 'deploy', weight: { 'deploy kontrak':3, 'compile solidity':3, create2:3, 'bikin token':3, 'deploy contract':3, forge:2, solidity:2, verify:2 } },
  x8: { name: 'diagnostic', weight: { 'perbaiki dirimu':3, 'cek kesehatan':3, 'self repair':3, 'diagnosa':3, 'health check':3, 'diagnostic':3 } },
};

/**
 * One-line domain descriptions per skill (used in matchSkills results and suggestions)
 */
const SKILL_DESCRIPTIONS = {
  m0: 'Skill registry, daftar kemampuan, dan refleksi',
  m1: 'Monetisasi, pricing, dan strategi revenue',
  m2: 'VPS deploy, SSH, server management, dan file access',
  m3: 'Content creation, viral hooks, dan copywriting',
  m4: 'Telegram bot automation, cron, dan scheduling',
  m5: 'Data processing, spreadsheet, CSV, dan analytics',
  m6: 'API integrations, REST, webhook, dan SDK',
  m7: 'LLM management, prompt engineering, dan model routing',
  m8: 'Document generation (PDF, DOCX, XLSX, PPTX)',
  m9: 'Frontend development, landing page, React, dan UI',
  m10: 'Web3 wallet, airdrop, on-chain operations, dan balance check',
  m11: 'Security audit, vulnerability scanning, dan scam detection',
  m12: 'Batch processing, parallel execution, dan bulk operations',
  m13: 'NFT minting, collection deployment, dan marketplace',
  m14: 'Briefing harian, alert monitoring, dan notifikasi',
  m15: 'Daily assistant, watchdog, macro, dan vault',
  m16: 'Software engineering, backend, coding, dan testing',
  m17: 'Power pack: workflow automation, dashboard, dan swarm',
  m18: 'Creative media: animasi, diagram, visual, dan design',
  m19: 'Desktop control, robotics, dan physical AI',
  m20: 'Humanizer: brand voice, rewriting, dan natural copy',
  m21: 'Enterprise defense: SIEM, firewall, dan intrusion detection',
  m22: 'Deep research: riset, hipotesis, sitasi, dan eksperimen',
  m23: 'Executive function: task breakdown, fokus, dan prioritas',
  m24: 'MCP & prompt engineering: scaffold dan audit',
  m25: 'Compliance, GDPR, SOC2, CI/CD, dan migration',
  m26: 'Product spec, PRD, TDD, dan RFC',
  m27: 'Content strategy: calendar, carousel, reels, dan social media',
  m28: 'Copywriting framework: AIDA, PAS, SEO, dan storytelling',
  m29: 'Content analytics: trend, social listening, dan A/B test',
  x1: 'Self-audit, system improvement, dan optimization',
  x2: 'Strategy, architecture, dan complex problem decomposition',
  x3: 'Debug: error tracing, bug fixing, dan crash analysis',
  x4: 'Self-improvement: learning, reflection, dan adaptation',
  x5: 'Eval & critique: LLM judge, consistency test, dan benchmark',
  x6: 'Systematic debug: root cause analysis, bisect, dan reproduce',
  x7: 'Problem shaping: brainstorm, decision support, dan tradeoff',
  x8: 'Diagnostic: health check, self-repair, dan system diagnosis',
  H1: 'Token swap via DEX aggregator (1inch, Jupiter)',
  H2: 'Cross-chain bridge (LayerZero, Stargate, Li.Fi)',
  H3: 'DeFi protocols: lending, staking, perps (Aave, GMX, Pendle)',
  H4: 'Token sniping, honeypot detection, dan launch monitoring',
  H5: 'On-chain monitoring: whale tracking, mempool, dan smart money',
  H6: 'NFT marketplace: buy, sell, listing (Blur, Magic Eden)',
  H7: 'SIWE, WalletConnect, EIP-712, dan signature operations',
  H8: 'Browser automation: Playwright, dApp interaction',
  H9: 'Contract read/write: ABI calls, proxy inspection',
  H10: 'Smart contract deploy, compile, dan verify',
};

export let skills = {};

/**
 * initSkillRegistry — Auto-discover semua .js file di src/skills/
 * Skill baru yang ditulis code-engine langsung ter-register tanpa perlu edit file ini.
 */
export async function initSkillRegistry() {
  const skillsDir = path.join(__dirname, '..', 'skills');

  // Pastikan folder ada
  if (!fs.existsSync(skillsDir)) {
    logger.warn(`Skills directory not found: ${skillsDir}`);
    return;
  }

  // Baca semua .js file di folder skills
  const files = fs.readdirSync(skillsDir).filter(f => f.endsWith('.js'));

  for (const file of files) {
    const id = file.replace('.js', '');
    try {
      const mod = await import(`../skills/${file}`);
      const skillMod = mod.default;

      if (skillMod?.id) {
        // Gabungkan metadata dari SKILL_KEYWORDS (kalau ada) dengan module
        const keywordMeta = SKILL_KEYWORDS[skillMod.id] || SKILL_KEYWORDS[id] || {};
        skills[skillMod.id] = {
          ...keywordMeta,
          id: skillMod.id,
          name: skillMod.name || keywordMeta.name || skillMod.id,
          description: skillMod.description || '',
          module: skillMod,
        };
      } else if (SKILL_KEYWORDS[id]) {
        // Fallback: pakai id dari filename kalau skill tidak punya id field
        skills[id] = { ...SKILL_KEYWORDS[id], module: skillMod };
      }
    } catch (err) {
      logger.warn(`Skill ${id} not loaded: ${err.message}`);
    }
  }

  // Juga register skill dari SKILL_KEYWORDS yang tidak punya file .js
  // (keyword-only skills untuk routing, tanpa module)
  for (const [id, meta] of Object.entries(SKILL_KEYWORDS)) {
    if (!skills[id]) {
      skills[id] = { ...meta, id };
    }
  }

  logger.info(`Loaded ${Object.keys(skills).length} skills (${files.length} from files)`);
}

export function routeSkill(input) {
  const lower = input.toLowerCase();
  const scores = {};
  const matched = [];

  // 1. Scan hardcoded SKILL_KEYWORDS
  for (const [id, skill] of Object.entries(SKILL_KEYWORDS)) {
    let score = 0;
    const weights = skill.weight || {};
    for (const [keyword, weight] of Object.entries(weights)) {
      if (lower.includes(keyword.toLowerCase())) {
        score += weight;
        matched.push({ id, keyword, weight });
      }
    }
    if (score > 0) scores[id] = score;
  }

  // 2. Scan dynamic skills (dari file) yang punya keywords field
  for (const [id, skill] of Object.entries(skills)) {
    if (scores[id]) continue; // sudah di-score dari hardcoded
    const mod = skill.module;
    if (!mod) continue;

    // Cek keywords field dari skill module
    const keywords = mod.keywords || {};
    if (Object.keys(keywords).length > 0) {
      let score = 0;
      for (const [keyword, weight] of Object.entries(keywords)) {
        if (lower.includes(keyword.toLowerCase())) {
          score += weight;
          matched.push({ id, keyword, weight });
        }
      }
      if (score > 0) scores[id] = score;
    }

    // Fallback: cek description sebagai keywords (split per kata)
    // GUARD: hanya match kalau ada minimal 2 kata cocok DAN kata tsb bukan common Indonesian words
    if (!scores[id] && mod.description) {
      const COMMON_WORDS = new Set([
        'yang', 'dan', 'atau', 'dari', 'untuk', 'dengan', 'ini', 'itu', 'ada',
        'tidak', 'akan', 'bisa', 'sudah', 'semua', 'lebih', 'juga', 'hanya',
        'saya', 'kamu', 'anda', 'mereka', 'kami', 'kita', 'baru', 'lama',
        'real', 'time', 'data', 'info', 'cara', 'satu', 'dua', 'tiga',
        'very', 'some', 'this', 'that', 'with', 'from', 'have', 'been',
        'selalu', 'terlalu', 'setiap', 'masih', 'lagi', 'kalau', 'mau',
        'apa', 'siapa', 'kapan', 'dimana', 'mengapa', 'bagaimana', 'gimana',
      ]);
      const descWords = mod.description.toLowerCase().split(/[\s,./()]+/).filter(w => w.length > 3 && !COMMON_WORDS.has(w));
      let score = 0;
      let matchCount = 0;
      for (const word of descWords) {
        if (lower.includes(word)) {
          score += 1; // reduced weight from 2 to 1 for description matches
          matchCount++;
          matched.push({ id, keyword: word, weight: 1 });
        }
      }
      // Only count if at least 2 meaningful words matched
      if (matchCount >= 2) scores[id] = score;
    }
  }

  if (Object.keys(scores).length === 0) {
    return { skill: null, score: 0, matched: [] };
  }

  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const topId = sorted[0][0];
  const topScore = sorted[0][1];
  const topMatched = matched.filter(m => m.id === topId);

  return {
    skill: topId,
    name: skills[topId]?.name || SKILL_KEYWORDS[topId]?.name || topId,
    score: topScore,
    matched: topMatched.map(m => m.keyword),
  };
}

/**
 * @typedef {Object} SkillKeywordEntry
 * @property {string} keyword
 * @property {number} weight - 1 (generic), 2 (secondary), or 3 (primary domain keyword)
 */

/**
 * @typedef {Object} SkillMatch
 * @property {string} skillId
 * @property {number} score - Weighted score: Σ(keyword_weight × occurrence_count_in_input)
 * @property {number} maxTheoreticalScore - Sum of all keyword weights × 3
 * @property {string} description - One-line domain description
 */

/**
 * Converts the SKILL_KEYWORDS weight object into an array of { keyword, weight } entries.
 * @param {Object} weightObj - e.g. { swap: 3, token: 2, exchange: 1 }
 * @returns {SkillKeywordEntry[]}
 */
function toKeywordEntries(weightObj) {
  if (!weightObj || typeof weightObj !== 'object') return [];
  return Object.entries(weightObj).map(([keyword, weight]) => ({ keyword: keyword.toLowerCase(), weight }));
}

/**
 * Computes maxTheoreticalScore for a skill: sum of all keyword weights × 3
 * This represents the theoretical maximum if every keyword appeared 3 times in input.
 * @param {SkillKeywordEntry[]} keywordEntries
 * @returns {number}
 */
function computeMaxTheoreticalScore(keywordEntries) {
  return keywordEntries.reduce((sum, { weight }) => sum + weight * 3, 0);
}

/**
 * Keyword-weighted matching.
 * Score = Σ (keyword_weight × occurrence_count_in_input)
 *
 * Each skill has keywords with weight:
 *   weight 3 = primary domain keyword
 *   weight 2 = secondary keyword
 *   weight 1 = generic keyword
 *
 * Multi-word keywords (e.g. "deploy kontrak") are matched as substrings in each token
 * sequence, using a sliding window approach for proper multi-word support.
 *
 * @param {string} input - User input text
 * @returns {SkillMatch[]} Sorted by score descending
 */
export function matchSkills(input) {
  if (!input || typeof input !== 'string') return [];

  const normalizedInput = input.toLowerCase();
  const inputTokens = normalizedInput.split(/\s+/).filter(t => t.length > 0);

  if (inputTokens.length === 0) return [];

  const results = [];

  for (const [skillId, skillMeta] of Object.entries(SKILL_KEYWORDS)) {
    const keywordEntries = toKeywordEntries(skillMeta.weight);
    if (keywordEntries.length === 0) continue;

    let score = 0;

    for (const { keyword, weight } of keywordEntries) {
      const keywordParts = keyword.split(/\s+/);

      if (keywordParts.length === 1) {
        // Single-word keyword: count tokens that contain the keyword
        const occurrences = inputTokens.filter(t => t.includes(keyword)).length;
        score += weight * occurrences;
      } else {
        // Multi-word keyword: count occurrences as substring in the full input
        let occurrences = 0;
        let searchFrom = 0;
        while (true) {
          const idx = normalizedInput.indexOf(keyword, searchFrom);
          if (idx === -1) break;
          occurrences++;
          searchFrom = idx + keyword.length;
        }
        score += weight * occurrences;
      }
    }

    if (score > 0) {
      const maxTheoreticalScore = computeMaxTheoreticalScore(keywordEntries);
      const description = SKILL_DESCRIPTIONS[skillId] || skillMeta.name || skillId;

      results.push({
        skillId,
        score,
        maxTheoreticalScore,
        description,
      });
    }
  }

  // Sort by score descending
  return results.sort((a, b) => b.score - a.score);
}

/**
 * Fuzzy match dengan threshold 0.5 dari max theoretical score.
 * Returns best match above threshold, or null if no match or ambiguous.
 *
 * Logic:
 * 1. Call matchSkills(input) to get scored results
 * 2. For each result, check if score >= 0.5 * maxTheoreticalScore
 * 3. Filter to only those above threshold
 * 4. If exactly 1 result above threshold → return it
 * 5. If 2+ results have identical highest score → return null (disambiguation)
 * 6. If 1 result has strictly highest score → return it
 * 7. If no results above threshold → return null
 *
 * @param {string} input
 * @returns {SkillMatch|null} Best match above threshold, or null
 *
 * Validates: Requirements 2.2, 2.3, 2.8
 */
export function fuzzyMatch(input) {
  const results = matchSkills(input);

  // Filter results above threshold (each skill has its own maxTheoreticalScore)
  const aboveThreshold = results.filter(r => r.score >= 0.5 * r.maxTheoreticalScore);

  if (aboveThreshold.length === 0) return null;
  if (aboveThreshold.length === 1) return aboveThreshold[0];

  // Multiple above threshold — check if top 2+ are tied
  const topScore = aboveThreshold[0].score;
  const tied = aboveThreshold.filter(r => r.score === topScore);

  if (tied.length >= 2) return null; // Disambiguation needed

  return aboveThreshold[0]; // Single highest
}

/**
 * Top N suggestions untuk klarifikasi fallback.
 * Used when no skill matches above threshold — provides suggestions to user.
 *
 * @param {string} input - User input text
 * @param {number} [n=3] - Number of suggestions to return (default 3)
 * @returns {SkillMatch[]} Top N skill matches sorted by score DESC
 *
 * Validates: Requirements 2.4
 */
export function getSuggestions(input, n = 3) {
  const results = matchSkills(input);
  return results.slice(0, n);
}
