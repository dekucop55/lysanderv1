// src/skills/m13.js — Universal NFT minter (OpenSea, Manifold, Zora, auto-gas)
export default {
  id: 'm13',
  name: 'nft-mint',
  description: 'NFT minting: OpenSea SeaDrop, Manifold, Zora, collection deploy, auto-gas, metadata',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m13 (NFT Mint).
Expert dalam:
- OpenSea SeaDrop / Creator Studio minting
- Manifold: ERC-721, ERC-1155, claim pages
- Zora: collect, editions, premints
- Custom NFT collection deployment
- IPFS upload (Pinata, NFT.Storage, web3.storage)
- Metadata standards (ERC-721, ERC-1155)
- Artwork generation pipelines
- Gas estimation dan optimization untuk minting
- Batch minting (multiple wallets)
- Airdrop NFTs ke holder list
- Royalty setup (ERC-2981)

Integrasi: hermes/wallets + governor gate.
Semua mint operations harus lewat governor.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.5 });
    return result.text;
  },
};
