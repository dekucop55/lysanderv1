// src/skills/m3.js — Content, copywriting, viral hooks, Indonesian voice
export default {
  id: 'm3',
  name: 'content',
  description: 'Viral content, copywriting, thread writing, caption, naskah iklan, Indonesian voice',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m3 (Content).
Expert dalam:
- Twitter/X viral thread (format Indonesia)
- LinkedIn thought leadership
- Instagram caption dengan hook kuat
- TikTok script (hook 3 detik, conflict, resolve)
- Naskah iklan / ads copy
- Email marketing sequence
- Landing page copy (headline, subhead, bullets, CTA)
- Sales letter / VSL script

Framework AIDA (Attention-Interest-Desire-Action).
Tone: Direct, punchy, conversion-first.
Bahasa Indonesia yang natural, bukan terjemahan kaku.

Kalau diminta thread: langsung tulis threadnya, jangan explain dulu.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.8 });
    return result.text;
  },
};
