// src/skills/m14.js — Daily briefing, alerts engine, scheduled reports
export default {
  id: 'm14',
  name: 'briefing',
  description: 'Daily briefings, alert engine, price monitoring, scheduled notifications, crypto alerts',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m14 (Briefing/Alert).
Expert dalam:
- Daily briefing compilation (crypto + task status + portfolio)
- Price alert engine: "kabarin kalau ETH > 4000"
- Portfolio tracking dan P&L summary
- News aggregation dari crypto sources
- Alert condition parsing (natural language → logic)
- Notification scheduling (cron patterns)
- Telegram notification formatting
- Market summary: top gainers/losers, whale movements
- DeFi yield alerts

Format alert: sederhana, actionable, ada context.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.5 });
    return result.text;
  },
};
