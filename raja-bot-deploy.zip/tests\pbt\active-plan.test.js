// tests/pbt/active-plan.test.js
// Property-Based Test: Property 3 — TTL Expiration Active Plan
// **Validates: Requirements 1.6, 1.8**
//
// Property 3: *For any* `active_plan` dengan `lastInteraction` timestamp T,
// jika waktu saat ini melebihi T + 30 menit, maka `getActivePlan()` SHALL
// mengembalikan null dan plan tersebut SHALL dihapus dari session.

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import { ActivePlanManager } from '../../src/core/brain.js';

// ─── Constants ──────────────────────────────────────────────────────────────

const DEFAULT_TTL_MS = 30 * 60 * 1000; // 30 minutes = 1,800,000 ms

// ─── Property Tests ─────────────────────────────────────────────────────────

describe('Property 3: TTL Expiration Active Plan', () => {
  describe('Expired Plans (elapsed > TTL)', () => {
    it('**Validates: Requirements 1.6, 1.8** — Plans with lastInteraction > TTL ago return null from getActivePlan', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: DEFAULT_TTL_MS + 1, max: 10_000_000 }), // elapsed ms > 30 min
          (elapsedMs) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'test plan',
              status: 'agreed'
            };
            manager.setPlan('session1', plan);

            // Simulate time having passed by backdating lastInteraction
            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - elapsedMs;

            const result = manager.getActivePlan('session1');
            expect(result).toBeNull();
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 1.8** — Expired plans are removed from session after getActivePlan call', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: DEFAULT_TTL_MS + 1, max: 10_000_000 }),
          (elapsedMs) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'test plan',
              status: 'agreed'
            };
            manager.setPlan('session1', plan);

            // Backdate lastInteraction to simulate expiry
            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - elapsedMs;

            // getActivePlan triggers pruneExpired internally
            manager.getActivePlan('session1');

            // Session should have no plans left
            const remaining = manager.sessions.get('session1') || [];
            expect(remaining.length).toBe(0);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 1.8** — pruneExpired removes expired plans and returns them with status "expired"', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: DEFAULT_TTL_MS + 1, max: 5_000_000 }),
          (elapsedMs) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'test plan',
              status: 'agreed'
            };
            manager.setPlan('session1', plan);

            // Backdate to expire
            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - elapsedMs;

            const expired = manager.pruneExpired('session1');

            // Should return exactly one expired plan
            expect(expired.length).toBe(1);
            expect(expired[0].planId).toBe('p1');
            expect(expired[0].status).toBe('expired');

            // Session should be empty after pruning
            const remaining = manager.sessions.get('session1') || [];
            expect(remaining.length).toBe(0);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  describe('Active Plans Within TTL (elapsed <= TTL)', () => {
    it('**Validates: Requirements 1.6** — Plans within TTL (elapsed < 30min) are returned by getActivePlan', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 0, max: DEFAULT_TTL_MS - 1 }), // elapsed ms < 30 min
          (elapsedMs) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'test plan',
              status: 'agreed'
            };
            manager.setPlan('session1', plan);

            // Set lastInteraction within TTL window
            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - elapsedMs;

            const result = manager.getActivePlan('session1');
            expect(result).not.toBeNull();
            expect(result.planId).toBe('p1');
            expect(result.status).toBe('agreed');
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 1.6** — Plans within TTL remain in session after pruning', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 0, max: DEFAULT_TTL_MS - 1 }),
          (elapsedMs) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'test plan',
              status: 'agreed'
            };
            manager.setPlan('session1', plan);

            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - elapsedMs;

            const expired = manager.pruneExpired('session1');

            // Nothing should be expired
            expect(expired.length).toBe(0);

            // Plan should still be in session
            const remaining = manager.sessions.get('session1');
            expect(remaining.length).toBe(1);
            expect(remaining[0].planId).toBe('p1');
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  describe('TTL Boundary Behavior', () => {
    it('**Validates: Requirements 1.6, 1.8** — At exactly TTL boundary (elapsed === TTL), plan is still active (strict > comparison)', () => {
      // The implementation uses: now - lastInteraction > ttlMs (strict greater than)
      // So at exactly TTL, the plan should still be active (not expired)
      const manager = new ActivePlanManager();
      const plan = {
        planId: 'p1',
        skillId: 's1',
        description: 'boundary test',
        status: 'agreed'
      };
      manager.setPlan('session1', plan);

      // Set lastInteraction to exactly TTL ago
      const storedPlans = manager.sessions.get('session1');
      storedPlans[0].lastInteraction = Date.now() - DEFAULT_TTL_MS;

      const result = manager.getActivePlan('session1');
      // At exactly the boundary, strict > means NOT expired — plan is still active
      expect(result).not.toBeNull();
      expect(result.planId).toBe('p1');
    });

    it('**Validates: Requirements 1.6, 1.8** — Custom TTL is respected per plan', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 60_000, max: 3_600_000 }), // custom TTL: 1min to 1hr
          fc.integer({ min: 1, max: 60_000 }),           // margin above TTL
          (customTtl, margin) => {
            const manager = new ActivePlanManager();
            const plan = {
              planId: 'p1',
              skillId: 's1',
              description: 'custom ttl plan',
              status: 'agreed',
              ttlMs: customTtl
            };
            manager.setPlan('session1', plan);

            // Backdate to customTtl + margin (expired)
            const storedPlans = manager.sessions.get('session1');
            storedPlans[0].lastInteraction = Date.now() - (customTtl + margin);

            const result = manager.getActivePlan('session1');
            expect(result).toBeNull();
          }
        ),
        { numRuns: 200 }
      );
    });
  });
});


// ─── Property 4: Disambiguation pada Multiple Plans ─────────────────────────
// **Validates: Requirements 1.5**
//
// Property 4: *For any* session dengan lebih dari satu `active_plan` berstatus
// "agreed", dan *for any* perintah EXECUTE yang cocok dengan lebih dari satu plan,
// Brain SHALL mengembalikan prompt konfirmasi yang berisi daftar semua plan aktif.
//
// In terms of ActivePlanManager behavior: when multiple agreed plans exist,
// `getActivePlan()` returns null (disambiguation needed), while `getActivePlans()`
// returns all of them.

describe('Property 4: Disambiguation pada Multiple Plans', () => {
  it('**Validates: Requirements 1.5** — getActivePlan returns null when 2+ agreed plans exist', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 2, max: 10 }), // number of agreed plans
        (numPlans) => {
          const manager = new ActivePlanManager();
          for (let i = 0; i < numPlans; i++) {
            manager.setPlan('session1', {
              planId: `p${i}`,
              skillId: `s${i}`,
              description: `plan ${i}`,
              status: 'agreed'
            });
          }

          // getActivePlan should return null (disambiguation needed)
          expect(manager.getActivePlan('session1')).toBeNull();
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 1.5** — getActivePlans returns all active plans for disambiguation display', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 2, max: 10 }),
        (numPlans) => {
          const manager = new ActivePlanManager();
          for (let i = 0; i < numPlans; i++) {
            manager.setPlan('session1', {
              planId: `p${i}`,
              skillId: `s${i}`,
              description: `plan ${i}`,
              status: 'agreed'
            });
          }

          const allPlans = manager.getActivePlans('session1');
          expect(allPlans.length).toBe(numPlans);
        }
      ),
      { numRuns: 200 }
    );
  });
});
