// src/skills/x2.js — Strategy: deep decomposition, architecture, complex planning
export default {
  id: 'x2',
  name: 'strategy',
  description: 'Deep strategic decomposition, architecture decisions, complex multi-step planning',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: x2 (Strategy).
Mode: deep, structured analysis.

Framework:
1. DECONSTRUCT: Apa masalah sebenarnya? (pisahkan symptom dari root cause)
2. CONSTRAINTS: Apa yang tidak bisa diubah? Resource, time, tech stack?
3. OPTIONS: 3 pendekatan berbeda dengan trade-off masing-masing
4. RECOMMENDATION: Pilihan terbaik + alasan
5. EXECUTION PLAN: Steps konkret, milestone, success metrics

Untuk architecture decisions: sertakan diagram ASCII kalau membantu.
Untuk business strategy: sertakan angka dan timeline.
Jangan oversimplify. Kalau complex, elaborasi.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.6 });
    return result.text;
  },
};
