// src/utils/crypto.js — Encryption helpers for secret storage
import { createHash, randomBytes, createCipheriv, createDecipheriv } from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY_LEN = 32; // bytes
const IV_LEN = 16;
const TAG_LEN = 16;

/**
 * Derive a 32-byte key from a passphrase using SHA-256
 */
export function deriveKey(passphrase) {
  return createHash('sha256').update(String(passphrase)).digest();
}

/**
 * Encrypt plaintext using AES-256-GCM
 * Returns base64 string: iv(16) + tag(16) + ciphertext
 */
export function encrypt(plaintext, passphrase) {
  const key = deriveKey(passphrase);
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGORITHM, key, iv);

  const encrypted = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();

  // Combine: iv + tag + ciphertext
  const combined = Buffer.concat([iv, tag, encrypted]);
  return combined.toString('base64');
}

/**
 * Decrypt AES-256-GCM ciphertext
 */
export function decrypt(encryptedB64, passphrase) {
  const key = deriveKey(passphrase);
  const combined = Buffer.from(encryptedB64, 'base64');

  if (combined.length < IV_LEN + TAG_LEN + 1) {
    throw new Error('Invalid ciphertext: too short');
  }

  const iv = combined.subarray(0, IV_LEN);
  const tag = combined.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const ciphertext = combined.subarray(IV_LEN + TAG_LEN);

  const decipher = createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);

  const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return decrypted.toString('utf8');
}

/**
 * Hash a value (SHA-256, hex)
 */
export function sha256(input) {
  return createHash('sha256').update(String(input)).digest('hex');
}

/**
 * Generate a random hex token of given bytes
 */
export function randomToken(bytes = 32) {
  return randomBytes(bytes).toString('hex');
}

/**
 * Mask sensitive values for logging (show first 4 + last 4 chars)
 */
export function maskSecret(secret) {
  if (!secret || secret.length < 10) return '****';
  return `${secret.slice(0, 4)}...${secret.slice(-4)}`;
}
