// tests/pbt/brain-routing.test.js
// Property-Based Tests: Brain EXECUTE Routing (Properties 1, 2, 7, 8)
//
// Property 1: Klasifikasi EXECUTE dengan Active Plan
// Property 2: Active Plan Retrieval untuk Short Command
// Property 7: EXECUTE Path Tidak Inject Anti-Hallucination
// Property 8: Error Report Format pada Skill Failure

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';
import {
  classifyIntent,
  planManager,
  routeExecute,
  EXECUTE_KEYWORDS,
  ERROR_CATEGORIES,
  classifyError,
  formatErrorReport
} from '../../src/core/brain.js';

// ─── Helpers ────────────────────────────────────────────────────────────────

const execKeywordsArr = [...EXECUTE_KEYWORDS];

// Words that are BOTH in EXECUTE_KEYWORDS and AGREEMENT_PHRASES (handled as CONFIRM)
const AGREEMENT_ONLY = new Set(['gas']);

// Exec keywords that won't trigger CONFIRM (agreement phrase) on their own
const safeExecKeywords = execKeywordsArr.filter(kw => !AGREEMENT_ONLY.has(kw));

// Multi-word keywords that need special handling
const MULTI_WORD_KEYWORDS = ['ok gas', 'send it', 'do it'];
const singleWordExecKeywords = safeExecKeywords.filter(kw => !kw.includes(' '));

// ─── Property 1: Klasifikasi EXECUTE dengan Active Plan ─────────────────────
// **Validates: Requirements 1.1, 1.3, 1.4**
//
// *For any* session dengan `active_plan` berstatus "agreed" yang belum expired,
// dan *for any* pesan singkat (1-5 kata) yang mengandung minimal satu kata kunci
// eksekusi, klasifikasi intent SHALL selalu menghasilkan "EXECUTE".

describe('Property 1: Klasifikasi EXECUTE dengan Active Plan', () => {
  it('**Validates: Requirements 1.1, 1.3, 1.4** — short command (1-5 words) + exec keyword + agreed plan → EXECUTE', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...singleWordExecKeywords),
        fc.array(fc.constantFrom('sekarang', 'dong', 'bos', 'cepat', 'itu', 'ya'), { minLength: 0, maxLength: 3 }),
        (keyword, fillers) => {
          // Setup: clear sessions and set an agreed plan
          planManager.sessions.clear();
          const sessionId = 'pbt-session-1';
          planManager.setPlan(sessionId, {
            planId: 'p1',
            skillId: 's1',
            description: 'test plan',
            status: 'agreed'
          });

          // Build message: keyword + fillers (1-5 words total)
          const message = [keyword, ...fillers].join(' ');
          const words = message.trim().split(/\s+/);

          // Only test if 1-5 words
          if (words.length < 1 || words.length > 5) return;

          const result = classifyIntent(message, { id: sessionId });
          expect(result).toBe('EXECUTE');
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 1.1, 1.3, 1.4** — "ok gas" multi-word keyword + agreed plan → EXECUTE (via "gas" single-word match)', () => {
    // Note: Multi-word keywords like "ok gas" work because "gas" alone is in EXECUTE_KEYWORDS
    // and "ok" is in AGREEMENT_PHRASES. When combined as "ok gas", it's 2 words so isAgreementPhrase
    // (which checks the FULL string) won't match "ok gas" literally, but "gas" IS in EXECUTE_KEYWORDS.
    // "send it" and "do it" don't have individual words in the keyword set so they rely on
    // the longer-command path (hasExecKeyword via multi-word match is not supported by word splitting).
    fc.assert(
      fc.property(
        fc.constantFrom('ok gas', 'go bos', 'run dong', 'execute ya'),
        (message) => {
          planManager.sessions.clear();
          const sessionId = 'pbt-session-1b';
          planManager.setPlan(sessionId, {
            planId: 'p1',
            skillId: 's1',
            description: 'test plan',
            status: 'agreed'
          });

          const words = message.trim().split(/\s+/);
          if (words.length > 5) return;

          const result = classifyIntent(message, { id: sessionId });
          expect(result).toBe('EXECUTE');
        }
      ),
      { numRuns: 200 }
    );
  });
});

// ─── Property 2: Active Plan Retrieval untuk Short Command ──────────────────
// **Validates: Requirements 1.2, 1.3**
//
// *For any* pesan pendek (1-5 kata) yang terklasifikasi sebagai EXECUTE dan
// *for any* session dengan satu `active_plan` agreed, Brain SHALL menggunakan
// `plan.skillId` sebagai target routing.

describe('Property 2: Active Plan Retrieval untuk Short Command', () => {
  it('**Validates: Requirements 1.2, 1.3** — short EXECUTE command with active plan → routes to plan.skillId', () => {
    fc.assert(
      fc.property(
        fc.constantFrom('eksekusi', 'jalankan', 'run', 'lakukan', 'execute'),
        fc.constantFrom('H1', 'H2', 'H3', 'm2', 'm10', 'm11', 'deploy-skill', 'swap-engine'),
        (keyword, skillId) => {
          planManager.sessions.clear();
          const sessionId = 'pbt-session-2';
          planManager.setPlan(sessionId, {
            planId: 'p1',
            skillId,
            description: 'test plan',
            status: 'agreed'
          });

          const result = routeExecute(keyword, { id: sessionId });

          // Should dispatch to the plan's skillId
          expect(result.action).toBe('dispatch');
          expect(result.skillId).toBe(skillId);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 1.2, 1.3** — skillId is always taken from the plan, not from matching', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...singleWordExecKeywords),
        fc.uuid(),
        (keyword, randomSkillId) => {
          planManager.sessions.clear();
          const sessionId = 'pbt-session-2b';
          planManager.setPlan(sessionId, {
            planId: 'plan-x',
            skillId: randomSkillId,
            description: 'random plan',
            status: 'agreed'
          });

          const result = routeExecute(keyword, { id: sessionId });

          expect(result.action).toBe('dispatch');
          expect(result.skillId).toBe(randomSkillId);
        }
      ),
      { numRuns: 200 }
    );
  });
});

// ─── Property 7: EXECUTE Path Tidak Inject Anti-Hallucination ───────────────
// **Validates: Requirements 2.5**
//
// *For any* pesan yang di-route melalui path EXECUTE ke skill yang cocok,
// prompt yang dikirim ke skill handler SHALL tidak mengandung
// grounding/anti-hallucination injection.

describe('Property 7: EXECUTE Path Tidak Inject Anti-Hallucination', () => {
  it('**Validates: Requirements 2.5** — dispatch result never contains anti-hallucination fields', () => {
    fc.assert(
      fc.property(
        fc.constantFrom('eksekusi', 'jalankan', 'run', 'lakukan', 'execute', 'go'),
        fc.constantFrom('H1', 'H2', 'H3', 'm2', 'm10', 'swap-engine', 'deploy-skill'),
        (keyword, skillId) => {
          planManager.sessions.clear();
          const sessionId = 'pbt-session-7';
          planManager.setPlan(sessionId, {
            planId: 'p7',
            skillId,
            description: 'execute test plan',
            status: 'agreed'
          });

          const result = routeExecute(keyword, { id: sessionId });

          // Route result must NOT contain anti-hallucination injections
          expect(result.antiHallucination).toBeUndefined();
          expect(result.groundingPrompt).toBeUndefined();
          expect(result.realityAnchors).toBeUndefined();
          expect(result.hallucinationGuard).toBeUndefined();

          // Verify no grounding/reality anchor content in the result
          // (check top-level string fields, excluding plan description which is user-defined)
          if (result.message) {
            expect(result.message).not.toContain('REALITY ANCHORS');
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.5** — dispatch action is always "dispatch" (not redirected to LLM)', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(...singleWordExecKeywords),
        fc.constantFrom('H1', 'H2', 'm2', 'm10', 'm11'),
        (keyword, skillId) => {
          planManager.sessions.clear();
          const sessionId = 'pbt-session-7b';
          planManager.setPlan(sessionId, {
            planId: 'p7b',
            skillId,
            description: 'no llm redirect test',
            status: 'agreed'
          });

          const result = routeExecute(keyword, { id: sessionId });

          // Should always be dispatch, never routed to LLM
          expect(result.action).toBe('dispatch');
          // No LLM-related fields
          expect(result.llmFallback).toBeUndefined();
          expect(result.chatResponse).toBeUndefined();
        }
      ),
      { numRuns: 200 }
    );
  });
});

// ─── Property 8: Error Report Format pada Skill Failure ─────────────────────
// **Validates: Requirements 2.7**
//
// *For any* skill execution yang gagal dengan error E, respons ke user SHALL
// mengandung tiga elemen: (a) nama skill yang gagal, (b) kategori error dari
// set {network, timeout, permission, runtime}, dan (c) satu saran aksi konkret.

describe('Property 8: Error Report Format pada Skill Failure', () => {
  it('**Validates: Requirements 2.7** — error report always contains skill name, category, and suggestion', () => {
    fc.assert(
      fc.property(
        fc.constantFrom('H1', 'H2', 'H3', 'm2', 'm10', 'deploy-skill', 'swap-engine', 'bridge-engine'),
        fc.constantFrom(
          new Error('ECONNREFUSED: connection refused'),
          new Error('ETIMEDOUT: request timed out'),
          new Error('timeout exceeded waiting for response'),
          new Error('DEADLINE_EXCEEDED'),
          new Error('EACCES: permission denied'),
          new Error('403 Forbidden unauthorized'),
          new Error('TypeError: Cannot read properties of undefined'),
          new Error('ReferenceError: x is not defined'),
          new Error('SyntaxError: Unexpected token'),
          new Error('fetch failed: ENOTFOUND')
        ),
        (skillId, error) => {
          // Classify the error
          const { category, suggestion } = classifyError(error);

          // Category must be one of the valid set
          expect(['network', 'timeout', 'permission', 'runtime']).toContain(category);

          // Suggestion must be non-empty
          expect(suggestion.length).toBeGreaterThan(0);

          // Format the error report
          const report = formatErrorReport({ skillId, category, suggestion });

          // Report must contain all three elements:
          // (a) nama skill yang gagal
          expect(report).toContain(skillId);
          // (b) kategori error
          expect(report).toContain(category);
          // (c) saran aksi konkret
          expect(report).toContain(suggestion);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.7** — classifyError always returns valid category for any error', () => {
    fc.assert(
      fc.property(
        fc.oneof(
          fc.constant('ECONNREFUSED'),
          fc.constant('ETIMEDOUT'),
          fc.constant('timeout'),
          fc.constant('EACCES'),
          fc.constant('TypeError'),
          fc.constant('some unknown error that does not match'),
          fc.string({ minLength: 1, maxLength: 100 })
        ),
        (errorMessage) => {
          const error = new Error(errorMessage);
          const { category, suggestion } = classifyError(error);

          // Must always return a valid category
          expect(['network', 'timeout', 'permission', 'runtime']).toContain(category);

          // Must always return a non-empty suggestion
          expect(typeof suggestion).toBe('string');
          expect(suggestion.length).toBeGreaterThan(0);
        }
      ),
      { numRuns: 200 }
    );
  });

  it('**Validates: Requirements 2.7** — error patterns correctly map to their categories', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(
          { msg: 'ECONNREFUSED', expected: 'network' },
          { msg: 'ETIMEDOUT', expected: 'network' },
          { msg: 'ENOTFOUND', expected: 'network' },
          { msg: 'fetch failed', expected: 'network' },
          { msg: 'timeout exceeded', expected: 'timeout' },
          { msg: 'DEADLINE_EXCEEDED', expected: 'timeout' },
          { msg: 'AbortError', expected: 'timeout' },
          { msg: 'EACCES denied', expected: 'permission' },
          { msg: 'EPERM not permitted', expected: 'permission' },
          { msg: '403 Forbidden', expected: 'permission' },
          { msg: 'unauthorized access', expected: 'permission' },
          { msg: 'TypeError: null', expected: 'runtime' },
          { msg: 'ReferenceError: x', expected: 'runtime' },
          { msg: 'SyntaxError: bad', expected: 'runtime' }
        ),
        ({ msg, expected }) => {
          const { category } = classifyError(new Error(msg));
          expect(category).toBe(expected);
        }
      ),
      { numRuns: 200 }
    );
  });
});
