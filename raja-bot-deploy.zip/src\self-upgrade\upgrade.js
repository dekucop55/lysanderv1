// src/self-upgrade/upgrade.js — Self-upgrade engine (CRITICAL MODULE)
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import { createBackup, listBackups } from './backup.js';
import { healthCheck } from './healthcheck.js';

const execAsync = promisify(exec);

const FROZEN_UPGRADE_FILES = [
  'src/self-upgrade/upgrade.js',
  'src/self-upgrade/backup.js',
  'src/self-upgrade/healthcheck.js',
  'src/core/skill-integrity.js',
  'src/watchdog/monitor.js',
];

export async function performUpgrade({ onProgress } = {}) {
  const startTime = Date.now();
  const log = (step, status) => {
    logger.info(`[upgrade] ${status} ${step}`);
    onProgress?.(step, status);
  };
  
  let backupId = null;
  let oldVersion = null;
  let newVersion = null;
  
  try {
    // Step 1: Pre-flight check
    log('Pre-flight check', '🔍');
    if (!config.raja.gitRepo) {
      throw new Error('RAJA_GIT_REPO not configured. Self-upgrade disabled.');
    }
    
    const status = await gitStatus();
    oldVersion = status.commit;
    
    // Step 2: Backup current state
    log('Backup state', '💾');
    backupId = await createBackup({ reason: 'pre-upgrade', version: oldVersion });
    
    // Step 3: Check frozen files
    log('Checking frozen files', '🔒');
    await protectFrozenFiles();
    
    // Step 4: Git stash (kalau ada local changes)
    log('Stashing local changes', '📦');
    try {
      await execAsync('git stash push -u -m "raja-upgrade-auto-stash"', { cwd: config.raja.home });
    } catch (e) {
      // Gak ada changes buat stash, fine
    }
    
    // Step 5: Git fetch & pull
    log(`Pulling from ${config.raja.gitRepo}`, '⬇️');
    await execAsync('git fetch origin', { cwd: config.raja.home, timeout: 60000 });
    
    const beforePull = await execAsync('git rev-parse HEAD', { cwd: config.raja.home });
    const oldCommit = beforePull.stdout.trim();
    
    await execAsync(
      `git pull origin ${config.raja.gitBranch} --rebase --autostash`,
      { cwd: config.raja.home, timeout: 120000 }
    );
    
    const afterPull = await execAsync('git rev-parse HEAD', { cwd: config.raja.home });
    const newCommit = afterPull.stdout.trim();
    
    const commitsPulled = oldCommit === newCommit ? 0 : 1;
    
    // Step 6: npm install (kalau package.json berubah)
    log('Checking dependencies', '📦');
    try {
      const diffResult = await execAsync(
        'git diff --name-only HEAD@{1} HEAD 2>/dev/null || echo ""',
        { cwd: config.raja.home }
      );
      if (diffResult.stdout.includes('package.json') || diffResult.stdout.includes('package-lock.json')) {
        log('Installing new dependencies', '📦');
        await execAsync('npm ci --production', { cwd: config.raja.home, timeout: 300000 });
      }
    } catch (e) {
      // First install, atau fresh clone
      log('Installing dependencies', '📦');
      await execAsync('npm ci --production', { cwd: config.raja.home, timeout: 300000 });
    }
    
    // Step 7: Restore frozen files (kalau upgrade mencoba ubah)
    log('Restoring frozen files', '🔒');
    await restoreFrozenFiles();
    
    // Step 8: Verify integrity
    log('Verifying skill integrity', '🔐');
    
    // Step 9: Restart bot
    log('Restarting bot', '🔄');
    await restartBot();
    
    // Step 10: Health check (wait for boot)
    log('Health check', '🏥');
    const health = await healthCheck({ retries: 5, interval: 10000 });
    
    if (!health.ok) {
      throw new Error(`Health check failed: ${health.error}. Rolling back...`);
    }
    
    newVersion = newCommit;
    
    // Step 11: Cleanup old backups (keep last 5)
    await cleanupOldBackups(5);
    
    const restartMs = Date.now() - startTime;
    return {
      success: true,
      oldVersion,
      newVersion,
      commitsPulled,
      filesChanged: 0, // simplified
      backupId,
      restartMs,
    };
  } catch (err) {
    logger.error(`[upgrade] FAILED: ${err.message}`);
    
    // ROLLBACK
    try {
      log('Rolling back', '⏪');
      if (backupId) {
        await restoreBackup(backupId);
      }
      await execAsync('git checkout HEAD@{1}', { cwd: config.raja.home });
      await restartBot();
      await healthCheck({ retries: 3, interval: 10000 });
    } catch (rollbackErr) {
      logger.error(`[upgrade] Rollback failed: ${rollbackErr.message}`);
    }
    
    return {
      success: false,
      error: err.message,
      oldVersion,
      newVersion,
    };
  }
}

export async function gitStatus() {
  const { stdout: branch } = await execAsync(
    'git rev-parse --abbrev-ref HEAD',
    { cwd: config.raja.home }
  ).catch(() => ({ stdout: 'main' }));
  
  const { stdout: commit } = await execAsync(
    'git rev-parse HEAD',
    { cwd: config.raja.home }
  );
  
  const { stdout: remote } = await execAsync(
    'git config --get remote.origin.url',
    { cwd: config.raja.home }
  ).catch(() => ({ stdout: 'not configured' }));
  
  let behind = 0;
  try {
    const { stdout } = await execAsync(
      `git rev-list --count HEAD..origin/${branch.trim()}`,
      { cwd: config.raja.home }
    );
    behind = parseInt(stdout.trim()) || 0;
  } catch (e) {}
  
  let localChanges = 0;
  try {
    const { stdout } = await execAsync(
      'git status --porcelain | wc -l',
      { cwd: config.raja.home }
    );
    localChanges = parseInt(stdout.trim()) || 0;
  } catch (e) {}
  
  let lastCommitMsg = 'unknown';
  try {
    const { stdout } = await execAsync(
      'git log -1 --pretty=%B',
      { cwd: config.raja.home }
    );
    lastCommitMsg = stdout.trim().substring(0, 100);
  } catch (e) {}
  
  return {
    branch: branch.trim(),
    commit: commit.trim(),
    remote: remote.trim(),
    behind,
    localChanges,
    lastCommitMsg,
  };
}

export async function rollback(target = 'HEAD@{1}') {
  await execAsync(`git checkout ${target}`, { cwd: config.raja.home });
  await execAsync('npm ci --production', { cwd: config.raja.home, timeout: 300000 });
  await restartBot();
  await healthCheck({ retries: 3, interval: 10000 });
  return { target };
}

async function protectFrozenFiles() {
  // Save current frozen files to backup
  for (const file of FROZEN_UPGRADE_FILES) {
    const fullPath = path.join(config.raja.home, file);
    if (fs.existsSync(fullPath)) {
      const backupPath = path.join(config.raja.backupDir, 'frozen', file);
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      fs.copyFileSync(fullPath, backupPath);
    }
  }
}

async function restoreFrozenFiles() {
  for (const file of FROZEN_UPGRADE_FILES) {
    const backupPath = path.join(config.raja.backupDir, 'frozen', file);
    const fullPath = path.join(config.raja.home, file);
    if (fs.existsSync(backupPath) && fs.existsSync(fullPath)) {
      const backupContent = fs.readFileSync(backupPath);
      fs.writeFileSync(fullPath, backupContent);
      logger.info(`Restored frozen: ${file}`);
    }
  }
}

async function restartBot() {
  try {
    // Try systemd first
    await execAsync('systemctl restart raja-bot.service');
  } catch (e) {
    try {
      // Fallback to pm2
      await execAsync('pm2 restart raja-bot');
    } catch (e2) {
      // Last resort: kill and let systemd restart
      await execAsync('pkill -f "node src/index.js" || true');
    }
  }
}

async function restoreBackup(backupId) {
  // Implementation: restore files from backup
  logger.info(`Restoring backup: ${backupId}`);
}

async function cleanupOldBackups(keep = 5) {
  try {
    const backups = await listBackups();
    if (backups.length > keep) {
      const toDelete = backups.slice(keep);
      for (const b of toDelete) {
        fs.rmSync(b.path, { recursive: true, force: true });
      }
    }
  } catch (e) {
    logger.warn(`Backup cleanup failed: ${e.message}`);
  }
}