import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest';
import { ContextWindow } from '../../src/core/context-window.js';

// Mock the logger module
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
    debug: vi.fn()
  }
}));

describe('ContextWindow', () => {
  let cw;

  beforeEach(() => {
    // Create with mock memory (not needed for estimateTokens/fitToBudget)
    cw = new ContextWindow(null);
  });

  describe('constructor', () => {
    it('uses default options when none provided', () => {
      expect(cw.maxLongTermTokens).toBe(2000);
      expect(cw.maxPreferenceTokens).toBe(500);
      expect(cw.maxMemories).toBe(5);
      expect(cw.minRelevanceScore).toBe(0.1);
      expect(cw.sessionTimeoutMs).toBe(30 * 60 * 1000);
    });

    it('accepts custom options', () => {
      const custom = new ContextWindow(null, {
        maxLongTermTokens: 1000,
        maxPreferenceTokens: 300,
        maxMemories: 3,
        minRelevanceScore: 0.2,
        sessionTimeoutMs: 10 * 60 * 1000
      });
      expect(custom.maxLongTermTokens).toBe(1000);
      expect(custom.maxPreferenceTokens).toBe(300);
      expect(custom.maxMemories).toBe(3);
      expect(custom.minRelevanceScore).toBe(0.2);
      expect(custom.sessionTimeoutMs).toBe(600000);
    });

    it('stores memory instance', () => {
      const mockMemory = { getRecentHistory: () => [] };
      const instance = new ContextWindow(mockMemory);
      expect(instance.memory).toBe(mockMemory);
    });
  });

  describe('estimateTokens', () => {
    it('returns 0 for null input', () => {
      expect(cw.estimateTokens(null)).toBe(0);
    });

    it('returns 0 for undefined input', () => {
      expect(cw.estimateTokens(undefined)).toBe(0);
    });

    it('returns 0 for empty string', () => {
      expect(cw.estimateTokens('')).toBe(0);
    });

    it('returns 0 for non-string input', () => {
      expect(cw.estimateTokens(123)).toBe(0);
      expect(cw.estimateTokens({})).toBe(0);
      expect(cw.estimateTokens([])).toBe(0);
    });

    it('returns 0 for whitespace-only string', () => {
      expect(cw.estimateTokens('   ')).toBe(0);
      expect(cw.estimateTokens('\t\n')).toBe(0);
    });

    it('counts single word correctly', () => {
      expect(cw.estimateTokens('hello')).toBe(1);
    });

    it('counts multiple words correctly', () => {
      expect(cw.estimateTokens('hello world foo bar')).toBe(4);
    });

    it('handles multiple spaces between words', () => {
      expect(cw.estimateTokens('hello   world')).toBe(2);
    });

    it('handles leading and trailing whitespace', () => {
      expect(cw.estimateTokens('  hello world  ')).toBe(2);
    });

    it('handles newlines and tabs as word separators', () => {
      expect(cw.estimateTokens('hello\nworld\tfoo')).toBe(3);
    });

    it('counts a longer text correctly', () => {
      const text = 'Saya ingin bot mengingat konteks percakapan lama yang relevan';
      // 9 words
      expect(cw.estimateTokens(text)).toBe(9);
    });
  });

  describe('fitToBudget', () => {
    it('returns empty array for null memories', () => {
      expect(cw.fitToBudget(null, 100)).toEqual([]);
    });

    it('returns empty array for empty memories', () => {
      expect(cw.fitToBudget([], 100)).toEqual([]);
    });

    it('returns empty array for zero budget', () => {
      const memories = [{ content: 'hello', score: 0.9 }];
      expect(cw.fitToBudget(memories, 0)).toEqual([]);
    });

    it('returns empty array for negative budget', () => {
      const memories = [{ content: 'hello', score: 0.9 }];
      expect(cw.fitToBudget(memories, -10)).toEqual([]);
    });

    it('selects single memory that fits within budget', () => {
      const memories = [{ content: 'hello world', score: 0.9 }];
      const result = cw.fitToBudget(memories, 10);
      expect(result).toEqual(memories);
    });

    it('selects multiple memories within budget', () => {
      const memories = [
        { content: 'hello world', score: 0.9 },       // 2 tokens
        { content: 'foo bar baz', score: 0.8 },       // 3 tokens
        { content: 'one two', score: 0.7 }            // 2 tokens
      ];
      // Total: 7 tokens, budget: 10
      const result = cw.fitToBudget(memories, 10);
      expect(result).toHaveLength(3);
    });

    it('stops adding when budget would be exceeded', () => {
      const memories = [
        { content: 'one two three', score: 0.9 },     // 3 tokens
        { content: 'four five six', score: 0.8 },     // 3 tokens
        { content: 'seven eight nine ten', score: 0.7 } // 4 tokens
      ];
      // Budget: 6, first two fit (3+3=6), third would exceed
      const result = cw.fitToBudget(memories, 6);
      expect(result).toHaveLength(2);
      expect(result[0].score).toBe(0.9);
      expect(result[1].score).toBe(0.8);
    });

    it('excludes first memory if it alone exceeds budget', () => {
      const memories = [
        { content: 'this is a very long memory with many many words', score: 0.9 }
      ];
      // 10 tokens, budget: 5
      const result = cw.fitToBudget(memories, 5);
      expect(result).toEqual([]);
    });

    it('prioritizes highest-scored memories (assumes sorted input)', () => {
      const memories = [
        { content: 'high score memory', score: 0.95 },  // 3 tokens
        { content: 'medium score', score: 0.7 },         // 2 tokens
        { content: 'low score memory item', score: 0.3 } // 4 tokens
      ];
      // Budget: 5 — first two fit (3+2=5), third cut
      const result = cw.fitToBudget(memories, 5);
      expect(result).toHaveLength(2);
      expect(result[0].score).toBe(0.95);
      expect(result[1].score).toBe(0.7);
    });

    it('handles exact budget match', () => {
      const memories = [
        { content: 'one two three', score: 0.9 },  // 3 tokens
        { content: 'four five', score: 0.8 }        // 2 tokens
      ];
      // Budget exactly 5
      const result = cw.fitToBudget(memories, 5);
      expect(result).toHaveLength(2);
    });

    it('preserves memory objects without mutation', () => {
      const memories = [
        { content: 'hello world', score: 0.9, tags: 'test', id: 1 }
      ];
      const result = cw.fitToBudget(memories, 10);
      expect(result[0]).toBe(memories[0]); // Same reference
      expect(result[0].tags).toBe('test');
      expect(result[0].id).toBe(1);
    });
  });

  describe('calculateRelevanceScore', () => {
    beforeEach(() => {
      vi.useFakeTimers();
      vi.setSystemTime(new Date('2025-01-15T12:00:00.000Z'));
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it('returns 0 for null query', () => {
      const memory = { content: 'hello world', ts: Date.now() };
      expect(cw.calculateRelevanceScore(null, memory, {})).toBe(0);
    });

    it('returns 0 for empty string query', () => {
      const memory = { content: 'hello world', ts: Date.now() };
      expect(cw.calculateRelevanceScore('', memory, {})).toBe(0);
    });

    it('returns 0 for whitespace-only query', () => {
      const memory = { content: 'hello world', ts: Date.now() };
      expect(cw.calculateRelevanceScore('   ', memory, {})).toBe(0);
    });

    it('returns 0 for non-string query', () => {
      const memory = { content: 'hello world', ts: Date.now() };
      expect(cw.calculateRelevanceScore(123, memory, {})).toBe(0);
    });

    it('calculates full token overlap correctly (all tokens match)', () => {
      const now = Date.now();
      const memory = { content: 'hello world', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 2/2 = 1.0
      // recency = 0.5^(0/30) = 1.0
      // interaction = 0
      // score = (1.0 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.9
      expect(score).toBeCloseTo(0.9, 5);
    });

    it('calculates partial token overlap correctly', () => {
      const now = Date.now();
      const memory = { content: 'hello world foo', ts: now };
      const score = cw.calculateRelevanceScore('hello bar', memory, { interactionFrequency: 0 });
      // token_overlap = 1/2 = 0.5
      // recency = 0.5^(0/30) = 1.0
      // interaction = 0
      // score = (0.5 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.6
      expect(score).toBeCloseTo(0.6, 5);
    });

    it('returns score with zero overlap but recent memory', () => {
      const now = Date.now();
      const memory = { content: 'completely different words', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 0/2 = 0
      // recency = 0.5^(0/30) = 1.0
      // interaction = 0
      // score = (0 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.3
      expect(score).toBeCloseTo(0.3, 5);
    });

    it('applies exponential decay for old memories', () => {
      const now = Date.now();
      const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);
      const memory = { content: 'hello world', ts: thirtyDaysAgo };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 2/2 = 1.0
      // recency = 0.5^(30/30) = 0.5
      // interaction = 0
      // score = (1.0 * 0.6) + (0.5 * 0.3) + (0 * 0.1) = 0.75
      expect(score).toBeCloseTo(0.75, 5);
    });

    it('applies correct decay for 60 day old memory', () => {
      const now = Date.now();
      const sixtyDaysAgo = now - (60 * 24 * 60 * 60 * 1000);
      const memory = { content: 'hello world', ts: sixtyDaysAgo };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 1.0
      // recency = 0.5^(60/30) = 0.5^2 = 0.25
      // interaction = 0
      // score = (1.0 * 0.6) + (0.25 * 0.3) + (0 * 0.1) = 0.675
      expect(score).toBeCloseTo(0.675, 5);
    });

    it('includes interaction frequency in scoring', () => {
      const now = Date.now();
      const memory = { content: 'hello world', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 1.0 });
      // token_overlap = 1.0
      // recency = 1.0
      // interaction = 1.0
      // score = (1.0 * 0.6) + (1.0 * 0.3) + (1.0 * 0.1) = 1.0
      expect(score).toBeCloseTo(1.0, 5);
    });

    it('clamps interaction frequency to [0, 1]', () => {
      const now = Date.now();
      const memory = { content: 'hello world', ts: now };
      const scoreHigh = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 5.0 });
      const scoreNeg = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: -2.0 });
      // interactionFrequency should be clamped to 1.0 and 0.0 respectively
      // high: (1.0*0.6) + (1.0*0.3) + (1.0*0.1) = 1.0
      expect(scoreHigh).toBeCloseTo(1.0, 5);
      // neg: (1.0*0.6) + (1.0*0.3) + (0*0.1) = 0.9
      expect(scoreNeg).toBeCloseTo(0.9, 5);
    });

    it('handles missing userStats gracefully', () => {
      const now = Date.now();
      const memory = { content: 'hello world', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, null);
      // interaction = 0 (default)
      // score = (1.0 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.9
      expect(score).toBeCloseTo(0.9, 5);
    });

    it('handles missing userStats.interactionFrequency', () => {
      const now = Date.now();
      const memory = { content: 'hello world', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, {});
      expect(score).toBeCloseTo(0.9, 5);
    });

    it('handles memory with ISO timestamp string', () => {
      const memory = { content: 'hello world', timestamp: '2025-01-15T12:00:00.000Z' };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // timestamp is current time (0 days ago)
      // score = (1.0 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.9
      expect(score).toBeCloseTo(0.9, 5);
    });

    it('handles memory with missing timestamp (recency = 0)', () => {
      const memory = { content: 'hello world' };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // No timestamp → recencyFactor = 0
      // score = (1.0 * 0.6) + (0 * 0.3) + (0 * 0.1) = 0.6
      expect(score).toBeCloseTo(0.6, 5);
    });

    it('handles empty memory content', () => {
      const now = Date.now();
      const memory = { content: '', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 0/2 = 0
      // recency = 1.0
      // score = (0 * 0.6) + (1.0 * 0.3) + (0 * 0.1) = 0.3
      expect(score).toBeCloseTo(0.3, 5);
    });

    it('handles null memory content', () => {
      const now = Date.now();
      const memory = { content: null, ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 0 (empty set from null content)
      // recency = 1.0
      // score = 0.3
      expect(score).toBeCloseTo(0.3, 5);
    });

    it('is case-insensitive for token matching', () => {
      const now = Date.now();
      const memory = { content: 'Hello WORLD Foo', ts: now };
      const score = cw.calculateRelevanceScore('hello world', memory, { interactionFrequency: 0 });
      // token_overlap = 2/2 = 1.0 (case insensitive)
      // score = (1.0 * 0.6) + (1.0 * 0.3) = 0.9
      expect(score).toBeCloseTo(0.9, 5);
    });

    it('score is always between 0 and 1 inclusive', () => {
      const now = Date.now();
      const memory = { content: 'x', ts: now };
      const score = cw.calculateRelevanceScore('x', memory, { interactionFrequency: 1.0 });
      expect(score).toBeGreaterThanOrEqual(0);
      expect(score).toBeLessThanOrEqual(1);
    });

    it('uses ts field over timestamp when both present', () => {
      const now = Date.now();
      const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);
      const memory = { content: 'hello', ts: now, timestamp: thirtyDaysAgo };
      const score = cw.calculateRelevanceScore('hello', memory, { interactionFrequency: 0 });
      // Should use ts (now) → recency = 1.0
      // score = (1.0 * 0.6) + (1.0 * 0.3) = 0.9
      expect(score).toBeCloseTo(0.9, 5);
    });
  });

  describe('buildContext', () => {
    let mockMemory;
    let contextWindow;

    beforeEach(() => {
      vi.useFakeTimers();
      vi.setSystemTime(new Date('2025-01-15T12:00:00.000Z'));

      mockMemory = {
        getRecentHistory: vi.fn().mockReturnValue([]),
        recallMemory: vi.fn().mockResolvedValue([]),
        getPreferences: vi.fn().mockReturnValue([])
      };
      contextWindow = new ContextWindow(mockMemory);
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it('returns empty context when no data available', async () => {
      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result).toEqual({
        recentHistory: '',
        longTermMemories: '',
        userPreferences: '',
        totalTokens: 0
      });
    });

    it('includes recent history when session is active (within 30 minutes)', async () => {
      const now = new Date('2025-01-15T12:00:00.000Z');
      const fiveMinAgo = new Date(now.getTime() - 5 * 60 * 1000).toISOString();
      const twoMinAgo = new Date(now.getTime() - 2 * 60 * 1000).toISOString();

      mockMemory.getRecentHistory.mockReturnValue([
        { role: 'user', content: 'hi there', timestamp: fiveMinAgo },
        { role: 'assistant', content: 'hello!', timestamp: twoMinAgo }
      ]);

      const result = await contextWindow.buildContext('user1', 'how are you', 'session1');
      expect(result.recentHistory).toBe('user: hi there\nassistant: hello!');
      expect(result.totalTokens).toBeGreaterThan(0);
    });

    it('excludes recent history when session is expired (> 30 minutes)', async () => {
      const now = new Date('2025-01-15T12:00:00.000Z');
      const fortyMinAgo = new Date(now.getTime() - 40 * 60 * 1000).toISOString();

      mockMemory.getRecentHistory.mockReturnValue([
        { role: 'user', content: 'old message', timestamp: fortyMinAgo }
      ]);

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.recentHistory).toBe('');
    });

    it('retrieves max 10 recent messages', async () => {
      await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(mockMemory.getRecentHistory).toHaveBeenCalledWith('user1', 10);
    });

    it('includes long-term memories with score > 0.1', async () => {
      const now = Date.now();
      mockMemory.recallMemory.mockResolvedValue([
        { content: 'hello world fact', ts: now / 1000, score: 0.5 },
        { content: 'relevant memory here', ts: now / 1000, score: 0.3 }
      ]);

      const result = await contextWindow.buildContext('user1', 'hello world', 'session1');
      expect(result.longTermMemories).toContain('hello world fact');
    });

    it('filters out memories with relevance score <= 0.1', async () => {
      const veryOld = Date.now() / 1000 - (365 * 86400); // 1 year ago
      mockMemory.recallMemory.mockResolvedValue([
        { content: 'completely unrelated xyz abc', ts: veryOld, score: 0.01 }
      ]);

      const result = await contextWindow.buildContext('user1', 'hello world', 'session1');
      // calculateRelevanceScore for unrelated content with very old ts should be very low
      expect(result.longTermMemories).toBe('');
    });

    it('limits long-term memories to maxMemories (5)', async () => {
      const now = Date.now();
      const memories = Array.from({ length: 10 }, (_, i) => ({
        content: `memory ${i} hello world`,
        ts: now / 1000,
        score: 0.5
      }));
      mockMemory.recallMemory.mockResolvedValue(memories);

      const result = await contextWindow.buildContext('user1', 'hello world', 'session1');
      const memoryLines = result.longTermMemories.split('\n').filter(l => l.length > 0);
      expect(memoryLines.length).toBeLessThanOrEqual(5);
    });

    it('includes user preferences', async () => {
      mockMemory.getPreferences.mockReturnValue([
        { key: 'language', value: 'indonesian' },
        { key: 'format', value: 'markdown' }
      ]);

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.userPreferences).toContain('language: indonesian');
      expect(result.userPreferences).toContain('format: markdown');
    });

    it('truncates preferences when exceeding 500 token budget', async () => {
      // Generate preferences that exceed 500 tokens
      const longPrefs = Array.from({ length: 100 }, (_, i) => ({
        key: `pref_key_${i}`,
        value: `this is a fairly long preference value number ${i} with extra words`
      }));
      mockMemory.getPreferences.mockReturnValue(longPrefs);

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      const prefTokens = contextWindow.estimateTokens(result.userPreferences);
      expect(prefTokens).toBeLessThanOrEqual(500);
    });

    it('gracefully degrades when DB throws error on recallMemory', async () => {
      const now = new Date('2025-01-15T12:00:00.000Z');
      const twoMinAgo = new Date(now.getTime() - 2 * 60 * 1000).toISOString();

      mockMemory.getRecentHistory.mockReturnValue([
        { role: 'user', content: 'hello', timestamp: twoMinAgo }
      ]);
      mockMemory.recallMemory.mockRejectedValue(new Error('DB connection failed'));

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      // Should still have recent history (set before error)
      expect(result.recentHistory).toBe('user: hello');
      // Long-term and preferences should be empty
      expect(result.longTermMemories).toBe('');
      expect(result.userPreferences).toBe('');
    });

    it('gracefully degrades when getRecentHistory throws', async () => {
      mockMemory.getRecentHistory.mockImplementation(() => {
        throw new Error('DB locked');
      });

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.recentHistory).toBe('');
      expect(result.longTermMemories).toBe('');
      expect(result.userPreferences).toBe('');
      expect(result.totalTokens).toBe(0);
    });

    it('gracefully degrades when getPreferences throws', async () => {
      const now = new Date('2025-01-15T12:00:00.000Z');
      const twoMinAgo = new Date(now.getTime() - 2 * 60 * 1000).toISOString();

      mockMemory.getRecentHistory.mockReturnValue([
        { role: 'user', content: 'hi', timestamp: twoMinAgo }
      ]);
      mockMemory.recallMemory.mockResolvedValue([]);
      mockMemory.getPreferences.mockImplementation(() => {
        throw new Error('Preferences table corrupted');
      });

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      // recentHistory was set before error, should still be present
      expect(result.recentHistory).toBe('user: hi');
      expect(result.longTermMemories).toBe('');
      expect(result.userPreferences).toBe('');
    });

    it('calculates totalTokens correctly across all sections', async () => {
      const now = new Date('2025-01-15T12:00:00.000Z');
      const twoMinAgo = new Date(now.getTime() - 2 * 60 * 1000).toISOString();

      mockMemory.getRecentHistory.mockReturnValue([
        { role: 'user', content: 'one two', timestamp: twoMinAgo }
      ]);
      mockMemory.recallMemory.mockResolvedValue([
        { content: 'three four five one two', ts: Date.now() / 1000 }
      ]);
      mockMemory.getPreferences.mockReturnValue([
        { key: 'lang', value: 'id' }
      ]);

      const result = await contextWindow.buildContext('user1', 'one two', 'session1');
      
      const expectedTokens = contextWindow.estimateTokens(result.recentHistory) +
                             contextWindow.estimateTokens(result.longTermMemories) +
                             contextWindow.estimateTokens(result.userPreferences);
      expect(result.totalTokens).toBe(expectedTokens);
    });

    it('respects long-term token budget of 2000', async () => {
      // Create memories with large content
      const now = Date.now();
      const bigMemories = Array.from({ length: 5 }, (_, i) => ({
        content: Array(500).fill(`word${i}`).join(' ') + ' hello', // ~501 tokens each
        ts: now / 1000
      }));
      mockMemory.recallMemory.mockResolvedValue(bigMemories);

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      const longTermTokens = contextWindow.estimateTokens(result.longTermMemories);
      expect(longTermTokens).toBeLessThanOrEqual(2000);
    });

    it('handles empty preferences array', async () => {
      mockMemory.getPreferences.mockReturnValue([]);
      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.userPreferences).toBe('');
    });

    it('handles null preferences', async () => {
      mockMemory.getPreferences.mockReturnValue(null);
      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.userPreferences).toBe('');
    });

    it('calls recallMemory with maxMemories * 2 as limit', async () => {
      await contextWindow.buildContext('user1', 'hello world', 'session1');
      expect(mockMemory.recallMemory).toHaveBeenCalledWith('hello world', 10); // 5 * 2
    });

    it('supports preference_key/preference_value field names', async () => {
      mockMemory.getPreferences.mockReturnValue([
        { preference_key: 'theme', preference_value: 'dark' }
      ]);

      const result = await contextWindow.buildContext('user1', 'hello', 'session1');
      expect(result.userPreferences).toContain('theme: dark');
    });
  });
});
