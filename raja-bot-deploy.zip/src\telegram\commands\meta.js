// src/telegram/commands/meta.js — /audit, /debug, /improve
import { logger } from '../../utils/logger.js';
import { callCascade } from '../../llm/cascade.js';
import { getRecent, rememberFact } from '../../core/memory.js';
import { verifyIntegrity } from '../../core/skill-integrity.js';
import { runManualReflection } from '../../core/reflection.js';
import { getSession } from '../../core/brain.js';
import { config } from '../../config.js';
import fs from 'fs';

// ─── AUDIT ───────────────────────────────────────────────────────────────────

export async function cmdAudit(bot, msg) {
  try {
    await bot.sendChatAction(msg.chat.id, 'typing');
    await bot.sendMessage(msg.chat.id, '🔍 Memulai self-audit...');

    const results = [];

    // 1. Skill integrity check
    const integrity = await verifyIntegrity();
    if (integrity.unverified) {
      results.push('⚠️ Integrity: SKILLS.lock tidak ada (unverified mode)');
    } else if (integrity.tampered) {
      results.push(`❌ Integrity: ${integrity.modified.length} modified, ${integrity.missing.length} missing, ${integrity.added.length} added`);
    } else {
      results.push('✅ Integrity: semua skill verified');
    }

    // 2. Governor check
    const killswitchExists = config.governor.killswitch && fs.existsSync(config.governor.killswitch);
    results.push(killswitchExists ? '🛑 Governor: KILL-SWITCH AKTIF' : '✅ Governor: normal');

    // 3. Memory check
    const recent = await getRecent(5);
    results.push(`✅ Memory: ${recent.length} entries recent`);

    // 4. LLM providers check
    const providers = [];
    if (config.llm.ollamaCloud.apiKey) providers.push('ollama-cloud');
    if (config.llm.openrouter.apiKey) providers.push('openrouter');
    if (config.llm.bai.apiKey) providers.push('b.ai');
    providers.push('ollama-local'); // always
    results.push(`✅ LLM: ${providers.length} provider tersedia`);

    // 5. Session check
    const session = getSession();
    const uptime = Math.floor((Date.now() - session.startTime) / 1000 / 60);
    results.push(`✅ Session: ${uptime} menit uptime, ${session.history.length / 2} turns`);

    const summary = results.join('\n');
    await bot.sendMessage(msg.chat.id, `*Hasil Self-Audit*\n\n${summary}`, { parse_mode: 'Markdown' });
  } catch (err) {
    logger.error(`[audit] ${err.message}`);
    await bot.sendMessage(msg.chat.id, `Audit error: ${err.message}`);
  }
}

// ─── DEBUG ───────────────────────────────────────────────────────────────────

export async function cmdDebug(bot, msg) {
  try {
    await bot.sendChatAction(msg.chat.id, 'typing');

    const session = getSession();
    const recent = await getRecent(5);

    // Get last few log lines
    let logTail = 'Log tidak tersedia';
    try {
      const logDir = config.raja.logDir;
      const today = new Date().toISOString().slice(0, 10);
      const logFile = `${logDir}/raja-${today}.log`;
      if (fs.existsSync(logFile)) {
        const content = fs.readFileSync(logFile, 'utf8');
        const lines = content.trim().split('\n');
        logTail = lines.slice(-10).join('\n');
      }
    } catch (e) {}

    const debugInfo = `*Debug Info*

Session uptime: ${Math.floor((Date.now() - session.startTime) / 1000)}s
Active skill: ${session.activeSkill || 'none'}
History turns: ${session.history.length / 2}
Recent memories: ${recent.length}

*Last 10 log lines:*
\`\`\`
${logTail.substring(0, 1000)}
\`\`\``;

    await bot.sendMessage(msg.chat.id, debugInfo, { parse_mode: 'Markdown' });
  } catch (err) {
    await bot.sendMessage(msg.chat.id, `Debug error: ${err.message}`);
  }
}

// ─── SELF-IMPROVE ─────────────────────────────────────────────────────────────

export async function cmdSelfImprove(bot, msg) {
  try {
    await bot.sendChatAction(msg.chat.id, 'typing');
    await bot.sendMessage(msg.chat.id, '🧠 Menjalankan self-improve loop...');

    const reflection = await runManualReflection('Apa yang bisa saya perbaiki dari sesi terakhir?');

    await rememberFact({
      content: `Manual self-improve: ${reflection.substring(0, 300)}`,
      kind: 'reflection',
      tags: 'manual,self-improve',
      weight: 2.0,
    });

    // Trim response for Telegram
    const trimmed = reflection.substring(0, 3000);
    await bot.sendMessage(msg.chat.id, `*Self-Improve Result*\n\n${trimmed}`, { parse_mode: 'Markdown' });
  } catch (err) {
    logger.error(`[improve] ${err.message}`);
    await bot.sendMessage(msg.chat.id, `Self-improve error: ${err.message}`);
  }
}
