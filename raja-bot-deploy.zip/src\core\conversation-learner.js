// src/core/conversation-learner.js — Conversation Learning Engine
// Learns from every conversation to improve intent accuracy and response quality.
// Self-trains by analyzing user satisfaction signals and building misunderstanding patterns.
import { rememberFact, recallMemory, getRecent } from './memory.js';
import { callCascade } from '../llm/cascade.js';
import { logger } from '../utils/logger.js';

// ─── Dissatisfaction Signal Detection ────────────────────────────────────────
// Detects when user is unhappy with bot's last response

const DISSATISFACTION_PATTERNS = [
  // Explicit correction
  /\b(bukan|salah|bkn|gak gitu|bukan gitu|gk gitu|gak bener|gk bener)\b/i,
  // Frustration
  /\b(mana hasilnya|hasilnya mana|kok gak|kenapa gak|gak ngerti|bego|goblok|tolol)\b/i,
  // Repetition (user repeats request = bot didn't get it)
  /\b(sekali lagi|ulangi|coba lagi|lakukan|eksekusi|jalankan)\b/i,
  // "I meant..." / "yang gue mau..."
  /\b(yang gue mau|yang gw mau|maksud gue|maksud gw|yang dimaksud)\b/i,
  // Short imperative after explanation (means bot explained instead of executing)
  /^(mana|mana\?|terus\?|lanjut|gas|eksekusi|jalankan)\s*\??$/i,
  // Clarification that implies misunderstanding
  /\b(bukan nanya|gak nanya|gue gak|gw gak|jangan jelasin|langsung aja)\b/i,
];

const SATISFACTION_PATTERNS = [
  // Positive feedback
  /\b(ok|oke|sip|mantap|good|nice|thanks|makasih|thx|bagus|keren|perfect|siap)\b/i,
  // Moving to new topic (implicit satisfaction)
  /\b(selanjutnya|next|lanjut ke|topik lain|btw|oh ya)\b/i,
];

/**
 * Analyze if current message indicates dissatisfaction with previous bot response.
 * @param {string} userMessage - Current user message
 * @param {Array} history - Recent conversation history
 * @returns {{ dissatisfied: boolean, signal: string, confidence: number }}
 */
export function detectDissatisfaction(userMessage, history) {
  const lower = userMessage.toLowerCase().trim();

  // Check dissatisfaction patterns
  for (const pattern of DISSATISFACTION_PATTERNS) {
    if (pattern.test(lower)) {
      return { dissatisfied: true, signal: 'explicit_correction', confidence: 0.9 };
    }
  }

  // Check if user is repeating a very similar message (bot didn't execute)
  if (history.length >= 2) {
    const lastUserMsg = history.filter(h => h.role === 'user').pop();
    if (lastUserMsg) {
      const similarity = calculateSimilarity(lower, lastUserMsg.content.toLowerCase());
      if (similarity > 0.6) {
        return { dissatisfied: true, signal: 'repeated_request', confidence: 0.8 };
      }
    }
  }

  // Very short message after bot gave long explanation = frustration
  if (lower.length < 15 && history.length >= 2) {
    const lastBotMsg = [...history].reverse().find(h => h.role === 'assistant');
    if (lastBotMsg && lastBotMsg.content.length > 500 && /^(mana|terus|lanjut|gas|eksekusi|hasilnya)/i.test(lower)) {
      return { dissatisfied: true, signal: 'wants_action_not_explanation', confidence: 0.85 };
    }
  }

  return { dissatisfied: false, signal: null, confidence: 0 };
}

/**
 * Detect satisfaction signal
 */
export function detectSatisfaction(userMessage) {
  const lower = userMessage.toLowerCase().trim();
  for (const pattern of SATISFACTION_PATTERNS) {
    if (pattern.test(lower)) {
      return { satisfied: true, confidence: 0.7 };
    }
  }
  return { satisfied: false, confidence: 0 };
}

/**
 * Simple token-based similarity (0-1)
 */
function calculateSimilarity(a, b) {
  const tokensA = new Set(a.split(/\s+/).filter(t => t.length > 2));
  const tokensB = new Set(b.split(/\s+/).filter(t => t.length > 2));
  if (tokensA.size === 0 || tokensB.size === 0) return 0;

  let overlap = 0;
  for (const t of tokensA) {
    if (tokensB.has(t)) overlap++;
  }
  return overlap / Math.max(tokensA.size, tokensB.size);
}

// ─── Lesson Learning ─────────────────────────────────────────────────────────

/**
 * When dissatisfaction is detected, analyze what went wrong and store a lesson.
 * @param {string} currentMessage - The dissatisfied follow-up
 * @param {Array} history - Recent history (includes the misunderstood exchange)
 */
export async function learnFromMistake(currentMessage, history) {
  try {
    // Get last 2 exchanges (4 messages: user-bot-user-bot or user-bot-user)
    const recentExchanges = history.slice(-6);

    const analysisMessages = [
      {
        role: 'system',
        content: `Kamu adalah analis percakapan. Analisis kenapa bot (RAJA) salah menanggapi user.

Dari percakapan di bawah, tentukan:
1. Apa yang user SEBENARNYA mau?
2. Apa yang bot SALAH lakukan?
3. Apa yang SEHARUSNYA bot lakukan?
4. Pelajaran singkat (1 kalimat) yang bisa diingat untuk next time.

JAWAB HANYA DENGAN JSON:
{
  "user_actual_intent": "apa yang user sebenarnya mau",
  "bot_mistake": "apa yang bot salah lakukan",
  "correct_action": "apa yang seharusnya dilakukan",
  "lesson": "pelajaran singkat 1 kalimat",
  "pattern": "pola input yang harus diingat (misal: 'cek X' = eksekusi bukan jelaskan)",
  "severity": "low|medium|high"
}`,
      },
      {
        role: 'user',
        content: `PERCAKAPAN:\n${recentExchanges.map(m => `[${m.role}]: ${m.content.substring(0, 300)}`).join('\n')}\n\nPESAN TERBARU (indikasi ketidakpuasan): ${currentMessage}`,
      },
    ];

    const result = await callCascade(analysisMessages, { maxTokens: 400, temperature: 0.2 });
    const jsonMatch = result.text.replace(/<think>[\s\S]*?<\/think>/gi, '').match(/\{[\s\S]*\}/);

    if (jsonMatch) {
      const lesson = JSON.parse(jsonMatch[0]);

      // Store lesson in memory
      await rememberFact({
        content: `[LESSON] Pattern: "${lesson.pattern}" | Correct: ${lesson.correct_action} | Mistake: ${lesson.bot_mistake}`,
        kind: 'lesson',
        tags: `learning,${lesson.severity},auto`,
        weight: lesson.severity === 'high' ? 3.0 : lesson.severity === 'medium' ? 2.0 : 1.5,
      });

      logger.info(`[learner] New lesson stored: "${lesson.lesson}" (${lesson.severity})`);
      return lesson;
    }
  } catch (err) {
    logger.warn(`[learner] Failed to learn from mistake: ${err.message}`);
  }
  return null;
}

/**
 * When satisfaction is detected, reinforce what went right.
 */
export async function reinforceGoodResponse(history) {
  try {
    // Get the last successful exchange
    const lastExchange = history.slice(-4);
    const userMsg = lastExchange.find(m => m.role === 'user');
    const botMsg = lastExchange.find(m => m.role === 'assistant');

    if (!userMsg || !botMsg) return;

    // Only reinforce if response was non-trivial
    if (botMsg.content.length < 30) return;

    // Store positive pattern
    await rememberFact({
      content: `[GOOD] Input: "${userMsg.content.substring(0, 80)}" → Response style worked (${botMsg.content.length > 500 ? 'detailed' : 'concise'})`,
      kind: 'pattern',
      tags: 'positive,learning',
      weight: 1.0,
    });
  } catch (err) {
    // Non-critical
  }
}

// ─── Lesson Recall (for prompt injection) ────────────────────────────────────

/**
 * Recall relevant lessons for current user message.
 * These get injected into the LLM prompt as "past mistakes to avoid".
 * @param {string} userMessage
 * @returns {string} - Formatted lessons string for system prompt
 */
export async function recallLessons(userMessage, maxLessons = 5) {
  try {
    // Query memory for lessons
    const allLessons = await recallMemory(`lesson ${userMessage}`, maxLessons * 2);
    const lessons = allLessons.filter(m => m.kind === 'lesson').slice(0, maxLessons);

    if (lessons.length === 0) return '';

    const formatted = lessons.map(l => {
      // Extract pattern from content
      const patternMatch = l.content.match(/Pattern: "(.+?)"/);
      const correctMatch = l.content.match(/Correct: (.+?)(?:\||$)/);
      return `• ${patternMatch?.[1] || l.content.substring(0, 80)} → ${correctMatch?.[1] || ''}`;
    }).join('\n');

    return `═══ PELAJARAN DARI KESALAHAN SEBELUMNYA ═══\n${formatted}\n\nJANGAN ulangi kesalahan yang sama. Ikuti pola "Correct" di atas.`;
  } catch (err) {
    return '';
  }
}

// ─── Preference Detection ────────────────────────────────────────────────────

/**
 * Detect pola berulang dari history (pattern-based preference).
 * Analyzes recent messages (within 30 days) for repeated patterns
 * that appear 3+ times, indicating implicit user preferences.
 * 
 * Patterns to detect:
 * - Repeated use of same tool/format request
 * - Repeated language preference in messages
 * - Repeated structural requests (e.g., "kasih contoh", "buat summary")
 * 
 * Confidence for inferred patterns: 0.7 (assigned by calling code)
 *
 * @param {Object[]} recentMessages - Messages from last 30 days
 *   Each message: { content: string, timestamp: string|number, role: string }
 * @returns {{key: string, value: string, count: number}[]}
 *   Returns array of detected pattern preferences (count >= 3), or empty array.
 * 
 * Validates: Requirements 5.3
 */
export function detectPatternPreference(recentMessages) {
  if (!recentMessages || !Array.isArray(recentMessages) || recentMessages.length === 0) {
    return [];
  }

  const now = Date.now();
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

  // Filter to only user messages within 30 days
  const validMessages = recentMessages.filter(msg => {
    if (!msg || !msg.content || msg.role !== 'user') return false;
    const ts = typeof msg.timestamp === 'number'
      ? msg.timestamp
      : new Date(msg.timestamp).getTime();
    if (isNaN(ts)) return false;
    return (now - ts) <= thirtyDaysMs;
  });

  if (validMessages.length < 3) return [];

  const detectedPatterns = [];

  // --- Pattern 1: Repeated language/format requests ---
  // Detect when user frequently asks for a specific programming language or format
  const languagePatterns = new Map(); // language -> count
  const LANGUAGE_REGEX = /\b(python|javascript|typescript|java|go|rust|c\+\+|ruby|php|kotlin|swift|bash|sql|html|css|json|yaml|markdown|xml)\b/gi;

  for (const msg of validMessages) {
    const matches = msg.content.match(LANGUAGE_REGEX);
    if (matches) {
      for (const match of matches) {
        const lang = match.toLowerCase();
        languagePatterns.set(lang, (languagePatterns.get(lang) || 0) + 1);
      }
    }
  }

  for (const [lang, count] of languagePatterns) {
    if (count >= 3) {
      detectedPatterns.push({
        key: 'preferred_language',
        value: lang,
        count
      });
    }
  }

  // --- Pattern 2: Repeated format requests ---
  // e.g., "kasih dalam bentuk tabel", "format json", "pakai bullet points"
  const formatPatterns = new Map();
  const FORMAT_PHRASES = [
    { regex: /\b(format|bentuk|kasih dalam)\s+(json|tabel|table|list|bullet|code|markdown|csv|xml|yaml)\b/gi, extract: 2 },
    { regex: /\b(singkat|brief|pendek|ringkas)\b/gi, value: 'concise' },
    { regex: /\b(detail|lengkap|panjang|elaborasi|jelaskan lengkap)\b/gi, value: 'detailed' },
    { regex: /\b(step.?by.?step|langkah.?demi.?langkah)\b/gi, value: 'step-by-step' },
    { regex: /\b(contoh|example|kasih contoh)\b/gi, value: 'with_examples' },
  ];

  for (const msg of validMessages) {
    for (const pattern of FORMAT_PHRASES) {
      const matches = msg.content.matchAll(pattern.regex);
      for (const match of matches) {
        const value = pattern.value || (match[pattern.extract] || '').toLowerCase();
        if (value) {
          formatPatterns.set(value, (formatPatterns.get(value) || 0) + 1);
        }
      }
    }
  }

  for (const [format, count] of formatPatterns) {
    if (count >= 3) {
      detectedPatterns.push({
        key: 'response_format',
        value: format,
        count
      });
    }
  }

  // --- Pattern 3: Repeated tool/skill usage ---
  // Detect when user keeps invoking similar tools/skills
  const toolPatterns = new Map();
  const TOOL_REGEX = /\b(swap|bridge|deploy|monitor|scan|snipe|stake|transfer|send|check|cek|analyze|backtest|alert)\b/gi;

  for (const msg of validMessages) {
    const matches = msg.content.match(TOOL_REGEX);
    if (matches) {
      for (const match of matches) {
        const tool = match.toLowerCase();
        toolPatterns.set(tool, (toolPatterns.get(tool) || 0) + 1);
      }
    }
  }

  for (const [tool, count] of toolPatterns) {
    if (count >= 3) {
      detectedPatterns.push({
        key: 'frequent_action',
        value: tool,
        count
      });
    }
  }

  // --- Pattern 4: Repeated phrases/n-grams (general pattern detection) ---
  // Look for bigrams (2-word phrases) that appear 3+ times
  const phraseCounts = new Map();

  for (const msg of validMessages) {
    const words = msg.content.toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(w => w.length > 2);

    // Generate bigrams
    for (let i = 0; i < words.length - 1; i++) {
      const bigram = `${words[i]} ${words[i + 1]}`;
      // Skip very common bigrams (stopwords)
      if (isStopwordBigram(bigram)) continue;
      phraseCounts.set(bigram, (phraseCounts.get(bigram) || 0) + 1);
    }
  }

  for (const [phrase, count] of phraseCounts) {
    if (count >= 3) {
      // Only include if not already captured by more specific patterns
      const alreadyCaptured = detectedPatterns.some(p =>
        p.value.includes(phrase) || phrase.includes(p.value)
      );
      if (!alreadyCaptured) {
        detectedPatterns.push({
          key: 'repeated_phrase',
          value: phrase,
          count
        });
      }
    }
  }

  if (detectedPatterns.length === 0) return [];

  // Sort by count descending, return top patterns
  detectedPatterns.sort((a, b) => b.count - a.count);
  return detectedPatterns;
}

/**
 * Check if a bigram is a common stopword combination that should be ignored
 */
function isStopwordBigram(bigram) {
  const STOPWORD_BIGRAMS = new Set([
    'yang ini', 'apa itu', 'ini adalah', 'yang ada',
    'aku mau', 'gue mau', 'bisa gak', 'bisa nggak',
    'tolong dong', 'coba deh', 'gimana cara',
    'the the', 'and the', 'for the', 'that the',
    'this is', 'it is', 'can you', 'how to',
    'what is', 'there is', 'will be', 'has been',
  ]);
  return STOPWORD_BIGRAMS.has(bigram);
}

// ─── Explicit Preference Detection (Task 2.3) ────────────────────────────────

/**
 * Kata kunci yang menandakan preferensi eksplisit.
 * Digunakan oleh detectExplicitPreference() untuk mendeteksi
 * pernyataan preferensi user dari pesan.
 * 
 * Validates: Requirements 5.2
 */
export const PREFERENCE_KEYWORDS = [
  'aku lebih suka', 'aku mau pakai', 'jangan pakai',
  'selalu kasih', 'ganti ke', 'pakai format',
  'i prefer', 'always use', 'never use', 'switch to'
];

/**
 * Detect preferensi eksplisit dari pesan (Task 2.3)
 * Detects explicit preference statements from user messages.
 * 
 * Logic:
 * 1. Check if message contains any PREFERENCE_KEYWORDS
 * 2. If found, extract the key (category based on keyword) and value (text after keyword)
 * 3. Return {key, value} or null
 * 
 * The calling code is responsible for saving with confidence 1.0.
 * This function is pure — no DB access, just detection.
 * 
 * @param {string} message - User message
 * @returns {{key: string, value: string}|null}
 * 
 * Validates: Requirements 5.2
 */
export function detectExplicitPreference(message) {
  if (!message || typeof message !== 'string') return null;

  const lowerMessage = message.toLowerCase().trim();
  if (lowerMessage.length === 0) return null;

  for (const keyword of PREFERENCE_KEYWORDS) {
    const idx = lowerMessage.indexOf(keyword);
    if (idx !== -1) {
      // Extract value: text after the keyword
      const valueStart = idx + keyword.length;
      const rawValue = message.substring(valueStart).trim();

      // Clean up: remove trailing punctuation, limit length
      const value = rawValue.replace(/[.!?,;]+$/, '').trim();

      if (value.length === 0) continue; // Skip if no value extracted

      // Determine preference key from keyword category
      // Use exact keyword matching for precise categorization
      let key;
      if (keyword === 'jangan pakai' || keyword === 'never use') {
        key = 'avoidance';
      } else if (keyword === 'aku lebih suka' || keyword === 'i prefer') {
        key = 'preference';
      } else if (keyword === 'aku mau pakai' || keyword === 'pakai format' || keyword === 'always use') {
        key = 'tool_preference';
      } else if (keyword === 'selalu kasih') {
        key = 'always_do';
      } else if (keyword === 'ganti ke' || keyword === 'switch to') {
        key = 'switch_to';
      } else {
        key = 'general';
      }

      return { key, value };
    }
  }

  return null;
}

// ─── User Preference Learning ────────────────────────────────────────────────

/**
 * Over time, build a profile of user preferences:
 * - Response length preference (concise vs detailed)
 * - Action preference (execute-first vs explain-first)
 * - Language style (formal vs casual)
 */
export async function analyzeUserPreferences() {
  try {
    const recentLessons = await getRecent(50, 'lesson');
    const recentPatterns = await getRecent(50, 'pattern');

    if (recentLessons.length < 3 && recentPatterns.length < 3) return null;

    // Count preference signals
    let wantsAction = 0;
    let wantsExplanation = 0;
    let wantsConcise = 0;
    let wantsDetailed = 0;

    for (const l of recentLessons) {
      if (/eksekusi|langsung|action|execute/i.test(l.content)) wantsAction++;
      if (/jelaskan|explain|detail/i.test(l.content)) wantsExplanation++;
    }

    for (const p of recentPatterns) {
      if (/concise|singkat|short/i.test(p.content)) wantsConcise++;
      if (/detailed|panjang|lengkap/i.test(p.content)) wantsDetailed++;
    }

    return {
      actionFirst: wantsAction > wantsExplanation,
      preferConcise: wantsConcise > wantsDetailed,
      totalLessons: recentLessons.length,
      totalPatterns: recentPatterns.length,
    };
  } catch {
    return null;
  }
}

// ─── Weekly Reflection Enhancement ───────────────────────────────────────────

/**
 * Enhanced weekly reflection that analyzes ALL lessons and generates
 * system prompt improvements. Called by the weekly cron or manually.
 */
export async function weeklyLearningReview() {
  try {
    const allLessons = await getRecent(100, 'lesson');

    if (allLessons.length < 5) {
      logger.info('[learner] Not enough lessons for weekly review. Skipping.');
      return null;
    }

    const lessonDump = allLessons.map(l => l.content).join('\n');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah meta-analis untuk AI agent bernama RAJA.
Analisis semua LESSON di bawah dan hasilkan:
1. Top 5 pola kesalahan yang paling sering (pattern)
2. Top 3 aturan baru yang harus ditambah ke system prompt
3. Confidence score (0-1): seberapa yakin kamu dengan rekomendasi ini

JAWAB HANYA DENGAN JSON:
{
  "top_patterns": ["pattern1", "pattern2", ...],
  "new_rules": [
    {"rule": "aturan baru singkat", "reason": "kenapa"},
    ...
  ],
  "confidence": 0.8,
  "summary": "ringkasan 1 kalimat"
}`,
      },
      {
        role: 'user',
        content: `SEMUA LESSONS (${allLessons.length} total):\n\n${lessonDump}`,
      },
    ];

    const result = await callCascade(messages, { maxTokens: 800, temperature: 0.3 });
    const jsonMatch = result.text.replace(/<think>[\s\S]*?<\/think>/gi, '').match(/\{[\s\S]*\}/);

    if (jsonMatch) {
      const review = JSON.parse(jsonMatch[0]);

      // Store weekly review
      await rememberFact({
        content: `[WEEKLY_REVIEW] Rules: ${review.new_rules?.map(r => r.rule).join(' | ')} | Confidence: ${review.confidence}`,
        kind: 'meta_learning',
        tags: 'weekly,rules,auto',
        weight: 3.0,
      });

      logger.info(`[learner] Weekly review: ${review.new_rules?.length || 0} new rules, confidence ${review.confidence}`);
      return review;
    }
  } catch (err) {
    logger.error(`[learner] Weekly review failed: ${err.message}`);
  }
  return null;
}
