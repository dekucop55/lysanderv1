// src/hermes/governor.js — Spend governor (circuit breaker)
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

let db;

export function initGovernor() {
  const dbPath = config.raja.dataDir + '/governor.db';
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  
  db = new Database(dbPath);
  db.exec(`
    CREATE TABLE IF NOT EXISTS spend (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts REAL NOT NULL,
      session_id TEXT,
      wallet TEXT,
      chain_id INTEGER,
      action TEXT,
      usd_value REAL,
      tx_hash TEXT
    );
  `);
}

export function isHalted() {
  if (config.governor.killswitch && fs.existsSync(config.governor.killswitch)) {
    return 'kill-switch file exists';
  }
  return null;
}

export function trip(reason) {
  if (config.governor.killswitch) {
    fs.writeFileSync(config.governor.killswitch, reason);
  }
  logger.warn(`Governor TRIPPED: ${reason}`);
}

export function resetKillSwitch() {
  if (config.governor.killswitch && fs.existsSync(config.governor.killswitch)) {
    fs.unlinkSync(config.governor.killswitch);
  }
}

export function authorize({ wallet, chainId, action, usdValue, slippage, gasPrice, simulated }) {
  if (isHalted()) {
    return { allowed: false, verdict: 'halt', reason: isHalted() };
  }
  
  if (config.governor.maxSlippagePct && slippage > config.governor.maxSlippagePct) {
    return { allowed: false, verdict: 'block', reason: `Slippage ${slippage}% > cap ${config.governor.maxSlippagePct}%` };
  }
  
  if (simulated !== true) {
    return { allowed: false, verdict: 'block', reason: 'Simulation required first' };
  }
  
  if (usdValue && config.governor.maxTxUsd && usdValue > config.governor.maxTxUsd) {
    return { allowed: false, verdict: 'block', reason: `Tx value $${usdValue} > cap $${config.governor.maxTxUsd}` };
  }
  
  if (usdValue && config.governor.dailyCapUsd) {
    const spent24h = getSpent24h(wallet);
    if (spent24h + usdValue > config.governor.dailyCapUsd) {
      return { allowed: false, verdict: 'block', reason: `Daily cap would be exceeded: $${spent24h} + $${usdValue} > $${config.governor.dailyCapUsd}` };
    }
  }
  
  return { allowed: true, verdict: 'allow' };
}

export function record({ wallet, chainId, action, usdValue, txHash, sessionId = 'default' }) {
  db.prepare(
    'INSERT INTO spend(ts, session_id, wallet, chain_id, action, usd_value, tx_hash) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(Date.now() / 1000, sessionId, wallet, chainId, action, usdValue, txHash);
}

function getSpent24h(wallet) {
  const cutoff = Date.now() / 1000 - 86400;
  const row = db.prepare(
    'SELECT COALESCE(SUM(usd_value), 0) as total FROM spend WHERE wallet = ? AND ts > ?'
  ).get(wallet, cutoff);
  return row.total || 0;
}