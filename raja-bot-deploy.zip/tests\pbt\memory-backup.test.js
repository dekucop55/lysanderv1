// tests/pbt/memory-backup.test.js
// Property-Based Test: Property 22 — Backup Rotation
// **Validates: Requirements 7.4**
//
// Property 22: *For any* state di mana jumlah file backup > 7, setelah rotasi hanya
// SHALL tersisa tepat 7 file backup, yaitu 7 yang paling baru berdasarkan timestamp
// di nama file.
//
// Format nama file: memory_{YYYYMMDD_HHmmss}.db
// Rotasi: sort descending (newest first), keep 7, delete the rest.

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';

// ─── Constants ───────────────────────────────────────────────────────────────

const MAX_BACKUPS = 7;

// ─── Pure rotation logic (mirrors rotateBackups in memory.js) ────────────────

/**
 * Simulate the rotateBackups() logic from src/core/memory.js.
 *
 * The real implementation:
 *   1. List files matching memory_*.db in backupDir
 *   2. Sort descending by filename (newest first via localeCompare)
 *   3. If count <= 7: do nothing
 *   4. If count > 7: delete slice(7) — the oldest files
 *
 * @param {string[]} backupFiles - All filenames in the backup directory
 * @returns {{ kept: string[], deleted: string[], didRotate: boolean }}
 */
function simulateRotateBackups(backupFiles) {
  // Filter to only memory_*.db files (mirrors real implementation filter)
  const validFiles = backupFiles.filter(
    f => f.startsWith('memory_') && f.endsWith('.db')
  );

  // Sort descending: newest filename first (localeCompare-based, same as real impl)
  const sorted = [...validFiles].sort((a, b) => b.localeCompare(a));

  if (sorted.length <= MAX_BACKUPS) {
    return {
      kept: sorted,
      deleted: [],
      didRotate: false,
    };
  }

  const kept = sorted.slice(0, MAX_BACKUPS);
  const deleted = sorted.slice(MAX_BACKUPS);

  return { kept, deleted, didRotate: true };
}

// ─── Generators ──────────────────────────────────────────────────────────────

/**
 * Generate a valid backup filename: memory_{YYYYMMDD_HHmmss}.db
 * Uses a unique sequential timestamp offset from a base date to guarantee uniqueness.
 *
 * @param {number} index - Sequential index used to produce a unique timestamp
 * @returns {string}
 */
function makeBackupFilename(index) {
  // Start from a base date and increment by 1 hour per index → unique timestamps
  const base = new Date('2025-01-01T00:00:00Z');
  const ts = new Date(base.getTime() + index * 3600 * 1000);

  const YYYY = ts.getUTCFullYear();
  const MM = String(ts.getUTCMonth() + 1).padStart(2, '0');
  const DD = String(ts.getUTCDate()).padStart(2, '0');
  const HH = String(ts.getUTCHours()).padStart(2, '0');
  const mm = String(ts.getUTCMinutes()).padStart(2, '0');
  const ss = String(ts.getUTCSeconds()).padStart(2, '0');

  return `memory_${YYYY}${MM}${DD}_${HH}${mm}${ss}.db`;
}

/**
 * Arbitrary: generates N unique backup filenames (indices 0..N-1).
 * When N > 7, rotateBackups should trim to 7 newest.
 */
const backupFileSetArb = (minCount, maxCount) =>
  fc.integer({ min: minCount, max: maxCount }).map(n =>
    Array.from({ length: n }, (_, i) => makeBackupFilename(i))
  );

// ─── Property Tests ──────────────────────────────────────────────────────────

describe('Property 22: Backup Rotation', () => {

  // ── Core invariant: count is capped at MAX_BACKUPS ───────────────────────

  describe('Count After Rotation', () => {
    it('**Validates: Requirements 7.4** — After rotation exactly 7 files remain when count > 7', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(8, 30),
          (files) => {
            const result = simulateRotateBackups(files);

            // Exactly 7 files remain
            expect(result.kept.length).toBe(MAX_BACKUPS);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.4** — Exactly (N - 7) files are deleted when N > 7', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(8, 30),
          (files) => {
            const validFiles = files.filter(f => f.startsWith('memory_') && f.endsWith('.db'));
            const result = simulateRotateBackups(files);

            expect(result.deleted.length).toBe(validFiles.length - MAX_BACKUPS);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── No rotation when count <= MAX_BACKUPS ────────────────────────────────

  describe('No-Op When Count ≤ 7', () => {
    it('**Validates: Requirements 7.4** — No files deleted when backup count = 7', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(7, 7),
          (files) => {
            const result = simulateRotateBackups(files);

            expect(result.deleted.length).toBe(0);
            expect(result.kept.length).toBe(7);
            expect(result.didRotate).toBe(false);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('**Validates: Requirements 7.4** — No files deleted when backup count < 7', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(0, 6),
          (files) => {
            const validFiles = files.filter(f => f.startsWith('memory_') && f.endsWith('.db'));
            const result = simulateRotateBackups(files);

            expect(result.deleted.length).toBe(0);
            expect(result.kept.length).toBe(validFiles.length);
            expect(result.didRotate).toBe(false);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.4** — Boundary: exactly at threshold (7) never triggers rotation', () => {
      // Explicit boundary check
      const files = Array.from({ length: MAX_BACKUPS }, (_, i) => makeBackupFilename(i));
      const result = simulateRotateBackups(files);

      expect(result.kept.length).toBe(MAX_BACKUPS);
      expect(result.deleted.length).toBe(0);
      expect(result.didRotate).toBe(false);
    });
  });

  // ── Newest 7 are kept ────────────────────────────────────────────────────

  describe('Newest Files Are Kept', () => {
    it('**Validates: Requirements 7.4** — Kept files are the 7 newest (highest sort order)', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(8, 30),
          (files) => {
            const validFiles = files.filter(f => f.startsWith('memory_') && f.endsWith('.db'));
            const sortedDesc = [...validFiles].sort((a, b) => b.localeCompare(a));
            const expectedKept = sortedDesc.slice(0, MAX_BACKUPS);

            const result = simulateRotateBackups(files);

            expect(result.kept).toEqual(expectedKept);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.4** — Deleted files are all older than any kept file', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(8, 30),
          (files) => {
            const result = simulateRotateBackups(files);

            // The minimum kept filename must be greater than the maximum deleted filename
            // (since files are sorted desc: smaller filename = older)
            const minKept = result.kept.reduce((min, f) => f < min ? f : min, result.kept[0]);
            const maxDeleted = result.deleted.reduce((max, f) => f > max ? f : max, result.deleted[0]);

            expect(minKept > maxDeleted).toBe(true);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.4** — No kept file is older than any deleted file', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(8, 20),
          (files) => {
            const result = simulateRotateBackups(files);

            // For every (kept, deleted) pair: kept filename > deleted filename
            for (const keptFile of result.kept) {
              for (const deletedFile of result.deleted) {
                expect(keptFile > deletedFile).toBe(true);
              }
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── File count conservation ──────────────────────────────────────────────

  describe('Conservation: kept + deleted = original valid count', () => {
    it('**Validates: Requirements 7.4** — kept + deleted always equals original file count', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(0, 30),
          (files) => {
            const validFiles = files.filter(f => f.startsWith('memory_') && f.endsWith('.db'));
            const result = simulateRotateBackups(files);

            expect(result.kept.length + result.deleted.length).toBe(validFiles.length);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Non-backup files are ignored ─────────────────────────────────────────

  describe('File Filter: only memory_*.db files are considered', () => {
    it('**Validates: Requirements 7.4** — Non-matching files are not counted toward the limit', () => {
      fc.assert(
        fc.property(
          // Generate 6 valid memory backup files + 1-10 non-matching files
          fc.integer({ min: 1, max: 10 }).map(n => {
            const validFiles = Array.from({ length: 6 }, (_, i) => makeBackupFilename(i));
            const nonMatchingFiles = [
              ...Array.from({ length: n }, (_, i) => `other_file_${i}.db`),
              ...Array.from({ length: n }, (_, i) => `memory_file_${i}.txt`),
              ...Array.from({ length: n }, (_, i) => `backup_${i}.db`),
            ];
            return [...validFiles, ...nonMatchingFiles];
          }),
          (files) => {
            const result = simulateRotateBackups(files);

            // Only 6 valid memory_*.db files → no rotation (6 < 7)
            expect(result.deleted.length).toBe(0);
            expect(result.kept.length).toBe(6);
            expect(result.didRotate).toBe(false);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.4** — Non-matching files with 8+ valid backups triggers rotation correctly', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 8, max: 20 }).chain(validCount =>
            fc.integer({ min: 1, max: 10 }).map(nonMatchCount => ({
              validCount,
              nonMatchCount,
              files: [
                ...Array.from({ length: validCount }, (_, i) => makeBackupFilename(i)),
                ...Array.from({ length: nonMatchCount }, (_, i) => `ignore_this_${i}.db`),
                ...Array.from({ length: nonMatchCount }, (_, i) => `memory_ignore_${i}.txt`),
              ]
            }))
          ),
          ({ validCount, files }) => {
            const result = simulateRotateBackups(files);

            // Should keep exactly 7, ignoring the non-matching files
            expect(result.kept.length).toBe(MAX_BACKUPS);
            expect(result.deleted.length).toBe(validCount - MAX_BACKUPS);

            // All kept files are valid memory_*.db
            for (const f of result.kept) {
              expect(f.startsWith('memory_')).toBe(true);
              expect(f.endsWith('.db')).toBe(true);
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Determinism ──────────────────────────────────────────────────────────

  describe('Determinism: same input always produces same output', () => {
    it('**Validates: Requirements 7.4** — Rotation is deterministic for any file set', () => {
      fc.assert(
        fc.property(
          backupFileSetArb(0, 30),
          (files) => {
            const result1 = simulateRotateBackups(files);
            const result2 = simulateRotateBackups(files);

            expect(result1.kept).toEqual(result2.kept);
            expect(result1.deleted).toEqual(result2.deleted);
            expect(result1.didRotate).toBe(result2.didRotate);
          }
        ),
        { numRuns: 200 }
      );
    });
  });
});
