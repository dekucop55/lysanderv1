// src/skills/H3.js — Hermes: DeFi (Aave, Lido, GMX, Hyperliquid, Pendle) with intent detection
import { aaveSupply, lidoStake, getDefiSummary } from '../hermes/defi.js';
import { logger } from '../utils/logger.js';

// ─── Chain aliases ───────────────────────────────────────────────────────────
const CHAIN_ALIASES = {
  eth: 'ethereum', ethereum: 'ethereum', arb: 'arbitrum', arbitrum: 'arbitrum',
  op: 'optimism', optimism: 'optimism', poly: 'polygon', polygon: 'polygon',
  base: 'base', avax: 'avalanche', avalanche: 'avalanche',
};

/**
 * Detect actionable DeFi intent from natural language query.
 * Returns { intent, params } or null for general questions.
 */
function detectDefiIntent(query) {
  const q = query.trim();

  // Pattern: "stake <amount> ETH [wallet <label>]" (Lido)
  const stakeMatch = q.match(
    /(?:stake|staking)\s+([\d.,]+)\s+(?:eth|ether)(?:\s+(?:wallet|from|via)\s+(\S+))?/i
  );
  if (stakeMatch) {
    const amountEth = parseFloat(stakeMatch[1].replace(',', '.'));
    const wallet = stakeMatch[2] || null;
    return { intent: 'LIDO_STAKE', params: { amountEth, wallet } };
  }

  // Pattern: "supply/deposit <amount> <token> [to aave] [on <chain>] [wallet <label>]"
  const supplyMatch = q.match(
    /(?:supply|deposit|setor)\s+([\d.,]+)\s+(\S+)(?:\s+(?:to|ke)\s+(?:aave))?(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (supplyMatch) {
    const amount = parseFloat(supplyMatch[1].replace(',', '.'));
    const asset = supplyMatch[2].toUpperCase();
    const chain = resolveChain(supplyMatch[3]) || 'ethereum';
    const wallet = supplyMatch[4] || null;
    return { intent: 'AAVE_SUPPLY', params: { amount, asset, chain, wallet } };
  }

  // Pattern: "unstake" / "withdraw" / "tarik" (informational — directs to proper flow)
  const unstakeMatch = q.match(
    /(?:unstake|withdraw|tarik|redeem)\s+([\d.,]+)?\s*(\S+)?(?:\s+(?:from|dari)\s+(\S+))?(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:wallet)\s+(\S+))?/i
  );
  if (unstakeMatch) {
    const amount = unstakeMatch[1] ? parseFloat(unstakeMatch[1].replace(',', '.')) : null;
    const asset = unstakeMatch[2]?.toUpperCase() || null;
    const protocol = unstakeMatch[3] || null;
    const chain = resolveChain(unstakeMatch[4]) || 'ethereum';
    const wallet = unstakeMatch[5] || null;
    return { intent: 'WITHDRAW', params: { amount, asset, protocol, chain, wallet } };
  }

  // Pattern: "defi summary [wallet <label>]" / "cek posisi defi"
  const summaryMatch = q.match(
    /(?:defi\s+summary|cek\s+(?:posisi|position)\s*(?:defi)?|my\s+defi|portfolio\s+defi)(?:\s+(?:wallet)\s+(\S+))?/i
  );
  if (summaryMatch) {
    const wallet = summaryMatch[1] || null;
    return { intent: 'SUMMARY', params: { wallet } };
  }

  return null;
}

function resolveChain(raw) {
  if (!raw) return null;
  return CHAIN_ALIASES[raw.toLowerCase()] || null;
}

export default {
  id: 'H3',
  name: 'defi',
  description: 'DeFi operations: Aave lending, Lido staking, GMX perps, Hyperliquid, Pendle yield',

  async execute(query, context) {
    // 1. Detect actionable DeFi command
    const intent = detectDefiIntent(query);

    if (intent) {
      logger.info(`[H3] DeFi intent detected: ${intent.intent}`, intent.params);

      try {
        switch (intent.intent) {
          case 'LIDO_STAKE': {
            const { amountEth, wallet } = intent.params;

            if (!amountEth || isNaN(amountEth) || amountEth <= 0) {
              return '❌ Amount tidak valid. Contoh: `stake 1 ETH wallet main`';
            }
            if (!wallet) {
              return '⚠️ Wallet belum di-specify. Format: `stake <amount> ETH wallet <label>`';
            }

            const result = await lidoStake({ walletLabel: wallet, amountEth });
            if (!result.success) {
              return `❌ Lido stake gagal: ${result.reason}`;
            }

            return [
              `✅ **Staked ${amountEth} ETH via Lido**`,
              ``,
              `Tx: \`${result.txHash}\``,
              `Received: stETH (auto-rebase, ~3-4% APY)`,
              `Chain: Ethereum`,
              `Wallet: ${wallet}`,
              ``,
              `stETH akan muncul di wallet setelah tx confirmed.`,
            ].join('\n');
          }

          case 'AAVE_SUPPLY': {
            const { amount, asset, chain, wallet } = intent.params;

            if (!amount || isNaN(amount) || amount <= 0) {
              return '❌ Amount tidak valid. Contoh: `supply 1000 USDC to aave on arbitrum wallet main`';
            }
            if (!wallet) {
              return '⚠️ Wallet belum di-specify. Format: `supply <amount> <token> to aave on <chain> wallet <label>`';
            }

            // Note: aaveSupply expects asset as contract address. For now provide symbol guidance.
            return [
              `📋 **Aave Supply Request**`,
              ``,
              `Asset: ${amount} ${asset}`,
              `Chain: ${chain}`,
              `Wallet: ${wallet}`,
              `Protocol: Aave v3`,
              ``,
              `🔐 Untuk eksekusi: \`/deficonfirm\``,
              `⚠️ Pastikan token sudah di-approve untuk Aave Pool contract.`,
              `Approve otomatis akan dilakukan saat konfirmasi.`,
            ].join('\n');
          }

          case 'WITHDRAW': {
            const { amount, asset, protocol, chain, wallet } = intent.params;
            return [
              `📋 **Withdraw/Unstake Request**`,
              ``,
              amount ? `Amount: ${amount} ${asset || ''}` : 'Amount: belum di-specify',
              protocol ? `Protocol: ${protocol}` : 'Protocol: belum di-specify',
              `Chain: ${chain}`,
              wallet ? `Wallet: ${wallet}` : 'Wallet: belum di-specify',
              ``,
              `🔐 Untuk eksekusi withdraw, gunakan \`/deficonfirm\``,
              `⚠️ Note: Lido unstake memerlukan ~1-5 hari (withdrawal queue).`,
              `Aave withdraw instant selama ada liquidity.`,
            ].join('\n');
          }

          case 'SUMMARY': {
            const { wallet } = intent.params;
            if (!wallet) {
              return '⚠️ Specify wallet: `defi summary wallet <label>`';
            }

            const summary = await getDefiSummary(wallet);
            return [
              `📊 **DeFi Positions: ${wallet}**`,
              ``,
              summary?.positions?.length
                ? summary.positions.map(p => `• ${p.protocol}: ${p.balance} ${p.token} (${p.type})`).join('\n')
                : 'Tidak ada posisi DeFi aktif.',
              ``,
              summary?.totalValueUsd ? `Total value: ~$${summary.totalValueUsd}` : '',
            ].filter(Boolean).join('\n');
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[H3] DeFi operation failed: ${err.message}`);
        return `❌ DeFi operation gagal: ${err.message}`;
      }
    }

    // 2. Fallback: general DeFi question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H3 (DeFi).
Mode: methodical, risk-aware.

Kamu menjawab pertanyaan tentang DeFi:
- Aave v3: lending, borrowing, health factor, liquidation risk
- Lido: ETH staking, stETH mechanics, withdrawal queue
- GMX v2: perpetual trading, GLP, leverage
- Hyperliquid: perp DEX, order types, funding rates
- Pendle: yield tokenization, PT vs YT, maturity dates
- General: yield farming, impermanent loss, risk assessment

Untuk EXECUTE DeFi operations, user harus pakai format:
  stake <amount> ETH wallet <label>
  supply <amount> <token> to aave on <chain> wallet <label>
  withdraw <amount> <token> from <protocol> wallet <label>

Safety:
- Governor gate aktif untuk semua tx
- Health factor monitoring (Aave)
- Liquidation threshold alerts
- APY/APR current rates`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1200, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H3] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan DeFi: ${err.message}`;
    }
  },
};
