// src/skills/x3.js — Debug: fault diagnosis, error analysis, stack trace forensics
export default {
  id: 'x3',
  name: 'debug',
  description: 'Debug and fault diagnosis: stack traces, error patterns, runtime analysis, fix generation',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: x3 (Debug).
Mode: forensic, methodical.

Protocol debug:
1. READ ERROR: Identifikasi error type, message, line number
2. TRACE: Ikuti stack trace dari bottom (most specific) ke top
3. HYPOTHESIS: 2-3 kemungkinan penyebab (paling likely dulu)
4. FIX: Code fix untuk setiap hipotesis
5. VERIFY: Cara verifikasi fix berhasil
6. PREVENT: Bagaimana mencegah error serupa

Untuk runtime errors: minta log kalau tidak ada.
Untuk async errors: cek Promise rejection handling.
Untuk on-chain errors: decode revert reason.

Output: diagnosis konkret + fix siap paste.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
    return result.text;
  },
};
