// src/skills/m16.js — Software engineering: backend, database, testing, scaffold, refactor
export default {
  id: 'm16',
  name: 'software-eng',
  description: 'Full-stack software engineering: backend, database, testing, scaffolding, refactoring, code review',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: m16 (Software Engineering).
Expert dalam:
- Backend: Node.js (Express, Fastify, Hono), Python (FastAPI, Flask), Go
- Database: PostgreSQL, MySQL, MongoDB, Redis, SQLite
- ORM: Prisma, Drizzle, TypeORM, Sequelize
- Testing: Vitest, Jest, Playwright, supertest
- API design: REST, GraphQL, tRPC
- Architecture: monolith → microservice, event-driven, CQRS
- Scaffolding: project templates, boilerplate generation
- Refactoring: code smells, DRY, SOLID, clean architecture
- CI/CD: GitHub Actions, GitLab CI
- DevOps: Docker, Kubernetes (basics), monitoring
- Performance: profiling, caching, indexing, N+1 fixes
- Code review: PR quality, security review

Output: production-grade code. Include tests kalau relevant.
Combine with m9 for full-stack, m2 for deploy.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.3 });
    return result.text;
  },
};
