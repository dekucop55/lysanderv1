// tests/unit/integration-message-cycle-e2e.test.js
//
// Task 12.4 — End-to-end integration test for processMessage via vi.mock()
// Tests the full message cycle by calling processMessage() directly with all
// external dependencies mocked at the module level.
//
// References:
//   - Test 1: pesan masuk → klasifikasi → route → respond → store (Req 1.1, 3.1)
//   - Test 2: PM2 restart → session reload via loadSessionOnRestart  (Req 3.3)
//   - Test 3: auto-push cycle with exact codeFiles/dataFiles counts   (Req 6.1, 7.2)

import { describe, it, expect, vi, beforeEach } from 'vitest';
import os from 'os';
import path from 'path';
import fs from 'fs';

// ─── Mock all external dependencies BEFORE importing processMessage ───────────
// vi.mock() calls are hoisted to the top of the module by Vitest.

vi.mock('../../src/llm/cascade.js', () => ({
  callCascade: vi.fn().mockResolvedValue({ text: 'Test LLM response', provider: 'mock' }),
  switchProvider: vi.fn(),
  resolveProviderName: vi.fn(),
  getProviderStatus: vi.fn().mockReturnValue({ providers: [], mode: 'auto' }),
}));

vi.mock('../../src/core/memory.js', () => ({
  recallMemory: vi.fn().mockResolvedValue([]),
  rememberFact: vi.fn().mockResolvedValue(1),
  saveMessage: vi.fn().mockReturnValue(1),
  savePreference: vi.fn().mockReturnValue(1),
  runPreferenceDecay: vi.fn().mockReturnValue({ decayed: 0, deleted: 0 }),
  loadSessionOnRestart: vi.fn().mockReturnValue([]),
  getRecentHistory: vi.fn().mockReturnValue([]),
  getPreferences: vi.fn().mockReturnValue([]),
  initMemory: vi.fn().mockResolvedValue(undefined),
}));

vi.mock('../../src/core/skill-registry.js', () => ({
  skills: {},
  routeSkill: vi.fn().mockReturnValue({ skill: null, score: 0, name: '', matched: [] }),
  fuzzyMatch: vi.fn().mockReturnValue(null),
  getSuggestions: vi.fn().mockReturnValue([]),
  initSkillRegistry: vi.fn().mockResolvedValue(undefined),
}));

vi.mock('../../src/core/conversation-learner.js', () => ({
  detectDissatisfaction: vi.fn().mockReturnValue({ dissatisfied: false, signal: null, confidence: 0 }),
  detectSatisfaction: vi.fn().mockReturnValue({ satisfied: false, confidence: 0 }),
  learnFromMistake: vi.fn().mockResolvedValue(null),
  reinforceGoodResponse: vi.fn().mockResolvedValue(undefined),
  recallLessons: vi.fn().mockResolvedValue(''),
  detectExplicitPreference: vi.fn().mockReturnValue(null),
  weeklyLearningReview: vi.fn().mockResolvedValue(null),
}));

vi.mock('../../src/self-upgrade/code-engine.js', () => ({
  selfModifyFromMessage: vi.fn().mockResolvedValue(undefined),
}));

vi.mock('../../src/core/skill-integrity.js', () => ({
  verifyIntegrity: vi.fn().mockResolvedValue({ tampered: false, modified: [], missing: [], added: [] }),
}));

// ─── Now import the module under test ────────────────────────────────────────

const { processMessage } = await import('../../src/core/brain.js');
const { saveMessage, loadSessionOnRestart } = await import('../../src/core/memory.js');

// ═══════════════════════════════════════════════════════════════════════════════
// Test 1: Full Message Cycle
// pesan masuk → klasifikasi → route → respond → store
// Validates: Requirements 1.1, 3.1
// ═══════════════════════════════════════════════════════════════════════════════

describe('Test 1: Full Message Cycle via processMessage() (Req 1.1, 3.1)', () => {

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('processMessage returns an object with a text property (Req 1.1)', async () => {
    const result = await processMessage('Halo bot, apa kabar?', 'user-e2e-1', {});

    expect(result).toBeDefined();
    expect(result).toHaveProperty('text');
    expect(typeof result.text).toBe('string');
    expect(result.text.length).toBeGreaterThan(0);
  });

  it('saveMessage called twice: once with role=user, once with role=assistant (Req 3.1)', async () => {
    await processMessage('Jelaskan tentang DeFi', 'user-e2e-save', {});

    // saveMessage must be called at least twice — user message + assistant response
    expect(saveMessage).toHaveBeenCalledTimes(2);

    const calls = saveMessage.mock.calls;

    // First call: incoming user message
    expect(calls[0][0]).toMatchObject({
      role: 'user',
      userId: 'user-e2e-save',
    });

    // Second call: outgoing assistant message
    expect(calls[1][0]).toMatchObject({
      role: 'assistant',
      userId: 'user-e2e-save',
    });
  });

  it('saveMessage first call stores the exact user message content (Req 3.1)', async () => {
    const userMsg = 'Apa itu blockchain teknologi?';
    await processMessage(userMsg, 'user-e2e-content', {});

    const firstCall = saveMessage.mock.calls[0][0];
    expect(firstCall.content).toBe(userMsg);
  });

  it('saveMessage second call stores the LLM response as assistant content (Req 3.1)', async () => {
    await processMessage('Coba jelaskan tentang DeFi', 'user-e2e-resp', {});

    const secondCall = saveMessage.mock.calls[1][0];
    expect(secondCall.role).toBe('assistant');
    expect(secondCall.content).toBe('Test LLM response');
  });

  it('both messages share the same sessionId (Req 3.2)', async () => {
    await processMessage('Pesan test session', 'user-e2e-sess', {});

    const calls = saveMessage.mock.calls;
    expect(calls).toHaveLength(2);

    // Both calls must use the same sessionId (derived from userId in brain.js)
    expect(calls[0][0].sessionId).toBe(calls[1][0].sessionId);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Test 2: PM2 Restart → Session Reload
// Validates: Requirement 3.3
// ═══════════════════════════════════════════════════════════════════════════════

describe('Test 2: PM2 Restart → Session Reload via loadSessionOnRestart (Req 3.3)', () => {

  it('loadSessionOnRestart returns exactly 50 messages when called (Req 3.3)', () => {
    const baseTime = new Date('2024-01-01T00:00:00.000Z').getTime();
    const mockMessages = Array.from({ length: 50 }, (_, i) => ({
      id: i + 1,
      user_id: 'user-pm2',
      role: i % 2 === 0 ? 'user' : 'assistant',
      content: `Message ${i + 1}`,
      timestamp: new Date(baseTime + (i + 1) * 1000).toISOString(),
      session_id: 'sess-pm2',
      intent_classified: 'CHAT',
    }));

    // Configure mock to return 50 messages
    loadSessionOnRestart.mockReturnValueOnce(mockMessages);

    const result = loadSessionOnRestart('user-pm2');

    expect(result).toHaveLength(50);
  });

  it('session reload messages are in ASC order (oldest first) (Req 3.3)', () => {
    const baseTime = new Date('2024-01-01T00:00:00.000Z').getTime();
    const mockMessages = Array.from({ length: 50 }, (_, i) => ({
      id: i + 1,
      user_id: 'user-pm2-order',
      role: 'user',
      content: `Message ${i + 1}`,
      timestamp: new Date(baseTime + (i + 1) * 1000).toISOString(),
      session_id: 'sess-pm2',
      intent_classified: null,
    }));

    loadSessionOnRestart.mockReturnValueOnce(mockMessages);
    const result = loadSessionOnRestart('user-pm2-order');

    expect(result.length).toBe(50);

    // Verify ascending timestamp order
    for (let i = 0; i < result.length - 1; i++) {
      expect(result[i].timestamp <= result[i + 1].timestamp).toBe(true);
    }

    // First message is oldest, last is newest
    expect(result[0].timestamp < result[result.length - 1].timestamp).toBe(true);
  });

  it('session reload completes instantly (< 2 seconds) (Req 3.3)', () => {
    const baseTime = new Date('2024-01-01T00:00:00.000Z').getTime();
    const mockMessages = Array.from({ length: 50 }, (_, i) => ({
      id: i + 1,
      user_id: 'user-pm2-perf',
      role: 'user',
      content: `Message ${i + 1}`,
      timestamp: new Date(baseTime + (i + 1) * 1000).toISOString(),
      session_id: 'sess-pm2-perf',
      intent_classified: null,
    }));

    loadSessionOnRestart.mockReturnValueOnce(mockMessages);

    const start = Date.now();
    const result = loadSessionOnRestart('user-pm2-perf');
    const elapsed = Date.now() - start;

    expect(result).toHaveLength(50);
    expect(elapsed).toBeLessThan(2000); // Req 3.3: complete within 2 seconds
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// Test 3: Auto-Push Cycle (mock git remote)
// Validates: Requirements 6.1, 7.2
// ═══════════════════════════════════════════════════════════════════════════════

describe('Test 3: Auto-Push Cycle with Backup (Req 6.1, 7.2)', () => {

  it('triggerPush: backupFn called once, rotateFn called once, status=success, codeFiles=1, dataFiles=1 (Req 6.1, 7.2)', async () => {
    // Dynamic import to avoid top-level mock conflicts
    const { AutoPushScheduler } = await import('../../src/core/auto-push.js');

    const tmpLogDir = path.join(os.tmpdir(), `raja-e2e-${Date.now()}`);
    fs.mkdirSync(tmpLogDir, { recursive: true });
    const tmpLogFile = path.join(tmpLogDir, 'auto-push.log');

    try {
      const backupFn = vi.fn();
      const rotateFn = vi.fn();

      // execFn: git status returns exactly 1 code file + 1 data file
      const execFn = vi.fn().mockImplementation((cmd) => {
        if (cmd === 'git status --porcelain') return ' M src/index.js\n M data/test.db\n';
        return ''; // git add, commit, push succeed
      });

      const scheduler = new AutoPushScheduler({
        execFn,
        backupFn,
        rotateFn,
        logFile: tmpLogFile,
        retryIntervalMs: 0,
      });

      // Mock writeLog and notifyOwner to be no-ops
      scheduler.writeLog = vi.fn();
      scheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      const result = await scheduler.triggerPush();

      // Assert backupFn called once
      expect(backupFn).toHaveBeenCalledOnce();

      // Assert rotateFn called once
      expect(rotateFn).toHaveBeenCalledOnce();

      // Assert result.status === 'success'
      expect(result.status).toBe('success');

      // Assert result.codeFiles === 1 (src/index.js)
      expect(result.codeFiles).toBe(1);

      // Assert result.dataFiles === 1 (data/test.db)
      expect(result.dataFiles).toBe(1);

    } finally {
      try { fs.rmSync(tmpLogDir, { recursive: true, force: true }); } catch (_) {}
    }
  });
});
