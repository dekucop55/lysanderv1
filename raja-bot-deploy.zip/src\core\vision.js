// src/core/vision.js — Image analysis via multimodal LLM (Gemini Vision)
// Handles: direct photo from Telegram + image URLs in text messages
import axios from 'axios';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';

/**
 * Find the vision-capable provider from LLM slots.
 * Prefers Google (Gemini) as it natively supports vision.
 * Falls back to any provider that has "gemini" or "gpt-4o" in model name.
 */
function getVisionProvider() {
  const slots = config.llm.slots || {};
  
  // Priority: google slot (gemini supports vision natively)
  for (let i = 2; i <= 9; i++) {
    const slot = slots[i];
    if (!slot?.key || !slot?.url || !slot?.model) continue;
    if (slot.name?.includes('google') || slot.model?.includes('gemini')) {
      return slot;
    }
  }
  
  // Fallback: any slot with vision-capable model
  for (let i = 2; i <= 9; i++) {
    const slot = slots[i];
    if (!slot?.key || !slot?.url || !slot?.model) continue;
    if (slot.model?.includes('gpt-4o') || slot.model?.includes('vision')) {
      return slot;
    }
  }
  
  return null;
}

/**
 * Download image from URL and convert to base64.
 * @param {string} url - Image URL
 * @returns {Promise<{base64: string, mimeType: string}>}
 */
export async function fetchImageAsBase64(url) {
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 15000,
    headers: { 'User-Agent': 'RAJA-Bot/4.1' },
  });
  
  const contentType = response.headers['content-type'] || 'image/png';
  const base64 = Buffer.from(response.data).toString('base64');
  return { base64, mimeType: contentType };
}

/**
 * Download Telegram photo file and convert to base64.
 * @param {Object} bot - Telegram bot instance
 * @param {string} fileId - Telegram file_id
 * @returns {Promise<{base64: string, mimeType: string}>}
 */
export async function fetchTelegramPhoto(bot, fileId) {
  const fileLink = await bot.getFileLink(fileId);
  return fetchImageAsBase64(fileLink);
}

/**
 * Analyze image using vision-capable LLM.
 * @param {string} base64Image - Base64 encoded image
 * @param {string} mimeType - Image MIME type
 * @param {string} userPrompt - User's text/question about the image
 * @returns {Promise<string>} Analysis result text
 */
export async function analyzeImage(base64Image, mimeType, userPrompt = 'Analisis gambar ini.') {
  const provider = getVisionProvider();
  
  if (!provider) {
    return '❌ Tidak ada provider vision yang aktif. Butuh Gemini (Google AI Studio) atau GPT-4o di .env.';
  }

  const messages = [
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: userPrompt,
        },
        {
          type: 'image_url',
          image_url: {
            url: `data:${mimeType};base64,${base64Image}`,
          },
        },
      ],
    },
  ];

  try {
    const response = await axios.post(
      provider.url,
      {
        model: provider.model,
        messages,
        max_tokens: 2000,
        temperature: 0.5,
      },
      {
        headers: {
          'Authorization': `Bearer ${provider.key}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      }
    );

    const text = response.data.choices?.[0]?.message?.content || '';
    logger.info(`[vision] Analysis complete via ${provider.name} (${text.length} chars)`);
    return text;
  } catch (err) {
    logger.error(`[vision] Analysis failed: ${err.message}`);
    return `❌ Vision analysis gagal: ${err.response?.data?.error?.message || err.message}`;
  }
}

/**
 * Extract image URL from a text message if present.
 * @param {string} text - Message text
 * @returns {string|null} First image URL found, or null
 */
export function extractImageUrl(text) {
  const urlMatch = text.match(/https?:\/\/[^\s]+\.(png|jpg|jpeg|gif|webp|bmp)/i);
  if (urlMatch) return urlMatch[0];
  
  // TradingView screenshot URLs (no extension but are images)
  const tvMatch = text.match(/https?:\/\/(?:www\.)?tradingview\.com\/x\/[^\s]+/i);
  if (tvMatch) return tvMatch[0];
  
  // Generic image hosting
  const imgHostMatch = text.match(/https?:\/\/(?:i\.imgur\.com|pbs\.twimg\.com|cdn\.discordapp\.com)\/[^\s]+/i);
  if (imgHostMatch) return imgHostMatch[0];
  
  return null;
}

/**
 * Check if a message contains an image URL that should be analyzed.
 */
export function hasImageUrl(text) {
  return extractImageUrl(text) !== null;
}
