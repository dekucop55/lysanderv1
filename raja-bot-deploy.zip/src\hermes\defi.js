// src/hermes/defi.js — DeFi operations: Aave, Lido, GMX, Hyperliquid, Pendle
import axios from 'axios';
import { ethers } from 'ethers';
import { config } from '../config.js';
import { getPrivateKey, getWalletInfo } from './wallets.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { logger } from '../utils/logger.js';

// Minimal ABIs for DeFi interactions
const AAVE_POOL_ABI = [
  'function supply(address asset, uint256 amount, address onBehalfOf, uint16 referralCode)',
  'function withdraw(address asset, uint256 amount, address to)',
  'function borrow(address asset, uint256 amount, uint256 interestRateMode, uint16 referralCode, address onBehalfOf)',
  'function repay(address asset, uint256 amount, uint256 interestRateMode, address onBehalfOf)',
];

const AAVE_V3_POOL = {
  ethereum: '0x87870Bca3F3fD6335C3F4ce8392D69350B4fA4E2',
  arbitrum: '0x794a61358D6845594F94dc1DB02A252b5b4814aD',
  optimism: '0x794a61358D6845594F94dc1DB02A252b5b4814aD',
  polygon: '0x794a61358D6845594F94dc1DB02A252b5b4814aD',
};

const LIDO_STETH = '0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84'; // Ethereum
const LIDO_SUBMIT_ABI = ['function submit(address _referral) external payable returns (uint256)'];

/**
 * Supply assets to Aave v3
 */
export async function aaveSupply({ walletLabel, chain, asset, amount }) {
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: getChainId(chain),
    action: 'aave:supply',
    usdValue: null,
    slippage: 0,
    simulated: true,
  });
  if (!decision.allowed) return { success: false, reason: decision.reason };

  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[chain]);
  const signer = new ethers.Wallet(pk, provider);
  const info = getWalletInfo(walletLabel);

  const poolAddr = AAVE_V3_POOL[chain];
  if (!poolAddr) throw new Error(`Aave not supported on ${chain}`);

  const amountWei = ethers.parseUnits(String(amount), 18);

  // Approve first
  const erc20 = new ethers.Contract(asset, [
    'function approve(address spender, uint256 amount) returns (bool)',
  ], signer);
  await erc20.approve(poolAddr, amountWei);

  // Supply
  const pool = new ethers.Contract(poolAddr, AAVE_POOL_ABI, signer);
  const tx = await pool.supply(asset, amountWei, info.address, 0);
  await tx.wait();

  governorRecord({ wallet: walletLabel, chainId: getChainId(chain), action: 'aave:supply', usdValue: null, txHash: tx.hash });
  logger.info(`[defi] Aave supply tx: ${tx.hash}`);
  return { success: true, txHash: tx.hash, action: 'aave:supply', chain };
}

/**
 * Stake ETH via Lido
 */
export async function lidoStake({ walletLabel, amountEth }) {
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: 1,
    action: 'lido:stake',
    usdValue: null,
    slippage: 0,
    simulated: true,
  });
  if (!decision.allowed) return { success: false, reason: decision.reason };

  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm.ethereum);
  const signer = new ethers.Wallet(pk, provider);

  const lido = new ethers.Contract(LIDO_STETH, LIDO_SUBMIT_ABI, signer);
  const tx = await lido.submit(ethers.ZeroAddress, {
    value: ethers.parseEther(String(amountEth)),
  });
  await tx.wait();

  governorRecord({ wallet: walletLabel, chainId: 1, action: 'lido:stake', usdValue: null, txHash: tx.hash });
  logger.info(`[defi] Lido stake tx: ${tx.hash}`);
  return { success: true, txHash: tx.hash, action: 'lido:stake', stETH: amountEth };
}

/**
 * Get DeFi positions summary for a wallet
 */
export async function getDefiSummary(walletLabel) {
  const info = getWalletInfo(walletLabel);
  if (!info) throw new Error(`Wallet "${walletLabel}" not found`);

  const results = [];

  // Check Aave position via API (keyless)
  try {
    const res = await axios.get(
      `https://aave-api-v2.aave.com/data/liquidity/v2?poolId=0x7d2768dE32b0b80b7a3454c06BdAc94A69DDc7A9&userAddress=${info.address}`,
      { timeout: 10000 }
    );
    if (res.data) results.push({ protocol: 'aave', data: res.data });
  } catch (e) {}

  return { wallet: walletLabel, address: info.address, positions: results };
}

function getChainId(chain) {
  const map = { ethereum: 1, base: 8453, arbitrum: 42161, optimism: 10, polygon: 137, bsc: 56 };
  return map[chain] || 1;
}
