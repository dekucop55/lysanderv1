// tests/unit/route-execute.test.js
//
// Unit tests for routeExecute() (Task 5.2)
// Validates: Requirements 1.2, 1.5, 1.7, 2.3, 2.4, 2.5

import { describe, it, expect, beforeEach } from 'vitest';
import { routeExecute, planManager } from '../../src/core/brain.js';

describe('routeExecute', () => {
  const sessionId = 'test-session-route';
  const sessionState = { id: sessionId };

  beforeEach(() => {
    // Clear all plans between tests
    planManager.sessions.clear();
  });

  describe('Priority 1: Single agreed active plan → dispatch', () => {
    it('should dispatch to plan.skillId when single agreed plan exists', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-abc',
        skillId: 'H1',
        description: 'Swap ETH to USDC',
        status: 'agreed',
      });

      const result = routeExecute('gas', sessionState);
      expect(result.action).toBe('dispatch');
      expect(result.skillId).toBe('H1');
      expect(result.plan).toBeDefined();
      expect(result.plan.planId).toBe('plan-abc');
    });

    it('should touch plan TTL on dispatch', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-ttl',
        skillId: 'm2',
        description: 'Deploy bot',
        status: 'agreed',
      });

      // Manually set lastInteraction to the past
      const plans = planManager.sessions.get(sessionId);
      plans[0].lastInteraction = Date.now() - 10000;

      const beforeTouch = planManager.getActivePlan(sessionId).lastInteraction;
      routeExecute('jalankan', sessionState);
      const afterTouch = planManager.getActivePlan(sessionId).lastInteraction;

      expect(afterTouch).toBeGreaterThan(beforeTouch);
    });

    it('should dispatch to plan regardless of message content', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-x',
        skillId: 'H3',
        description: 'DeFi staking',
        status: 'agreed',
      });

      // Even if message matches another skill via fuzzy, plan takes priority
      const result = routeExecute('swap ETH to USDC on 1inch', sessionState);
      expect(result.action).toBe('dispatch');
      expect(result.skillId).toBe('H3'); // Plan skill, not H1 (swap)
    });

    it('should NOT dispatch proposed-only plans (only agreed)', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-proposed',
        skillId: 'm10',
        description: 'Check balance',
        status: 'proposed',
      });

      // getActivePlan returns null for proposed-only (not agreed)
      // Should fall through to fuzzy match or clarify
      const result = routeExecute('some random command', sessionState);
      // Since there are no agreed plans and no fuzzy match, it should clarify
      expect(result.action).toBe('clarify');
    });
  });

  describe('Priority 2: Multiple active plans → disambiguate', () => {
    it('should return disambiguate when multiple agreed plans exist', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-1',
        skillId: 'H1',
        description: 'Swap ETH',
        status: 'agreed',
      });
      planManager.setPlan(sessionId, {
        planId: 'plan-2',
        skillId: 'H2',
        description: 'Bridge tokens',
        status: 'agreed',
      });

      const result = routeExecute('lakukan', sessionState);
      expect(result.action).toBe('disambiguate');
      expect(result.plans).toHaveLength(2);
      expect(result.plans[0].planId).toBe('plan-1');
      expect(result.plans[1].planId).toBe('plan-2');
    });

    it('should include message with disambiguation', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-a',
        skillId: 'H1',
        description: 'Swap',
        status: 'agreed',
      });
      planManager.setPlan(sessionId, {
        planId: 'plan-b',
        skillId: 'H3',
        description: 'DeFi',
        status: 'agreed',
      });

      const result = routeExecute('eksekusi', sessionState);
      expect(result.message).toBeDefined();
      expect(typeof result.message).toBe('string');
      expect(result.message.length).toBeGreaterThan(0);
    });

    it('should dispatch single agreed plan even when proposed plan also exists', () => {
      // 1 agreed + 1 proposed: getActivePlan returns the agreed one (since it only checks agreed plans)
      planManager.setPlan(sessionId, {
        planId: 'plan-agreed',
        skillId: 'H1',
        description: 'Swap',
        status: 'agreed',
      });
      planManager.setPlan(sessionId, {
        planId: 'plan-proposed',
        skillId: 'H2',
        description: 'Bridge',
        status: 'proposed',
      });

      // getActivePlan returns the single agreed plan
      // But getActivePlans returns 2 (agreed + proposed)
      // routeExecute checks getActivePlan first — if exactly 1 agreed → dispatch
      const result = routeExecute('gas', sessionState);
      // getActivePlan checks for agreed plans only - there is exactly 1
      // so it returns it and dispatches
      expect(result.action).toBe('dispatch');
      expect(result.skillId).toBe('H1');
    });
  });

  describe('Priority 3: No plan → fuzzy match (high keyword density)', () => {
    it('should dispatch via fuzzyMatch when input has high keyword density', () => {
      // fuzzyMatch requires score >= 0.5 * maxTheoreticalScore
      // H1 maxTheoreticalScore = 63, so we need score >= 31.5
      // Use input with many repeated H1 keywords to exceed threshold
      const input = 'swap swap swap 1inch 1inch jual token jual token sell dex slippage aggregator sell';
      const result = routeExecute(input, sessionState);
      expect(result.action).toBe('dispatch');
      expect(result.skillId).toBe('H1');
      expect(result.matchedSkill).toBeDefined();
      expect(result.matchedSkill.score).toBeGreaterThanOrEqual(result.matchedSkill.maxTheoreticalScore * 0.5);
    });

    it('should NOT dispatch via fuzzyMatch for typical short commands (below threshold)', () => {
      // "swap ETH ke USDC" only scores ~6 out of 63 maxTheoretical — well below 0.5 threshold
      const result = routeExecute('swap ETH ke USDC via 1inch', sessionState);
      expect(result.action).toBe('clarify');
      // But should still have suggestions
      expect(result.suggestions).toBeDefined();
    });
  });

  describe('Priority 4: No match → clarify with suggestions', () => {
    it('should return clarify with suggestions when no strong match', () => {
      const result = routeExecute('tolong urus urusan kantor besok', sessionState);
      expect(result.action).toBe('clarify');
      expect(result.message).toBeDefined();
      expect(typeof result.message).toBe('string');
    });

    it('should include suggestions array (max 3)', () => {
      const result = routeExecute('swap token di blockchain', sessionState);
      expect(result.suggestions).toBeDefined();
      expect(Array.isArray(result.suggestions)).toBe(true);
      expect(result.suggestions.length).toBeLessThanOrEqual(3);
      expect(result.suggestions.length).toBeGreaterThan(0);
    });

    it('should return clarify with "no active plan" message for gibberish input', () => {
      // Even gibberish might match something in keyword scanning (e.g. 'e' in keyword)
      // The key behavior: if no plan exists and no match → clarify
      const result = routeExecute('qwerty', sessionState);
      expect(result.action).toBe('clarify');
      expect(result.message).toBeDefined();
    });
  });

  describe('Requirement 1.7: No active plan → inform user', () => {
    it('should inform user there is no active plan for unrecognized commands', () => {
      // With no plan and no skill match
      const result = routeExecute('qwerty', sessionState);
      expect(result.action).toBe('clarify');
      // When suggestions are empty, message says "Tidak ada rencana aktif"
      if (result.suggestions.length === 0) {
        expect(result.message).toContain('Tidak ada rencana aktif');
      }
    });

    it('should suggest skills when partial match exists but below threshold', () => {
      const result = routeExecute('swap ETH', sessionState);
      expect(result.action).toBe('clarify');
      expect(result.suggestions.length).toBeGreaterThan(0);
      expect(result.message).toContain('Tidak bisa mencocokkan command');
    });
  });

  describe('Requirement 2.5: No anti-hallucination on EXECUTE path', () => {
    it('should NOT have any grounding/anti-hallucination fields in dispatch result', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-no-ah',
        skillId: 'H1',
        description: 'Swap',
        status: 'agreed',
      });

      const result = routeExecute('gas', sessionState);
      // Result should not contain anti-hallucination prompt injection
      expect(result.antiHallucination).toBeUndefined();
      expect(result.groundingPrompt).toBeUndefined();
      expect(result.realityAnchors).toBeUndefined();
    });

    it('should NOT inject grounding for clarify results', () => {
      const result = routeExecute('swap ETH ke USDC via 1inch', sessionState);
      expect(result.antiHallucination).toBeUndefined();
      expect(result.groundingPrompt).toBeUndefined();
    });

    it('should NOT inject grounding for disambiguate results', () => {
      planManager.setPlan(sessionId, {
        planId: 'p1',
        skillId: 'H1',
        description: 'Swap',
        status: 'agreed',
      });
      planManager.setPlan(sessionId, {
        planId: 'p2',
        skillId: 'H2',
        description: 'Bridge',
        status: 'agreed',
      });

      const result = routeExecute('gas', sessionState);
      expect(result.antiHallucination).toBeUndefined();
      expect(result.groundingPrompt).toBeUndefined();
    });
  });

  describe('Edge cases', () => {
    it('should handle expired plan gracefully (prune and fall through)', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-expired',
        skillId: 'H1',
        description: 'Old swap',
        status: 'agreed',
      });

      // Manually set lastInteraction to 31 minutes ago (beyond TTL)
      const plans = planManager.sessions.get(sessionId);
      plans[0].lastInteraction = Date.now() - (31 * 60 * 1000);
      plans[0].ttlMs = 30 * 60 * 1000;

      const result = routeExecute('jalankan', sessionState);
      // Expired plan should be pruned by getActivePlan, so no dispatch from plan
      expect(result.action).not.toBe('dispatch');
    });

    it('should handle empty message gracefully', () => {
      const result = routeExecute('', sessionState);
      expect(result.action).toBe('clarify');
    });

    it('should handle undefined context gracefully', () => {
      const result = routeExecute('swap ETH', sessionState);
      expect(result).toBeDefined();
      expect(result.action).toBeDefined();
    });

    it('should return valid action types only', () => {
      const validActions = ['dispatch', 'clarify', 'disambiguate'];

      // Test various inputs
      const inputs = ['gas', 'swap ETH', '', 'deploy kontrak', 'xyzzy'];
      for (const input of inputs) {
        const result = routeExecute(input, sessionState);
        expect(validActions).toContain(result.action);
      }
    });

    it('should include skillId in dispatch result', () => {
      planManager.setPlan(sessionId, {
        planId: 'plan-skill',
        skillId: 'm2',
        description: 'Deploy',
        status: 'agreed',
      });

      const result = routeExecute('eksekusi', sessionState);
      expect(result.action).toBe('dispatch');
      expect(result.skillId).toBeDefined();
      expect(typeof result.skillId).toBe('string');
    });
  });
});
