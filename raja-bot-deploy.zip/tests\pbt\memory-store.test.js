// tests/pbt/memory-store.test.js
// Property-Based Test: Property 9 — Message Storage Truncation dan Completeness
// **Validates: Requirements 3.1, 3.2**
//
// Property 9: *For any* pesan dengan panjang L, jika L ≤ 65535 maka pesan disimpan utuh;
// jika L > 65535 maka pesan disimpan truncated pada karakter ke-65535.
// Setiap record yang tersimpan SHALL memiliki semua field metadata:
// id, user_id, role, content, timestamp, session_id, intent_classified.

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';

// ─── Constants ──────────────────────────────────────────────────────────────

const MAX_CONTENT_LENGTH = 65535;

// ─── Pure truncation logic (mirrors saveMessage implementation) ─────────────

/**
 * Truncate content at MAX_CONTENT_LENGTH characters.
 * This mirrors the logic inside saveMessage() in src/core/memory.js.
 */
function truncateContent(content) {
  if (content && content.length > MAX_CONTENT_LENGTH) {
    return content.substring(0, MAX_CONTENT_LENGTH);
  }
  return content;
}

/**
 * Simulate what saveMessage() produces as a stored record.
 * This tests the contract without requiring a live SQLite DB.
 */
function simulateSaveMessage({ userId, role, content, sessionId, intentClassified = null }) {
  const truncatedContent = truncateContent(content);
  const timestamp = new Date().toISOString();

  return {
    id: 1, // Would be auto-incremented in real DB
    user_id: userId,
    role: role,
    content: truncatedContent,
    timestamp: timestamp,
    session_id: sessionId,
    intent_classified: intentClassified
  };
}

// ─── Generators ─────────────────────────────────────────────────────────────

/**
 * Generate random content strings from length 0 to 100000.
 * Uses a two-strategy approach: short strings use fc.string directly,
 * long strings use integer length + char repeat for performance.
 */
const contentArb = fc.oneof(
  // Short strings (0 to 1000) — full random content
  fc.string({ minLength: 0, maxLength: 1000 }),
  // Medium strings near the boundary
  fc.string({ minLength: 65530, maxLength: 65540 }),
  // Long strings (65536 to 100000) — built by repeating a base pattern
  fc.tuple(
    fc.integer({ min: MAX_CONTENT_LENGTH + 1, max: 100000 }),
    fc.string({ minLength: 1, maxLength: 100 })
  ).map(([length, base]) => {
    const repeated = base.repeat(Math.ceil(length / base.length));
    return repeated.substring(0, length);
  })
);

/**
 * Generate random user ID
 */
const userIdArb = fc.string({ minLength: 1, maxLength: 50 }).filter(s => s.trim().length > 0);

/**
 * Generate valid role
 */
const roleArb = fc.constantFrom('user', 'assistant');

/**
 * Generate random session ID
 */
const sessionIdArb = fc.string({ minLength: 1, maxLength: 50 }).filter(s => s.trim().length > 0);

/**
 * Generate optional intent classification
 */
const intentArb = fc.option(
  fc.constantFrom('EXECUTE', 'CHAT', 'CONFIRM', null),
  { nil: null }
);

/**
 * Generate a full message object for saveMessage
 */
const messageArb = fc.record({
  userId: userIdArb,
  role: roleArb,
  content: contentArb,
  sessionId: sessionIdArb,
  intentClassified: intentArb
});

// ─── Property Tests ─────────────────────────────────────────────────────────

describe('Property 9: Message Storage Truncation dan Completeness', () => {
  describe('Content Truncation', () => {
    it('**Validates: Requirements 3.1** — Messages ≤ 65535 chars are stored intact (no modification)', () => {
      fc.assert(
        fc.property(
          fc.string({ minLength: 0, maxLength: MAX_CONTENT_LENGTH }),
          (content) => {
            const result = truncateContent(content);
            // Content within limit must be stored exactly as-is
            expect(result).toBe(content);
            expect(result.length).toBe(content.length);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.1** — Messages > 65535 chars are truncated to exactly 65535 chars', () => {
      // Use integer-based length generation + repeat to avoid slow char-by-char generation
      fc.assert(
        fc.property(
          fc.integer({ min: MAX_CONTENT_LENGTH + 1, max: 100000 }),
          fc.string({ minLength: 1, maxLength: 1 }),
          (length, singleChar) => {
            // Build a long string efficiently by repeating a char
            const content = singleChar.repeat(length);
            const result = truncateContent(content);
            // Must be truncated to exactly MAX_CONTENT_LENGTH
            expect(result.length).toBe(MAX_CONTENT_LENGTH);
            // Truncated content must be the first 65535 characters of original
            expect(result).toBe(content.substring(0, MAX_CONTENT_LENGTH));
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.1** — For any content length L, stored length = min(L, 65535)', () => {
      fc.assert(
        fc.property(
          contentArb,
          (content) => {
            const result = truncateContent(content);
            const expectedLength = Math.min(content.length, MAX_CONTENT_LENGTH);
            expect(result.length).toBe(expectedLength);
          }
        ),
        { numRuns: 150 }
      );
    });
  });

  describe('Metadata Completeness', () => {
    it('**Validates: Requirements 3.2** — Every stored record SHALL have all required metadata fields', () => {
      fc.assert(
        fc.property(
          messageArb,
          (msg) => {
            const stored = simulateSaveMessage(msg);

            // All required fields must exist and be defined
            expect(stored).toHaveProperty('id');
            expect(stored).toHaveProperty('user_id');
            expect(stored).toHaveProperty('role');
            expect(stored).toHaveProperty('content');
            expect(stored).toHaveProperty('timestamp');
            expect(stored).toHaveProperty('session_id');
            expect(stored).toHaveProperty('intent_classified');

            // id must be a number
            expect(typeof stored.id).toBe('number');

            // user_id must match input
            expect(stored.user_id).toBe(msg.userId);

            // role must be 'user' or 'assistant'
            expect(['user', 'assistant']).toContain(stored.role);
            expect(stored.role).toBe(msg.role);

            // content must be defined (string)
            expect(typeof stored.content).toBe('string');

            // timestamp must be valid ISO 8601
            expect(stored.timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/);
            expect(new Date(stored.timestamp).toString()).not.toBe('Invalid Date');

            // session_id must match input
            expect(stored.session_id).toBe(msg.sessionId);

            // intent_classified can be null or a string
            if (stored.intent_classified !== null) {
              expect(typeof stored.intent_classified).toBe('string');
            }
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.2** — Stored content reflects truncation AND metadata is always complete', () => {
      fc.assert(
        fc.property(
          messageArb,
          (msg) => {
            const stored = simulateSaveMessage(msg);

            // Verify truncation is applied correctly
            if (msg.content.length <= MAX_CONTENT_LENGTH) {
              expect(stored.content).toBe(msg.content);
            } else {
              expect(stored.content.length).toBe(MAX_CONTENT_LENGTH);
              expect(stored.content).toBe(msg.content.substring(0, MAX_CONTENT_LENGTH));
            }

            // Verify all 7 required metadata fields are present
            const requiredFields = ['id', 'user_id', 'role', 'content', 'timestamp', 'session_id', 'intent_classified'];
            for (const field of requiredFields) {
              expect(field in stored).toBe(true);
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });
});


// ─── Property 10: getRecentHistory Limit Cap ────────────────────────────────
// **Validates: Requirements 3.5**
//
// Property 10: *For any* nilai `limit` yang diberikan ke `getRecentHistory()`,
// jika limit > 1000 maka fungsi SHALL menggunakan 1000.
// Hasil SHALL berisi tepat `min(limit, total_messages)` pesan terurut dari terbaru.

// ─── Pure limit capping logic (mirrors getRecentHistory implementation) ─────

/**
 * Replicates the limit capping logic from getRecentHistory in src/core/memory.js:
 *   const cappedLimit = Math.min(Math.max(limit, 1), 1000);
 */
function capLimit(limit) {
  return Math.min(Math.max(limit, 1), 1000);
}

/**
 * Given a capped limit and total available messages,
 * compute expected result count (what DB would return).
 */
function expectedResultCount(cappedLimit, totalMessages) {
  return Math.min(cappedLimit, totalMessages);
}

describe('Property 10: getRecentHistory Limit Cap', () => {
  describe('Limit Capping Logic', () => {
    it('**Validates: Requirements 3.5** — Any limit > 1000 SHALL be capped to exactly 1000', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 1001, max: 999999 }),
          (limit) => {
            const capped = capLimit(limit);
            expect(capped).toBe(1000);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.5** — Any limit in [1, 1000] SHALL be used as-is', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 1000 }),
          (limit) => {
            const capped = capLimit(limit);
            expect(capped).toBe(limit);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.5** — Any limit < 1 SHALL be clamped to 1 (minimum floor)', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: -10000, max: 0 }),
          (limit) => {
            const capped = capLimit(limit);
            expect(capped).toBe(1);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.5** — capLimit is idempotent: applying twice yields same result', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: -10000, max: 999999 }),
          (limit) => {
            const once = capLimit(limit);
            const twice = capLimit(once);
            expect(twice).toBe(once);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  describe('Result Count Invariant', () => {
    it('**Validates: Requirements 3.5** — Result count SHALL be min(cappedLimit, totalMessages)', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 5000 }),  // limit (raw, before capping)
          fc.integer({ min: 0, max: 5000 }),  // totalMessages available in DB
          (limit, totalMessages) => {
            const capped = capLimit(limit);
            const resultCount = expectedResultCount(capped, totalMessages);

            // Result count must equal min(capped, total)
            expect(resultCount).toBe(Math.min(capped, totalMessages));

            // Result count must never exceed 1000
            expect(resultCount).toBeLessThanOrEqual(1000);

            // Result count must never exceed total available messages
            expect(resultCount).toBeLessThanOrEqual(totalMessages);

            // Result count must be non-negative
            expect(resultCount).toBeGreaterThanOrEqual(0);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.5** — When totalMessages >= cappedLimit, result count equals cappedLimit exactly', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 5000 }),  // limit
          fc.integer({ min: 1000, max: 10000 }), // totalMessages (always >= max cap)
          (limit, totalMessages) => {
            const capped = capLimit(limit);
            const resultCount = expectedResultCount(capped, totalMessages);

            // When enough messages exist, we always get exactly cappedLimit messages
            expect(resultCount).toBe(capped);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 3.5** — When totalMessages < cappedLimit, result count equals totalMessages', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 500, max: 5000 }),  // limit (will cap to at least 500 or 1000)
          fc.integer({ min: 0, max: 499 }),     // totalMessages (always less than limit)
          (limit, totalMessages) => {
            const capped = capLimit(limit);
            // Only test when totalMessages is actually less than capped
            if (totalMessages < capped) {
              const resultCount = expectedResultCount(capped, totalMessages);
              expect(resultCount).toBe(totalMessages);
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });
});
