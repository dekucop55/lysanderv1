// tests/unit/auto-push-notify.test.js
//
// Unit tests for AutoPushScheduler.notifyOwner() (Task 9.4)
// Validates: Requirements 6.5, 6.7

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { AutoPushScheduler } from '../../src/core/auto-push.js';

// Mock node-cron
vi.mock('node-cron', () => ({
  default: {
    schedule: vi.fn((schedule, callback) => ({
      stop: vi.fn(),
      _callback: callback
    }))
  }
}));

// Mock child_process
vi.mock('child_process', () => ({
  execSync: vi.fn()
}));

// Mock logger
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn()
  }
}));

// Mock config
vi.mock('../../src/config.js', () => ({
  config: {
    telegram: {
      token: 'test-bot-token-123',
      allowedUserId: 12345678
    }
  }
}));

describe('AutoPushScheduler.notifyOwner()', () => {
  let scheduler;
  let mockFetch;

  beforeEach(() => {
    scheduler = new AutoPushScheduler();
    // Mock global fetch
    mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      statusText: 'OK'
    });
    global.fetch = mockFetch;
  });

  afterEach(() => {
    vi.restoreAllMocks();
    delete global.fetch;
  });

  it('should call Telegram API with correct URL', async () => {
    const result = {
      status: 'failed',
      error: 'network timeout',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 3);

    expect(mockFetch).toHaveBeenCalledWith(
      'https://api.telegram.org/bottest-bot-token-123/sendMessage',
      expect.any(Object)
    );
  });

  it('should send POST request with JSON content type', async () => {
    const result = {
      status: 'failed',
      error: 'ECONNREFUSED',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 2);

    const [, options] = mockFetch.mock.calls[0];
    expect(options.method).toBe('POST');
    expect(options.headers['Content-Type']).toBe('application/json');
  });

  it('should include timestamp, error, and retryCount in message', async () => {
    const result = {
      status: 'failed',
      error: 'push timeout after 120s',
      timestamp: '2025-06-15T20:05:00.000Z'
    };

    await scheduler.notifyOwner(result, 3);

    const [, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body);

    expect(body.text).toContain('2025-06-15T20:05:00.000Z');
    expect(body.text).toContain('push timeout after 120s');
    expect(body.text).toContain('3');
  });

  it('should send to ownerChatId from config', async () => {
    const result = {
      status: 'failed',
      error: 'auth failure',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 0);

    const [, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body);
    expect(body.chat_id).toBe(12345678);
  });

  it('should use Markdown parse mode', async () => {
    const result = {
      status: 'failed',
      error: 'test',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 1);

    const [, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body);
    expect(body.parse_mode).toBe('Markdown');
  });

  it('should NOT throw when fetch fails (catch and log)', async () => {
    mockFetch.mockRejectedValue(new Error('Network unreachable'));

    const result = {
      status: 'failed',
      error: 'original error',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    // Should not throw
    await expect(scheduler.notifyOwner(result, 3)).resolves.toBeUndefined();
  });

  it('should log error when fetch fails', async () => {
    const { logger } = await import('../../src/utils/logger.js');
    mockFetch.mockRejectedValue(new Error('DNS resolution failed'));

    const result = {
      status: 'failed',
      error: 'push error',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 2);

    expect(logger.error).toHaveBeenCalledWith(
      expect.stringContaining('Failed to notify owner')
    );
  });

  it('should log warning when Telegram API returns non-ok status', async () => {
    const { logger } = await import('../../src/utils/logger.js');
    mockFetch.mockResolvedValue({
      ok: false,
      status: 401,
      statusText: 'Unauthorized'
    });

    const result = {
      status: 'failed',
      error: 'push error',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 1);

    expect(logger.warn).toHaveBeenCalledWith(
      expect.stringContaining('Telegram API returned 401')
    );
  });

  it('should log info when notification succeeds', async () => {
    const { logger } = await import('../../src/utils/logger.js');

    const result = {
      status: 'failed',
      error: 'timeout',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 3);

    expect(logger.info).toHaveBeenCalledWith(
      expect.stringContaining('Owner notified')
    );
  });

  it('should handle null/undefined error in result gracefully', async () => {
    const result = {
      status: 'failed',
      error: null,
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 2);

    const [, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body);
    expect(body.text).toContain('Unknown');
  });

  it('should include status in notification message', async () => {
    const result = {
      status: 'failed',
      error: 'merge conflict detected',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await scheduler.notifyOwner(result, 0);

    const [, options] = mockFetch.mock.calls[0];
    const body = JSON.parse(options.body);
    expect(body.text).toContain('failed');
  });

  it('should skip notification when no bot token configured', async () => {
    // Override config mock to have no token
    vi.resetModules();
    vi.doMock('../../src/config.js', () => ({
      config: {
        telegram: {
          token: undefined,
          allowedUserId: 12345678
        }
      }
    }));
    vi.doMock('node-cron', () => ({
      default: {
        schedule: vi.fn((schedule, callback) => ({
          stop: vi.fn(),
          _callback: callback
        }))
      }
    }));
    vi.doMock('child_process', () => ({
      execSync: vi.fn()
    }));
    vi.doMock('../../src/utils/logger.js', () => ({
      logger: {
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn()
      }
    }));

    const { AutoPushScheduler: FreshScheduler } = await import('../../src/core/auto-push.js');
    const freshScheduler = new FreshScheduler();
    const freshFetch = vi.fn();
    global.fetch = freshFetch;

    const result = {
      status: 'failed',
      error: 'test',
      timestamp: '2025-06-15T20:00:00.000Z'
    };

    await freshScheduler.notifyOwner(result, 1);

    // Fetch should not have been called
    expect(freshFetch).not.toHaveBeenCalled();
  });
});
