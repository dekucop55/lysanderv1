// src/hermes/bridge.js — Cross-chain bridge via LI.FI
import axios from 'axios';
import { ethers } from 'ethers';
import { config } from '../config.js';
import { getPrivateKey } from './wallets.js';
import { authorize as governorAuthorize, record as governorRecord } from './governor.js';
import { logger } from '../utils/logger.js';

const LIFI_API = 'https://li.quest/v1';

const CHAIN_MAP = {
  ethereum: { id: 1, name: 'ETH' },
  base: { id: 8453, name: 'BAS' },
  arbitrum: { id: 42161, name: 'ARB' },
  optimism: { id: 10, name: 'OPT' },
  polygon: { id: 137, name: 'POL' },
  bsc: { id: 56, name: 'BSC' },
  avalanche: { id: 43114, name: 'AVA' },
};

/**
 * Get best bridge route between chains
 */
export async function getRoutes({ fromChain, toChain, fromToken, toToken, amount, walletLabel }) {
  const walletInfo = (await import('./wallets.js')).getWalletInfo(walletLabel);
  if (!walletInfo) throw new Error(`Wallet "${walletLabel}" not found`);

  const fromChainData = CHAIN_MAP[fromChain];
  const toChainData = CHAIN_MAP[toChain];
  if (!fromChainData || !toChainData) throw new Error(`Unknown chain: ${fromChain} or ${toChain}`);

  const res = await axios.get(`${LIFI_API}/quote`, {
    params: {
      fromChain: fromChainData.id,
      toChain: toChainData.id,
      fromToken: fromToken === 'ETH' ? '0x0000000000000000000000000000000000000000' : fromToken,
      toToken: toToken === 'ETH' ? '0x0000000000000000000000000000000000000000' : toToken,
      fromAmount: ethers.parseUnits(String(amount), 18).toString(),
      fromAddress: walletInfo.address,
    },
    timeout: 30000,
  });

  return res.data;
}

/**
 * Execute bridge transaction
 */
export async function executeBridge({ walletLabel, fromChain, toChain, fromToken, toToken, amount, slippage = 1.0 }) {
  // Governor gate
  const decision = governorAuthorize({
    wallet: walletLabel,
    chainId: CHAIN_MAP[fromChain]?.id,
    action: `bridge:${fromChain}->${toChain}`,
    usdValue: null, // Would need price oracle
    slippage,
    simulated: true,
  });

  if (!decision.allowed) {
    return { success: false, reason: decision.reason };
  }

  const quote = await getRoutes({ fromChain, toChain, fromToken, toToken, amount, walletLabel });

  if (!quote?.transactionRequest) {
    return { success: false, reason: 'No bridge route found' };
  }

  const pk = await getPrivateKey(walletLabel);
  const provider = new ethers.JsonRpcProvider(config.rpc.evm[fromChain]);
  const wallet = new ethers.Wallet(pk, provider);

  const txReq = quote.transactionRequest;
  const tx = await wallet.sendTransaction({
    to: txReq.to,
    data: txReq.data,
    value: txReq.value ? BigInt(txReq.value) : 0n,
    gasLimit: txReq.gasLimit ? BigInt(txReq.gasLimit) : undefined,
  });

  governorRecord({
    wallet: walletLabel,
    chainId: CHAIN_MAP[fromChain]?.id,
    action: `bridge:${fromChain}->${toChain}`,
    usdValue: null,
    txHash: tx.hash,
  });

  logger.info(`[bridge] ${fromChain}->${toChain} tx: ${tx.hash}`);
  return {
    success: true,
    txHash: tx.hash,
    fromChain,
    toChain,
    explorer: getExplorer(fromChain, tx.hash),
    estimatedTime: quote.estimate?.executionDuration,
  };
}

function getExplorer(chain, hash) {
  const map = {
    ethereum: 'https://etherscan.io/tx/',
    base: 'https://basescan.org/tx/',
    arbitrum: 'https://arbiscan.io/tx/',
    optimism: 'https://optimistic.etherscan.io/tx/',
    polygon: 'https://polygonscan.com/tx/',
    bsc: 'https://bscscan.com/tx/',
    avalanche: 'https://snowtrace.io/tx/',
  };
  return (map[chain] || 'https://etherscan.io/tx/') + hash;
}
