// src/skills/H1.js — Hermes: Token swap (1inch, 0x) with intent detection
import { getSwapQuote, swapToken, ensureAllowance, get1inchRouter } from '../hermes/swap.js';
import { logger } from '../utils/logger.js';

// ─── Token alias map ─────────────────────────────────────────────────────────
const TOKEN_ALIASES = {
  eth: 'ETH', weth: 'WETH', usdc: 'USDC', usdt: 'USDT', dai: 'DAI',
  wbtc: 'WBTC', matic: 'MATIC', bnb: 'BNB', avax: 'AVAX', arb: 'ARB',
  op: 'OP', link: 'LINK', uni: 'UNI', aave: 'AAVE', pepe: 'PEPE',
  shib: 'SHIB', doge: 'DOGE', sol: 'SOL',
};

const CHAIN_ALIASES = {
  eth: 'ethereum', ethereum: 'ethereum', base: 'base', arb: 'arbitrum',
  arbitrum: 'arbitrum', op: 'optimism', optimism: 'optimism',
  poly: 'polygon', polygon: 'polygon', bsc: 'bsc', avax: 'avalanche',
  avalanche: 'avalanche',
};

/**
 * Detect actionable swap intent from natural language query.
 * Returns { intent, params } or null for general questions.
 */
function detectSwapIntent(query) {
  const q = query.trim();
  const ql = q.toLowerCase();

  // Pattern: "swap <amount> <tokenIn> to/ke/for <tokenOut> [on/di <chain>] [wallet <label>]"
  const swapMatch = q.match(
    /(?:swap|tukar|convert)\s+([\d.,]+)\s+(\S+)\s+(?:to|ke|for|jadi)\s+(\S+)(?:\s+(?:on|di|chain)\s+(\S+))?(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (swapMatch) {
    const amount = parseFloat(swapMatch[1].replace(',', '.'));
    const tokenIn = resolveToken(swapMatch[2]);
    const tokenOut = resolveToken(swapMatch[3]);
    const chain = resolveChain(swapMatch[4]) || 'ethereum';
    const wallet = swapMatch[5] || null;
    return { intent: 'QUOTE', params: { amount, tokenIn, tokenOut, chain, wallet } };
  }

  // Pattern: "beli <amount> <token> [pakai/with <tokenIn>] [on chain] [wallet]"
  const buyMatch = q.match(
    /(?:beli|buy)\s+([\d.,]+)\s+(\S+)(?:\s+(?:pakai|with|using)\s+(\S+))?(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (buyMatch) {
    const amount = parseFloat(buyMatch[1].replace(',', '.'));
    const tokenOut = resolveToken(buyMatch[2]);
    const tokenIn = resolveToken(buyMatch[3]) || 'ETH';
    const chain = resolveChain(buyMatch[4]) || 'ethereum';
    const wallet = buyMatch[5] || null;
    return { intent: 'QUOTE', params: { amount, tokenIn, tokenOut, chain, wallet } };
  }

  // Pattern: "jual <amount> <token> [ke/to <tokenOut>] [on chain] [wallet]"
  const sellMatch = q.match(
    /(?:jual|sell)\s+([\d.,]+)\s+(\S+)(?:\s+(?:ke|to|for)\s+(\S+))?(?:\s+(?:on|di)\s+(\S+))?(?:\s+(?:wallet|from)\s+(\S+))?/i
  );
  if (sellMatch) {
    const amount = parseFloat(sellMatch[1].replace(',', '.'));
    const tokenIn = resolveToken(sellMatch[2]);
    const tokenOut = resolveToken(sellMatch[3]) || 'USDC';
    const chain = resolveChain(sellMatch[4]) || 'ethereum';
    const wallet = sellMatch[5] || null;
    return { intent: 'QUOTE', params: { amount, tokenIn, tokenOut, chain, wallet } };
  }

  // Pattern: "execute swap" / "confirm swap" / "eksekusi swap"
  const execMatch = ql.match(/(?:execute|confirm|eksekusi|lakukan|jalankan)\s+swap/);
  if (execMatch) {
    return { intent: 'EXECUTE', params: {} };
  }

  // No actionable intent
  return null;
}

function resolveToken(raw) {
  if (!raw) return null;
  const lower = raw.toLowerCase().replace(/[^a-z0-9]/g, '');
  return TOKEN_ALIASES[lower] || raw.toUpperCase();
}

function resolveChain(raw) {
  if (!raw) return null;
  return CHAIN_ALIASES[raw.toLowerCase()] || null;
}

export default {
  id: 'H1',
  name: 'swap',
  description: 'Token swaps via 1inch (EVM), slippage control, route optimization',

  async execute(query, context) {
    // 1. Detect actionable swap command
    const intent = detectSwapIntent(query);

    if (intent) {
      logger.info(`[H1] Swap intent detected: ${intent.intent}`, intent.params);

      try {
        switch (intent.intent) {
          case 'QUOTE': {
            const { amount, tokenIn, tokenOut, chain, wallet } = intent.params;

            if (!amount || isNaN(amount) || amount <= 0) {
              return '❌ Amount tidak valid. Contoh: `swap 1 ETH ke USDC on base`';
            }

            const quote = await getSwapQuote({
              chain,
              tokenIn,
              tokenOut,
              amount,
              slippage: 1.0,
            });

            const router = get1inchRouter(chain);
            return [
              `📊 **Swap Quote: ${amount} ${tokenIn} → ${tokenOut}**`,
              ``,
              `Chain: ${chain}`,
              `Expected output: **${quote.toAmount} ${tokenOut}**`,
              `Min output (slippage 1%): ${quote.toAmountMin} ${tokenOut}`,
              `Estimated gas: ~${quote.estimatedGas?.toLocaleString() || 'N/A'} gas units`,
              `Router: \`${router}\``,
              ``,
              wallet
                ? `Wallet: ${wallet}`
                : `⚠️ Specify wallet untuk eksekusi: \`swap ${amount} ${tokenIn} ke ${tokenOut} on ${chain} wallet <label>\``,
              ``,
              `🔐 Untuk eksekusi, gunakan command: \`/swapconfirm\``,
              `⚠️ Quote berlaku ~30 detik. Harga bisa berubah.`,
            ].join('\n');
          }

          case 'EXECUTE': {
            return [
              `🔐 **Swap Execution memerlukan konfirmasi eksplisit.**`,
              ``,
              `Untuk keamanan, eksekusi swap dilakukan via \`/swapconfirm\` command.`,
              `Ini memastikan governor authorization dan double-check sebelum broadcast.`,
              ``,
              `Langkah:`,
              `1. Dapatkan quote dulu: \`swap <amount> <token> ke <token> on <chain> wallet <label>\``,
              `2. Review quote`,
              `3. Konfirmasi: \`/swapconfirm\``,
            ].join('\n');
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[H1] Swap operation failed: ${err.message}`);
        return `❌ Swap gagal: ${err.message}`;
      }
    }

    // 2. Fallback: general swap question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H1 (Swap).
Mode: methodical, risk-aware.

Kamu menjawab pertanyaan tentang token swap:
- Bagaimana swap bekerja (AMM, order routing, aggregator)
- Best practices: slippage, MEV protection, timing
- Perbandingan DEX aggregator (1inch vs 0x vs Paraswap)
- Solusi masalah swap (failed tx, high slippage, token not found)
- Gas optimization tips

Untuk EXECUTE swap, user harus pakai format:
  swap <amount> <tokenIn> ke <tokenOut> on <chain> wallet <label>

Supported chains: ethereum, base, arbitrum, optimism, polygon, bsc, avalanche
Provider: 1inch v6 (EVM) dengan 0x fallback.

Safety checks otomatis:
1. Governor authorization (daily cap check)
2. Slippage validation (max 5% default)
3. Token safety check untuk token baru`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1000, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H1] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan swap: ${err.message}`;
    }
  },
};
