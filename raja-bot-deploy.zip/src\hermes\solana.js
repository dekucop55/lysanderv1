// src/hermes/solana.js — Solana wallet & basic operations
// Uses @solana/web3.js — install: npm install @solana/web3.js@1 @coral-xyz/anchor
import { logger } from '../utils/logger.js';
import { config } from '../config.js';
import { encrypt, decrypt } from '../utils/crypto.js';
import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

// Dynamic import karena @solana/web3.js opsional
async function getSolanaLib() {
  try {
    const { Connection, PublicKey, Keypair, LAMPORTS_PER_SOL, SystemProgram, Transaction, sendAndConfirmTransaction } =
      await import('@solana/web3.js');
    return { Connection, PublicKey, Keypair, LAMPORTS_PER_SOL, SystemProgram, Transaction, sendAndConfirmTransaction };
  } catch {
    throw new Error('Solana library tidak terinstall. Jalankan: npm install @solana/web3.js@1');
  }
}

let solanaDb;

function getSolanaDb() {
  if (solanaDb) return solanaDb;
  const dbPath = path.join(config.raja.dataDir, 'solana-wallets.db');
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  solanaDb = new Database(dbPath);
  solanaDb.exec(`
    CREATE TABLE IF NOT EXISTS solana_wallets (
      label TEXT PRIMARY KEY,
      pubkey TEXT NOT NULL,
      encrypted_secret TEXT NOT NULL,
      created_at REAL NOT NULL
    );
  `);
  return solanaDb;
}

/**
 * Generate wallet Solana baru
 */
export async function generateSolanaWallet() {
  const { Keypair } = await getSolanaLib();
  const kp = Keypair.generate();
  return {
    pubkey: kp.publicKey.toBase58(),
    secretKey: Buffer.from(kp.secretKey).toString('hex'),
    secretKeyBase58: kp.secretKey.toString(), // array format
  };
}

/**
 * Import dan simpan Solana wallet (dari private key hex atau base58)
 */
export async function importSolanaWallet({ label, secretKeyHex }) {
  const pw = config.governor.masterPw;
  if (!pw) throw new Error('HERMES_MASTER_PW tidak diset');

  const { Keypair } = await getSolanaLib();
  const secretBytes = Buffer.from(secretKeyHex, 'hex');
  const kp = Keypair.fromSecretKey(secretBytes);
  const pubkey = kp.publicKey.toBase58();

  const encryptedSecret = encrypt(secretKeyHex, pw);
  getSolanaDb().prepare(
    'INSERT OR REPLACE INTO solana_wallets(label, pubkey, encrypted_secret, created_at) VALUES (?, ?, ?, ?)'
  ).run(label, pubkey, encryptedSecret, Date.now() / 1000);

  logger.info(`[solana] Imported wallet ${label}: ${pubkey}`);
  return { label, pubkey };
}

/**
 * Ambil keypair dari vault
 */
export async function getSolanaKeypair(label) {
  const pw = config.governor.masterPw;
  if (!pw) throw new Error('HERMES_MASTER_PW tidak diset');

  const row = getSolanaDb().prepare('SELECT * FROM solana_wallets WHERE label = ?').get(label);
  if (!row) throw new Error(`Solana wallet "${label}" tidak ditemukan`);

  const secretHex = decrypt(row.encrypted_secret, pw);
  const { Keypair } = await getSolanaLib();
  return Keypair.fromSecretKey(Buffer.from(secretHex, 'hex'));
}

/**
 * Cek SOL balance
 */
export async function getSolanaBalance(label) {
  const { Connection, LAMPORTS_PER_SOL } = await getSolanaLib();
  const row = getSolanaDb().prepare('SELECT pubkey FROM solana_wallets WHERE label = ?').get(label);
  if (!row) throw new Error(`Wallet "${label}" tidak ditemukan`);

  const conn = new Connection(config.rpc.solana, 'confirmed');
  const { PublicKey } = await getSolanaLib();
  const lamports = await conn.getBalance(new PublicKey(row.pubkey));

  return {
    label,
    pubkey: row.pubkey,
    balance: lamports / LAMPORTS_PER_SOL,
    lamports,
    symbol: 'SOL',
  };
}

/**
 * Transfer SOL
 */
export async function transferSol({ fromLabel, toAddress, amountSol }) {
  const { Connection, PublicKey, SystemProgram, Transaction, sendAndConfirmTransaction, LAMPORTS_PER_SOL } =
    await getSolanaLib();

  const fromKp = await getSolanaKeypair(fromLabel);
  const conn = new Connection(config.rpc.solana, 'confirmed');

  const toPubkey = new PublicKey(toAddress);
  const lamports = Math.floor(amountSol * LAMPORTS_PER_SOL);

  const tx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: fromKp.publicKey,
      toPubkey,
      lamports,
    })
  );

  const sig = await sendAndConfirmTransaction(conn, tx, [fromKp]);
  logger.info(`[solana] Transfer ${amountSol} SOL: ${sig}`);

  return {
    success: true,
    signature: sig,
    explorer: `https://solscan.io/tx/${sig}`,
    from: fromKp.publicKey.toBase58(),
    to: toAddress,
    amount: amountSol,
  };
}

/**
 * List semua Solana wallets
 */
export function listSolanaWallets() {
  return getSolanaDb()
    .prepare('SELECT label, pubkey, created_at FROM solana_wallets ORDER BY label')
    .all();
}

/**
 * Jupiter swap (Solana DEX aggregator) — keyless
 */
export async function jupiterSwap({ fromLabel, inputMint, outputMint, amountLamports, slippageBps = 100 }) {
  const { Connection, PublicKey, VersionedTransaction } = await getSolanaLib();

  const fromKp = await getSolanaKeypair(fromLabel);
  const conn = new Connection(config.rpc.solana, 'confirmed');
  const axios_ = (await import('axios')).default;

  // 1. Get quote
  const quoteRes = await axios_.get('https://quote-api.jup.ag/v6/quote', {
    params: {
      inputMint,
      outputMint,
      amount: amountLamports,
      slippageBps,
    },
    timeout: 15000,
  });

  const quote = quoteRes.data;

  // 2. Get swap transaction
  const swapRes = await axios_.post('https://quote-api.jup.ag/v6/swap', {
    quoteResponse: quote,
    userPublicKey: fromKp.publicKey.toBase58(),
    wrapAndUnwrapSol: true,
  }, { timeout: 15000 });

  const { swapTransaction } = swapRes.data;

  // 3. Deserialize, sign, send
  const txBuf = Buffer.from(swapTransaction, 'base64');
  const tx = VersionedTransaction.deserialize(txBuf);
  tx.sign([fromKp]);

  const sig = await conn.sendRawTransaction(tx.serialize(), { skipPreflight: false });
  await conn.confirmTransaction(sig, 'confirmed');

  logger.info(`[solana] Jupiter swap: ${sig}`);
  return {
    success: true,
    signature: sig,
    explorer: `https://solscan.io/tx/${sig}`,
    inputMint,
    outputMint,
    inAmount: quote.inAmount,
    outAmount: quote.outAmount,
  };
}
