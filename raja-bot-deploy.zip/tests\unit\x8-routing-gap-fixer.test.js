import { describe, it } from 'vitest';
import assert from 'node:assert';
import fc from 'fast-check';
import { extractMissingKeywords, assignKeywordWeights, verifyNoRoutingCollision } from '../../src/skills/x8.js';
import { SKILL_KEYWORDS } from '../../src/core/skill-registry.js';

/**
 * **Validates: Requirements 16.5, 16.6, 16.7**
 * Property 23: Keyword weight assignment.
 * Property 24: Keyword extraction.
 * Property 28: Keyword addition safety (no routing collisions).
 */
describe('Property 23: Keyword Weight Assignment', () => {
  it('assigns weight 3 to unique keywords', () => {
    // "xyzuniquetest" should not be in any skill's keywords
    const result = assignKeywordWeights(['xyzuniquetest123'], 'm2');
    assert.strictEqual(result[0].weight, 3);
  });

  it('assigns weight 2 to overlapping keywords', () => {
    // Find a keyword that exists in another skill to test overlap detection
    const allSkillIds = Object.keys(SKILL_KEYWORDS);
    let overlapKeyword = null;
    let targetSkill = null;

    for (const id of allSkillIds) {
      const weights = SKILL_KEYWORDS[id]?.weight || {};
      const keys = Object.keys(weights);
      if (keys.length > 0) {
        overlapKeyword = keys[0];
        // Choose a DIFFERENT skill as target
        targetSkill = allSkillIds.find(s => s !== id);
        break;
      }
    }

    if (overlapKeyword && targetSkill) {
      const result = assignKeywordWeights([overlapKeyword], targetSkill);
      assert.strictEqual(result[0].weight, 2);
    }
  });
});

describe('Property 28: Keyword Addition Safety', () => {
  it('detects collision when new keyword matches other skill keywords', () => {
    // Find a primary keyword from any skill
    const allSkillIds = Object.keys(SKILL_KEYWORDS);
    let primaryKeyword = null;
    let ownerSkill = null;

    for (const id of allSkillIds) {
      const weights = SKILL_KEYWORDS[id]?.weight || {};
      const keys = Object.keys(weights);
      if (keys.length > 0) {
        primaryKeyword = keys[0];
        ownerSkill = id;
        break;
      }
    }

    if (primaryKeyword && ownerSkill) {
      // Adding ownerSkill's keyword to a different skill should cause collision
      const targetSkill = allSkillIds.find(s => s !== ownerSkill) || 'm2';
      const result = verifyNoRoutingCollision(targetSkill, [{ keyword: primaryKeyword, weight: 5 }]);
      assert.strictEqual(result.safe, false);
      assert.ok(result.conflicts.length > 0);
    }
  });

  it('no collision for unique keywords', () => {
    const result = verifyNoRoutingCollision('m2', [{ keyword: 'xyzunique999', weight: 3 }]);
    assert.strictEqual(result.safe, true);
    assert.strictEqual(result.conflicts.length, 0);
  });
});

describe('extractMissingKeywords', () => {
  it('returns non-empty for messages with meaningful words', () => {
    const result = extractMissingKeywords('akses file di server lewat ssh', 'm2');
    assert.ok(result.length > 0);
  });

  it('filters out stop words', () => {
    const result = extractMissingKeywords('yang dan atau dari untuk', 'm2');
    assert.strictEqual(result.length, 0);
  });

  it('returns empty for null input', () => {
    assert.deepStrictEqual(extractMissingKeywords(null, 'm2'), []);
    assert.deepStrictEqual(extractMissingKeywords('test', null), []);
  });
});
