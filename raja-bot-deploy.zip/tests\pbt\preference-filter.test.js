// tests/pbt/preference-filter.test.js
// Property-Based Test: Property 17 — getPreferences Filtering dan Sorting
// **Validates: Requirements 5.5**
//
// Property 17: *For any* user, `getPreferences(userId)` SHALL hanya mengembalikan
// preferensi dengan confidence >= 0.5 DAN `last_updated` dalam 90 hari terakhir,
// terurut berdasarkan confidence DESC.

import { describe, it, expect, beforeEach } from 'vitest';
import * as fc from 'fast-check';

// === Mock DB layer (mirrors real getPreferences filtering logic in memory.js) ===

class MockPreferenceDB {
  constructor() {
    this.rows = [];
    this.nextId = 1;
  }

  clear() {
    this.rows = [];
    this.nextId = 1;
  }

  insert(row) {
    const newRow = { ...row, id: this.nextId++ };
    this.rows.push(newRow);
    return newRow.id;
  }

  getAllForUser(userId) {
    return this.rows.filter(r => r.user_id === userId);
  }
}

let mockDb;

/**
 * getPreferences — mirrors the real implementation logic in src/core/memory.js
 * Filter: confidence >= 0.5 AND last_updated within 90 days
 * Sort: confidence DESC
 */
function getPreferences(userId) {
  if (!userId) return [];

  const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);

  const rows = mockDb.getAllForUser(userId)
    .filter(r => r.confidence >= 0.5)
    .filter(r => new Date(r.last_updated) >= ninetyDaysAgo)
    .sort((a, b) => b.confidence - a.confidence);

  return rows.map(row => ({
    id: row.id,
    userId: row.user_id,
    key: row.preference_key,
    value: row.preference_value,
    confidence: row.confidence,
    lastUpdated: row.last_updated,
    source: row.source_message_id
  }));
}

// === Generators (compatible with fast-check v4) ===

/** Generate valid user IDs */
const userIdArb = fc.constantFrom(
  'user1', 'user2', 'user3', 'alice', 'bob', 'charlie', 'owner123'
);

/** Generate valid preference keys */
const prefKeyArb = fc.constantFrom(
  'language', 'theme', 'format', 'timezone', 'currency',
  'response_style', 'code_lang', 'notification', 'greeting',
  'output_format', 'detail_level', 'preferred_chain',
  'swap_slippage', 'gas_limit', 'default_token',
  'alert_threshold', 'backup_freq', 'log_level'
);

/** Generate valid preference values */
const prefValueArb = fc.constantFrom(
  'python', 'javascript', 'typescript', 'rust', 'golang',
  'dark', 'light', 'auto', 'json', 'yaml', 'markdown',
  'concise', 'detailed', 'bahasa', 'english', 'high', 'low'
);

/** Generate confidence values across the full range [0.0, 1.0] */
const confidenceArb = fc.double({ min: 0, max: 1, noNaN: true });

/**
 * Generate a date ISO string.
 * daysAgo controls how far back in the past it is.
 */
function dateAgo(daysAgo) {
  return new Date(Date.now() - daysAgo * 24 * 60 * 60 * 1000).toISOString();
}

/** Generate days ago values — spanning both within and beyond 90 days */
const daysAgoArb = fc.integer({ min: 0, max: 180 });

/** Generate a single preference row with controlled confidence and recency */
const preferenceRowArb = fc.record({
  key: prefKeyArb,
  value: prefValueArb,
  confidence: confidenceArb,
  daysAgo: daysAgoArb,
  source: fc.constantFrom(null, 'msg_001', 'msg_002', 'msg_abc')
});

// === Property Tests ===

describe('Property 17: getPreferences Filtering dan Sorting', () => {
  beforeEach(() => {
    mockDb = new MockPreferenceDB();
  });

  it('only returns preferences with confidence >= 0.5', () => {
    // **Validates: Requirements 5.5**
    fc.assert(
      fc.property(
        userIdArb,
        fc.array(preferenceRowArb, { minLength: 1, maxLength: 20 }),
        (userId, prefs) => {
          mockDb.clear();

          // Insert all preferences for user
          for (const pref of prefs) {
            mockDb.insert({
              user_id: userId,
              preference_key: pref.key,
              preference_value: pref.value,
              confidence: pref.confidence,
              last_updated: dateAgo(pref.daysAgo),
              source_message_id: pref.source
            });
          }

          // Call getPreferences
          const result = getPreferences(userId);

          // Property: every returned preference has confidence >= 0.5
          for (const item of result) {
            expect(item.confidence).toBeGreaterThanOrEqual(0.5);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('only returns preferences updated within 90 days', () => {
    // **Validates: Requirements 5.5**
    fc.assert(
      fc.property(
        userIdArb,
        fc.array(preferenceRowArb, { minLength: 1, maxLength: 20 }),
        (userId, prefs) => {
          mockDb.clear();

          // Insert all preferences for user
          for (const pref of prefs) {
            mockDb.insert({
              user_id: userId,
              preference_key: pref.key,
              preference_value: pref.value,
              confidence: pref.confidence,
              last_updated: dateAgo(pref.daysAgo),
              source_message_id: pref.source
            });
          }

          // Call getPreferences
          const result = getPreferences(userId);

          // Property: every returned preference has last_updated within 90 days
          const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
          for (const item of result) {
            const updatedDate = new Date(item.lastUpdated);
            expect(updatedDate.getTime()).toBeGreaterThanOrEqual(ninetyDaysAgo.getTime());
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('results are sorted by confidence DESC', () => {
    // **Validates: Requirements 5.5**
    fc.assert(
      fc.property(
        userIdArb,
        fc.array(preferenceRowArb, { minLength: 2, maxLength: 20 }),
        (userId, prefs) => {
          mockDb.clear();

          // Insert all preferences for user (use unique keys to avoid duplicates)
          const uniquePrefs = prefs.slice(0, 18); // max 18 unique keys from our key set
          const usedKeys = new Set();
          for (const pref of uniquePrefs) {
            if (usedKeys.has(pref.key)) continue;
            usedKeys.add(pref.key);
            mockDb.insert({
              user_id: userId,
              preference_key: pref.key,
              preference_value: pref.value,
              confidence: pref.confidence,
              last_updated: dateAgo(pref.daysAgo),
              source_message_id: pref.source
            });
          }

          // Call getPreferences
          const result = getPreferences(userId);

          // Property: result is sorted by confidence DESC
          for (let i = 1; i < result.length; i++) {
            expect(result[i - 1].confidence).toBeGreaterThanOrEqual(result[i].confidence);
          }
        }
      ),
      { numRuns: 200 }
    );
  });

  it('never includes preferences below 0.5 confidence regardless of recency', () => {
    // **Validates: Requirements 5.5**
    fc.assert(
      fc.property(
        userIdArb,
        fc.array(
          fc.record({
            key: prefKeyArb,
            value: prefValueArb,
            // Force low confidence values (below 0.5) to verify they are excluded
            confidence: fc.double({ min: 0, max: 0.49, noNaN: true }),
            daysAgo: fc.integer({ min: 0, max: 30 }), // very recent
            source: fc.constantFrom(null, 'msg_001')
          }),
          { minLength: 1, maxLength: 10 }
        ),
        (userId, lowConfPrefs) => {
          mockDb.clear();

          // Insert all low-confidence preferences (all very recent, within 90 days)
          const usedKeys = new Set();
          for (const pref of lowConfPrefs) {
            if (usedKeys.has(pref.key)) continue;
            usedKeys.add(pref.key);
            mockDb.insert({
              user_id: userId,
              preference_key: pref.key,
              preference_value: pref.value,
              confidence: pref.confidence,
              last_updated: dateAgo(pref.daysAgo),
              source_message_id: pref.source
            });
          }

          // Call getPreferences
          const result = getPreferences(userId);

          // Property: no results returned — all have confidence < 0.5
          expect(result.length).toBe(0);
        }
      ),
      { numRuns: 200 }
    );
  });
});
