// src/skills/m10.js — Web3 ops, on-chain, airdrop farming, wallet management
import { importWallet, listWallets, getBalance, generateWallet } from '../hermes/wallets.js';
import { logger } from '../utils/logger.js';

/**
 * Resolve chain name aliases to standard names used in config.rpc.evm
 */
function resolveChainName(input) {
  const map = {
    eth: 'ethereum', ethereum: 'ethereum', mainnet: 'ethereum',
    base: 'base',
    arb: 'arbitrum', arbitrum: 'arbitrum',
    op: 'optimism', optimism: 'optimism',
    polygon: 'polygon', matic: 'polygon', pol: 'polygon',
    bsc: 'bsc', bnb: 'bsc',
    avalanche: 'avalanche', avax: 'avalanche',
    solana: 'solana', sol: 'solana',
    ronin: 'ronin', ron: 'ronin',
    hyperliquid: 'hyperliquid', hype: 'hyperliquid',
  };
  return map[input.toLowerCase()] || input.toLowerCase();
}

/**
 * Detect actionable wallet intent from natural language query.
 * Returns { intent, params } for actionable commands, null for general questions.
 */
function detectWalletIntent(query) {
  const q = query.trim().toLowerCase();

  // IMPORT: "import wallet <label> <privateKey>"
  const importMatch = query.match(
    /(?:import\s+wallet|wallet\s+import)\s+(\S+)\s+(0x)?([a-fA-F0-9]{64})/i
  );
  if (importMatch) {
    const label = importMatch[1];
    const privateKey = '0x' + importMatch[3];
    return { intent: 'IMPORT', params: { label, privateKey } };
  }

  // LIST: various phrasings
  const listPatterns = [
    /(?:list|show|daftar|lihat)\s+wallet/i,
    /wallet\s+(?:list|apa\s+aja|saya|ku)/i,
    /wallets?\s*$/i,
    /(?:tampilkan|cek)\s+(?:semua\s+)?wallet/i,
  ];
  if (listPatterns.some((p) => p.test(q))) {
    return { intent: 'LIST', params: {} };
  }

  // Known chain names for smart detection
  const KNOWN_CHAINS = ['ethereum', 'eth', 'base', 'arbitrum', 'arb', 'optimism', 'op', 'polygon', 'matic', 'bsc', 'bnb', 'avalanche', 'avax', 'solana', 'sol', 'ronin', 'hyperliquid'];

  // BALANCE: "cek balance <label>", "balance <label> <chain>", "check balance <label>"
  const balanceMatch = query.match(
    /(?:cek|check|get|lihat)?\s*(?:balance|saldo)\s+(\S+)(?:\s+(?:di|on|at|chain|network)?\s*(\S+))?/i
  );
  if (balanceMatch) {
    let label = balanceMatch[1];
    let chain = balanceMatch[2] || 'ethereum';

    // Smart detect: if "label" is actually a chain name, swap logic
    // e.g., "cek balance base" → user means default wallet on base chain
    if (KNOWN_CHAINS.includes(label.toLowerCase())) {
      // label is actually a chain name — use first wallet as default
      chain = resolveChainName(label);
      const wallets = listWallets();
      label = wallets.length > 0 ? wallets[0].label : label;
    } else {
      chain = resolveChainName(chain);
    }

    return { intent: 'BALANCE', params: { label, chain } };
  }

  // BALANCE v2: "<label> balance" or "saldo <label>"
  const balanceMatch2 = query.match(
    /(?:saldo|balance)\s+(?:wallet\s+)?(\S+)(?:\s+(?:di|on|at|chain)\s+(\S+))?/i
  );
  if (balanceMatch2 && !balanceMatch) {
    let label = balanceMatch2[1];
    let chain = balanceMatch2[2] || 'ethereum';

    if (KNOWN_CHAINS.includes(label.toLowerCase())) {
      chain = resolveChainName(label);
      const wallets = listWallets();
      label = wallets.length > 0 ? wallets[0].label : label;
    } else {
      chain = resolveChainName(chain);
    }

    return { intent: 'BALANCE', params: { label, chain } };
  }

  // GENERATE: "buat wallet baru", "bikin wallet", "generate wallet", "create wallet new"
  const generatePatterns = [
    /(?:buat|bikin|create|generate)\s+(?:wallet|dompet)/i,
    /wallet\s+(?:baru|new|generate)/i,
    /new\s+wallet/i,
  ];
  if (generatePatterns.some((p) => p.test(q))) {
    return { intent: 'GENERATE', params: {} };
  }

  // No actionable intent detected — fall through to LLM
  return null;
}

/**
 * Truncate address for display: 0x1234...abcd
 */
function truncateAddress(address) {
  if (!address || address.length < 12) return address;
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export default {
  id: 'm10',
  name: 'web3',
  description: 'Web3 operations, on-chain interactions, wallet management, airdrop farming, mass tx automation',

  async execute(query, context) {
    // 1. Detect actionable wallet command
    const intent = detectWalletIntent(query);

    if (intent) {
      logger.info(`[m10] Wallet intent detected: ${intent.intent}`);

      try {
        switch (intent.intent) {
          case 'IMPORT': {
            const { label, privateKey } = intent.params;
            const result = await importWallet({ label, privateKey });
            // NEVER echo private key back
            return `✅ Wallet imported: **${result.label}** (\`${result.address}\`)`;
          }

          case 'LIST': {
            const wallets = listWallets();
            if (!wallets || wallets.length === 0) {
              return '📭 Belum ada wallet tersimpan. Gunakan `import wallet <label> <privateKey>` atau `buat wallet baru`.';
            }
            const lines = wallets.map(
              (w) => `• **${w.label}** — \`${truncateAddress(w.address)}\` (${w.chain_type})`
            );
            return `🗂️ **Daftar Wallet** (${wallets.length}):\n\n${lines.join('\n')}`;
          }

          case 'BALANCE': {
            const { label, chain } = intent.params;
            try {
              const result = await getBalance(label, chain);
              return [
                `💰 **Balance: ${result.label}**`,
                `Chain: ${result.chain}`,
                `Address: \`${truncateAddress(result.address)}\``,
                `Balance: **${result.balance} ${result.symbol}**`,
              ].join('\n');
            } catch (balErr) {
              // Specific error handling for balance check
              if (balErr.message.includes('RPC not configured')) {
                return `❌ RPC untuk chain "${chain}" belum di-set di .env.\n\nTambahkan: \`RPC_EVM_${chain.toUpperCase()}=https://...\` lalu restart bot.`;
              }
              return `❌ Gagal cek balance ${label} di ${chain}: ${balErr.message}`;
            }
          }

          case 'GENERATE': {
            const wallet = generateWallet();
            return [
              `🆕 **Wallet Baru Di-generate**`,
              ``,
              `Address: \`${wallet.address}\``,
              `Private Key: \`${wallet.privateKey}\``,
              wallet.mnemonic ? `Mnemonic: \`${wallet.mnemonic}\`` : '',
              ``,
              `⚠️ **SIMPAN PRIVATE KEY & MNEMONIC DI TEMPAT AMAN!**`,
              `Jangan share ke siapapun. Tidak bisa di-recover kalau hilang.`,
            ]
              .filter(Boolean)
              .join('\n');
          }

          default:
            break;
        }
      } catch (err) {
        logger.error(`[m10] Wallet operation failed: ${err.message}`);
        return `❌ Gagal eksekusi wallet command: ${err.message}`;
      }
    }

    // 2. Fallback: general web3 question → LLM cascade
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Skill aktif: m10 (Web3).
Expert dalam:
- ethers.js v6, viem, web3.js
- EVM chains: Ethereum, Base, Arbitrum, Optimism, Polygon, BSC
- Solana: @solana/web3.js, anchor
- Wallet operations: generate, import, sign, broadcast
- Token operations: transfer, approve, allowance
- Multi-wallet orchestration dan nonce management
- Airdrop farming strategy dan execution
- Gas optimization (EIP-1559, priority fee)
- Transaction batching (Multicall3)
- NFT minting dan trading
- DeFi interactions: swap, LP, staking
- Smart contract interaction (ABI encoding/decoding)

Semua operasi on-chain harus disertai gas estimate.
Flag risiko kalau ada (rug, honeypot, gas war).`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 2000, temperature: 0.4 });
      return result.text;
    } catch (err) {
      logger.error(`[m10] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan web3: ${err.message}`;
    }
  },
};
