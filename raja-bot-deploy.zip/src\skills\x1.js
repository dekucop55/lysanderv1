// src/skills/x1.js — Self-audit: system review, skill quality check, optimization
export default {
  id: 'x1',
  name: 'audit',
  description: 'System self-audit, skill quality review, performance analysis, improvement recommendations',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');
    const { verifyIntegrity } = await import('../core/skill-integrity.js');
    const { getRecent } = await import('../core/memory.js');

    // Get system state
    const integrity = await verifyIntegrity();
    const recent = await getRecent(10);

    const systemState = `
Integrity: ${integrity.tampered ? `TAMPERED (${integrity.modified.join(',')})` : 'OK'}
Recent memories: ${recent.length}
Modified skills: ${integrity.modified.join(', ') || 'none'}
Added skills: ${integrity.added.join(', ') || 'none'}
Missing skills: ${integrity.missing.join(', ') || 'none'}
    `.trim();

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: x1 (Self-Audit).
Mode: forensic, structured.

Kamu sedang mengaudit dirimu sendiri.

Analisis:
1. Kondisi sistem (integrity, memory, session)
2. Skill performance berdasarkan memory
3. Pola buruk yang harus diperbaiki
4. Rekomendasi konkret

Output: laporan terstruktur dengan severity dan action items.`,
      },
      {
        role: 'user',
        content: `System state:\n${systemState}\n\nQuery: ${query}`,
      },
    ];

    const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.3 });
    return result.text;
  },
};
