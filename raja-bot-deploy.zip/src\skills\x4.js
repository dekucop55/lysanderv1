// src/skills/x4.js — Self-improve: learning loop, adaptation, capability expansion
export default {
  id: 'x4',
  name: 'self-improve',
  description: 'Self-improvement loop: analyze past sessions, learn patterns, adapt behavior, expand capabilities',

  async execute(query, context) {
    const { callCascade } = await import('../llm/cascade.js');
    const { getRecent, rememberFact } = await import('../core/memory.js');

    const memories = await getRecent(20, 'reflection');
    const reflectionDump = memories
      .map((m) => m.content)
      .slice(0, 10)
      .join('\n');

    const messages = [
      {
        role: 'system',
        content: `Kamu adalah RAJA. Skill aktif: x4 (Self-Improve).
Mode: meta-cognitive, growth-oriented.

Tugasmu:
1. Analisis pola dari reflection memory
2. Identifikasi skill gaps
3. Propose concrete improvements:
   - Prompt refinements untuk skill tertentu
   - Routing keyword yang perlu ditambah
   - Behavior yang harus diubah
4. Auto-implement kalau bisa (update memory, suggest config changes)

Reflection memories available:
${reflectionDump || 'tidak ada reflection memory'}

Prinsip: setiap sesi harus lebih baik dari sesi sebelumnya.`,
      },
      { role: 'user', content: query },
    ];

    const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.6 });

    // Save improvement suggestions as memory
    await rememberFact({
      content: `x4 improvement: ${result.text.substring(0, 300)}`,
      kind: 'improvement',
      tags: 'x4,self-improve',
      weight: 2.5,
    });

    return result.text;
  },
};
