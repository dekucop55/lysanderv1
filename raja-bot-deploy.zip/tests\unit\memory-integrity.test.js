// tests/unit/memory-integrity.test.js
//
// Unit tests for checkIntegrity() and restoreFromBackup() (Task 10.2)
// Validates: Requirements 7.3, 7.5, 7.6

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Track mock Database instances
let mockInstances = [];
const createMockDbInstance = (pragmaResult) => {
  const instance = {
    pragma: vi.fn().mockReturnValue(pragmaResult || [{ integrity_check: 'ok' }]),
    exec: vi.fn(),
    close: vi.fn(),
  };
  mockInstances.push(instance);
  return instance;
};

// Default behavior: pass integrity check
let pragmaResults = [];
let pragmaCallIndex = 0;

vi.mock('better-sqlite3', () => {
  const MockDb = vi.fn(function(dbPath, opts) {
    let pragmaResult;
    if (pragmaResults.length > 0) {
      pragmaResult = pragmaResults[pragmaCallIndex] || pragmaResults[pragmaResults.length - 1];
      pragmaCallIndex++;
    } else {
      pragmaResult = [{ integrity_check: 'ok' }];
    }
    const instance = createMockDbInstance(pragmaResult);
    return instance;
  });
  return { default: MockDb };
});

// Mock logger
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn(),
  }
}));

// Mock config
const mockConfig = {
  raja: {
    dataDir: '',
    backupDir: '',
    home: '/opt/raja-bot',
  },
  telegram: {
    token: 'test-token',
    allowedUserId: 12345,
  },
  memory: {
    retentionDays: 30,
  },
};

vi.mock('../../src/config.js', () => ({
  config: mockConfig,
}));

// Mock global fetch for notifyOwnerRestore
global.fetch = vi.fn().mockResolvedValue({ ok: true });

describe('checkIntegrity()', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'raja-integrity-'));
    mockInstances = [];
    pragmaResults = [];
    pragmaCallIndex = 0;
    vi.clearAllMocks();
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('returns true when PRAGMA integrity_check returns "ok"', async () => {
    const { checkIntegrity } = await import('../../src/core/memory.js');
    
    const dbPath = path.join(tmpDir, 'valid.db');
    fs.writeFileSync(dbPath, 'dummy');

    pragmaResults = [[{ integrity_check: 'ok' }]];
    
    const result = checkIntegrity(dbPath);
    
    expect(result).toBe(true);
    expect(mockInstances.length).toBeGreaterThan(0);
    const lastInstance = mockInstances[mockInstances.length - 1];
    expect(lastInstance.pragma).toHaveBeenCalledWith('integrity_check');
    expect(lastInstance.close).toHaveBeenCalled();
  });

  it('returns false when PRAGMA integrity_check returns error', async () => {
    const { checkIntegrity } = await import('../../src/core/memory.js');
    
    const dbPath = path.join(tmpDir, 'bad.db');
    fs.writeFileSync(dbPath, 'dummy');

    pragmaResults = [[{ integrity_check: 'corruption found on page 5' }]];

    const result = checkIntegrity(dbPath);
    
    expect(result).toBe(false);
  });

  it('returns false for a non-existent file', async () => {
    const { checkIntegrity } = await import('../../src/core/memory.js');
    
    const result = checkIntegrity(path.join(tmpDir, 'nonexistent.db'));
    
    expect(result).toBe(false);
  });

  it('returns false when Database constructor throws', async () => {
    const { checkIntegrity } = await import('../../src/core/memory.js');
    
    const dbPath = path.join(tmpDir, 'throws.db');
    fs.writeFileSync(dbPath, 'dummy');

    // Override mock to throw for this specific call
    const Database = (await import('better-sqlite3')).default;
    Database.mockImplementationOnce(() => {
      throw new Error('file is not a database');
    });

    const result = checkIntegrity(dbPath);
    
    expect(result).toBe(false);
  });

  it('returns false when pragma result is empty array', async () => {
    const { checkIntegrity } = await import('../../src/core/memory.js');
    
    const dbPath = path.join(tmpDir, 'empty-result.db');
    fs.writeFileSync(dbPath, 'dummy');

    pragmaResults = [[]];

    const result = checkIntegrity(dbPath);
    
    expect(result).toBe(false);
  });
});

describe('restoreFromBackup()', () => {
  let tmpDir;

  beforeEach(() => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'raja-restore-'));
    mockConfig.raja.dataDir = tmpDir;
    mockConfig.raja.backupDir = path.join(tmpDir, 'backups');
    mockInstances = [];
    pragmaResults = [];
    pragmaCallIndex = 0;
    vi.clearAllMocks();
  });

  afterEach(() => {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('returns success=false when no backup directory exists', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    mockConfig.raja.backupDir = path.join(tmpDir, 'nonexistent');

    const result = restoreFromBackup();
    
    expect(result.success).toBe(false);
    expect(result.backupUsed).toBe(null);
  });

  it('returns success=false when backup directory is empty', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    const result = restoreFromBackup();
    
    expect(result.success).toBe(false);
    expect(result.backupUsed).toBe(null);
  });

  it('restores from the newest valid backup (sorted by filename)', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    fs.writeFileSync(path.join(backupDir, 'memory_20240101_120000.db'), 'older');
    fs.writeFileSync(path.join(backupDir, 'memory_20240115_120000.db'), 'middle');
    fs.writeFileSync(path.join(backupDir, 'memory_20240120_120000.db'), 'newest');

    // All pass integrity check
    pragmaResults = [
      [{ integrity_check: 'ok' }],
      [{ integrity_check: 'ok' }],
      [{ integrity_check: 'ok' }],
    ];

    const result = restoreFromBackup();
    
    expect(result.success).toBe(true);
    expect(result.backupUsed).toBe('memory_20240120_120000.db');
  });

  it('skips corrupt backups and uses next valid one', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    fs.writeFileSync(path.join(backupDir, 'memory_20240110_120000.db'), 'older valid');
    fs.writeFileSync(path.join(backupDir, 'memory_20240120_120000.db'), 'newest corrupt');

    // First (newest) fails, second (older) passes
    pragmaResults = [
      [{ integrity_check: 'corruption on page 3' }],
      [{ integrity_check: 'ok' }],
    ];

    const result = restoreFromBackup();
    
    expect(result.success).toBe(true);
    expect(result.backupUsed).toBe('memory_20240110_120000.db');
  });

  it('creates empty database when all backups fail integrity check', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    fs.writeFileSync(path.join(backupDir, 'memory_20240120_120000.db'), 'corrupt1');
    fs.writeFileSync(path.join(backupDir, 'memory_20240110_120000.db'), 'corrupt2');

    pragmaResults = [
      [{ integrity_check: 'corruption' }],
      [{ integrity_check: 'corruption' }],
    ];

    const result = restoreFromBackup();
    
    expect(result.success).toBe(false);
    expect(result.backupUsed).toBe(null);
  });

  it('only considers files matching memory_*.db pattern', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    // Non-matching files
    fs.writeFileSync(path.join(backupDir, 'other_backup.db'), 'ignored');
    fs.writeFileSync(path.join(backupDir, 'memory_20240120_120000.txt'), 'wrong ext');
    fs.writeFileSync(path.join(backupDir, 'backup_20240120_120000.db'), 'wrong prefix');
    // One valid matching file
    fs.writeFileSync(path.join(backupDir, 'memory_20240110_120000.db'), 'valid');

    pragmaResults = [[{ integrity_check: 'ok' }]];

    const result = restoreFromBackup();
    
    expect(result.success).toBe(true);
    expect(result.backupUsed).toBe('memory_20240110_120000.db');
  });

  it('notifies owner on successful restore', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });

    fs.writeFileSync(path.join(backupDir, 'memory_20240120_120000.db'), 'valid');
    pragmaResults = [[{ integrity_check: 'ok' }]];

    restoreFromBackup();
    
    // Allow async notifyOwnerRestore to fire
    await new Promise(r => setTimeout(r, 50));

    expect(global.fetch).toHaveBeenCalled();
    const fetchCall = global.fetch.mock.calls[0];
    expect(fetchCall[0]).toContain('api.telegram.org');
    const body = JSON.parse(fetchCall[1].body);
    expect(body.text).toContain('Database Restored');
    expect(body.text).toContain('memory_20240120_120000.db');
  });

  it('notifies owner on failed restore (no valid backups)', async () => {
    const { restoreFromBackup } = await import('../../src/core/memory.js');
    const backupDir = path.join(tmpDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });
    // No backup files

    restoreFromBackup();
    
    // Allow async notifyOwnerRestore to fire
    await new Promise(r => setTimeout(r, 50));

    expect(global.fetch).toHaveBeenCalled();
    const fetchCall = global.fetch.mock.calls[0];
    const body = JSON.parse(fetchCall[1].body);
    expect(body.text).toContain('Restore Failed');
  });
});
