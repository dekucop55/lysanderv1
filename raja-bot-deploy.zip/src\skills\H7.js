// src/skills/H7.js — Hermes: SIWE, WalletConnect, EIP-712, ENS, Permit
// TODO: Wire intent detection to hermes/auth.js or hermes/siwe.js when module is created.
// Expected exports: generateSiweMessage, verifySiweMessage, resolveEns, signTypedData, generatePermit
// Intent patterns to detect: "resolve ENS <name>", "sign message <msg>",
// "generate permit <token> <spender> <amount>", "verify signature <sig>"
import { logger } from '../utils/logger.js';

/**
 * Detect actionable SIWE/Auth intent from natural language query.
 * Currently returns null (LLM-only) — will be wired to hermes module in future.
 *
 * TODO: Implement when hermes/auth.js or hermes/siwe.js exports are available:
 * - "resolve <name>.eth" → resolveEns({ name })
 * - "sign message <message> wallet <label>" → signMessage
 * - "generate permit <token> for <spender> <amount>" → generatePermit
 * - "verify siwe <message> <signature>" → verifySiweMessage
 * - "generate siwe for <domain>" → generateSiweMessage
 */
function detectAuthIntent(query) {
  // TODO: Implement when hermes module is ready
  // const q = query.trim();
  //
  // const ensMatch = q.match(/(?:resolve|lookup|cari)\s+(\S+\.eth)/i);
  // if (ensMatch) return { intent: 'RESOLVE_ENS', params: { name: ensMatch[1] } };
  //
  // const permitMatch = q.match(/(?:generate|buat)\s+permit\s+(\S+)\s+(?:for|untuk)\s+(\S+)\s+([\d.]+)/i);
  // if (permitMatch) return { intent: 'GENERATE_PERMIT', params: { token: permitMatch[1], spender: permitMatch[2], amount: permitMatch[3] } };
  //
  return null;
}

export default {
  id: 'H7',
  name: 'siwe',
  description: 'Sign-In with Ethereum, WalletConnect, EIP-712 typed data, ENS resolution, Permit signatures',

  async execute(query, context) {
    // 1. Attempt intent detection (currently LLM-only, TODO: wire to hermes)
    const intent = detectAuthIntent(query);

    if (intent) {
      // TODO: Handle actionable auth intents here when hermes module is ready
      logger.info(`[H7] Auth intent detected: ${intent.intent}`, intent.params);
    }

    // 2. LLM cascade for all SIWE/auth queries
    try {
      const { callCascade } = await import('../llm/cascade.js');

      const messages = [
        {
          role: 'system',
          content: `Kamu adalah RAJA. Hermes skill aktif: H7 (SIWE/Auth/ENS).
Mode: precise, security-conscious.

Kamu adalah expert Web3 authentication & signing:

Core Capabilities:
- SIWE (EIP-4361): Sign-In With Ethereum message generation, signing, verification
- EIP-712: Typed structured data signing (human-readable approval)
- EIP-2612 Permit: Gasless token approvals via signature
- ENS: Forward resolution (name→address), reverse (address→name)
- WalletConnect v2: Pairing, session management, request handling
- Off-chain governance: Snapshot.org voting with signatures

Implementation Guidance:
- SIWE flow: generate nonce → create message → sign → verify server-side
- EIP-712: define domain separator + type hash → sign → verify on-chain or off-chain
- Permit: encode permit data → sign EIP-712 → submit permit() call (gasless for user)
- ENS: use ethers.js provider.resolveName() / provider.lookupAddress()

Security Rules (ALWAYS enforce):
- Verify domain matches expected dApp before signing SIWE
- Check nonce freshness (prevent replay attacks)
- EIP-712: verify all struct fields match expected values
- Never sign messages with unclear intent or suspicious domains
- Permit: verify spender address is legitimate contract
- WalletConnect: verify bridge URL is official

Code Output:
- Berikan implementation code yang production-ready
- Include error handling dan security checks
- Comment explaining security decisions
- Test cases untuk verification flow`,
        },
        { role: 'user', content: query },
      ];

      const result = await callCascade(messages, { maxTokens: 1500, temperature: 0.3 });
      return result.text;
    } catch (err) {
      logger.error(`[H7] LLM cascade failed: ${err.message}`);
      return `❌ Gagal memproses pertanyaan SIWE/Auth: ${err.message}`;
    }
  },
};
