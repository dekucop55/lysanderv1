// tests/unit/auto-push-retry.test.js
//
// Unit tests for AutoPushScheduler retry logic and error classification (Task 9.3)
// Validates: Requirements 6.4, 6.6

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { AutoPushScheduler } from '../../src/core/auto-push.js';
import { execSync } from 'child_process';

// Mock node-cron
vi.mock('node-cron', () => ({
  default: {
    schedule: vi.fn((schedule, callback) => {
      return { stop: vi.fn(), _callback: callback };
    })
  }
}));

// Mock child_process
vi.mock('child_process', () => ({
  execSync: vi.fn()
}));

// Mock logger
vi.mock('../../src/utils/logger.js', () => ({
  logger: {
    info: vi.fn(),
    warn: vi.fn(),
    error: vi.fn()
  }
}));

describe('AutoPushScheduler — executeGitPush retry logic (Task 9.3)', () => {
  let scheduler;

  beforeEach(() => {
    scheduler = new AutoPushScheduler({
      maxRetries: 3,
      retryIntervalMs: 100, // Use short interval for tests
      pushTimeoutMs: 120000,
      logFile: 'logs/test-retry.log'
    });
    // Spy on notifyOwner
    scheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  const changes = {
    codeFiles: ['src/index.js', 'src/utils.js'],
    dataFiles: ['data/memory.db']
  };
  const commitMsg = '[auto-sync] 2025-06-15 | code: 2 files | data: 1 files';

  describe('successful push', () => {
    it('should stage files, commit, and push successfully on first attempt', async () => {
      execSync.mockReturnValue('');

      const promise = scheduler.executeGitPush(commitMsg, changes);
      await promise;

      // git add called with all files
      expect(execSync).toHaveBeenCalledWith(
        'git add src/index.js src/utils.js data/memory.db',
        expect.objectContaining({ cwd: process.cwd(), encoding: 'utf8', timeout: 30000 })
      );

      // git commit called with commit message
      expect(execSync).toHaveBeenCalledWith(
        `git commit -m "${commitMsg}"`,
        expect.objectContaining({ cwd: process.cwd(), encoding: 'utf8', timeout: 30000 })
      );

      // git push called with pushTimeoutMs
      expect(execSync).toHaveBeenCalledWith(
        'git push',
        expect.objectContaining({ cwd: process.cwd(), encoding: 'utf8', timeout: 120000 })
      );

      // No notification needed
      expect(scheduler.notifyOwner).not.toHaveBeenCalled();
    });

    it('should use pushTimeoutMs (120s) for git push timeout', async () => {
      execSync.mockReturnValue('');
      await scheduler.executeGitPush(commitMsg, changes);

      const pushCall = execSync.mock.calls.find(call => call[0] === 'git push');
      expect(pushCall[1].timeout).toBe(120000);
    });
  });

  describe('network/timeout errors — retry behavior (Requirement 6.4)', () => {
    it('should retry up to 3 times on network error then notify', async () => {
      vi.useRealTimers();
      const shortScheduler = new AutoPushScheduler({
        maxRetries: 3,
        retryIntervalMs: 10, // very short for test speed
        pushTimeoutMs: 120000,
        logFile: 'logs/test-retry.log'
      });
      shortScheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      const networkError = new Error('ECONNREFUSED: connection refused');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw networkError;
        return '';
      });

      await expect(
        shortScheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('ECONNREFUSED');

      // Should have been called 4 times total (initial + 3 retries)
      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(4);

      // Should notify owner after all retries exhausted
      expect(shortScheduler.notifyOwner).toHaveBeenCalledWith(
        expect.objectContaining({
          status: 'failed',
          error: 'ECONNREFUSED: connection refused'
        }),
        3 // maxRetries
      );
    });

    it('should retry on timeout error', async () => {
      vi.useRealTimers();
      const shortScheduler = new AutoPushScheduler({
        maxRetries: 3,
        retryIntervalMs: 10,
        pushTimeoutMs: 120000,
        logFile: 'logs/test-retry.log'
      });
      shortScheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      const timeoutError = new Error('Command timeout: ETIMEDOUT');
      let pushAttempts = 0;

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') {
          pushAttempts++;
          if (pushAttempts <= 2) throw timeoutError;
          return ''; // succeed on 3rd attempt
        }
        return '';
      });

      await shortScheduler.executeGitPush(commitMsg, changes);

      expect(pushAttempts).toBe(3); // 2 failures + 1 success
      expect(shortScheduler.notifyOwner).not.toHaveBeenCalled();
    });

    it('should succeed if push works after some retries', async () => {
      vi.useRealTimers();
      const shortScheduler = new AutoPushScheduler({
        maxRetries: 3,
        retryIntervalMs: 10,
        pushTimeoutMs: 120000,
        logFile: 'logs/test-retry.log'
      });
      shortScheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      let pushAttempts = 0;
      const networkError = new Error('network timeout');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') {
          pushAttempts++;
          if (pushAttempts <= 1) throw networkError;
          return ''; // succeed on 2nd attempt
        }
        return '';
      });

      await shortScheduler.executeGitPush(commitMsg, changes);

      expect(pushAttempts).toBe(2);
      expect(shortScheduler.notifyOwner).not.toHaveBeenCalled();
    });

    it('should wait retryIntervalMs between retries', async () => {
      vi.useRealTimers();
      const retryInterval = 50; // 50ms for testability
      const shortScheduler = new AutoPushScheduler({
        maxRetries: 3,
        retryIntervalMs: retryInterval,
        pushTimeoutMs: 120000,
        logFile: 'logs/test-retry.log'
      });
      shortScheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      const networkError = new Error('ENOTFOUND github.com');
      const attemptTimestamps = [];

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') {
          attemptTimestamps.push(Date.now());
          throw networkError;
        }
        return '';
      });

      await expect(
        shortScheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('ENOTFOUND');

      // Should have 4 attempt timestamps
      expect(attemptTimestamps).toHaveLength(4);

      // Verify intervals between attempts are approximately retryIntervalMs
      for (let i = 1; i < attemptTimestamps.length; i++) {
        const diff = attemptTimestamps[i] - attemptTimestamps[i - 1];
        // Allow some tolerance (at least 40ms for a 50ms interval)
        expect(diff).toBeGreaterThanOrEqual(retryInterval - 15);
        expect(diff).toBeLessThan(retryInterval + 50);
      }
    });
  });

  describe('auth/conflict errors — no retry (Requirement 6.6)', () => {
    it('should NOT retry on auth error and notify immediately', async () => {
      const authError = new Error('authentication failed: invalid token');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw authError;
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('authentication failed');

      // Only ONE push attempt (no retries)
      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(1);

      // Notify owner immediately
      expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
      expect(scheduler.notifyOwner).toHaveBeenCalledWith(
        expect.objectContaining({
          status: 'failed',
          error: 'authentication failed: invalid token'
        }),
        0 // first attempt
      );
    });

    it('should NOT retry on 403 Forbidden error', async () => {
      const forbiddenError = new Error('403 Forbidden: access denied');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw forbiddenError;
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('403 Forbidden');

      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(1);
      expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
    });

    it('should NOT retry on conflict/merge error', async () => {
      const conflictError = new Error('non-fast-forward update rejected');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw conflictError;
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('non-fast-forward');

      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(1);
      expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
    });

    it('should NOT retry on merge conflict error', async () => {
      const mergeError = new Error('merge conflict detected');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw mergeError;
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('merge conflict');

      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(1);
      expect(scheduler.notifyOwner).toHaveBeenCalledTimes(1);
    });

    it('should NOT retry on permission denied error', async () => {
      const permError = new Error('permission denied to push');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw permError;
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('permission denied');

      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(1);
    });
  });

  describe('unknown errors — retry behavior', () => {
    it('should retry unknown errors (treated like network errors)', async () => {
      vi.useRealTimers();
      const shortScheduler = new AutoPushScheduler({
        maxRetries: 3,
        retryIntervalMs: 10,
        pushTimeoutMs: 120000,
        logFile: 'logs/test-retry.log'
      });
      shortScheduler.notifyOwner = vi.fn().mockResolvedValue(undefined);

      const unknownError = new Error('unexpected repository state');

      execSync.mockImplementation((cmd) => {
        if (cmd === 'git push') throw unknownError;
        return '';
      });

      await expect(
        shortScheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('unexpected repository state');

      // Should attempt 4 times (initial + 3 retries)
      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(4);

      expect(shortScheduler.notifyOwner).toHaveBeenCalledWith(
        expect.objectContaining({ status: 'failed' }),
        3
      );
    });
  });

  describe('git add / commit failures', () => {
    it('should throw immediately if git add fails', async () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.startsWith('git add')) throw new Error('git add failed: pathspec not found');
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('git add failed');

      // No push should be attempted
      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(0);
    });

    it('should throw immediately if git commit fails', async () => {
      execSync.mockImplementation((cmd) => {
        if (cmd.startsWith('git commit')) throw new Error('nothing to commit');
        return '';
      });

      await expect(
        scheduler.executeGitPush(commitMsg, changes)
      ).rejects.toThrow('nothing to commit');

      // No push should be attempted
      const pushCalls = execSync.mock.calls.filter(call => call[0] === 'git push');
      expect(pushCalls).toHaveLength(0);
    });
  });

  describe('integration with triggerPush()', () => {
    it('should call executeGitPush from triggerPush when changes exist', async () => {
      // Mock detectChanges to return some changes
      scheduler.detectChanges = vi.fn().mockResolvedValue({
        codeFiles: ['src/index.js'],
        dataFiles: ['data/test.db']
      });

      // Mock executeGitPush to succeed
      scheduler.executeGitPush = vi.fn().mockResolvedValue(undefined);

      const result = await scheduler.triggerPush();

      expect(result.status).toBe('success');
      expect(scheduler.executeGitPush).toHaveBeenCalledWith(
        expect.stringContaining('[auto-sync]'),
        { codeFiles: ['src/index.js'], dataFiles: ['data/test.db'] }
      );
    });

    it('should return failed status when executeGitPush throws', async () => {
      scheduler.detectChanges = vi.fn().mockResolvedValue({
        codeFiles: ['src/index.js'],
        dataFiles: []
      });

      scheduler.executeGitPush = vi.fn().mockRejectedValue(new Error('push failed'));

      const result = await scheduler.triggerPush();

      expect(result.status).toBe('failed');
      expect(result.error).toBe('push failed');
    });

    it('should still skip when no changes are detected', async () => {
      execSync.mockReturnValue('');

      const result = await scheduler.triggerPush();

      expect(result.status).toBe('skipped');
      expect(result.error).toBeNull();
    });
  });
});
