// src/self-upgrade/rollback.js — Rollback to previous version
import { exec } from 'child_process';
import { promisify } from 'util';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import { listBackups, restoreBackup } from './backup.js';
import { healthCheck } from './healthcheck.js';

const execAsync = promisify(exec);

/**
 * Rollback to specific commit or latest backup
 * @param {string|null} target - git ref (e.g. HEAD@{1}) or null for latest backup
 */
export async function rollback(target = null) {
  logger.info(`[rollback] Starting rollback. Target: ${target || 'latest backup'}`);

  try {
    if (target) {
      // Git-based rollback
      await execAsync(`git checkout ${target}`, { cwd: config.raja.home });
      await execAsync('npm ci --production', { cwd: config.raja.home, timeout: 300000 });
      logger.info(`[rollback] Git rollback to ${target} done`);
    } else {
      // File-based backup rollback
      const backups = await listBackups();
      if (backups.length === 0) {
        throw new Error('No backups available for rollback');
      }
      const latest = backups[0];
      logger.info(`[rollback] Restoring backup: ${latest.id}`);
      await restoreBackup(latest.id);
    }

    // Restart
    await restartBot();

    // Health check
    const health = await healthCheck({ retries: 5, interval: 8000 });
    if (!health.ok) {
      throw new Error(`Health check failed after rollback: ${health.error}`);
    }

    logger.info('[rollback] Success. Bot healthy.');
    return { success: true, target };
  } catch (err) {
    logger.error(`[rollback] FAILED: ${err.message}`);
    return { success: false, error: err.message };
  }
}

async function restartBot() {
  try {
    await execAsync('systemctl restart raja-bot.service');
  } catch {
    try {
      await execAsync('pm2 restart raja-bot');
    } catch {
      await execAsync('pkill -f "node src/index.js" || true');
    }
  }
}
