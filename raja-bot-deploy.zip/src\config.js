// src/config.js — Environment loader & validator
import 'dotenv/config';
import fs from 'fs';
import path from 'path';

const required = ['BOT_TOKEN', 'ALLOWED_USER_ID'];

/**
 * Load flexible LLM provider slots (2-9) from environment variables.
 * Format: LLM_N_NAME, LLM_N_URL, LLM_N_KEY, LLM_N_MODEL
 * All OpenAI-compatible. Ganti provider = ganti env vars, restart.
 */
function loadLlmSlots() {
  const slots = {};
  for (let i = 2; i <= 9; i++) {
    const name = process.env[`LLM_${i}_NAME`];
    const url = process.env[`LLM_${i}_URL`];
    const key = process.env[`LLM_${i}_KEY`];
    const model = process.env[`LLM_${i}_MODEL`];
    if (name || url || key || model) {
      slots[i] = { name: name || `provider-${i}`, url, key, model };
    }
  }
  return slots;
}

function load() {
  return {
    server: {
      port: parseInt(process.env.PORT || '3000'),
      ip: process.env.SERVER_IP || '0.0.0.0',
      env: process.env.NODE_ENV || 'production',
    },
    telegram: {
      token: process.env.BOT_TOKEN,
      allowedUserId: parseInt(process.env.ALLOWED_USER_ID || '0'),
    },
    llm: {
      // Legacy (backward compat — used if LLM_1_* not defined)
      ollamaCloud: {
        url: process.env.OLLAMA_CLOUD_URL || 'https://api.ollama.com',
        apiKey: process.env.GEMMA4_API_KEY,
        model: process.env.OLLAMA_MODEL_PRIMARY || 'gemma4:31b',
      },
      openrouter: {
        apiKey: process.env.OPENROUTER_API_KEY,
      },
      bai: {
        apiKey: process.env.BAI_API_KEY,
      },
      // New: all slots read at cascade.js level from process.env directly
      slots: loadLlmSlots(),
    },
    raja: {
      home: process.env.RAJA_HOME || '/opt/raja-bot',
      gitRepo: process.env.RAJA_GIT_REPO,
      gitBranch: process.env.RAJA_GIT_BRANCH || 'main',
      dataDir: process.env.RAJA_DATA_DIR || '/opt/raja-bot/data',
      logDir: process.env.RAJA_LOG_DIR || '/opt/raja-bot/logs',
      backupDir: process.env.RAJA_BACKUP_DIR || '/opt/raja-bot/data/backups',
    },
    watchdog: {
      heartbeatPath: process.env.WATCHDOG_HEARTBEAT_PATH || '/opt/raja-bot/data/heartbeat',
      maxRestartPerHour: parseInt(process.env.WATCHDOG_MAX_RESTART_PER_HOUR || '5'),
      alertThreshold: parseInt(process.env.WATCHDOG_ALERT_THRESHOLD || '3'),
    },
    governor: {
      masterPw: process.env.HERMES_MASTER_PW,
      maxTxUsd: parseFloat(process.env.HERMES_MAX_TX_USD || '500'),
      dailyCapUsd: parseFloat(process.env.HERMES_DAILY_CAP_USD || '2000'),
      sessionCapUsd: parseFloat(process.env.HERMES_SESSION_CAP_USD || '1000'),
      maxSlippagePct: parseFloat(process.env.HERMES_MAX_SLIPPAGE_PCT || '5'),
      maxGasMultiple: parseFloat(process.env.HERMES_MAX_GAS_MULTIPLE || '4'),
      killswitch: process.env.HERMES_KILLSWITCH,
    },
    rpc: {
      evm: {
        ethereum: process.env.RPC_EVM_ETHEREUM,
        base: process.env.RPC_EVM_BASE,
        arbitrum: process.env.RPC_EVM_ARBITRUM,
        optimism: process.env.RPC_EVM_OPTIMISM,
        polygon: process.env.RPC_EVM_POLYGON,
        bsc: process.env.RPC_EVM_BSC,
        avalanche: process.env.RPC_EVM_AVALANCHE,
      },
      wsEvm: {
        ethereum: process.env.WS_RPC_EVM_ETHEREUM,
      },
      solana: process.env.RPC_SOLANA,
    },
    cryptoApis: {
      oneinch: process.env.ONEINCH_API_KEY,
      reservoir: process.env.RESERVOIR_API_KEY,
      opensea: process.env.OPENSEA_API_KEY,
      birdeye: process.env.BIRDEYE_API_KEY,
      nansen: process.env.NANSEN_API_KEY,
      arkham: process.env.ARKHAM_API_KEY,
      zerion: process.env.ZERION_API_KEY_B64,
      dune: process.env.DUNE_API_KEY,
    },
    frozenPaths: (process.env.FROZEN_PATHS || '').split(',').filter(Boolean),
    memory: {
      retentionDays: parseInt(process.env.MEMORY_RETENTION_DAYS || '30'),
    },
    marketplace: {
      quarantineDir: process.env.SKILL_QUARANTINE_DIR || 'src/skills/_quarantine',
      downloadTimeout: parseInt(process.env.SKILL_DOWNLOAD_TIMEOUT || '30000'),
      allowedHosts: (process.env.SKILL_ALLOWED_HOSTS || 'github.com,raw.githubusercontent.com').split(','),
    },
  };
}

function validateConfig() {
  const cfg = load();
  const missing = [];
  for (const key of required) {
    const val = key === 'BOT_TOKEN' ? cfg.telegram.token : cfg.telegram.allowedUserId;
    if (!val) missing.push(key);
  }
  return { valid: missing.length === 0, missing };
}

export const config = load();
export { validateConfig, load };