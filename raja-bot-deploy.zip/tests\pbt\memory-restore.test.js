// tests/pbt/memory-restore.test.js
// Property-Based Test: Property 23 — Database Restore dari Backup Valid Terbaru
// **Validates: Requirements 7.3, 7.5**
//
// Property 23: *For any* set backup files, restore SHALL mencoba dari file terbaru ke terlama.
// File pertama yang lolos `PRAGMA integrity_check` SHALL digunakan.
// Jika tidak ada yang valid, database baru kosong dibuat.
//
// Format nama file: memory_{YYYYMMDD_HHmmss}.db in data/backups/
// Restore: sort descending (newest first), try each; use first that passes integrity check.
// If none pass: create empty database.

import { describe, it, expect } from 'vitest';
import * as fc from 'fast-check';

// ─── Pure restore logic (mirrors restoreFromBackup in memory.js) ─────────────

/**
 * Simulate the restoreFromBackup() logic from src/core/memory.js.
 *
 * The real implementation:
 *   1. List files matching memory_*.db in backupDir
 *   2. Sort descending by filename (newest first via localeCompare)
 *   3. Try each backup in order; the first one that passes checkIntegrity() is used
 *   4. If none pass: create empty database, notify owner
 *   5. If one passes: copy to dbPath, notify owner
 *
 * @param {Array<{name: string, valid: boolean}>} backupEntries - Backup files with validity flags
 * @returns {{
 *   success: boolean,
 *   backupUsed: string|null,
 *   trialOrder: string[],
 *   emptyDbCreated: boolean
 * }}
 */
function simulateRestoreFromBackup(backupEntries) {
  // Filter to only memory_*.db files (mirrors real implementation filter)
  const validEntries = backupEntries.filter(
    e => e.name.startsWith('memory_') && e.name.endsWith('.db')
  );

  if (validEntries.length === 0) {
    // No backup files available → create empty DB
    return {
      success: false,
      backupUsed: null,
      trialOrder: [],
      emptyDbCreated: true,
    };
  }

  // Sort descending: newest filename first (same as real impl)
  const sorted = [...validEntries].sort((a, b) => b.name.localeCompare(a.name));

  const trialOrder = [];

  // Try each backup from newest to oldest
  for (const entry of sorted) {
    trialOrder.push(entry.name);

    if (entry.valid) {
      // First valid backup found → restore from this one
      return {
        success: true,
        backupUsed: entry.name,
        trialOrder,
        emptyDbCreated: false,
      };
    }
  }

  // All backups failed integrity check → create empty DB
  return {
    success: false,
    backupUsed: null,
    trialOrder,
    emptyDbCreated: true,
  };
}

// ─── Generators ──────────────────────────────────────────────────────────────

/**
 * Generate a valid backup filename: memory_{YYYYMMDD_HHmmss}.db
 * Uses sequential timestamp offset from a base date to guarantee uniqueness.
 *
 * @param {number} index - Sequential index; higher index = newer timestamp
 * @returns {string}
 */
function makeBackupFilename(index) {
  // Start from a base date and increment by 1 hour per index → unique timestamps
  const base = new Date('2025-01-01T00:00:00Z');
  const ts = new Date(base.getTime() + index * 3600 * 1000);

  const YYYY = ts.getUTCFullYear();
  const MM = String(ts.getUTCMonth() + 1).padStart(2, '0');
  const DD = String(ts.getUTCDate()).padStart(2, '0');
  const HH = String(ts.getUTCHours()).padStart(2, '0');
  const mm = String(ts.getUTCMinutes()).padStart(2, '0');
  const ss = String(ts.getUTCSeconds()).padStart(2, '0');

  return `memory_${YYYY}${MM}${DD}_${HH}${mm}${ss}.db`;
}

/**
 * Arbitrary: generates a set of N backup files where at least one is valid.
 * The valid file can be at any position (newest, middle, or oldest).
 * Files are indexed 0..N-1, higher index = newer timestamp.
 *
 * @param {number} minCount - Minimum number of backups
 * @param {number} maxCount - Maximum number of backups
 * @returns {fc.Arbitrary<Array<{name: string, valid: boolean}>>}
 */
const backupSetWithAtLeastOneValid = (minCount, maxCount) =>
  fc.integer({ min: minCount, max: maxCount }).chain(n =>
    // Pick which index will be valid (at least one guaranteed)
    fc.integer({ min: 0, max: n - 1 }).chain(validIdx =>
      // Each other file may also be valid or invalid
      fc.array(fc.boolean(), { minLength: n, maxLength: n }).map(validityFlags => {
        const entries = Array.from({ length: n }, (_, i) => ({
          name: makeBackupFilename(i),
          // The guaranteed valid index is always valid; others follow the random flag
          valid: i === validIdx ? true : validityFlags[i],
        }));
        return entries;
      })
    )
  );

/**
 * Arbitrary: generates a set of N backup files where ALL are invalid.
 * Used for testing the "no valid backup" scenario.
 *
 * @param {number} minCount - Minimum number of backups (may be 0)
 * @param {number} maxCount - Maximum number of backups
 * @returns {fc.Arbitrary<Array<{name: string, valid: boolean}>>}
 */
const backupSetAllInvalid = (minCount, maxCount) =>
  fc.integer({ min: minCount, max: maxCount }).map(n =>
    Array.from({ length: n }, (_, i) => ({
      name: makeBackupFilename(i),
      valid: false,
    }))
  );

// ─── Property Tests ──────────────────────────────────────────────────────────

describe('Property 23: Database Restore dari Backup Valid Terbaru', () => {

  // ── Core property: newest-to-oldest trial order ──────────────────────────

  describe('Trial Order: Newest to Oldest', () => {
    it('**Validates: Requirements 7.3** — Restore tries backups from newest to oldest', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            // trialOrder must be sorted descending (newest first)
            for (let i = 0; i < result.trialOrder.length - 1; i++) {
              expect(result.trialOrder[i] > result.trialOrder[i + 1]).toBe(true);
            }
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — Trial order for all-invalid set is also newest-to-oldest', () => {
      fc.assert(
        fc.property(
          backupSetAllInvalid(2, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            // All files tried, sorted descending
            for (let i = 0; i < result.trialOrder.length - 1; i++) {
              expect(result.trialOrder[i] > result.trialOrder[i + 1]).toBe(true);
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Core property: first valid file is used ──────────────────────────────

  describe('First Valid Backup Is Used', () => {
    it('**Validates: Requirements 7.3** — The backup used is the first one that passes integrity check (newest valid)', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            // The result must be a success
            expect(result.success).toBe(true);
            expect(result.backupUsed).not.toBeNull();

            // The backup used must be the newest valid file
            const validEntries = entries.filter(
              e => e.name.startsWith('memory_') && e.name.endsWith('.db') && e.valid
            );
            const newestValid = validEntries.reduce((newest, e) =>
              e.name > newest.name ? e : newest
            );

            expect(result.backupUsed).toBe(newestValid.name);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — No backup newer than backupUsed was tried and passed', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(2, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            if (!result.success) return; // Skip if somehow no valid (shouldn't happen)

            const usedName = result.backupUsed;

            // All files tried BEFORE the used backup must have failed (i.e., been invalid)
            const triedBeforeUsed = result.trialOrder.slice(
              0, result.trialOrder.indexOf(usedName)
            );

            const entriesMap = Object.fromEntries(entries.map(e => [e.name, e.valid]));

            for (const triedFile of triedBeforeUsed) {
              expect(entriesMap[triedFile]).toBe(false);
            }
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — backupUsed is the newest valid file when valid file is at the beginning (newest)', () => {
      // Scenario: the first (newest) backup is the only valid one
      fc.assert(
        fc.property(
          fc.integer({ min: 2, max: 8 }).map(n =>
            // Index n-1 is the newest; make it valid, all others invalid
            Array.from({ length: n }, (_, i) => ({
              name: makeBackupFilename(i),
              valid: i === n - 1, // Only the newest is valid
            }))
          ),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            expect(result.success).toBe(true);
            const newestFile = makeBackupFilename(entries.length - 1);
            expect(result.backupUsed).toBe(newestFile);
            // Only one file tried (the first one was valid)
            expect(result.trialOrder.length).toBe(1);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('**Validates: Requirements 7.3** — backupUsed is the oldest valid file when it is the only valid one at the end', () => {
      // Scenario: only the oldest (index 0) backup is valid
      fc.assert(
        fc.property(
          fc.integer({ min: 2, max: 8 }).map(n =>
            // Index 0 is the oldest; make it valid, all others invalid
            Array.from({ length: n }, (_, i) => ({
              name: makeBackupFilename(i),
              valid: i === 0, // Only the oldest is valid
            }))
          ),
          (entries) => {
            const n = entries.length;
            const result = simulateRestoreFromBackup(entries);

            expect(result.success).toBe(true);
            const oldestFile = makeBackupFilename(0);
            expect(result.backupUsed).toBe(oldestFile);
            // All files were tried (oldest was last and first valid)
            expect(result.trialOrder.length).toBe(n);
          }
        ),
        { numRuns: 100 }
      );
    });

    it('**Validates: Requirements 7.3** — backupUsed is the middle valid file when earlier ones fail', () => {
      // Scenario: N backups; some invalid at top, then first valid in the middle
      fc.assert(
        fc.property(
          fc.integer({ min: 3, max: 9 }).chain(n =>
            fc.integer({ min: 1, max: n - 1 }).map(validIdx => ({
              n,
              validIdx,
              // All indices BELOW validIdx (newer) are invalid; validIdx and above may vary
              entries: Array.from({ length: n }, (_, i) => ({
                name: makeBackupFilename(i),
                // Files newer than validIdx (i > validIdx) are invalid; validIdx is valid
                valid: i === validIdx,
              })),
            }))
          ),
          ({ n, validIdx, entries }) => {
            const result = simulateRestoreFromBackup(entries);

            const validFile = makeBackupFilename(validIdx);
            expect(result.success).toBe(true);
            expect(result.backupUsed).toBe(validFile);

            // Tried all files newer than validIdx plus validIdx itself
            // In sorted-desc order, valid file is at position: (n-1) - validIdx
            const expectedTrialCount = (n - 1) - validIdx + 1;
            expect(result.trialOrder.length).toBe(expectedTrialCount);
          }
        ),
        { numRuns: 100 }
      );
    });
  });

  // ── No valid backups → empty DB created ──────────────────────────────────

  describe('No Valid Backups: Empty Database Created', () => {
    it('**Validates: Requirements 7.5** — If all backups fail integrity check, empty DB is created', () => {
      fc.assert(
        fc.property(
          backupSetAllInvalid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            expect(result.success).toBe(false);
            expect(result.backupUsed).toBeNull();
            expect(result.emptyDbCreated).toBe(true);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.5** — If no backup files exist, empty DB is created', () => {
      // Empty set
      const result = simulateRestoreFromBackup([]);

      expect(result.success).toBe(false);
      expect(result.backupUsed).toBeNull();
      expect(result.emptyDbCreated).toBe(true);
      expect(result.trialOrder.length).toBe(0);
    });

    it('**Validates: Requirements 7.5** — All files are tried before giving up', () => {
      fc.assert(
        fc.property(
          backupSetAllInvalid(1, 10),
          (entries) => {
            const validEntries = entries.filter(
              e => e.name.startsWith('memory_') && e.name.endsWith('.db')
            );
            const result = simulateRestoreFromBackup(entries);

            // All valid backup files must have been tried
            expect(result.trialOrder.length).toBe(validEntries.length);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.5** — Non-matching files are ignored even when all valid files fail', () => {
      // Mix of non-matching files + all-invalid matching files
      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 5 }).chain(invalidCount =>
            fc.integer({ min: 1, max: 5 }).map(nonMatchCount => {
              const invalidBackups = Array.from({ length: invalidCount }, (_, i) => ({
                name: makeBackupFilename(i),
                valid: false,
              }));
              const nonMatchingFiles = [
                ...Array.from({ length: nonMatchCount }, (_, i) => ({
                  name: `other_${i}.db`,
                  valid: true, // These would pass integrity but should be ignored
                })),
                ...Array.from({ length: nonMatchCount }, (_, i) => ({
                  name: `memory_${i}.txt`,
                  valid: true,
                })),
              ];
              return [...invalidBackups, ...nonMatchingFiles];
            })
          ),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);

            // Non-matching files should not count; only invalid memory_*.db tried
            expect(result.success).toBe(false);
            expect(result.emptyDbCreated).toBe(true);

            // All trials should be valid memory_*.db files
            for (const triedFile of result.trialOrder) {
              expect(triedFile.startsWith('memory_')).toBe(true);
              expect(triedFile.endsWith('.db')).toBe(true);
            }
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── First valid backup stops the search ──────────────────────────────────

  describe('Early Stop: Restore Halts at First Valid Backup', () => {
    it('**Validates: Requirements 7.3** — Files after the first valid backup are NOT tried', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(2, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            if (!result.success) return;

            const usedIdx = result.trialOrder.indexOf(result.backupUsed);
            // usedIdx is the last position in trialOrder; no files after it should have been tried
            expect(usedIdx).toBe(result.trialOrder.length - 1);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — Total trials equals position of first valid backup in sorted order', () => {
      // When we have exactly one valid backup (at a known position), trials should stop there
      fc.assert(
        fc.property(
          fc.integer({ min: 1, max: 8 }).chain(n =>
            fc.integer({ min: 0, max: n - 1 }).map(validIdx => {
              // In sorted-desc order, index n-1 is newest. validIdx in sorted order is: (n-1) - validIdx
              return {
                n,
                validIdx,
                entries: Array.from({ length: n }, (_, i) => ({
                  name: makeBackupFilename(i),
                  valid: i === validIdx,
                })),
              };
            })
          ),
          ({ n, validIdx, entries }) => {
            const result = simulateRestoreFromBackup(entries);

            // In sorted-desc order (newest first), the entry with makeBackupFilename(validIdx)
            // is at position (n - 1 - validIdx) from the start
            const positionInSortedOrder = (n - 1) - validIdx;
            // Number of trials = positionInSortedOrder + 1 (for the valid file itself)
            expect(result.trialOrder.length).toBe(positionInSortedOrder + 1);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Result invariants ─────────────────────────────────────────────────────

  describe('Result Invariants', () => {
    it('**Validates: Requirements 7.3, 7.5** — success=true implies backupUsed is non-null', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            // With at least one valid backup, result.success should be true
            expect(result.success).toBe(true);
            expect(result.backupUsed).not.toBeNull();
            expect(result.backupUsed).toBeDefined();
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3, 7.5** — success=false implies backupUsed is null and emptyDbCreated=true', () => {
      fc.assert(
        fc.property(
          backupSetAllInvalid(0, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            expect(result.success).toBe(false);
            expect(result.backupUsed).toBeNull();
            expect(result.emptyDbCreated).toBe(true);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — backupUsed is always a valid memory_*.db filename', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            expect(result.backupUsed).toMatch(/^memory_\d{8}_\d{6}\.db$/);
          }
        ),
        { numRuns: 200 }
      );
    });

    it('**Validates: Requirements 7.3** — backupUsed is a file that actually passed validity check', () => {
      fc.assert(
        fc.property(
          backupSetWithAtLeastOneValid(1, 10),
          (entries) => {
            const result = simulateRestoreFromBackup(entries);
            const usedEntry = entries.find(e => e.name === result.backupUsed);
            expect(usedEntry).toBeDefined();
            expect(usedEntry.valid).toBe(true);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Determinism ──────────────────────────────────────────────────────────

  describe('Determinism', () => {
    it('**Validates: Requirements 7.3, 7.5** — Same backup set always produces the same restore result', () => {
      fc.assert(
        fc.property(
          // Mix valid and invalid
          fc.integer({ min: 0, max: 10 }).chain(n =>
            fc.array(fc.boolean(), { minLength: n, maxLength: n }).map(flags =>
              Array.from({ length: n }, (_, i) => ({
                name: makeBackupFilename(i),
                valid: flags[i],
              }))
            )
          ),
          (entries) => {
            const result1 = simulateRestoreFromBackup(entries);
            const result2 = simulateRestoreFromBackup(entries);

            expect(result1.success).toBe(result2.success);
            expect(result1.backupUsed).toBe(result2.backupUsed);
            expect(result1.trialOrder).toEqual(result2.trialOrder);
            expect(result1.emptyDbCreated).toBe(result2.emptyDbCreated);
          }
        ),
        { numRuns: 200 }
      );
    });
  });

  // ── Edge cases ────────────────────────────────────────────────────────────

  describe('Edge Cases', () => {
    it('**Validates: Requirements 7.3** — Single valid backup: that file is used', () => {
      const entries = [{ name: makeBackupFilename(0), valid: true }];
      const result = simulateRestoreFromBackup(entries);

      expect(result.success).toBe(true);
      expect(result.backupUsed).toBe(makeBackupFilename(0));
      expect(result.trialOrder.length).toBe(1);
    });

    it('**Validates: Requirements 7.5** — Single invalid backup: empty DB created', () => {
      const entries = [{ name: makeBackupFilename(0), valid: false }];
      const result = simulateRestoreFromBackup(entries);

      expect(result.success).toBe(false);
      expect(result.backupUsed).toBeNull();
      expect(result.emptyDbCreated).toBe(true);
      expect(result.trialOrder.length).toBe(1);
    });

    it('**Validates: Requirements 7.5** — Empty backup directory: empty DB created, no trials', () => {
      const result = simulateRestoreFromBackup([]);

      expect(result.success).toBe(false);
      expect(result.backupUsed).toBeNull();
      expect(result.emptyDbCreated).toBe(true);
      expect(result.trialOrder.length).toBe(0);
    });

    it('**Validates: Requirements 7.3** — All files valid: uses the newest one (only one trial)', () => {
      fc.assert(
        fc.property(
          fc.integer({ min: 2, max: 8 }).map(n =>
            Array.from({ length: n }, (_, i) => ({
              name: makeBackupFilename(i),
              valid: true,
            }))
          ),
          (entries) => {
            const n = entries.length;
            const result = simulateRestoreFromBackup(entries);

            // Newest is makeBackupFilename(n-1)
            expect(result.success).toBe(true);
            expect(result.backupUsed).toBe(makeBackupFilename(n - 1));
            // Only one trial needed (first file tried was valid)
            expect(result.trialOrder.length).toBe(1);
          }
        ),
        { numRuns: 100 }
      );
    });
  });
});
