// src/skills/x8.js — Self-diagnostic dan auto-repair skill
// Cek kesehatan semua subsystem, perbaiki masalah ringan, LLM-powered code fix

import { generateCodeChanges, executePlan } from '../self-upgrade/code-engine.js';
import { createBackup } from '../self-upgrade/backup.js';
import { getRecent } from '../core/memory.js';
import { routeSkill, SKILL_KEYWORDS } from '../core/skill-registry.js';
import { logger } from '../utils/logger.js';

// ═══════════════════════════════════════════════════════════════
// DATA MODEL TYPEDEFS
// ═══════════════════════════════════════════════════════════════

/**
 * @typedef {Object} CheckResult
 * @property {'pass' | 'warn' | 'critical'} status
 * @property {string} category - e.g., 'skills', 'integrity', 'llm', 'telegram', 'logs', 'behavioral'
 * @property {string} summary - One-line human-readable summary
 * @property {Object[]} details - Array of specific findings
 * @property {number} score - 0-100 score for this check
 */

/**
 * @typedef {Object} SkillCheckResult
 * @extends CheckResult
 * @property {string[]} loadedSkills - IDs of successfully loaded skills
 * @property {SkillFailure[]} failedSkills - Skills that failed to import with error classification
 * @property {string[]} orphanedKeywords - SKILL_KEYWORDS entries with no file
 */

/**
 * @typedef {Object} SkillFailure
 * @property {string} file - Skill filename
 * @property {string} error - Error message
 * @property {string} stackTrace - Full stack trace
 * @property {'syntax_error' | 'missing_import' | 'missing_package' | 'missing_export' | 'runtime_error' | 'unknown'} errorType
 * @property {string} [importPath] - The broken import path (for missing_import type)
 * @property {string} [packageName] - The missing package (for missing_package type)
 */

/**
 * @typedef {Object} IntegrityCheckResult
 * @extends CheckResult
 * @property {string[]} modified - Files with hash mismatch
 * @property {string[]} missing - Files in SKILLS.lock but not on disk
 * @property {string[]} added - Files on disk but not in SKILLS.lock
 * @property {boolean} tampered
 */

/**
 * @typedef {Object} LLMCheckResult
 * @extends CheckResult
 * @property {{name: string, reachable: boolean, latencyMs?: number, error?: string}[]} providers
 * @property {boolean} allDown - True if no provider responded
 */

/**
 * @typedef {Object} TelegramCheckResult
 * @extends CheckResult
 * @property {boolean} connected
 * @property {string} [botUsername]
 * @property {string} [error]
 */

/**
 * @typedef {Object} LogCheckResult
 * @extends CheckResult
 * @property {{pattern: string, count: number, lastSeen: string}[]} recurringErrors
 * @property {number} totalErrorCount
 * @property {number} totalWarnCount
 * @property {number} linesScanned
 */

/**
 * @typedef {Object} RepairAction
 * @property {'reload_skill' | 'regen_manifest' | 'switch_provider' | 'refresh_heartbeat' | 'code_fix_via_llm' | 'npm_install_package' | 'fix_import_path' | 'add_routing_keywords' | 'enhance_system_prompt'} type
 * @property {string} target - What's being repaired (file path, package name, or skill ID)
 * @property {'safe' | 'unsafe'} classification
 * @property {string} beforeState - State before repair
 * @property {string} afterState - State after repair
 * @property {boolean} success
 * @property {string} [error] - Error message if repair failed
 * @property {string} [fixDescription] - Human-readable description of what fix was generated
 * @property {string} [backupId] - Backup ID created before code modification
 * @property {boolean} [rolledBack] - Whether rollback was performed
 */

/**
 * @typedef {Object} CodeRepairResult
 * @property {boolean} success - Whether the code fix resolved the error
 * @property {string} file - The repaired file path
 * @property {string} errorType - Original error type
 * @property {string} errorMessage - Original error message
 * @property {string} fixDescription - What the LLM generated as a fix
 * @property {string} backupId - Backup created before modification
 * @property {boolean} rolledBack - Whether rollback was needed
 * @property {string} [rollbackReason] - Why rollback happened
 * @property {Object} [plan] - The generated plan from Code_Engine (for debugging)
 */

/**
 * @typedef {Object} PackageInstallResult
 * @property {boolean} success - Whether the package install resolved the error
 * @property {string} packageName - The installed package name
 * @property {string} skillFile - The affected skill file
 * @property {string} [npmOutput] - stdout from npm install
 * @property {string} [error] - Error message if install failed
 * @property {boolean} verified - Whether re-import succeeded after install
 */

/**
 * @typedef {Object} ImportFixResult
 * @property {boolean} success - Whether the import fix resolved the error
 * @property {string} file - The file with the broken import
 * @property {string} originalImport - The original broken import path
 * @property {string} fixedImport - The corrected import path
 * @property {string[]} candidatesFound - All matching files found
 * @property {boolean} usedLLM - Whether LLM disambiguation was needed
 * @property {string} backupId - Backup created before modification
 * @property {boolean} rolledBack - Whether rollback was needed
 * @property {boolean} verified - Whether re-import succeeded after fix
 */

/**
 * @typedef {Object} BehavioralCheckResult
 * @extends CheckResult
 * @property {BehavioralMisroute[]} misroutes - Detected behavioral misroutes
 * @property {Object[]} repeatedRequests - Detected repeated request patterns
 * @property {number} memoriesScanned - Number of memory entries analyzed
 * @property {number} refusalPatternsFound - Total refusal patterns detected
 */

/**
 * @typedef {Object} BehavioralMisroute
 * @property {string} userMessage - The original user message that was not routed
 * @property {string} expectedSkill - The skill ID that should have handled it
 * @property {string} expectedSkillName - Human-readable name of the expected skill
 * @property {string} refusalResponse - The bot's refusal response text
 * @property {string} refusalPattern - Which refusal phrase was matched
 * @property {number} routeScore - The score routeSkill() returned for this message (< 3)
 * @property {string} timestamp - When the misroute occurred
 */

/**
 * @typedef {Object} RoutingFixResult
 * @property {boolean} success - Whether the routing fix was applied and verified
 * @property {string} skill - Target skill ID
 * @property {string} skillName - Target skill name
 * @property {{keyword: string, weight: number}[]} addedKeywords - Keywords added to SKILL_KEYWORDS
 * @property {number} beforeScore - routeSkill score before fix
 * @property {number} afterScore - routeSkill score after fix
 * @property {boolean} verified - Whether routeSkill now scores >= 3
 * @property {boolean} rolledBack - Whether rollback was needed
 * @property {string} [error] - Error if fix failed
 * @property {string} backupId - Backup created before Code_Engine modification
 * @property {Object[]} [conflicts] - Routing collisions detected
 */

/**
 * @typedef {Object} PromptEnhanceResult
 * @property {boolean} success - Whether the prompt enhancement was applied
 * @property {string} capability - Description of the capability that was missing
 * @property {string} statement - The Capability_Awareness statement generated
 * @property {string} insertionPoint - Where in SYSTEM_PROMPT it was inserted
 * @property {string} skillId - The skill the capability belongs to
 * @property {boolean} verified - Whether brain.js still exports correctly after change
 * @property {boolean} rolledBack - Whether rollback was needed
 * @property {boolean} skippedDuplicate - Whether enhancement was skipped (already exists)
 * @property {string} backupId - Backup of brain.js before modification
 * @property {string} [error] - Error if enhancement failed
 */

/**
 * @typedef {Object} DiagnosticReport
 * @property {string} timestamp - ISO string
 * @property {number} healthScore - 0-100
 * @property {CheckResult[]} checks - All check results
 * @property {RepairAction[]} repairsApplied - Safe actions that were executed
 * @property {RepairAction[]} manualRequired - Unsafe actions deferred to operator
 * @property {CodeRepairResult[]} codeRepairs - Detailed code repair results
 * @property {PackageInstallResult[]} packageInstalls - Package install results
 * @property {ImportFixResult[]} importFixes - Import path fix results
 * @property {BehavioralMisroute[]} behavioralMisroutes - Detected behavioral misroutes
 * @property {RoutingFixResult[]} routingFixes - Routing gap fix results
 * @property {PromptEnhanceResult[]} promptEnhancements - System prompt enhancement results
 */

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

/**
 * Files that MUST NOT be modified by the diagnostic/repair system.
 */
export const FROZEN_FILES = [
  'src/self-upgrade/upgrade.js',
  'src/self-upgrade/backup.js',
  'src/self-upgrade/healthcheck.js',
  'src/core/skill-integrity.js',
  'src/watchdog/monitor.js',
];

/**
 * Category weights for computing the overall health score (sum = 1.0).
 */
export const HEALTH_WEIGHTS = {
  skills: 0.20,
  integrity: 0.15,
  llm: 0.25,
  telegram: 0.20,
  logs: 0.10,
  behavioral: 0.10,
};

/**
 * Timeout values in milliseconds for various operations.
 */
export const TIMEOUTS = {
  llmPing: 30000,
  telegram: 10000,
  skillImport: 5000,
  pipeline: 120000,
  codeEngine: 60000,
  npm: 120000,
  memory: 5000,
  behavioralAnalysis: 15000,
  routingVerification: 2000,
  brainExportVerification: 5000,
  capabilityGeneration: 30000,
};

/**
 * Known LLM refusal patterns to detect behavioral misroutes.
 */
export const REFUSAL_PATTERNS = [
  'saya tidak bisa',
  'tidak memiliki akses',
  'sebagai AI saya tidak',
  'sebagai AI',
  'I cannot access',
  'I cannot',
  'as an AI',
  "I don't have access",
];

// ═══════════════════════════════════════════════════════════════
// ERROR CLASSIFICATION
// ═══════════════════════════════════════════════════════════════

/**
 * Determine if a MODULE_NOT_FOUND error is for an npm package vs a local file.
 * @param {Error} error - The MODULE_NOT_FOUND error
 * @returns {boolean} true if the missing module is an npm package
 */
export function isPackageImport(error) {
  const msg = error.message || '';
  // If error mentions node_modules, it's a package
  if (msg.includes('node_modules')) return true;
  // Extract the module specifier from the error
  const match = msg.match(/Cannot find (?:module|package) '([^']+)'/);
  if (match) {
    const specifier = match[1];
    // Local files start with ./ or ../ or / or have a drive letter (Windows)
    if (specifier.startsWith('./') || specifier.startsWith('../') || specifier.startsWith('/')) return false;
    if (/^[a-zA-Z]:/.test(specifier)) return false;
    return true; // Bare specifier = npm package
  }
  // ERR_MODULE_NOT_FOUND often has the specifier in a different format
  const match2 = msg.match(/Cannot find module '([^']+)'/);
  if (match2) {
    const spec = match2[1];
    if (spec.startsWith('./') || spec.startsWith('../') || spec.startsWith('/')) return false;
    if (/^[a-zA-Z]:/.test(spec)) return false;
    return true;
  }
  return false;
}

/**
 * Classify a skill import error into a repair-actionable category.
 * @param {Error} error - The import error
 * @returns {'syntax_error' | 'missing_import' | 'missing_package' | 'missing_export' | 'runtime_error' | 'unknown'}
 */
export function classifySkillError(error) {
  const msg = error.message || '';
  const code = error.code || '';

  // MODULE_NOT_FOUND: distinguish package vs local file
  if (code === 'ERR_MODULE_NOT_FOUND' || msg.includes('Cannot find module') || msg.includes('Cannot find package')) {
    if (isPackageImport(error)) return 'missing_package';
    return 'missing_import';
  }
  // Syntax errors
  if (msg.includes('SyntaxError') || msg.includes('Unexpected token') || msg.includes('Unexpected identifier')) {
    return 'syntax_error';
  }
  // Named export not found
  if (msg.includes('does not provide an export named') || msg.includes('is not exported from')) {
    return 'missing_export';
  }
  // Runtime errors (function/variable not defined)
  if (msg.includes('is not a function') || msg.includes('is not defined') || msg.includes('Cannot read properties of')) {
    return 'runtime_error';
  }
  return 'unknown';
}

// ═══════════════════════════════════════════════════════════════
// SAFETY CLASSIFIER
// ═══════════════════════════════════════════════════════════════

/**
 * Determines if a repair action is safe to execute automatically.
 * Safe actions are reversible and don't touch FROZEN files, governor, wallets, or spend caps.
 * @param {RepairAction} action
 * @returns {'safe' | 'unsafe'}
 */
export function classifyRepairAction(action) {
  try {
    if (!action || !action.type) return 'unsafe';

    const target = (action.target || '').replace(/\\/g, '/');

    // Check against FROZEN_FILES
    for (const frozen of FROZEN_FILES) {
      if (target.includes(frozen) || target.endsWith(frozen)) {
        return 'unsafe';
      }
    }

    // Check against governor/wallet/spend-cap patterns
    const dangerousPatterns = [
      'governor', 'spend_cap', 'spend-cap', 'wallet', 'signing_key',
      'private_key', 'privateKey', 'HERMES_MASTER_PW', 'killswitch',
    ];
    for (const pattern of dangerousPatterns) {
      if (target.toLowerCase().includes(pattern.toLowerCase())) {
        return 'unsafe';
      }
    }

    // Delete operations are always unsafe
    if (action.type === 'delete' || action.type === 'delete_file') {
      return 'unsafe';
    }

    // Explicitly safe action types (with non-frozen, non-dangerous targets)
    const safeTypes = [
      'reload_skill',
      'regen_manifest',
      'switch_provider',
      'refresh_heartbeat',
      'code_fix_via_llm',
      'npm_install_package',
      'fix_import_path',
      'add_routing_keywords',
      'enhance_system_prompt',
    ];

    if (safeTypes.includes(action.type)) {
      return 'safe';
    }

    // Unknown action type defaults to unsafe
    return 'unsafe';
  } catch {
    return 'unsafe';
  }
}

// ═══════════════════════════════════════════════════════════════
// HEALTH SCORE COMPUTATION
// ═══════════════════════════════════════════════════════════════

/**
 * Computes the overall health score (0-100) from check results.
 * Uses HEALTH_WEIGHTS to weight each category's contribution.
 * @param {DiagnosticReport} report
 * @returns {number} Health score 0-100
 */
export function computeHealthScore(report) {
  if (!report || !report.checks || report.checks.length === 0) return 0;

  let weightedSum = 0;
  let totalWeight = 0;

  for (const check of report.checks) {
    const category = check.category;
    const weight = HEALTH_WEIGHTS[category];
    if (weight !== undefined) {
      // Normalize score to 0-100 range
      const score = Math.max(0, Math.min(100, check.score || 0));
      weightedSum += score * weight;
      totalWeight += weight;
    }
  }

  // If no matching categories found, return 0
  if (totalWeight === 0) return 0;

  // Normalize in case not all categories are present
  const rawScore = weightedSum / totalWeight;
  
  // Clamp and round
  return Math.round(Math.max(0, Math.min(100, rawScore)));
}

// ═══════════════════════════════════════════════════════════════
// DIAGNOSTIC CHECKS
// ═══════════════════════════════════════════════════════════════

/**
 * Attempts to import every .js file in src/skills/ and reports successes/failures.
 * Categorizes failures by error type.
 * @returns {Promise<SkillCheckResult>}
 */
export async function checkSkillLoads() {
  const fs = await import('fs');
  const path = await import('path');
  const { fileURLToPath } = await import('url');

  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const skillsDir = path.resolve(__dirname, '.');

  const loadedSkills = [];
  const failedSkills = [];

  let files;
  try {
    files = fs.readdirSync(skillsDir).filter(f => f.endsWith('.js') && f !== 'x8.js');
  } catch (err) {
    return {
      status: 'critical',
      category: 'skills',
      summary: `Skills directory unreadable: ${err.message}`,
      details: [{ error: err.message }],
      score: 0,
      loadedSkills: [],
      failedSkills: [],
      orphanedKeywords: [],
    };
  }

  for (const file of files) {
    const filePath = path.resolve(skillsDir, file);
    try {
      // Dynamic import with timeout
      const importPromise = import(`file://${filePath.replace(/\\/g, '/')}?t=${Date.now()}`);
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Import timeout (5s)')), TIMEOUTS.skillImport)
      );
      const mod = await Promise.race([importPromise, timeoutPromise]);
      const skill = mod.default;
      if (skill && skill.id) {
        loadedSkills.push(skill.id);
      } else {
        loadedSkills.push(file.replace('.js', ''));
      }
    } catch (err) {
      const errorType = classifySkillError(err);
      const failure = {
        file,
        error: err.message || String(err),
        stackTrace: err.stack || '',
        errorType,
      };
      // Extract additional info based on error type
      if (errorType === 'missing_import') {
        const match = (err.message || '').match(/Cannot find (?:module|package) '([^']+)'/);
        if (match) failure.importPath = match[1];
      }
      if (errorType === 'missing_package') {
        // Extract package name
        const msg = err.message || '';
        const match = msg.match(/Cannot find (?:module|package) '([^']+)'/);
        if (match) {
          const spec = match[1];
          // Scoped package: @scope/pkg or @scope/pkg/subpath
          if (spec.startsWith('@')) {
            const parts = spec.split('/');
            failure.packageName = parts.length >= 2 ? `${parts[0]}/${parts[1]}` : spec;
          } else {
            failure.packageName = spec.split('/')[0];
          }
        }
      }
      failedSkills.push(failure);
    }
  }

  // Detect orphaned keywords (SKILL_KEYWORDS entries with no loaded file)
  const allKeywordIds = Object.keys(SKILL_KEYWORDS);
  const loadedIds = new Set(loadedSkills);
  // Also count x8 itself as loaded
  loadedIds.add('x8');
  const orphanedKeywords = allKeywordIds.filter(id => !loadedIds.has(id));

  // Compute score: 100 if all loaded, reduce by percentage failed
  const total = files.length;
  const failedCount = failedSkills.length;
  const score = total > 0 ? Math.round(((total - failedCount) / total) * 100) : 100;

  let status = 'pass';
  if (failedCount > 0 && failedCount <= 3) status = 'warn';
  if (failedCount > 3) status = 'critical';

  return {
    status,
    category: 'skills',
    summary: `${loadedSkills.length}/${total} skills loaded, ${failedCount} failed`,
    details: failedSkills.map(f => ({ file: f.file, error: f.error, type: f.errorType })),
    score,
    loadedSkills,
    failedSkills,
    orphanedKeywords,
  };
}

/**
 * Delegates to skill-integrity.js verifyIntegrity() and interprets results.
 * @returns {Promise<IntegrityCheckResult>}
 */
export async function checkIntegrity() {
  try {
    const { verifyIntegrity } = await import('../core/skill-integrity.js');
    const result = await verifyIntegrity();

    const modified = result.modified || [];
    const missing = result.missing || [];
    const added = result.added || [];
    const tampered = result.tampered || false;

    let status = 'pass';
    let score = 100;

    if (added.length > 0) {
      status = 'warn';
      score = 80;
    }
    if (modified.length > 0 || missing.length > 0) {
      status = 'warn';
      score = 50;
    }
    if (tampered) {
      status = 'critical';
      score = 20;
    }

    const details = [];
    if (modified.length > 0) details.push({ type: 'modified', files: modified });
    if (missing.length > 0) details.push({ type: 'missing', files: missing });
    if (added.length > 0) details.push({ type: 'added', files: added });

    return {
      status,
      category: 'integrity',
      summary: tampered
        ? `TAMPERED: ${modified.length} modified, ${missing.length} missing`
        : modified.length + missing.length + added.length === 0
          ? 'SKILLS.lock integrity OK'
          : `${modified.length} modified, ${missing.length} missing, ${added.length} untracked`,
      details,
      score,
      modified,
      missing,
      added,
      tampered,
    };
  } catch (err) {
    // SKILLS.lock missing or unverifiable
    return {
      status: 'warn',
      category: 'integrity',
      summary: `Integrity check failed: ${err.message}`,
      details: [{ error: err.message }],
      score: 60,
      modified: [],
      missing: [],
      added: [],
      tampered: false,
    };
  }
}

/**
 * Tests connectivity of each configured LLM provider with a lightweight ping.
 * @returns {Promise<LLMCheckResult>}
 */
export async function checkLLMProviders() {
  const { callCascade, getProviderStatus, switchProvider } = await import('../llm/cascade.js');

  const status = getProviderStatus();
  const originalMode = status.forced; // Save current forced provider (null = auto)
  const providerResults = [];

  for (const provider of (status.providers || [])) {
    const start = Date.now();
    try {
      // Temporarily force this specific provider
      switchProvider(provider.name);

      const pingPromise = callCascade(
        [{ role: 'user', content: 'ping' }],
        { maxTokens: 5, temperature: 0 }
      );
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Timeout (30s)')), TIMEOUTS.llmPing)
      );
      await Promise.race([pingPromise, timeoutPromise]);
      const latencyMs = Date.now() - start;
      providerResults.push({ name: provider.name, reachable: true, latencyMs });
    } catch (err) {
      providerResults.push({ name: provider.name, reachable: false, error: err.message || String(err) });
    }
  }

  // Restore original provider mode
  switchProvider(originalMode || 'auto');

  const reachableCount = providerResults.filter(p => p.reachable).length;
  const allDown = reachableCount === 0 && providerResults.length > 0;

  let resultStatus = 'pass';
  let score = 100;
  if (allDown) {
    resultStatus = 'critical';
    score = 0;
  } else if (reachableCount < providerResults.length) {
    resultStatus = 'warn';
    score = Math.round((reachableCount / providerResults.length) * 100);
  }

  return {
    status: resultStatus,
    category: 'llm',
    summary: allDown
      ? `ALL ${providerResults.length} LLM providers unreachable`
      : `${reachableCount}/${providerResults.length} providers reachable`,
    details: providerResults,
    score,
    providers: providerResults,
    allDown,
  };
}

/**
 * Verifies Telegram bot connection by calling the getMe API endpoint.
 * @returns {Promise<TelegramCheckResult>}
 */
export async function checkTelegramConnection() {
  try {
    const { getBot } = await import('../telegram/bot.js');
    const bot = getBot();

    if (!bot) {
      return {
        status: 'critical',
        category: 'telegram',
        summary: 'Bot instance not available',
        details: [{ error: 'getBot() returned null/undefined' }],
        score: 0,
        connected: false,
        error: 'Bot instance not available',
      };
    }

    const getMePromise = bot.getMe();
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Timeout (10s)')), TIMEOUTS.telegram)
    );
    const me = await Promise.race([getMePromise, timeoutPromise]);

    return {
      status: 'pass',
      category: 'telegram',
      summary: `Connected as @${me.username}`,
      details: [{ username: me.username, id: me.id }],
      score: 100,
      connected: true,
      botUsername: me.username,
    };
  } catch (err) {
    return {
      status: 'warn',
      category: 'telegram',
      summary: `Telegram connection degraded: ${err.message}`,
      details: [{ error: err.message }],
      score: 30,
      connected: false,
      error: err.message,
    };
  }
}

/**
 * Reads the most recent 500 lines from the bot log file, groups error/warn patterns.
 * @returns {Promise<LogCheckResult>}
 */
export async function scanLogs() {
  const fs = await import('fs');
  const path = await import('path');
  const { config } = await import('../config.js');

  const logDir = config.raja.logDir || '/opt/raja-bot/logs';
  
  try {
    // Find the most recent log file
    let logFile;
    if (fs.existsSync(logDir)) {
      const logFiles = fs.readdirSync(logDir)
        .filter(f => f.endsWith('.log'))
        .sort()
        .reverse();
      if (logFiles.length > 0) {
        logFile = path.join(logDir, logFiles[0]);
      }
    }

    if (!logFile || !fs.existsSync(logFile)) {
      return {
        status: 'pass',
        category: 'logs',
        summary: 'No log files found (no errors to report)',
        details: [],
        score: 100,
        recurringErrors: [],
        totalErrorCount: 0,
        totalWarnCount: 0,
        linesScanned: 0,
      };
    }

    // Read last 500 lines
    const content = fs.readFileSync(logFile, 'utf8');
    const allLines = content.split('\n').filter(l => l.trim());
    const lines = allLines.slice(-500);
    const linesScanned = lines.length;

    // Parse error/warn entries
    let totalErrorCount = 0;
    let totalWarnCount = 0;
    const patternMap = new Map(); // pattern → { count, lastSeen }

    for (const line of lines) {
      const isError = /\berror\b/i.test(line) || /\bERR\b/.test(line);
      const isWarn = /\bwarn\b/i.test(line) || /\bWARN\b/.test(line);

      if (!isError && !isWarn) continue;

      if (isError) totalErrorCount++;
      if (isWarn && !isError) totalWarnCount++;

      // Normalize pattern: strip timestamps, numbers, paths with variable parts
      const normalized = line
        .replace(/\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}[.\d]*/g, '<TS>')
        .replace(/\d+/g, '<N>')
        .replace(/\/[\w/./-]+/g, '<PATH>')
        .substring(0, 150);

      const entry = patternMap.get(normalized) || { count: 0, lastSeen: '' };
      entry.count++;
      // Extract timestamp from original line
      const tsMatch = line.match(/(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})/);
      if (tsMatch && tsMatch[1] > entry.lastSeen) {
        entry.lastSeen = tsMatch[1];
      }
      patternMap.set(normalized, entry);
    }

    // Filter recurring patterns (count >= 3)
    const recurringErrors = [];
    for (const [pattern, { count, lastSeen }] of patternMap.entries()) {
      if (count >= 3) {
        recurringErrors.push({ pattern, count, lastSeen: lastSeen || 'unknown' });
      }
    }

    // Sort by count descending
    recurringErrors.sort((a, b) => b.count - a.count);

    let status = 'pass';
    let score = 100;
    if (recurringErrors.length > 0) {
      status = 'warn';
      score = Math.max(30, 100 - recurringErrors.length * 15);
    }
    if (totalErrorCount > 50) {
      status = 'critical';
      score = Math.min(score, 20);
    }

    return {
      status,
      category: 'logs',
      summary: `${linesScanned} lines scanned: ${totalErrorCount} errors, ${totalWarnCount} warns, ${recurringErrors.length} recurring patterns`,
      details: recurringErrors.slice(0, 10), // Top 10
      score,
      recurringErrors,
      totalErrorCount,
      totalWarnCount,
      linesScanned,
    };
  } catch (err) {
    return {
      status: 'pass',
      category: 'logs',
      summary: `Log scan failed: ${err.message} (non-blocking)`,
      details: [{ error: err.message }],
      score: 80,
      recurringErrors: [],
      totalErrorCount: 0,
      totalWarnCount: 0,
      linesScanned: 0,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// CODE REPAIR PIPELINE
// ═══════════════════════════════════════════════════════════════

/**
 * Build the instruction and context string for generateCodeChanges().
 * Combines error message, stack trace, and file content.
 * @param {SkillFailure} failedSkill
 * @returns {Promise<{ instruction: string, context: string }>}
 */
export async function buildCodeFixContext(failedSkill) {
  const fs = await import('fs');
  const path = await import('path');
  const { fileURLToPath } = await import('url');

  let fileContent = '';
  try {
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const filePath = path.resolve(__dirname, failedSkill.file);
    if (fs.existsSync(filePath)) {
      fileContent = fs.readFileSync(filePath, 'utf8');
    }
  } catch {
    fileContent = '[Could not read file]';
  }

  const instruction = `Fix this skill file error in "${failedSkill.file}": ${failedSkill.error}`;
  const context = [
    `Error type: ${failedSkill.errorType}`,
    `Error message: ${failedSkill.error}`,
    `Stack trace:\n${failedSkill.stackTrace || 'N/A'}`,
    failedSkill.importPath ? `Broken import path: ${failedSkill.importPath}` : '',
    failedSkill.packageName ? `Missing package: ${failedSkill.packageName}` : '',
    `\nFull file content of ${failedSkill.file}:\n\`\`\`javascript\n${fileContent}\n\`\`\``,
  ].filter(Boolean).join('\n');

  return { instruction, context };
}

/**
 * Verify a repaired skill by dynamically importing it.
 * Clears module cache before import to avoid stale modules.
 * @param {string} filePath - Absolute path to the repaired skill file
 * @returns {Promise<{ success: boolean, error?: string }>}
 */
export async function verifySkillImport(filePath) {
  try {
    // Use cache-busting query param to avoid stale module cache
    const importPath = `file://${filePath.replace(/\\/g, '/')}?t=${Date.now()}`;
    const importPromise = import(importPath);
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Import verification timeout (5s)')), TIMEOUTS.skillImport)
    );
    const mod = await Promise.race([importPromise, timeoutPromise]);

    // Basic validation: module should have a default export
    if (!mod.default) {
      return { success: false, error: 'Module has no default export' };
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message || String(err) };
  }
}

/**
 * Handles LLM-powered code-level auto-repair for a failed skill file.
 * Flow: check FROZEN → build context → generateCodeChanges → executePlan → verify → rollback on failure
 * @param {SkillFailure} failedSkill
 * @returns {Promise<CodeRepairResult>}
 */
export async function repairSkillCode(failedSkill) {
  const path = await import('path');
  const { fileURLToPath } = await import('url');
  const __dirname = path.dirname(fileURLToPath(import.meta.url));

  const targetPath = `src/skills/${failedSkill.file}`;

  // Check if target is FROZEN
  for (const frozen of FROZEN_FILES) {
    if (targetPath.includes(frozen)) {
      return {
        success: false,
        file: failedSkill.file,
        errorType: failedSkill.errorType,
        errorMessage: failedSkill.error,
        fixDescription: 'Skipped — FROZEN file',
        backupId: '',
        rolledBack: false,
        rollbackReason: 'FROZEN file protection',
      };
    }
  }

  try {
    // 1. Build context for LLM
    const { instruction, context } = await buildCodeFixContext(failedSkill);

    // 2. Generate code fix via Code_Engine (60s timeout)
    const genPromise = generateCodeChanges(instruction, context);
    const genTimeout = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Code generation timeout (60s)')), TIMEOUTS.codeEngine)
    );
    const plan = await Promise.race([genPromise, genTimeout]);

    if (!plan || !plan.files || plan.files.length === 0) {
      return {
        success: false,
        file: failedSkill.file,
        errorType: failedSkill.errorType,
        errorMessage: failedSkill.error,
        fixDescription: 'LLM returned empty fix plan',
        backupId: '',
        rolledBack: false,
      };
    }

    // 3. Execute plan (backup + write + optional npm install)
    const result = await executePlan(plan, (msg) => logger.info(`[x8-repair] ${msg}`));

    if (!result.success) {
      return {
        success: false,
        file: failedSkill.file,
        errorType: failedSkill.errorType,
        errorMessage: failedSkill.error,
        fixDescription: plan.plan || 'Code fix attempted',
        backupId: result.backupId || '',
        rolledBack: true,
        rollbackReason: result.error || 'executePlan failed',
        plan,
      };
    }

    // 4. Verify fix by re-importing the skill
    const filePath = path.resolve(__dirname, failedSkill.file);
    const verification = await verifySkillImport(filePath);

    if (!verification.success) {
      // Rollback
      try {
        const { restoreBackup } = await import('../self-upgrade/backup.js');
        await restoreBackup(result.backupId || 'latest');
      } catch (rollbackErr) {
        logger.error(`[x8-repair] Rollback failed: ${rollbackErr.message}`);
      }

      return {
        success: false,
        file: failedSkill.file,
        errorType: failedSkill.errorType,
        errorMessage: failedSkill.error,
        fixDescription: plan.plan || 'Code fix attempted',
        backupId: result.backupId || '',
        rolledBack: true,
        rollbackReason: `Verification failed: ${verification.error}`,
        plan,
      };
    }

    // 5. Success
    return {
      success: true,
      file: failedSkill.file,
      errorType: failedSkill.errorType,
      errorMessage: failedSkill.error,
      fixDescription: plan.plan || plan.summary || 'Code fix applied successfully',
      backupId: result.backupId || '',
      rolledBack: false,
      plan,
    };
  } catch (err) {
    return {
      success: false,
      file: failedSkill.file,
      errorType: failedSkill.errorType,
      errorMessage: failedSkill.error,
      fixDescription: `Error during repair: ${err.message}`,
      backupId: '',
      rolledBack: false,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// PACKAGE INSTALLER
// ═══════════════════════════════════════════════════════════════

/**
 * Extract npm package name from a MODULE_NOT_FOUND error message.
 * Handles scoped packages (@scope/pkg), regular packages, and subpath imports.
 * @param {Error} error - The MODULE_NOT_FOUND error
 * @returns {string | null} - Package name or null if not a package error
 */
export function extractPackageName(error) {
  const msg = error.message || '';

  // Try to extract module specifier
  const match = msg.match(/Cannot find (?:module|package) '([^']+)'/);
  if (!match) return null;

  const specifier = match[1];

  // Skip local file paths
  if (specifier.startsWith('./') || specifier.startsWith('../') || specifier.startsWith('/')) {
    return null;
  }
  if (/^[a-zA-Z]:/.test(specifier)) return null;

  // Scoped package: @scope/package or @scope/package/subpath
  if (specifier.startsWith('@')) {
    const parts = specifier.split('/');
    if (parts.length >= 2) {
      return `${parts[0]}/${parts[1]}`;
    }
    return specifier;
  }

  // Regular package: lodash or lodash/get
  return specifier.split('/')[0];
}

/**
 * Handles missing npm package detection and installation.
 * Flow: extract package name → npm install → re-verify import
 * @param {SkillFailure} failedSkill
 * @returns {Promise<PackageInstallResult>}
 */
export async function installMissingPackage(failedSkill) {
  const { exec } = await import('child_process');
  const { promisify } = await import('util');
  const path = await import('path');
  const { fileURLToPath } = await import('url');
  const { config } = await import('../config.js');
  const execAsync = promisify(exec);

  const packageName = extractPackageName(failedSkill.error ? { message: failedSkill.error } : { message: '' });

  if (!packageName) {
    return {
      success: false,
      packageName: 'unknown',
      skillFile: failedSkill.file,
      error: 'Could not extract package name from error',
      verified: false,
    };
  }

  try {
    // Run npm install with timeout
    const root = config.raja.home || process.cwd();
    const { stdout, stderr } = await execAsync(
      `npm install ${packageName}`,
      { cwd: root, timeout: TIMEOUTS.npm }
    );

    const npmOutput = stdout || stderr || '';

    // Verify the skill now loads
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const filePath = path.resolve(__dirname, failedSkill.file);
    const verification = await verifySkillImport(filePath);

    return {
      success: verification.success,
      packageName,
      skillFile: failedSkill.file,
      npmOutput: npmOutput.substring(0, 500),
      verified: verification.success,
      error: verification.success ? undefined : `Package installed but skill still fails: ${verification.error}`,
    };
  } catch (err) {
    return {
      success: false,
      packageName,
      skillFile: failedSkill.file,
      error: `npm install failed: ${err.message}`,
      verified: false,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// IMPORT PATH RESOLVER
// ═══════════════════════════════════════════════════════════════

/**
 * Recursively scan project directory for files matching a given module name.
 * Excludes node_modules, .git, backups, data, _quarantine directories.
 * @param {string} moduleName - Expected filename (e.g., 'cascade.js')
 * @param {string} rootDir - Project root absolute path
 * @returns {Promise<string[]>} - Array of matching file paths (relative to root, forward slashes)
 */
export async function findMatchingFiles(moduleName, rootDir) {
  const fs = await import('fs');
  const path = await import('path');

  const excludeDirs = new Set(['node_modules', '.git', 'backups', 'data', '_quarantine']);
  const results = [];

  function scanDir(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (excludeDirs.has(entry.name)) continue;
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        scanDir(fullPath);
      } else if (entry.isFile() && entry.name === moduleName) {
        results.push(path.relative(rootDir, fullPath).replace(/\\/g, '/'));
      }
    }
  }

  scanDir(rootDir);
  return results;
}

/**
 * Compute the correct relative import path from source file to target file.
 * Both paths should be relative to project root (forward slashes).
 * @param {string} sourceFile - The importing file (relative path, e.g., 'src/skills/x8.js')
 * @param {string} targetFile - The target module (relative path, e.g., 'src/llm/cascade.js')
 * @returns {string} - Correct relative import path (e.g., '../llm/cascade.js')
 */
export function computeRelativePath(sourceFile, targetFile) {
  // Normalize to forward slashes
  const sourceParts = sourceFile.replace(/\\/g, '/').split('/');
  const targetParts = targetFile.replace(/\\/g, '/').split('/');

  // Remove filename from source to get its directory segments
  sourceParts.pop();

  // Find the length of the common prefix (compare directory segments only)
  let commonLength = 0;
  const maxCommon = Math.min(sourceParts.length, targetParts.length - 1);
  while (commonLength < maxCommon && sourceParts[commonLength] === targetParts[commonLength]) {
    commonLength++;
  }

  // Number of '../' needed to go up from source dir to common ancestor
  const upCount = sourceParts.length - commonLength;
  const ups = '../'.repeat(upCount);

  // Remaining path segments from the common ancestor to the target
  const remaining = targetParts.slice(commonLength).join('/');

  let result = ups + remaining;

  // Ensure result starts with './' or '../'
  if (!result.startsWith('.') && !result.startsWith('/')) {
    result = './' + result;
  }

  // Ensure .js extension is present
  if (!result.endsWith('.js') && !result.endsWith('.mjs')) {
    result += '.js';
  }

  return result;
}

/**
 * Read a module's exported names (named exports and default export).
 * Uses regex parsing — does not actually import the module.
 * @param {string} filePath - Absolute path to the module
 * @returns {Promise<string[]>} - Array of export names (deduplicated)
 */
export async function readModuleExports(filePath) {
  const fs = await import('fs');

  try {
    if (!fs.existsSync(filePath)) return [];
    const content = fs.readFileSync(filePath, 'utf8');
    const exports = [];

    // Match: export function name, export async function name
    const funcMatches = content.matchAll(/export\s+(?:async\s+)?function\s+(\w+)/g);
    for (const m of funcMatches) exports.push(m[1]);

    // Match: export const/let/var name
    const varMatches = content.matchAll(/export\s+(?:const|let|var)\s+(\w+)/g);
    for (const m of varMatches) exports.push(m[1]);

    // Match: export class name
    const classMatches = content.matchAll(/export\s+class\s+(\w+)/g);
    for (const m of classMatches) exports.push(m[1]);

    // Match: export { name1, name2 } or export { name1 as alias1 }
    const namedMatches = content.matchAll(/export\s*\{([^}]+)\}/g);
    for (const m of namedMatches) {
      const names = m[1].split(',').map(n => {
        const trimmed = n.trim();
        // Handle "name as alias" — the exported name is the alias
        const asMatch = trimmed.match(/\w+\s+as\s+(\w+)/);
        return asMatch ? asMatch[1] : trimmed;
      });
      exports.push(...names.filter(n => n && /^\w+$/.test(n)));
    }

    // Match: export default (function, class, or expression)
    if (/export\s+default\b/.test(content)) {
      exports.push('default');
    }

    // Deduplicate
    return [...new Set(exports)];
  } catch {
    return [];
  }
}

/**
 * When multiple candidate files match, use LLM to select the most likely correct one.
 * @param {string[]} candidates - Matching file paths (relative to root)
 * @param {Object} context - { sourceFile, importStatement, errorMessage }
 * @returns {Promise<string>} - Best matching file path
 */
export async function disambiguateWithLLM(candidates, context) {
  const { callCascade } = await import('../llm/cascade.js');

  const prompt = `Given a broken import in "${context.sourceFile}":
Import statement: ${context.importStatement}
Error: ${context.errorMessage}

Multiple candidate files match. Which is the correct target?
Candidates:
${candidates.map((c, i) => `${i + 1}. ${c}`).join('\n')}

Reply with ONLY the number of the correct candidate (e.g., "1" or "2"). Nothing else.`;

  try {
    const result = await Promise.race([
      callCascade([{ role: 'user', content: prompt }], { maxTokens: 10, temperature: 0 }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('LLM timeout')), TIMEOUTS.capabilityGeneration)),
    ]);

    const num = parseInt(result.text.trim());
    if (num >= 1 && num <= candidates.length) {
      return candidates[num - 1];
    }
    // Fallback: return first candidate
    return candidates[0];
  } catch {
    // On LLM failure, return first candidate as best guess
    return candidates[0];
  }
}

/**
 * Handles broken import path detection and repair.
 * Flow: scan project for matching files → fix import path → verify
 * @param {SkillFailure} failedSkill - Must have errorType 'missing_import' and importPath set
 * @returns {Promise<ImportFixResult>}
 */
export async function resolveImportPath(failedSkill) {
  const path = await import('path');
  const { fileURLToPath } = await import('url');
  const { config } = await import('../config.js');
  const __dirname = path.dirname(fileURLToPath(import.meta.url));

  const root = config.raja.home || path.resolve(__dirname, '../..');
  const brokenImport = failedSkill.importPath || '';

  // Extract the expected module name (basename)
  const moduleName = path.basename(brokenImport);
  if (!moduleName) {
    return {
      success: false,
      file: failedSkill.file,
      originalImport: brokenImport,
      fixedImport: '',
      candidatesFound: [],
      usedLLM: false,
      backupId: '',
      rolledBack: false,
      verified: false,
    };
  }

  // Scan project for matching files
  const candidates = await findMatchingFiles(moduleName, root);

  if (candidates.length === 0) {
    return {
      success: false,
      file: failedSkill.file,
      originalImport: brokenImport,
      fixedImport: '',
      candidatesFound: [],
      usedLLM: false,
      backupId: '',
      rolledBack: false,
      verified: false,
    };
  }

  let selectedFile;
  let usedLLM = false;

  if (candidates.length === 1) {
    selectedFile = candidates[0];
  } else {
    // Multiple matches — use LLM to disambiguate
    usedLLM = true;
    selectedFile = await disambiguateWithLLM(candidates, {
      sourceFile: `src/skills/${failedSkill.file}`,
      importStatement: brokenImport,
      errorMessage: failedSkill.error,
    });
  }

  // Compute correct relative path
  const sourceRelative = `src/skills/${failedSkill.file}`;
  const fixedImport = computeRelativePath(sourceRelative, selectedFile);

  // Use Code_Engine to apply the fix
  const instruction = `Fix broken import in "src/skills/${failedSkill.file}": change import path from "${brokenImport}" to "${fixedImport}"`;
  const context = `The file "src/skills/${failedSkill.file}" has a broken import "${brokenImport}" that should be "${fixedImport}". Update the import statement.`;

  try {
    const plan = await Promise.race([
      generateCodeChanges(instruction, context),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), TIMEOUTS.codeEngine)),
    ]);

    if (!plan || !plan.files || plan.files.length === 0) {
      return {
        success: false,
        file: failedSkill.file,
        originalImport: brokenImport,
        fixedImport,
        candidatesFound: candidates,
        usedLLM,
        backupId: '',
        rolledBack: false,
        verified: false,
      };
    }

    const result = await executePlan(plan, (msg) => logger.info(`[x8-import-fix] ${msg}`));

    if (!result.success) {
      return {
        success: false,
        file: failedSkill.file,
        originalImport: brokenImport,
        fixedImport,
        candidatesFound: candidates,
        usedLLM,
        backupId: result.backupId || '',
        rolledBack: true,
        verified: false,
      };
    }

    // Verify fix
    const filePath = path.resolve(__dirname, failedSkill.file);
    const verification = await verifySkillImport(filePath);

    if (!verification.success) {
      // Rollback
      try {
        const { restoreBackup } = await import('../self-upgrade/backup.js');
        await restoreBackup(result.backupId || 'latest');
      } catch (rollbackErr) {
        logger.error(`[x8-import-fix] Rollback failed: ${rollbackErr.message}`);
      }
      return {
        success: false,
        file: failedSkill.file,
        originalImport: brokenImport,
        fixedImport,
        candidatesFound: candidates,
        usedLLM,
        backupId: result.backupId || '',
        rolledBack: true,
        verified: false,
      };
    }

    return {
      success: true,
      file: failedSkill.file,
      originalImport: brokenImport,
      fixedImport,
      candidatesFound: candidates,
      usedLLM,
      backupId: result.backupId || '',
      rolledBack: false,
      verified: true,
    };
  } catch (err) {
    return {
      success: false,
      file: failedSkill.file,
      originalImport: brokenImport,
      fixedImport,
      candidatesFound: candidates,
      usedLLM,
      backupId: '',
      rolledBack: false,
      verified: false,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// REPAIR ENGINE
// ═══════════════════════════════════════════════════════════════

/**
 * Given aggregated diagnostic results, identifies fixable issues and applies safe repairs.
 * Routes repairs to the appropriate pipeline based on error type.
 * @param {DiagnosticReport} report - Aggregated check results
 * @returns {Promise<void>} - Mutates report in place (adds to repairsApplied, manualRequired, etc.)
 */
export async function executeRepairs(report) {
  const fs = await import('fs');
  const { config } = await import('../config.js');
  const { generateManifest } = await import('../core/skill-integrity.js');

  // Check if LLM is available (needed for code repairs)
  const llmCheck = report.checks.find(c => c.category === 'llm');
  const llmAvailable = llmCheck && !llmCheck.allDown;

  // 1. Simple repairs first
  // --- SKILLS.lock out of sync ---
  const integrityCheck = report.checks.find(c => c.category === 'integrity');
  if (integrityCheck && (integrityCheck.added?.length > 0 || integrityCheck.modified?.length > 0)) {
    const action = { type: 'regen_manifest', target: 'SKILLS.lock', classification: 'safe', beforeState: `${integrityCheck.modified?.length || 0} modified, ${integrityCheck.added?.length || 0} added`, afterState: '', success: false };
    try {
      await generateManifest();
      action.success = true;
      action.afterState = 'SKILLS.lock regenerated';
      report.repairsApplied.push(action);
    } catch (err) {
      action.error = err.message;
      report.repairsApplied.push(action);
    }
  }

  // --- Heartbeat stale ---
  const heartbeatPath = config.watchdog?.heartbeatPath;
  if (heartbeatPath) {
    try {
      const hbContent = fs.existsSync(heartbeatPath) ? fs.readFileSync(heartbeatPath, 'utf8').trim() : '0';
      const hbTs = parseInt(hbContent) || 0;
      const age = Date.now() - hbTs;
      if (age > 90000) {
        const action = { type: 'refresh_heartbeat', target: heartbeatPath, classification: 'safe', beforeState: `Stale: ${Math.round(age / 1000)}s old`, afterState: '', success: false };
        fs.writeFileSync(heartbeatPath, Date.now().toString());
        action.success = true;
        action.afterState = 'Heartbeat refreshed';
        report.repairsApplied.push(action);
      }
    } catch (err) {
      logger.warn(`[x8-repair] Heartbeat refresh failed: ${err.message}`);
    }
  }

  // --- All LLM providers down ---
  if (llmCheck && llmCheck.allDown) {
    const action = { type: 'switch_provider', target: 'llm-cascade', classification: 'safe', beforeState: 'All providers unreachable', afterState: '', success: false };
    try {
      const { switchProvider } = await import('../llm/cascade.js');
      switchProvider('auto');
      action.success = true;
      action.afterState = 'Cascade reset to auto mode';
      report.repairsApplied.push(action);
    } catch (err) {
      action.error = err.message;
      report.repairsApplied.push(action);
    }
  }

  // 2. Code-level repairs (only if LLM is available)
  const skillCheck = report.checks.find(c => c.category === 'skills');
  if (skillCheck && skillCheck.failedSkills && llmAvailable) {
    for (const failed of skillCheck.failedSkills) {
      // Classify the repair action
      const repairAction = { type: '', target: `src/skills/${failed.file}`, classification: 'safe' };
      const safetyCheck = classifyRepairAction(repairAction);

      if (safetyCheck === 'unsafe') {
        report.manualRequired.push({ type: 'code_fix_via_llm', target: `src/skills/${failed.file}`, classification: 'unsafe', beforeState: failed.error, afterState: '', success: false, error: 'FROZEN or dangerous target' });
        continue;
      }

      // Route by error type
      switch (failed.errorType) {
        case 'missing_package': {
          const result = await installMissingPackage(failed);
          report.packageInstalls.push(result);
          report.repairsApplied.push({
            type: 'npm_install_package',
            target: result.packageName || 'unknown',
            classification: 'safe',
            beforeState: `Missing package: ${result.packageName}`,
            afterState: result.success ? `Installed ${result.packageName}` : `Install failed: ${result.error}`,
            success: result.success,
            error: result.error,
          });
          break;
        }
        case 'missing_import': {
          const result = await resolveImportPath(failed);
          report.importFixes.push(result);
          report.repairsApplied.push({
            type: 'fix_import_path',
            target: `src/skills/${failed.file}`,
            classification: 'safe',
            beforeState: `Broken import: ${failed.importPath}`,
            afterState: result.success ? `Fixed to: ${result.fixedImport}` : `Fix failed`,
            success: result.success,
            backupId: result.backupId,
            rolledBack: result.rolledBack,
          });
          break;
        }
        case 'syntax_error':
        case 'missing_export':
        case 'runtime_error': {
          const result = await repairSkillCode(failed);
          report.codeRepairs.push(result);
          report.repairsApplied.push({
            type: 'code_fix_via_llm',
            target: `src/skills/${failed.file}`,
            classification: 'safe',
            beforeState: `${failed.errorType}: ${failed.error.substring(0, 100)}`,
            afterState: result.success ? result.fixDescription : `Fix failed: ${result.rollbackReason || ''}`,
            success: result.success,
            fixDescription: result.fixDescription,
            backupId: result.backupId,
            rolledBack: result.rolledBack,
          });
          break;
        }
        default: {
          report.manualRequired.push({
            type: 'code_fix_via_llm',
            target: `src/skills/${failed.file}`,
            classification: 'unsafe',
            beforeState: `Unknown error type: ${failed.error}`,
            afterState: '',
            success: false,
            error: 'Cannot auto-repair unknown error type',
          });
        }
      }
    }
  } else if (skillCheck && skillCheck.failedSkills && !llmAvailable) {
    // LLM down — can't do code repairs, add all to manual
    for (const failed of skillCheck.failedSkills) {
      report.manualRequired.push({
        type: 'code_fix_via_llm',
        target: `src/skills/${failed.file}`,
        classification: 'unsafe',
        beforeState: `${failed.errorType}: ${failed.error.substring(0, 100)}`,
        afterState: '',
        success: false,
        error: 'LLM providers all down — cannot generate code fix',
      });
    }
  }

  // 3. Behavioral repairs (only if LLM is available)
  const behavioralCheck = report.checks.find(c => c.category === 'behavioral');
  if (behavioralCheck && behavioralCheck.misroutes && behavioralCheck.misroutes.length > 0 && llmAvailable) {
    report.behavioralMisroutes = behavioralCheck.misroutes;

    for (const misroute of behavioralCheck.misroutes) {
      // Fix routing gap
      const routingResult = await fixRoutingGap(misroute);
      report.routingFixes.push(routingResult);
      report.repairsApplied.push({
        type: 'add_routing_keywords',
        target: misroute.expectedSkill,
        classification: 'safe',
        beforeState: `Route score: ${misroute.routeScore} for "${misroute.userMessage.substring(0, 50)}"`,
        afterState: routingResult.success ? `Keywords added, score: ${routingResult.afterScore}` : `Fix failed: ${routingResult.error}`,
        success: routingResult.success,
        rolledBack: routingResult.rolledBack,
      });

      // Enhance system prompt
      const promptResult = await enhanceSystemPrompt(misroute);
      report.promptEnhancements.push(promptResult);
      if (!promptResult.skippedDuplicate) {
        report.repairsApplied.push({
          type: 'enhance_system_prompt',
          target: `brain.js (${misroute.expectedSkill})`,
          classification: 'safe',
          beforeState: `LLM refused "${misroute.refusalPattern}" for capability "${promptResult.capability}"`,
          afterState: promptResult.success ? `Added: "${promptResult.statement.substring(0, 80)}"` : `Enhancement failed: ${promptResult.error}`,
          success: promptResult.success,
          rolledBack: promptResult.rolledBack,
          backupId: promptResult.backupId,
        });
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// REPORT GENERATOR
// ═══════════════════════════════════════════════════════════════

/**
 * Split a long message into chunks of max 4096 chars for Telegram.
 * Splits at newline boundaries to avoid breaking mid-line.
 * @param {string} text - Full report text
 * @returns {string[]} - Array of message chunks
 */
export function splitMessage(text) {
  const MAX_LEN = 4096;
  if (text.length <= MAX_LEN) return [text];

  const chunks = [];
  let remaining = text;

  while (remaining.length > MAX_LEN) {
    // Find last newline within the limit
    let splitIdx = remaining.lastIndexOf('\n', MAX_LEN);
    if (splitIdx === -1 || splitIdx < MAX_LEN * 0.5) {
      // No good newline found — force split at limit
      splitIdx = MAX_LEN;
    }
    chunks.push(remaining.substring(0, splitIdx));
    remaining = remaining.substring(splitIdx).replace(/^\n/, '');
  }

  if (remaining.length > 0) {
    chunks.push(remaining);
  }

  return chunks;
}

/**
 * Generates a formatted diagnostic report for Telegram delivery.
 * @param {DiagnosticReport} report - Full report with all results
 * @returns {string[]} - Array of formatted message chunks (each <= 4096 chars)
 */
export function generateReport(report) {
  const statusEmoji = { pass: '✅', warn: '⚠️', critical: '🔴' };
  const lines = [];

  // Header
  lines.push(`🏥 *RAJA Self-Diagnostic Report*`);
  lines.push(`📊 Health Score: *${report.healthScore}/100*`);
  lines.push(`⏰ ${new Date(report.timestamp).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`);
  lines.push('');

  // Checks performed
  lines.push('━━━ *Checks* ━━━');
  for (const check of report.checks) {
    const emoji = statusEmoji[check.status] || '❓';
    lines.push(`${emoji} [${check.category}] ${check.summary}`);
  }
  lines.push('');

  // Issues found
  const issues = report.checks.filter(c => c.status !== 'pass');
  if (issues.length > 0) {
    lines.push('━━━ *Issues* ━━━');
    for (const issue of issues) {
      for (const detail of (issue.details || []).slice(0, 5)) {
        if (detail.file) lines.push(`  • ${detail.file}: ${detail.error || detail.type}`);
        else if (detail.pattern) lines.push(`  • ${detail.pattern} (${detail.count}x)`);
        else if (detail.name) lines.push(`  • ${detail.name}: ${detail.reachable ? 'OK' : detail.error}`);
      }
    }
    lines.push('');
  }

  // Auto-fixes applied
  const successes = report.repairsApplied.filter(r => r.success);
  if (successes.length > 0) {
    lines.push('━━━ *Auto-Fixes Applied* ━━━');
    for (const fix of successes) {
      lines.push(`🔧 [${fix.type}] ${fix.target}`);
      if (fix.afterState) lines.push(`   → ${fix.afterState}`);
    }
    lines.push('');
  }

  // Code repairs
  if (report.codeRepairs.length > 0) {
    lines.push('━━━ *Code Repairs* ━━━');
    for (const cr of report.codeRepairs) {
      const icon = cr.success ? '✅' : (cr.rolledBack ? '⏪' : '❌');
      lines.push(`${icon} ${cr.file} (${cr.errorType})`);
      lines.push(`   Fix: ${cr.fixDescription?.substring(0, 100) || 'N/A'}`);
    }
    lines.push('');
  }

  // Package installs
  if (report.packageInstalls.length > 0) {
    lines.push('━━━ *Package Installs* ━━━');
    for (const pi of report.packageInstalls) {
      const icon = pi.success ? '📦' : '❌';
      lines.push(`${icon} ${pi.packageName} → ${pi.skillFile} ${pi.verified ? '(verified)' : '(failed)'}`);
    }
    lines.push('');
  }

  // Import fixes
  if (report.importFixes.length > 0) {
    lines.push('━━━ *Import Fixes* ━━━');
    for (const imf of report.importFixes) {
      const icon = imf.success ? '🔗' : '❌';
      lines.push(`${icon} ${imf.file}: "${imf.originalImport}" → "${imf.fixedImport}"`);
    }
    lines.push('');
  }

  // Behavioral analysis
  if (report.behavioralMisroutes.length > 0) {
    lines.push('━━━ *🧠 Behavioral Misroutes* ━━━');
    for (const m of report.behavioralMisroutes) {
      lines.push(`  ⚡ "${m.userMessage.substring(0, 60)}" → should route to ${m.expectedSkill} (score: ${m.routeScore})`);
    }
    lines.push('');
  }

  // Routing fixes
  if (report.routingFixes.length > 0) {
    lines.push('━━━ *🔀 Routing Fixes* ━━━');
    for (const rf of report.routingFixes) {
      const icon = rf.success ? '✅' : (rf.rolledBack ? '⏪' : '❌');
      lines.push(`${icon} ${rf.skill}: +${rf.addedKeywords.map(k => k.keyword).join(', ')} (score: ${rf.beforeScore}→${rf.afterScore})`);
    }
    lines.push('');
  }

  // Prompt enhancements
  const promptFixes = report.promptEnhancements.filter(p => !p.skippedDuplicate);
  if (promptFixes.length > 0) {
    lines.push('━━━ *💡 Prompt Enhancements* ━━━');
    for (const pe of promptFixes) {
      const icon = pe.success ? '✅' : (pe.rolledBack ? '⏪' : '❌');
      lines.push(`${icon} ${pe.skillId}: "${pe.statement?.substring(0, 80) || pe.capability}"`);
    }
    lines.push('');
  }

  // Manual intervention needed
  if (report.manualRequired.length > 0) {
    lines.push('━━━ *Needs Manual* ━━━');
    for (const m of report.manualRequired) {
      lines.push(`🚨 [${m.type}] ${m.target}`);
      if (m.error) lines.push(`   Reason: ${m.error}`);
    }
    lines.push('');
  }

  // Footer
  const totalFixes = successes.length;
  const totalManual = report.manualRequired.length;
  lines.push(`📋 Summary: ${totalFixes} fixed, ${totalManual} need manual action`);

  const fullText = lines.join('\n');
  return splitMessage(fullText);
}

// ═══════════════════════════════════════════════════════════════
// BEHAVIORAL ANALYZER
// ═══════════════════════════════════════════════════════════════

/**
 * Detect if a bot response contains a known LLM refusal pattern.
 * @param {string} response - Bot response text
 * @returns {boolean}
 */
export function containsRefusalPattern(response) {
  if (!response) return false;
  const lower = response.toLowerCase();
  return REFUSAL_PATTERNS.some(pattern => lower.includes(pattern.toLowerCase()));
}

/**
 * Extract which refusal phrase was matched in a response.
 * @param {string} response - Bot response text
 * @returns {string | null} - The matched refusal phrase, or null
 */
export function extractRefusalPhrase(response) {
  if (!response) return null;
  const lower = response.toLowerCase();
  for (const pattern of REFUSAL_PATTERNS) {
    if (lower.includes(pattern.toLowerCase())) return pattern;
  }
  return null;
}

/**
 * Cross-reference a user message with SKILL_KEYWORDS to find which skill
 * SHOULD have handled the request (by analyzing keyword overlap at a domain level).
 * @param {string} userMessage - The original user message
 * @returns {{ skillId: string, skillName: string, score: number } | null}
 */
export function findExpectedSkill(userMessage) {
  if (!userMessage) return null;
  const lower = userMessage.toLowerCase();

  let bestSkill = null;
  let bestScore = 0;

  for (const [id, meta] of Object.entries(SKILL_KEYWORDS)) {
    if (id === 'x8') continue; // Skip self
    const weights = meta.weight || {};
    let score = 0;
    for (const [keyword, weight] of Object.entries(weights)) {
      if (lower.includes(keyword.toLowerCase())) {
        score += weight;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestSkill = { skillId: id, skillName: meta.name || id, score };
    }
  }

  // Only return if there's a meaningful match (score >= 2 but routeSkill returned < 3)
  if (bestSkill && bestScore >= 2) return bestSkill;
  return null;
}

/**
 * Detect repeated user requests (dissatisfaction signal) within a message window.
 * Flags sequences where the user rephrased a similar request 2+ times within 5 messages.
 * @param {Object[]} recentMemories - Recent memory entries from getRecent()
 * @returns {Object[]} - Array of { messages: string[], topic: string }
 */
export function detectRepeatedRequests(recentMemories) {
  if (!recentMemories || recentMemories.length < 2) return [];

  // Extract user messages from memories (filter by kind or content pattern)
  const userMessages = recentMemories
    .filter(m => m.kind === 'fact' || m.kind === 'conversation')
    .map(m => m.content || '')
    .filter(c => c.length > 5 && c.length < 500);

  const repeated = [];
  const windowSize = 5;

  for (let i = 0; i < userMessages.length - 1; i++) {
    const window = userMessages.slice(i, i + windowSize);
    const groups = [];

    for (let j = 1; j < window.length; j++) {
      // Simple word overlap ratio
      const words1 = new Set(window[0].toLowerCase().split(/\s+/).filter(w => w.length > 2));
      const words2 = new Set(window[j].toLowerCase().split(/\s+/).filter(w => w.length > 2));
      if (words1.size === 0 || words2.size === 0) continue;

      const intersection = [...words1].filter(w => words2.has(w));
      const ratio = intersection.length / Math.min(words1.size, words2.size);

      if (ratio > 0.6) {
        groups.push(window[j]);
      }
    }

    if (groups.length >= 1) { // At least 2 similar messages (original + 1)
      repeated.push({
        messages: [window[0], ...groups],
        topic: window[0].substring(0, 80),
      });
      i += groups.length; // Skip already-grouped messages
    }
  }

  return repeated;
}

/**
 * Scans Conversation_Memory for behavioral misroutes.
 * @returns {Promise<BehavioralCheckResult>}
 */
export async function analyzeBehavior() {
  const misroutes = [];
  let memoriesScanned = 0;
  let refusalPatternsFound = 0;

  try {
    // Get recent memories with timeout
    const memPromise = getRecent(50, null);
    const memTimeout = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Memory timeout')), TIMEOUTS.memory)
    );
    const memories = await Promise.race([memPromise, memTimeout]);
    memoriesScanned = memories.length;

    // Scan for refusal patterns in bot responses
    for (const mem of memories) {
      const content = mem.content || '';
      // Look for bot responses (stored as "Skill X: ..." pattern)
      if (!containsRefusalPattern(content)) continue;
      refusalPatternsFound++;

      // Try to find the user message that triggered this response
      // Memory entries often have format: "Skill X: [user query]"
      const skillMatch = content.match(/^Skill \w+: "(.+)"/);
      const userMsg = skillMatch ? skillMatch[1] : '';
      if (!userMsg) continue;

      // Check if a skill SHOULD have handled this
      const expected = findExpectedSkill(userMsg);
      if (!expected) continue;

      // Verify that routeSkill actually scored low for this message
      const routeResult = routeSkill(userMsg);
      if (routeResult.score >= 3) continue; // Actually routed correctly, skip

      misroutes.push({
        userMessage: userMsg,
        expectedSkill: expected.skillId,
        expectedSkillName: expected.skillName,
        refusalResponse: content.substring(0, 200),
        refusalPattern: extractRefusalPhrase(content),
        routeScore: routeResult.score,
        timestamp: mem.ts || new Date().toISOString(),
      });
    }

    // Also detect repeated requests
    const repeatedRequests = detectRepeatedRequests(memories);

    let status = 'pass';
    let score = 100;
    if (misroutes.length > 0 && misroutes.length <= 2) { status = 'warn'; score = 70; }
    if (misroutes.length > 2) { status = 'critical'; score = 30; }

    return {
      status,
      category: 'behavioral',
      summary: misroutes.length === 0
        ? 'No behavioral misroutes detected'
        : `${misroutes.length} behavioral misroute(s) detected`,
      details: misroutes.map(m => ({ skill: m.expectedSkill, message: m.userMessage.substring(0, 50) })),
      score,
      misroutes,
      repeatedRequests,
      memoriesScanned,
      refusalPatternsFound,
    };
  } catch (err) {
    return {
      status: 'pass',
      category: 'behavioral',
      summary: `Behavioral analysis skipped: ${err.message}`,
      details: [],
      score: 100,
      misroutes: [],
      repeatedRequests: [],
      memoriesScanned,
      refusalPatternsFound: 0,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// ROUTING GAP FIXER
// ═══════════════════════════════════════════════════════════════

/**
 * Extract keywords/phrases from a failed user message that would trigger correct routing.
 * @param {string} userMessage - The message that failed to route
 * @param {string} targetSkill - The skill ID it should route to
 * @returns {string[]} - Extracted keywords (not already in SKILL_KEYWORDS[targetSkill])
 */
export function extractMissingKeywords(userMessage, targetSkill) {
  if (!userMessage || !targetSkill) return [];
  const lower = userMessage.toLowerCase();

  // Tokenize into meaningful phrases (2-3 word ngrams + single words)
  const words = lower.split(/\s+/).filter(w => w.length >= 3);
  const stopWords = new Set(['yang', 'dan', 'atau', 'dari', 'untuk', 'dengan', 'ini', 'itu', 'ada', 'bisa', 'akan', 'sudah', 'belum', 'juga', 'kalau', 'mau', 'tolong', 'coba', 'please', 'the', 'and', 'for', 'with', 'this', 'that']);

  const candidates = new Set();

  // Single words (filtered)
  for (const w of words) {
    if (!stopWords.has(w) && w.length >= 3) candidates.add(w);
  }

  // 2-word phrases
  for (let i = 0; i < words.length - 1; i++) {
    if (!stopWords.has(words[i]) || !stopWords.has(words[i + 1])) {
      candidates.add(`${words[i]} ${words[i + 1]}`);
    }
  }

  // Filter out keywords already in SKILL_KEYWORDS[targetSkill]
  const existing = SKILL_KEYWORDS[targetSkill]?.weight || {};
  const existingKeys = new Set(Object.keys(existing).map(k => k.toLowerCase()));

  return [...candidates].filter(k => !existingKeys.has(k));
}

/**
 * Assign weights to keywords based on specificity/ambiguity.
 * Weight 3: keyword appears in no other skill's keyword set
 * Weight 2: keyword appears in at least one other skill's keyword set
 * @param {string[]} keywords - Keywords to weigh
 * @param {string} targetSkill - The target skill ID
 * @returns {{keyword: string, weight: number}[]}
 */
export function assignKeywordWeights(keywords, targetSkill) {
  return keywords.map(keyword => {
    const lower = keyword.toLowerCase();
    let foundInOther = false;

    for (const [id, meta] of Object.entries(SKILL_KEYWORDS)) {
      if (id === targetSkill) continue;
      const weights = meta.weight || {};
      for (const existingKey of Object.keys(weights)) {
        if (existingKey.toLowerCase() === lower || existingKey.toLowerCase().includes(lower) || lower.includes(existingKey.toLowerCase())) {
          foundInOther = true;
          break;
        }
      }
      if (foundInOther) break;
    }

    return { keyword, weight: foundInOther ? 2 : 3 };
  });
}

/**
 * Verify that adding keywords doesn't break existing routing.
 * @param {string} targetSkill - The skill receiving new keywords
 * @param {{keyword: string, weight: number}[]} newKeywords - Keywords being added
 * @returns {{ safe: boolean, conflicts: { message: string, originalSkill: string, newSkill: string }[] }}
 */
export function verifyNoRoutingCollision(targetSkill, newKeywords) {
  const conflicts = [];

  // For each OTHER skill, check if any of its typical trigger messages would now misroute
  for (const [id, meta] of Object.entries(SKILL_KEYWORDS)) {
    if (id === targetSkill) continue;
    const skillKeywords = Object.keys(meta.weight || {});

    // Use each skill's own keywords as representative messages
    for (const kw of skillKeywords.slice(0, 3)) { // Test top 3 keywords
      // Simulate: would this message route to targetSkill instead?
      let targetScore = 0;
      for (const nk of newKeywords) {
        if (kw.toLowerCase().includes(nk.keyword.toLowerCase())) {
          targetScore += nk.weight;
        }
      }
      // Also add existing targetSkill score for this message
      const existingWeights = SKILL_KEYWORDS[targetSkill]?.weight || {};
      for (const [ek, ew] of Object.entries(existingWeights)) {
        if (kw.toLowerCase().includes(ek.toLowerCase())) targetScore += ew;
      }

      // Check original skill's score for its own keyword
      const originalScore = meta.weight[kw] || 0;

      if (targetScore > originalScore) {
        conflicts.push({ message: kw, originalSkill: id, newSkill: targetSkill });
      }
    }
  }

  return { safe: conflicts.length === 0, conflicts };
}

/**
 * Fixes a routing gap by adding missing keywords to SKILL_KEYWORDS via Code_Engine.
 * @param {BehavioralMisroute} misroute
 * @returns {Promise<RoutingFixResult>}
 */
export async function fixRoutingGap(misroute) {
  const beforeScore = misroute.routeScore;

  // 1. Extract missing keywords
  const keywords = extractMissingKeywords(misroute.userMessage, misroute.expectedSkill);
  if (keywords.length === 0) {
    return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: [], beforeScore, afterScore: beforeScore, verified: false, rolledBack: false, error: 'No keywords extractable', backupId: '', conflicts: [] };
  }

  // 2. Assign weights
  const weighted = assignKeywordWeights(keywords.slice(0, 5), misroute.expectedSkill); // Limit to top 5

  // 3. Check for routing collisions
  const collision = verifyNoRoutingCollision(misroute.expectedSkill, weighted);
  if (!collision.safe) {
    return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore: beforeScore, verified: false, rolledBack: false, error: 'Routing collision detected', backupId: '', conflicts: collision.conflicts };
  }

  // 4. Use Code_Engine to add keywords to skill-registry.js
  const keywordEntries = weighted.map(k => `'${k.keyword}':${k.weight}`).join(', ');
  const instruction = `Add keywords to SKILL_KEYWORDS.${misroute.expectedSkill}.weight in src/core/skill-registry.js: ${keywordEntries}`;
  const context = `The skill "${misroute.expectedSkill}" (${misroute.expectedSkillName}) needs additional routing keywords. Add these to its "weight" object in SKILL_KEYWORDS: ${keywordEntries}. Do NOT remove existing keywords — only ADD new ones.`;

  try {
    const plan = await Promise.race([
      generateCodeChanges(instruction, context),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), TIMEOUTS.codeEngine)),
    ]);

    if (!plan || !plan.files || plan.files.length === 0) {
      return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore: beforeScore, verified: false, rolledBack: false, error: 'LLM returned empty plan', backupId: '' };
    }

    const result = await executePlan(plan, (msg) => logger.info(`[x8-routing-fix] ${msg}`));
    if (!result.success) {
      return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore: beforeScore, verified: false, rolledBack: true, error: result.error, backupId: result.backupId || '' };
    }

    // 5. Verify routing now works
    // Need to re-import skill-registry to get updated SKILL_KEYWORDS
    // (For now, use a simple heuristic: the added weights should give score >= 3)
    const afterScore = beforeScore + weighted.reduce((sum, k) => sum + k.weight, 0);
    const verified = afterScore >= 3;

    if (!verified) {
      try {
        const { restoreBackup } = await import('../self-upgrade/backup.js');
        await restoreBackup(result.backupId || 'latest');
      } catch {}
      return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore, verified: false, rolledBack: true, error: 'Score still below 3 after fix', backupId: result.backupId || '' };
    }

    return { success: true, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore, verified: true, rolledBack: false, backupId: result.backupId || '' };
  } catch (err) {
    return { success: false, skill: misroute.expectedSkill, skillName: misroute.expectedSkillName, addedKeywords: weighted, beforeScore, afterScore: beforeScore, verified: false, rolledBack: false, error: err.message, backupId: '' };
  }
}

// ═══════════════════════════════════════════════════════════════
// SYSTEM PROMPT ENHANCER
// ═══════════════════════════════════════════════════════════════

/**
 * Generate a Capability_Awareness statement for a given skill capability.
 * @param {string} skillId - The skill ID
 * @param {string} skillName - Human-readable skill name
 * @param {string} capability - Description of what the skill can do
 * @returns {string} - The awareness statement to insert
 */
export function generateCapabilityStatement(skillId, skillName, capability) {
  return `- Kamu BISA ${capability} via skill ${skillId} (${skillName}) — gunakan ${skillId} untuk ${capability}`;
}

/**
 * Check if a capability statement already exists in SYSTEM_PROMPT.
 * @param {string} systemPrompt - Current SYSTEM_PROMPT content
 * @param {string} skillId - The skill to check
 * @param {string} capability - The capability to check
 * @returns {boolean} - True if already declared
 */
export function isDuplicateCapability(systemPrompt, skillId, capability) {
  if (!systemPrompt) return false;
  const lower = systemPrompt.toLowerCase();
  // Check if skillId is already mentioned in a capability context
  if (lower.includes(`via skill ${skillId}`.toLowerCase()) || lower.includes(`gunakan ${skillId}`.toLowerCase())) {
    // Check capability overlap (>70% word match)
    const capWords = new Set(capability.toLowerCase().split(/\s+/).filter(w => w.length > 2));
    const lines = systemPrompt.split('\n');
    for (const line of lines) {
      if (!line.toLowerCase().includes(skillId.toLowerCase())) continue;
      const lineWords = new Set(line.toLowerCase().split(/\s+/).filter(w => w.length > 2));
      const overlap = [...capWords].filter(w => lineWords.has(w));
      if (capWords.size > 0 && overlap.length / capWords.size > 0.7) return true;
    }
  }
  return false;
}

/**
 * Verify that brain.js still exports processMessage and getSession after modification.
 * @param {string} brainPath - Absolute path to brain.js
 * @returns {Promise<{ valid: boolean, error?: string }>}
 */
export async function verifyBrainExports(brainPath) {
  try {
    const importPath = `file://${brainPath.replace(/\\/g, '/')}?t=${Date.now()}`;
    const importPromise = import(importPath);
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Brain.js import timeout (5s)')), TIMEOUTS.brainExportVerification)
    );
    const mod = await Promise.race([importPromise, timeoutPromise]);

    if (typeof mod.processMessage !== 'function') {
      return { valid: false, error: 'processMessage is not a function or missing' };
    }
    if (typeof mod.getSession !== 'function') {
      return { valid: false, error: 'getSession is not a function or missing' };
    }
    return { valid: true };
  } catch (err) {
    return { valid: false, error: err.message || String(err) };
  }
}

/**
 * Determine where in the SYSTEM_PROMPT to insert the capability statement.
 * @param {string} systemPrompt - Current SYSTEM_PROMPT content
 * @returns {string} - Section identifier describing where insertion should occur
 */
export function findInsertionPoint(systemPrompt) {
  // Look for existing CAPABILITY AWARENESS section
  if (systemPrompt.includes('CAPABILITY AWARENESS')) {
    return 'CAPABILITY AWARENESS';
  }
  // Look for INFRASTRUKTUR section
  if (systemPrompt.includes('═══ INFRASTRUKTUR ═══')) {
    return 'AFTER_INFRASTRUKTUR';
  }
  // Look for INTENT section (insert before it)
  if (systemPrompt.includes('═══ INTENT ═══')) {
    return 'BEFORE_INTENT';
  }
  // Fallback: append near end
  return 'END';
}

/**
 * Enhances SYSTEM_PROMPT in brain.js with a capability awareness statement.
 * @param {BehavioralMisroute} misroute - The misroute with identified capability gap
 * @returns {Promise<PromptEnhanceResult>}
 */
export async function enhanceSystemPrompt(misroute) {
  const fs = await import('fs');
  const path = await import('path');
  const { fileURLToPath } = await import('url');
  const __dirname = path.dirname(fileURLToPath(import.meta.url));
  const brainPath = path.resolve(__dirname, '../core/brain.js');

  // Determine capability description from skill keywords
  const skillMeta = SKILL_KEYWORDS[misroute.expectedSkill];
  const capability = skillMeta ? Object.keys(skillMeta.weight || {}).slice(0, 3).join(', ') : misroute.expectedSkillName;

  // 1. Generate statement
  const statement = generateCapabilityStatement(misroute.expectedSkill, misroute.expectedSkillName, capability);

  // 2. Read current brain.js to check for duplicates
  let brainContent = '';
  try {
    brainContent = fs.readFileSync(brainPath, 'utf8');
  } catch (err) {
    return { success: false, capability, statement, insertionPoint: '', skillId: misroute.expectedSkill, verified: false, rolledBack: false, skippedDuplicate: false, backupId: '', error: `Cannot read brain.js: ${err.message}` };
  }

  // 3. Check for duplicate
  if (isDuplicateCapability(brainContent, misroute.expectedSkill, capability)) {
    return { success: true, capability, statement, insertionPoint: 'DUPLICATE', skillId: misroute.expectedSkill, verified: true, rolledBack: false, skippedDuplicate: true, backupId: '' };
  }

  // 4. Find insertion point
  const insertionPoint = findInsertionPoint(brainContent);

  // 5. Use Code_Engine to add the statement
  const instruction = `Add this capability awareness line to SYSTEM_PROMPT in src/core/brain.js: "${statement}". Insert it ${insertionPoint === 'CAPABILITY AWARENESS' ? 'at the end of the existing CAPABILITY AWARENESS section' : insertionPoint === 'AFTER_INFRASTRUKTUR' ? 'after the ═══ INFRASTRUKTUR ═══ section' : insertionPoint === 'BEFORE_INTENT' ? 'before the ═══ INTENT ═══ section' : 'near the end of SYSTEM_PROMPT'}. This is an ADDITIVE change only — do NOT remove or modify any existing content.`;
  const context = `The bot needs to be aware that it has the capability: "${capability}" via skill ${misroute.expectedSkill}. Add a line to SYSTEM_PROMPT declaring this capability. IMPORTANT: Only ADD this one line — do not change anything else in the file.`;

  try {
    const plan = await Promise.race([
      generateCodeChanges(instruction, context),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), TIMEOUTS.codeEngine)),
    ]);

    if (!plan || !plan.files || plan.files.length === 0) {
      return { success: false, capability, statement, insertionPoint, skillId: misroute.expectedSkill, verified: false, rolledBack: false, skippedDuplicate: false, backupId: '', error: 'LLM returned empty plan' };
    }

    const result = await executePlan(plan, (msg) => logger.info(`[x8-prompt-enhance] ${msg}`));
    if (!result.success) {
      return { success: false, capability, statement, insertionPoint, skillId: misroute.expectedSkill, verified: false, rolledBack: true, skippedDuplicate: false, backupId: result.backupId || '', error: result.error };
    }

    // 6. Verify brain.js still exports correctly
    const verification = await verifyBrainExports(brainPath);
    if (!verification.valid) {
      try {
        const { restoreBackup } = await import('../self-upgrade/backup.js');
        await restoreBackup(result.backupId || 'latest');
      } catch {}
      return { success: false, capability, statement, insertionPoint, skillId: misroute.expectedSkill, verified: false, rolledBack: true, skippedDuplicate: false, backupId: result.backupId || '', error: `Brain.js broken: ${verification.error}` };
    }

    return { success: true, capability, statement, insertionPoint, skillId: misroute.expectedSkill, verified: true, rolledBack: false, skippedDuplicate: false, backupId: result.backupId || '' };
  } catch (err) {
    return { success: false, capability, statement, insertionPoint, skillId: misroute.expectedSkill, verified: false, rolledBack: false, skippedDuplicate: false, backupId: '', error: err.message };
  }
}

// ═══════════════════════════════════════════════════════════════
// SKILL INTERFACE
// ═══════════════════════════════════════════════════════════════

export default {
  id: 'x8',
  name: 'diagnostic',
  description: 'Self-diagnostic dan auto-repair: cek kesehatan semua subsystem, perbaiki masalah ringan, LLM-powered code fix',
  keywords: {
    'perbaiki dirimu': 3,
    'cek kesehatan': 3,
    'self repair': 3,
    'diagnosa': 3,
    'health check': 3,
    'diagnostic': 3,
  },

  /**
   * Execute the self-diagnostic and auto-repair pipeline.
   * @param {string} query - User's message/query
   * @param {Object} context - Execution context (chatId, bot, etc.)
   * @returns {string} - Diagnostic report text
   */
  async execute(query, context) {
    const { getBot } = await import('../telegram/bot.js');
    const { rememberFact } = await import('../core/memory.js');
    const { config } = await import('../config.js');
    const bot = getBot();
    const chatId = config.telegram.allowedUserId;

    // 1. Acknowledge immediately
    try {
      if (bot) await bot.sendMessage(chatId, '🔍 Starting self-diagnostic scan...');
    } catch {}

    const startTime = Date.now();

    // 2. Run all diagnostic checks in parallel
    const checkPromises = [
      checkSkillLoads().catch(err => ({ status: 'critical', category: 'skills', summary: `Error: ${err.message}`, details: [], score: 0, loadedSkills: [], failedSkills: [], orphanedKeywords: [] })),
      checkIntegrity().catch(err => ({ status: 'critical', category: 'integrity', summary: `Error: ${err.message}`, details: [], score: 0, modified: [], missing: [], added: [], tampered: false })),
      checkLLMProviders().catch(err => ({ status: 'critical', category: 'llm', summary: `Error: ${err.message}`, details: [], score: 0, providers: [], allDown: true })),
      checkTelegramConnection().catch(err => ({ status: 'critical', category: 'telegram', summary: `Error: ${err.message}`, details: [], score: 0, connected: false, error: err.message })),
      scanLogs().catch(err => ({ status: 'pass', category: 'logs', summary: `Error: ${err.message}`, details: [], score: 80, recurringErrors: [], totalErrorCount: 0, totalWarnCount: 0, linesScanned: 0 })),
      analyzeBehavior().catch(err => ({ status: 'pass', category: 'behavioral', summary: `Skipped: ${err.message}`, details: [], score: 100, misroutes: [], repeatedRequests: [], memoriesScanned: 0, refusalPatternsFound: 0 })),
    ];

    // Send progress updates as each check completes
    const checks = [];
    const labels = ['Skills', 'Integrity', 'LLM', 'Telegram', 'Logs', 'Behavioral'];
    const results = await Promise.allSettled(checkPromises);

    for (let i = 0; i < results.length; i++) {
      const result = results[i].status === 'fulfilled' ? results[i].value : { status: 'critical', category: labels[i].toLowerCase(), summary: `Check crashed`, details: [], score: 0 };
      checks.push(result);
      try {
        const emoji = result.status === 'pass' ? '✅' : result.status === 'warn' ? '⚠️' : '🔴';
        if (bot) await bot.sendMessage(chatId, `${emoji} ${labels[i]}: ${result.summary}`);
      } catch {}
    }

    // 3. Build DiagnosticReport
    /** @type {DiagnosticReport} */
    const report = {
      timestamp: new Date().toISOString(),
      healthScore: 0,
      checks,
      repairsApplied: [],
      manualRequired: [],
      codeRepairs: [],
      packageInstalls: [],
      importFixes: [],
      behavioralMisroutes: [],
      routingFixes: [],
      promptEnhancements: [],
    };

    // 4. Execute repairs
    try {
      if (bot) await bot.sendMessage(chatId, '🔧 Running auto-repair...');
    } catch {}

    try {
      await executeRepairs(report);
    } catch (err) {
      logger.error(`[x8] executeRepairs error: ${err.message}`);
    }

    // 5. Compute health score
    report.healthScore = computeHealthScore(report);

    // 6. Generate formatted report
    const messages = generateReport(report);

    // 7. Send report via Telegram
    for (const msg of messages) {
      try {
        if (bot) await bot.sendMessage(chatId, msg, { parse_mode: 'Markdown' });
      } catch {
        // Try without markdown if formatting fails
        try {
          if (bot) await bot.sendMessage(chatId, msg);
        } catch {}
      }
    }

    // 8. Store report in memory
    try {
      await rememberFact({
        content: `Diagnostic report: score=${report.healthScore}, repairs=${report.repairsApplied.filter(r => r.success).length}, manual=${report.manualRequired.length}`,
        kind: 'diagnostic',
        tags: 'x8,diagnostic,auto',
        weight: 2.0,
      });
    } catch {}

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    logger.info(`[x8] Diagnostic complete in ${elapsed}s. Score: ${report.healthScore}`);

    // Return null so brain.js doesn't send the report again (we already sent via Telegram)
    return null;
  },
};
