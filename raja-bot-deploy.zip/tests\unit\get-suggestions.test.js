// tests/unit/get-suggestions.test.js — Unit tests for getSuggestions()
import { describe, it, expect } from 'vitest';
import { getSuggestions, matchSkills } from '../../src/core/skill-registry.js';

describe('getSuggestions', () => {
  it('should return an empty array for empty or invalid input', () => {
    expect(getSuggestions('')).toEqual([]);
    expect(getSuggestions(null)).toEqual([]);
    expect(getSuggestions(undefined)).toEqual([]);
  });

  it('should return top 3 results by default', () => {
    const results = getSuggestions('swap token bridge defi lending');
    expect(results.length).toBeLessThanOrEqual(3);
    expect(results.length).toBeGreaterThan(0);
  });

  it('should respect custom n parameter', () => {
    const results = getSuggestions('deploy vps server docker nginx', 5);
    expect(results.length).toBeLessThanOrEqual(5);
    expect(results.length).toBeGreaterThan(0);
  });

  it('should return results sorted by score descending', () => {
    const results = getSuggestions('swap token bridge');
    for (let i = 1; i < results.length; i++) {
      expect(results[i - 1].score).toBeGreaterThanOrEqual(results[i].score);
    }
  });

  it('should return SkillMatch objects with correct shape', () => {
    const results = getSuggestions('deploy kontrak');
    expect(results.length).toBeGreaterThan(0);
    for (const result of results) {
      expect(result).toHaveProperty('skillId');
      expect(result).toHaveProperty('score');
      expect(result).toHaveProperty('maxTheoreticalScore');
      expect(result).toHaveProperty('description');
      expect(typeof result.skillId).toBe('string');
      expect(typeof result.score).toBe('number');
      expect(typeof result.maxTheoreticalScore).toBe('number');
      expect(typeof result.description).toBe('string');
      expect(result.description.length).toBeGreaterThan(0);
    }
  });

  it('should return same results as matchSkills sliced to n', () => {
    const input = 'riset hipotesis eksperimen paper';
    const allMatches = matchSkills(input);
    const suggestions = getSuggestions(input, 3);
    expect(suggestions).toEqual(allMatches.slice(0, 3));
  });

  it('should return fewer than n when matchSkills returns less', () => {
    // Very specific input that likely matches only 1-2 skills
    const results = getSuggestions('zzzzz_nomatch_xyz', 3);
    expect(results.length).toBe(0);
  });

  it('should return at most n results even when many skills match', () => {
    // Broad input matching many skills
    const results = getSuggestions('api data deploy server bot', 2);
    expect(results.length).toBeLessThanOrEqual(2);
  });

  it('should include one-line descriptions for each suggestion', () => {
    const results = getSuggestions('swap token');
    for (const result of results) {
      expect(result.description).toBeTruthy();
      // Descriptions should be reasonably short (one-line)
      expect(result.description.length).toBeLessThan(200);
    }
  });

  it('should work with n=1 returning only the best match', () => {
    const results = getSuggestions('swap 1inch jupiter', 1);
    expect(results.length).toBeLessThanOrEqual(1);
    if (results.length === 1) {
      const allMatches = matchSkills('swap 1inch jupiter');
      expect(results[0].skillId).toBe(allMatches[0].skillId);
    }
  });

  it('should handle n=0 returning empty array', () => {
    const results = getSuggestions('swap token', 0);
    expect(results).toEqual([]);
  });
});
