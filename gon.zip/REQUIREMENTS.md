# LYSANDER AGENT - VPS DEPENDENCIES
# OS: Ubuntu 22.04 / 24.04 LTS

## System Requirements
- CPU: Min 1vCPU (2vCPU Recommended)
- RAM: Min 2GB (4GB Recommended for LLM local integration)
- Disk: 10GB+ Free Space

## Required Software
1. Node.js (LTS Recommended: v20+)
2. NPM (Node Package Manager)
3. PM2 (Process Manager for Node.js)
4. TypeScript (Development build tool)
5. Git (For cloning repository)

## Quick Install List
- curl
- git
- build-essential
- nodejs/npm
- pm2
