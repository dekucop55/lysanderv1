import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs-extra';
import path from 'path';

const executeAsync = promisify(exec);

export class Executor {
    async shellExecute(command, workdir = '/home/acer/Lysander') {
        try {
            const { stdout, stderr } = await executeAsync(command, { cwd: workdir });
            return { stdout, stderr, code: 0 };
        } catch (error) {
            return { 
                stdout: error.stdout || '', 
                stderr: error.stderr || error.message, 
                code: error.code || 1 
            };
        }
    }

    async writeFile(filePath, content) {
        await fs.ensureDir(path.dirname(filePath));
        await fs.writeFile(filePath, content, 'utf8');
    }

    async readFile(filePath) {
        return await fs.readFile(filePath, 'utf8');
    }

    async deleteFile(filePath) {
        await fs.remove(filePath);
    }

    async selfUpdate(filePath, newCode) {
        await this.writeFile(filePath, newCode);
        return `File ${filePath} updated successfully. System evolution applied.`;
    }
}
