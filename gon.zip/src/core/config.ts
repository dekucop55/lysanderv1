import dotenv from 'dotenv';
import path from 'path';

// Use process.cwd() to ensure it works regardless of whether 
// it's run from /home/acer/Lysander or /root/Lysander
dotenv.config({ path: path.join(process.cwd(), '.env') });

export const CONFIG = {
    server: {
        port: process.env.PORT || 3000,
        env: process.env.NODE_ENV || 'development',
        ip: process.env.SERVER_IP,
    },
    telegram: {
        token: process.env.BOT_TOKEN,
        allowedUserId: process.env.ALLOWED_USER_ID,
    },
    models: {
        ollama: {
            apiKey: process.env.OLLAMA_API_KEY,
            baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
            model: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
        },
        openrouter: {
            apiKey: process.env.OPENROUTER_API_KEY,
            baseUrl: process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1',
            model: process.env.OPENROUTER_MODEL || 'moonshotai/kimi-k2.6:free',
        },
        providers: {
            anthropic: process.env.ANTHROPIC_API_KEY,
            kimi: process.env.KIMI_API_KEY,
            deepseek: process.env.DEEPSEEK_API_KEY,
            groq: process.env.GROQ_API_KEY,
        }
    },
    web3: {
        rpcEth: process.env.RPC_URL_ETH,
        rpcBsc: process.env.RPC_URL_BSC,
        rpcSol: process.env.RPC_URL_SOL,
        privateKey: process.env.PRIVATE_KEY,
    }
};

export function validateConfig() {
    const missing = [];
    if (!CONFIG.telegram.token) missing.push('BOT_TOKEN');
    if (!CONFIG.telegram.allowedUserId) missing.push('ALLOWED_USER_ID');
    if (!CONFIG.web3.privateKey) missing.push('PRIVATE_KEY');

    if (missing.length > 0) {
        console.warn(`[CONFIG WARNING] Missing essential variables: ${missing.join(', ')}`);
        return false;
    }
    return true;
}
