module.exports = {
  apps: [
    {
      name: 'lysander-agent',
      script: './dist/index.js',
      cwd: '/root/Lysander', // Set this to your actual project path on VPS
      instances: 1,
      exec_mode: 'fork',
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production'
      },
      error_file: './logs/err.log',
      out_file: './logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
};
