#!/bin/bash

# LYSANDER AUTO-DEPLOY SCRIPT
# target: Ubuntu VPS (/root/Lysander)

set -e

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  🚀 LYSANDER SOVEREIGN AGENT - DEPLOYMENT"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# 1. Update system and install basic tools
echo "[1/6] Updating system and installing dependencies..."
apt-get update && apt-get install -y curl git build-essential

# 2. Install Node.js (LTS v20)
if ! command -v node &> /dev/null; then
    echo "[2/6] Installing Node.js LTS..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
else
    echo "[2/6] Node.js already installed. Skipping."
fi

# 3. Install PM2 globally
if ! command -v pm2 &> /dev/null; then
    echo "[3/6] Installing PM2..."
    npm install -g pm2
else
    echo "[3/6] PM2 already installed. Skipping."
fi

# 4. Install project dependencies
echo "[4/6] Installing project dependencies..."
npm install

# 5. Build TypeScript to JavaScript
echo "[5/6] Compiling TypeScript source..."
npm run build

# 6. Deployment to PM2
echo "[6/6] Deploying to PM2..."
# Create logs directory if not exists
mkdir -p logs

# Restart if already exists, otherwise start
pm2 describe lysander-agent > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "🔄 Restarting existing agent..."
    pm2 restart lysander-agent
else
    echo "🆕 Starting agent for the first time..."
    pm2 start ecosystem.config.cjs
fi

# Save PM2 process list for server reboot
pm2 save

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ DEPLOYMENT COMPLETE!"
echo "  Bot is now running in background via PM2."
echo "  Check logs: pm2 logs lysander-agent"
echo "  Status:    pm2 status"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
