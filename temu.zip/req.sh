#!/bin/bash

# ==============================================================================
# OPENCLAW VPS AUTO-SETUP SCRIPT (Router & Crypto Suite)
# ==============================================================================
# Deskripsi: Mengonfigurasi environment dasar, folder skill, dan dependensi 
#            untuk menjalankan SuperAgent 4.0 IronClaw di VPS.
# ==============================================================================

set -e

# Warna untuk output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}[*] Memulai Auto-Setup OpenClaw Framework...${NC}"

# 1. Update & Dasar System
echo -e "${GREEN}[1/5] Menginstal dependensi sistem...${NC}"
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv git curl jq build-essential

# 2. Persiapan Struktur Folder (Sesuai Arsitektur OpenClaw)
echo -e "${GREEN}[2/5] Membangun struktur folder Agent...${NC}"
mkdir -p ~/openclaw/{skills/hermes/references,skills/hermes/scripts,tools,memory}

# Membuat file boot utama jika belum ada
touch ~/openclaw/AGENTS.md
touch ~/openclaw/IDENTITY.md
touch ~/openclaw/SOUL.md
touch ~/openclaw/TOOLS.md
touch ~/openclaw/TIME.md
touch ~/openclaw/USER.md
touch ~/openclaw/MEMORY.md

# 3. Setup Python Virtual Environment
echo -e "${GREEN}[3/5] Mengonfigurasi Python Venv...${NC}"
python3 -m venv ~/openclaw/venv
source ~/openclaw/venv/bin/activate

# Instalasi core library yang dibutuhkan oleh Hermes Suite & Tools
pip install --upgrade pip
pip install ethers web3 requests python-dotenv pydantic openai anthropic

# 4. Setup Environment Variables
echo -e "${GREEN}[4/5] Skipping .env creation (User will handle manually)...${NC}"

# 5. Health Check
echo -e "${GREEN}[5/5] Verifikasi Instalasi...${NC}"
if [ -d "$HOME/openclaw/skills/hermes/scripts" ]; then
    echo -e "${BLUE}✅ Struktur folder OpenClaw berhasil dibuat.${NC}"
else
    echo "❌ Gagal membuat struktur folder."
    exit 1
fi

echo -e "\n${BLUE}=============================================================${NC}"
echo -e "${GREEN}SETUP SELESAI!${NC}"
echo -e "Lokasi Project: ${BLUE}~/openclaw${NC}"
echo -e "Aktifkan Venv dengan: ${BLUE}source ~/openclaw/venv/bin/activate${NC}"
echo -e "Selanjutnya: Salin file .md dan .py dari lokal ke folder ~/openclaw/"
echo -e "${BLUE}=============================================================${NC}"
