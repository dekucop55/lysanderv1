"""
tools/model_registry.py — Dynamic LLM Model Registry (v4.0 Sovereign Edition)
Implements a priority-based cascade with encrypted storage and runtime modification.
"""
from __future__ import annotations

import base64
import json
import os
import sqlite3
import logging
from pathlib import Path
from typing import Optional, Literal, List, Dict, Any
from dataclasses import dataclass

import httpx
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.backends import default_backend
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ModelRegistry")

Kind = Literal["openai", "anthropic"]
# Store DB in the agent root to keep it sovereign and portable
DEFAULT_DB = Path("./models.db").expanduser()

@dataclass
class ModelConfig:
    name: str
    base_url: str
    model: str
    kind: str
    priority: int
    headers: dict
    api_key: Optional[str] = None

class ModelRegistry:
    def __init__(self, master_pw: Optional[str] = None, db_path: Path = DEFAULT_DB):
        # Master Password for Encryption (Sovereign Key)
        self.master_pw = master_pw or os.environ.get("HERMES_MASTER_PW", "lysander_default_pw")
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize SQLite DB
        self.db = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.db.execute("""CREATE TABLE IF NOT EXISTS models (
            name TEXT PRIMARY KEY, base_url TEXT, model TEXT, kind TEXT,
            priority INTEGER DEFAULT 100, headers TEXT DEFAULT '{}', enc_key TEXT DEFAULT '')""")
        self.db.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
        self.db.commit()
        
        # Initialize Encryption using Scrypt
        self.fernet = self._init_fernet()
        self._seed_from_env()

    def _init_fernet(self):
        salt = b'lysander_sovereign_salt' # Consistent salt for local persistence
        kdf = Scrypt(password=self.master_pw.encode(), salt=salt, length=32, 
                    n=2**14, r=8, p=1, backend=default_backend())
        key = base64.urlsafe_b64encode(kdf.derive(self.master_pw.encode()))
        return Fernet(key)

    def _encrypt(self, text: str) -> str:
        return self.fernet.encrypt(text.encode()).decode()

    def _decrypt(self, token: str) -> str:
        return self.fernet.decrypt(token.encode()).decode()

    def _seed_from_env(self):
        """Synchronizes .env keys into the encrypted DB if they don't exist."""
        seeds = [
            ("cloud_gemma", os.getenv("OLLAMA_CLOUD_URL"), "gemma4:31b", "openai", 10, os.getenv("GEMMA4_API_KEY")),
            ("openrouter_kimi", os.getenv("OPENROUTER_BASE_URL"), os.getenv("OPENROUTER_MODEL"), "openai", 20, os.getenv("OPENROUTER_API_KEY")),
            ("local_ollama", os.getenv("OLLAMA_BASE_URL"), os.getenv("OLLAMA_MODEL_PRIMARY"), "openai", 30, None),
        ]
        for name, url, model, kind, prio, key in seeds:
            if url and model:
                self.add_model(name, url, model, kind, prio, key)

    def add_model(self, name: str, base_url: str, model: str, kind: str, priority: int = 100, api_key: Optional[str] = None):
        """Add or update a model in the registry (The 'add model' command target)."""
        enc_key = self._encrypt(api_key) if api_key else ''
        headers = json.dumps({"Content-Type": "application/json"})
        
        self.db.execute("""INSERT OR REPLACE INTO models 
            (name, base_url, model, kind, priority, headers, enc_key) 
            VALUES (?, ?, ?, ?, ?, ?, ?)""", 
            (name, base_url, model, kind, priority, headers, enc_key))
        self.db.commit()
        logger.info(f"Model {name} added/updated with priority {priority}.")

    def get_all_models(self) -> List[ModelConfig]:
        """Returns all models sorted by priority (The Sovereign Cascade)."""
        cursor = self.db.execute("SELECT * FROM models ORDER BY priority ASC")
        models = []
        for row in cursor:
            key = self._decrypt(row[6]) if row[6] else None
            models.append(ModelConfig(
                name=row[0], base_url=row[1], model=row[2], 
                kind=row[3], priority=row[4], headers=json.loads(row[5]), api_key=key
            ))
        return models

    async def call_with_cascade(self, messages: List[Dict]) -> str:
        """
        Sovereign Cascade Execution:
        Tries models in order of priority (lowest number = highest priority).
        """
        models = self.get_all_models()
        
        for m in models:
            try:
                logger.info(f"Attempting call via {m.name} (Priority {m.priority})...")
                
                if m.kind == "openai":
                    response = await self._call_openai(m, messages)
                    if response: return response
                elif m.kind == "anthropic":
                    response = await self._call_anthropic(m, messages)
                    if response: return response
                    
            except Exception as e:
                logger.error(f"Model {m.name} failed: {e}")
                continue
        
        return "⚠️ [CRITICAL]: All brains in the cascade failed. Please check HERMES_MASTER_PW, API keys, or VPS connectivity."

    async def _call_openai(self, m: ModelConfig, messages: List[Dict]) -> Optional[str]:
        headers = m.headers.copy()
        if m.api_key:
            headers["Authorization"] = f"Bearer {m.api_key}"
        
        payload = {"model": m.model, "messages": messages}
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            # Handle Ollama-style /api/chat vs OpenAI-style /chat/completions
            endpoint = "/api/chat" if "ollama" in m.base_url.lower() else "/chat/completions"
            resp = await client.post(f"{m.base_url}{endpoint}", json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            
            if "choices" in data: return data["choices"][0]["message"]["content"]
            elif "message" in data: return data["message"]["content"]
        return None

    async def _call_anthropic(self, m: ModelConfig, messages: List[Dict]) -> Optional[str]:
        headers = m.headers.copy()
        if m.api_key:
            headers["x-api-key"] = m.api_key
        
        payload = {"model": m.model, "messages": messages, "max_tokens": 4096}
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(f"{m.base_url}/messages", json=payload, headers=headers)
            resp.raise_for_status()
            return resp.json()["content"][0]["text"]

# Singleton for easy access
registry = ModelRegistry()
